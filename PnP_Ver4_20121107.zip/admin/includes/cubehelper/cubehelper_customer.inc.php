<?php

  function check_list($val, $result_list) {
     for ($i=0; $i < count($result_list); $i++) {
	//echo "id: ".$result_list[$i]['id']."<br>";
        if ( $result_list[$i]['reg_field_value'] == $val && $result_list[$i]['reg_field_id'] ) {
	   return true;
	 }
      }
      return false; 
  }
  
  function search_data($id, $result1)
  {
      for ( $k = 0; $k < count($result1); $k++ ) {
          if ( $result1[$k]['reg_field_id'] == $id ) {
             return $result1[$k]['reg_field_value'];
          }
      }
      return "";
  }
  
   //Check for new registration fields...
  $sql_reg = "SELECT * FROM ".$glob['dbprefix']."cubehelper_reg";
  $sql_reg_result = $db->select($sql_reg);
  for ($i=0; $i<count($sql_reg_result); $i++) {
      //Check if id is in the cubehelper_reg_x_customer..
       $sql = "SELECT * FROM ".$glob['dbprefix']."cubehelper_reg_x_customer c where reg_field_id = ".$sql_reg_result[$i]['id']." and customer_id = ".$db->mySQLSafe($_GET['edit']); 
       $check_result = $db->select($sql);
       if ( $check_result[0]['reg_field_id'] == "" ) {
          //Add a blank record into cubehelper_reg_x_customer
          //echo "Adding -> customer_id: ".$_GET['edit']." id: ".$sql_reg_result[$i]['id']."<br>";
          $record['customer_id'] = $db->mySQLSafe($_GET['edit']);
	  $record['reg_field_id'] = $sql_reg_result[$i]['id'];
          $record['reg_data_id'] = 0;
          $record['reg_field_value'] = $db->mySQLSafe("");
	  $insertIdx = $db->insert($glob['dbprefix']."cubehelper_reg_x_customer", $record);
	  unset($record);
       }
  }

  $sql = "SELECT * FROM ".$glob['dbprefix']."cubehelper_reg_x_customer where customer_id = ".$db->mySQLSafe($_GET['edit']); 
  //echo "Sql: ".$sql."<br>";
  $result_cust_data = $db->select($sql);
  
  $sql = "SELECT * FROM ".$glob['dbprefix']."cubehelper_reg";
  //echo "Inner Sql: ".$sql."<BR>";
  $result = $db->select($sql);
  $skip_processing = false;
  for ($i=0; $i<count($result); $i++) {
  	   
	  $field_type = $result[$i]['field_type'];
	  //echo "field_type: ".$field_type."<br>";
	  if ( $field_type != 4 ) {
	     $sData = $sData."<tr><td align='left' class='tdText'><strong>";
 	     $sData = $sData.$result[$i]['field_name'];
 	     $sData = $sData."</strong></td><td align='left'>";
 	  }
 	  $sField = $result[$i]['id']."qqq";
 	  
 	  //echo "field_type: ".$field_type."<br>";
 	   if ( $field_type > 2 ) {
  	  	  $result_data = $db->select("SELECT * FROM ".$glob['dbprefix']."cubehelper_reg_data where parent_id = ".$result[$i]['id']." order by sort_order asc");
                  $count_data = count($result_data);
  	   }
  	   if ( isset($_POST[$sField]) ) {
  	   	  $data_value = $_POST[$sField];
  	   } else {
  	   	  $data_value = search_data($result[$i]['id'], $result_cust_data);
  	   }
           switch ( $field_type ) {
 		     case 1:
 		   	  $sField = $sField."0";
 		      	  $sData = $sData."<input class=textbox type=text name='".$sField."' size='16' value='".$data_value."'>";
 		      	  break;
 		      case 2:
 		          $sField = $sField."0";
 		   	  $sData = $sData."<textarea class=textbox name='".$sField."' rows='5' cols='30'>".$data_value."</textarea>";
 		   	  break;
 		      case 3: //select list
 		   	  $sField = $sField."0";
 		   	  $sData = $sData."<select name='".$sField."'>";
   	  	          for ( $j = 0; $j < $count_data; $j++ ) {
   	  	       	    if ( $result_data[$j]['field_value'] == $data_value ) {
   	  	       	  	 $flag = " selected ";
   	  	       	     } else {
   	  	       	  	 $flag = "";
   	  	       	     }
   	  	  	    $sData = $sData."<option ".$flag." name='".$sField.$result_data[$j]['id']."'>".$result_data[$j]['field_value']."</option>";
   	  	           }
   	  	           $sData = $sData."</select>";
 		   	    break;
 		   	case 4: // check box
 		   	      if ( $skip_processing != $result[0]['field_name'] ) {
 		              $sData = $sData."<tr><td align='left' class='tdText'><strong>";
 	                      $sData = $sData.$result[0]['field_name'];
 	                      $sData = $sData."</strong></td><td align='left'>";
 		   	      $sData = $sData."<input type=hidden name='".$sField."0' value='".$sField."'>";
 		   	      for ( $j = 0; $j < $count_data; $j++ ) {
 		   	       	 $sf = $sField.$result_data[$j]['id'];
 		   	       	 
 		   	        		   	       	 
 		   	       	 if ( $result_data[$j]['field_value'] == $_POST[$sf] ||
 		   	       	       check_list($result_data[$j]['field_value'], $result_cust_data) ) {
 		   	       	 	  $flag = " checked ";
 		   	       	  } else {
 		   	       	 	  $flag = "";
 		   	       	  } 
 		   	          $sData = $sData."<input type='checkbox' ".$flag." name='".$sField.$result_data[$j]['id']."' value='".$result_data[$j]['field_value']."'>".$result_data[$j]['field_value']."&nbsp;";
      	                          $skip_processing = $result[$i]['field_name'];
     	                       }
     	                     }
 		   	     break;
 		   	  case 5: // radio box
 		   	       $sData = $sData."<input type=hidden name='".$sField."0' value='".$sField."'>";
 		   	       for ( $j = 0; $j < $count_data; $j++ ) {
 		   	       	 $sf = $sField.$result_data[0]['id'];
 		   	       	 if ( $result_data[$j]['field_value'] == $_POST[$sf] ||
 		   	       	   check_list($result_data[$j]['field_value'], $result_cust_data) ) {
 		   	       	   $flag = " checked ";
 		   	       	 } else {
 		   	       	   $flag = "";
 		   	       	 }
   	  	  	     $sData = $sData."<input type='radio' ".$flag." name='".$sField.$result_data[0]['id']."' value='".$result_data[$j]['field_value']."'>".$result_data[$j]['field_value']."&nbsp;";
     	                   }
 		   	   break;
 		   }
 		   if ( $result[0]['require_flag'] == 1 ) {
 		   	  $sData = $sData."&nbsp;";
 		   }
 		   $sData = $sData."</td></tr>";
 	 }
	 echo $sData;

?>