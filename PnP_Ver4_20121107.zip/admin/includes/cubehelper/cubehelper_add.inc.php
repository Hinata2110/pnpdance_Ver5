<?php
     $result = $db->select("SELECT * FROM ".$glob['dbprefix']."cubehelper_reg order by sort_order asc"); 
     for ($i=0; $i<count($result); $i++) {
 		   $sData = $sData."<tr><td align='left' class='tdText'><strong>";
 		   $sData = $sData.$result[$i]['field_name'];
 		   $sData = $sData."</strong></td><td align='left' colspan=4 class='tdText'>";
 		   $sField = $result[$i]['id']."qqq";
 		   $field_type = $result[$i]['field_type'];
 		   if ( $field_type > 2 ) {
  	  	     $result_data = $db->select("SELECT * FROM ".$glob['dbprefix']."cubehelper_reg_data where parent_id = ".$result[$i]['id']." order by sort_order asc");
                     $count_data = count($result_data);
                   }
                    switch ( $field_type ) {
 		   	  case 1:
 		   	      $sField = $sField."0";
 		      	  $sData = $sData."<input class=textbox type=text name='".$sField."' size='16' value='".$_POST[$sField]."'>";
 		      	  break;
 		      case 2:
 		          $sField = $sField."0";
 		   	   	  $sData = $sData."<textarea class=textbox name='".$sField."' rows='5' cols='30'>".$_POST[$sField]."</textarea>";
 		   	   	  break;
 		   	  case 3: //select list
 		   	       $sField = $sField."0";
 		   	       $sData = $sData."<select name='".$sField."'>";
   	  	       for ( $j = 0; $j < $count_data; $j++ ) {
   	  	       	  if ( $result_data[$j]['field_value'] == $_POST[$sField] ) {
   	  	       	  	 $flag = " selected ";
   	  	       	  } else {
   	  	       	  	 $flag = "";
   	  	       	  }
   	  	  	    $sData = $sData."<option ".$flag." name='".$sField.$result_data[$j]['id']."'>".$result_data[$j]['field_value']."</option>";
   	  	       }
   	  	       $sData = $sData."</select>";
 		   	      break;
 		   	  case 4: // check box
 		   	       $sData = $sData."<input type=hidden name='".$sField."0' value='".$sField."'>";
 		   	       for ( $j = 0; $j < $count_data; $j++ ) {
 		   	       	 $sf = $sField.$result_data[$j]['id'];
 		   	       	 if ( $result_data[$j]['field_value'] == $_POST[$sf] ) {
 		   	       	 	  $flag = " checked ";
 		   	       	 	} else {
 		   	       	 		$flag = "";
 		   	       	  } 
 		   	          $sData = $sData."<input type='checkbox' ".$flag." name='".$sField.$result_data[$j]['id']."' value='".$result_data[$j]['field_value']."'>".$result_data[$j]['field_value']."&nbsp;";
     	        }
 		   	      break;
 		   	  case 5: // radio box
 		   	       $sData = $sData."<input type=hidden name='".$sField."0' value='".$sField."'>";
 		   	       for ( $j = 0; $j < $count_data; $j++ ) {
 		   	       	 $sf = $sField.$result_data[0]['id'];
 		   	       	 if ( $result_data[$j]['field_value'] == $_POST[$sf] ) {
 		   	       	 	  $flag = " checked ";
 		   	       	 	} else {
 		   	       	 		$flag = "";
 		   	       	  }
   	  	  	     $sData = $sData."<input type='radio' ".$flag." name='".$sField.$result_data[0]['id']."' value='".$result_data[$j]['field_value']."'>".$result_data[$j]['field_value']."&nbsp;";
     	        }
 		   	      break;
 		   }
 		   if ( $result[$i]['require_flag'] == 1 ) {
 		   	  $sData = $sData."&nbsp;*";
 		   }
 		   $sData = $sData."</td></tr>";
 	
	 }
	 echo $sData;
?>
