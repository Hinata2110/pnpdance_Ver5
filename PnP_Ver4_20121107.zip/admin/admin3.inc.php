<?php
/*-----------------------------------------------------------------------------
 * Extended Product Options (Visual Product Options)
 *-----------------------------------------------------------------------------
 * admin3.inc.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood
 * Email:    cubecart@expandingbrain.com
 * Website:  http://cubecart.expandingbrain.com
 *
 * Date:     August 14, 2008
 * Updated:  January 25, 2009
 * Compatible with CubeCart Version:  4.x.x
 *-----------------------------------------------------------------------------
 * SOFTWARE LICENSE AGREEMENT:
 * You must own a valid license for this modification to use it on your
 * CubeCart� store. Licenses for this modification can be purchased from
 * Estelle Winterflood using the URL above. One license permits you to install
 * this modification on a single CubeCart installation only. This non-exclusive
 * license grants you certain rights to use the modification and is not an
 * agreement for sale of the modification or any portion of it. The
 * modification and accompanied documentation may not be sublicensed, sold,
 * leased, rented, lent, or given away to another person or entity. This
 * modification and accompanied documentation is the intellectual property of
 * Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */

if(!defined('CC_INI_SET')){ die("Access Denied"); }

$qepo_mod = fetchDbConfig("Quick_Edit_Product_Options");
$qepo_enabled = ($qepo_mod && $qepo_mod['status_cc4']);

$vpo_mod = fetchDbConfig("Extended_Product_Options");
$vpo_enabled = ($vpo_mod && $vpo_mod['status_cc4'] && isset($vpo_mod['use_thumbs']));

?>

  <tr>
    <td width="25%"><strong>After product is saved:</strong></td>
    <td>
<?php if ($qepo_enabled) { ?>
	<input type="radio" name="ems_redir" value="<?php echo urlencode($glob['adminFile'].'?_g=modules&module=3rdparty/Quick_Edit_Product_Options/quickOptions&prod_id=%s'); ?>" id="ems_redir_qepo" /> <label for="ems_redir_qepo">Assign product options</label><br/>
<?php } else { ?>
	<input type="radio" name="ems_redir" value="<?php echo urlencode($glob['adminFile'].'?_g=products/options&prodIdFilter=%s'); ?>" id="ems_redir_qepo" /> <label for="ems_redir_qepo">Assign product options</label><br/>
<?php } ?>
<?php if ($vpo_enabled) { ?>
	<input type="radio" name="ems_redir" value="<?php echo urlencode($glob['adminFile'].'?_g=modules&module=3rdparty/Extended_Product_Options/visualOptions&prod_id=%s'); ?>" id="ems_redir_vpo" /> <label for="ems_redir_vpo">Setup images for visual options</label><br/>
<?php } ?>
	<input type="radio" name="ems_redir" value="<?php echo urlencode($glob['adminFile'].'?_g=products/index&mode=new'); ?>" id="ems_redir_add" /> <label for="ems_redir_add">Add another product</label><br/>
	<input type="radio" name="ems_redir" value="<?php echo urlencode($glob['adminFile'].'?_g=products/index&edit=%s'); ?>" id="ems_redir_edit" /> <label for="ems_redir_edit">Continue editing this product</label><br/>
    </td>
  </tr>

