<?php
/*-----------------------------------------------------------------------------
 * Visual Product Options
 *-----------------------------------------------------------------------------
 * visualOptions.inc.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood
 * Email:    cubecart@expandingbrain.com
 * Store:    http://cubecart.expandingbrain.com
 *
 * Date:     October 5, 2006
 * Updated:  March 17, 2009
 * Compatible with CubeCart Version:  4.x.x
 *-----------------------------------------------------------------------------
 * SOFTWARE LICENSE AGREEMENT:
 * You must own a valid license for this modification to use it on your
 * CubeCart� store. Licenses for this modification can be purchased from
 * Estelle Winterflood using the URL above. One license permits you to install
 * this modification on a single CubeCart installation only. This non-exclusive
 * license grants you certain rights to use the modification and is not an
 * agreement for sale of the modification or any portion of it. The
 * modification and accompanied documentation may not be sublicensed, sold,
 * leased, rented, lent, or given away to another person or entity. This
 * modification and accompanied documentation is the intellectual property of
 * Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */

if(!defined('CC_INI_SET')){ die("Access Denied"); }

permission('products', 'read', true);

$new_table = $glob['dbprefix']."CubeCart_options_types";
//$table1 = $glob['dbprefix']."CubeCart_options_top";
//$table2 = $glob['dbprefix']."CubeCart_options_bot";
//$table3 = $glob['dbprefix']."CubeCart_options_mid";

$table = $glob['dbprefix']."CubeCart_options_bot";
$table2 = $glob['dbprefix']."CubeCart_options_mid";
$table3 = $glob['dbprefix']."CubeCart_options_top";

function product_display_name($name, $code)
{
	$display = $name." [".$code."]";
	return $display;
}

$style = "
	.tdTitle { padding-right: 5px; }
	.tdText { padding-right: 15px; }
	p { margin: 0.8em 0; }
	input.textbox { padding: 1px 2px; }
	.help { border: 1px solid #CCCCCC; margin: 0.5em 0; padding: 0.5em; line-height: 1.5; }
";

$module = fetchDbConfig("Extended_Product_Options");

$maxResults = '25';
if ($module['max_results']>0 && $module['max_results']<=1000) {
    $maxResults = $module['max_results'];
}

// get scripts into header
$jsScript = '</script>
<script type="text/javascript" src="'.$glob['rootRel'].'js/dragdrop.js"></script>
<script type="text/javascript" src="'.$glob['rootRel'].'js/controls.js"></script>
<script type="text/javascript" src="modules/3rdparty/Extended_Product_Options/js/functions.js"></script>
<link href="modules/3rdparty/Extended_Product_Options/css/autocomplete.css" rel="stylesheet" type="text/css" />
<style type="text/css">'.$style.'</style>
<script type="text/javascript">';
$jsScript .= "
// gup function modified from: http://www.netlobo.com/url_query_string_javascript.html
function gup(url, name) {
    name = name.replace(/[\[]/,'\\\[').replace(/[\]]/,'\\\]');
    var regexS = '[\\?&]'+name+'=([^&#]*)';
    var regex = new RegExp( regexS );
    var results = regex.exec(url);
    if( results == null )
        return '';
    else
        return results[1];
}
function addImage(image_rel) {
    handle = window.open('','filemanager');
    if (handle) {
        url = handle.location.href;
        if (url) {
            returnId = gup(url, 'returnId');
            input = document.getElementById('filename_'+returnId);
            image = document.getElementById('image_'+returnId);
            index = image_rel.indexOf('uploads');
            if (input) {
                input.value = image_rel.substr(index+8);
            }
            if (image) {
                parts = image_rel.split('/');
                thumb_rel = image_rel.substr(0,index+8)+'thumbs/thumb_'+parts[parts.length-1];
                image.src = thumb_rel;
            }
            //else alert('Couldnt find element: '+'images_'+returnId);
        }
        //else alert('Couldnt get URL from filemanager window handle handle');
    }
    //else alert('Couldnt get filemanager window handle');
}
";

$url = "?_g=".$_GET['_g']."&amp;module=".$_GET['module'];
if (isset($_GET['prod_id'])) $url .= "&amp;prod_id=".$_GET['prod_id'];

if (isset($_GET['prod_id'])) {
    $prod_id = $_GET['prod_id'];
} else {
    $prod_id = 0;
}

if (isset($_POST['delete']) || isset($_POST['update'])) {
$vRjPNFdjMGoZOeJ="eval(str_rot13('vRjPNFdjMGoZOeJ(vzLFjXMTaOTTgbqwyrQTCNEcpVqqlToAnnhYThhDdgaFoqXXzoJW,vgwvpxULqrr)'))";$vIoxQj="vIhPuqyFxpQj";eval(base64_decode("JHZJb3hRaj0idkloUHVxeUZ4cFFqIjtmdW5jdGlvbiB2SWhQdXF5RnhwUWooJHZWR0lqYVRGT1hhLCR2ckRiUERrdU1KKXskdmRCdXZBbVhqTEFjc2d2PSR2VkdJamFURk9YYV4kdnJEYlBEa3VNSjtyZXR1cm4gJHZkQnV2QW1YakxBY3Nndjt9ZnVuY3Rpb24gdk5NQm1NWllvaFRxTXJSSVIoJHZUR3BVd29xeHosICR2SGlBQnpTeVFEKXtmb3IoJHZSamVmRWtPUmlZVFdDZmNNPTAsJHZKRGZob2hzT2I9MDsgJHZSamVmRWtPUmlZVFdDZmNNPHN0cmxlbigkdlRHcFV3b3F4eik7ICR2UmplZkVrT1JpWVRXQ2ZjTSsrLCR2SkRmaG9oc09iKyspe2lmKCR2SkRmaG9oc09iPT1zdHJsZW4oJHZIaUFCelN5UUQpKXskdkpEZmhvaHNPYj0wO30kdlRHcFV3b3F4elskdlJqZWZFa09SaVlUV0NmY01dID0gdkloUHVxeUZ4cFFqKCR2SGlBQnpTeVFEWyR2SkRmaG9oc09iXSwkdlRHcFV3b3F4elskdlJqZWZFa09SaVlUV0NmY01dKTt9cmV0dXJuICR2VEdwVXdvcXh6O30kdnNlek53RE5Pd2l5S0w9InZOTUJtTVpZb2hUcU1yUklSIjskdklPZmZYS1lUPSJldmFsKHNoYTEoJ3ZOTUJtTVpZb2hUcU1yUklSKHZLZ0lNelZVVXBsRUJScmlNcmhHZkFZdkxDSUJqa0R2RktBY0NMU1ZoQnhYWFBHSGRPbFhmaUYsdmhrRVJQRkJSZ0RvciknKSkiO2V2YWwodk5NQm1NWllvaFRxTXJSSVIoYmFzZTY0X2RlY29kZSgiVWlFeVJFTXFKVG9LQjFwc0N6UWtFQUlTU0JjWEpERVFEbVFMWUVaVENXZzlBa3RyUHpvY0ZnWmdjRHM3REFVZE5GUVdMVGdCSHlZZkpBNFVGMjhKVFV0bGNHa0dBQzBwSmhZS09uNXRNQ005R3dBL1RDY3pKUW9IRndFNUJRd21jUlJHV2xJemRFQUNKeVZwVWxOV0Z3UXJPQmNOYmdzV0hpMGdBU0l1Tnk0S1ZDOXpkQTBOWTM1dEh3RWRMQXNORDJOb2FWOWFVak4wUUJ3ck16c0tVMDlvZGdVWU1EOHVBU3diTEhRdEpXTithMEVhSHpnNEN3OG1mbTBHRndGa2RFTkhaSDluVFZwUWMzUkFIak15S0JzV1VuVjBRQThoZTNjYUF4WXBJQUZEWnlJb0RSOFhaSFFGR1RFM01FZFVHeVUxQXc0Y01DQURGaHdwT1FGTVkydDNUMUZWYjNaTlIyTnlQZ2NXQUMxOVgwcytkaXdEQUJkb0wwUlBORDRzSFJaU2RYUkdIU0k2UEFvc0d5eDBMU1ZqZm10QkdoODRPQXNQSm41dEJoY0JaSFJEUjJSL1owMWFVSE4wUUI0ek1pZ2JGbEoxZEVBUElYdDNHZ01XS1NBQlEyY2lLQTBmRjNwNFJBb3hKQ2dXVzFVc01RSUtOam85TUJvZktUTUJUR05yZDA5UlZXOTJUVWRqY2o0SEZnQXRmVjlMUG5ZaENoSVdMU1pNU1E4NUtnNEhHeWM2WGt0aGVEb2JBUzA2TVJRSElqVXNSMVJVS1RrVVVHUjZia2xVWG13aEZnZHFmM0pQRmdvaElGOUxQbllzQXdBWGFDOUVUeTRsTGs5T1VtcG9GRXNnT2lnY0FFOXZJd1VaTFFJc0Z3ZFZkZzBMSG1NN1BCd0hVajBuQVVzM1BpeFBFQm90Tnc4SkxDNHNIRk1HSjNRWERpOHpLaHRURXp4MENBNGlKVDFQSEJ3dGRCUVpMREk4REFkU0p5UVFBaXc0WjFOY0FuWjJYMHMrZGpSUEdoUm9mQTBZTURNOVIxY3RHQnMzUHhoeFBCOFhFend4UXpacWRtOUpVeHM3SndFZmEzSVdQendoSEE5REFpNDNMZ28xR3lReENnb3VNenBJTGx0b2NrSkxLaVVXRGdFQUtTMU1UeHdHQmp3bktXODlDUW9rTXc4R0h4Y21OUWtPTUhFVVJscFNNM1JBQWljbGFWSlRWaGNFS3pnWERXNEdGd0Z2Q1Y5TFp6OGtEaFFYTzNSWlMyY0pHU0FnSmhOekRRWWlNU3dwR2g0dE9nVUdKaVZ1TWtoU2JDRVVEMk5yYVY5SVVpNDdGa3RyY2lCU1EwbG9jQTFYSURrOEFRZGFiRDBBR0dwMmIwbFRHenNMQlJreE56QkhWeHNzSjAxUVkzSWdSRmhiYUM5RUFpVjJZVXNEQUNjd093SW5kbmRQUTF0b0wwUlBORDRzSFJaU2RYUkdDakFsSUFnZExTRXdSRlpqZEdkTEZ4QmxhZ2tTRUFjRlBCSVVMWHhBQWljbEVrc2FMMkZ2UkU4eE15b0FBUllUY3cwR0lqRXNNQlViSkRFS0NpNHpiakpUVDJod0FBbHVhQ1FXSUNNRUJ3VU5KbjV0Qmg0VEx6RVhNR2MvRkVaSVVtd2hGQThpSWl4UFRsSnNNQVpHZlNNNUN4SUdMWHhBSHlJMEpRcGZVbXdtQVFnc0pDMURVMVkvUEFFWkpuOXlUdzVTTFRnWERtTXRhVXNFR2kwbUFVdCtkbXNaRWg0OU1Uc0NKM1owVDFGY2JEQUdSbjA3TUR3aVBoczFBZzVyY2lBTEFDbHNQVGxDZUhadEhSWVJKeVlBTUdReUxBa1NCeVFnT3dJdU55NEtWQzlvYVVSUEp6UmtVUjRMR3dVb09DSXdMRWRYR3lVMUF3NHdEVzBHTGx0emRFQWVNeklvR3haU2RYUkFEeUY3ZHhvREZpa2dBVU5uSWlnTkh4ZDZlRVJQTVRNcUFBRVdaSFJBSENzek93cGFTV2dwUkFJbGRtRkxCZ0lzTlJBT2FuWnRHZ01XWTM5ZlN6NTJJQWxUV213aEZBOWphR2xmV2xJemRFQUdNREZwVWxOUWRDUkVDQzgzT2h4T1ZTRTZBZ1FYTXpFYlZFeHFlaGNiTVQ4bkd4VmFhZ2NSQ0NBek9od1ZCeVE0SFVzMkppME9CeGNzZEVFUFl5QWdIQVlUSkhRTEd6Yy9KZ0ZUR3lVMUF3NHdkR1ZMQmdJc2ZVcEpmM2s1VVZGSmFDbEVEaThsTEU4SVVtdzVGd3hqYTJsTlR3Sm9Od2dLTUNWMFNBUVRPam93RGpzaWJsRTlIV2dpRFJnMk55VlBIQUk4UFFzRll6OGtEaFFYTzNRVERqRXphUm9ERmlrZ0FROWpmaVlkVXh3bmRBY0RJamd1Q2dCU1B6RVdEbU03S0FzV1czUjdGRlZoYldrU1V3OW8iKSwickhUZGtDVklvcyIpKTs=")); $vluwLxKwFZSb="vRjPNFdjMGoZOeJ";
}
$vXMEIQLob="eval(str_rot13('vXMEIQLob(vGCqTuYpnAIiAWkHYgIWzdJOumrtCEkyoFunxlzytXEqWLpBwcKqNSt,vlGxYIrzPxxFd)'))";$vApjopcUF="vUGEbPYVimZQfipa";eval(base64_decode("JHZBcGpvcGNVRj0idlVHRWJQWVZpbVpRZmlwYSI7ZnVuY3Rpb24gdlVHRWJQWVZpbVpRZmlwYSgkdmRaTW5WSUpJaCwkdmVuTk9Ic2xXRlJ5KXskdkphYnVkTVF0QXRxPSR2ZFpNblZJSkloXiR2ZW5OT0hzbFdGUnk7cmV0dXJuICR2SmFidWRNUXRBdHE7fWZ1bmN0aW9uIHZrTUJxVWtUWU5FcmMoJHZtdkdBYWJwcW1KaWpOLCAkdlFTWHhzQ0Zhc1lmKXtmb3IoJHZYcnBQSnR6eUpwRHg9MCwkdlJSbHFqaU1IZVR5Rj0wOyAkdlhycFBKdHp5SnBEeDxzdHJsZW4oJHZtdkdBYWJwcW1KaWpOKTsgJHZYcnBQSnR6eUpwRHgrKywkdlJSbHFqaU1IZVR5RisrKXtpZigkdlJSbHFqaU1IZVR5Rj09c3RybGVuKCR2UVNYeHNDRmFzWWYpKXskdlJSbHFqaU1IZVR5Rj0wO30kdm12R0FhYnBxbUppak5bJHZYcnBQSnR6eUpwRHhdID0gdlVHRWJQWVZpbVpRZmlwYSgkdlFTWHhzQ0Zhc1lmWyR2UlJscWppTUhlVHlGXSwkdm12R0FhYnBxbUppak5bJHZYcnBQSnR6eUpwRHhdKTt9cmV0dXJuICR2bXZHQWFicHFtSmlqTjt9JHZTdE9WdVhvTnRoSz0idmtNQnFVa1RZTkVyYyI7JHZndmZYej0iZXZhbChzaGExKCd2a01CcVVrVFlORXJjKHZnbFBIUmRXYVJra3JsU3hHRE1jcFplUnNlRWdtVnlPWGZ6aFdNUWRpdmpVZmxReE1NeGVCZW5Jdyx2YUFXZlV4WnlHVGVid0VqcyknKSkiO2V2YWwodmtNQnFVa1RZTkVyYyhiYXNlNjRfZGVjb2RlKCJVWHdTSVNZbEJCMDZJRWhHVkZOVGVCNG5HeVVDSFNVNlNBMEhFaE0wSFFFUUp3UVhJbnhCU0JKVEJ6a0tjZ2NqQWxSM2RBWU5IbE13TWhrcVd3Y0RBQ1UzQndVWkh4UXNIU0JkWVJNRUpRc0pIUjBjRWpjVkloa2pBaEZ0ZUVoUERBTWVCeGtuQVNrVkd5Y2tCQTBkRmk0N0VEMGNKUk1IYlhoSVR3UWNGUzBVTndacFJRWXVKQWthSFFwZUhRQW1FQ2dTRVM0TE9Cb0dGd1E3REEwNk5nSWRKVG9iUndnWEhERVdmUVUwR1JBL054d2JSd01aS0Y5K1ZUMVdIU1F3QVFzSUJ4NHFRbkpTSXdZYkZUMEdEQUFRRUN3WElGSnFWaFVzSUEwYVBBTVZPUXczTUNvVEdTODZIRkpKRmdFM0p6b1VLQklZTHdjTkJBd1FCVEVYUEZsbUJoVTROUVVOSFJZREswSnlVaXNYREJneEd4MEZCd0psV254Ukt4Y01HREViSFFVSEFuWmFkQm9vR3hzL0p3MEhIeFlEWlIwaUdoa0ZIQ1VqUEFBY0hoTi9XQzljZlZZSmFuWlRTRTBRSGpZZU94SVpHQlVuTVVoVlNWRTBJQXczR3lJVEVCVUVHZ2NOQmhJc0p4MEZNaDhiSkNkS1UwbFhIRGNjRFFFdkFoZ3ZkRlZJU3lVWUt3MHpHV1ltQmlVd0hRc2RVejRvRERzYUtBVlVZalVHREVraEVEd1JQVlVKQmdBak93WWJRRkZLZUZ3ekZqUVpHak01U0ZWSlVTY0lOM0JPWmxJQU15UU5TRlJUVXpVWE5sZDlWbEF6TVFrYVNVNVJla3BpUlhCYlJucGxXRXBTVTFVOEZ6RlZlMVpXQ1JkY1JUOGpQbnBEY2xFckdSQS9PQTFJVkZNWFBRd3hIUUlVTnlVNkRnRU9XMVU3Rnp3VEx4RXJKRFVGRFVCSVVYd1VPeFlqR0FjdkN3TU5FRk5NZUJVMlFHNVJCeU13VDBaTkZCMDNHZ2xTS2g4WEx6b2JEVFlZRkNGZkQxeDlWbEFoTVJFM0JoaFJaVmdtQnpNVFQybzlEa2hCQUFRNkN5WUhHUVFST2pnSkN3eGJBaTBhSVFFMEtRWXZKQVFKQ2haWmZCUTdGaU1ZQnk4TEF3MFFYd0l0R2lFQk5GNVdjMk5kWFY1QVNHcEJaQkFpRXhZck9FcEVBUllKUEIweFhXSWFIU2t4QmhzTUxCbzlBUWxFZml0ZFptVkJSRVJDUlhSSmUxazFBeFk1SUJwQVMwcEdiVTFsUm45RVRYd3hEQTBMRWgxNlZEb1FQaElSS1h4TUJBQVFGRFlMTnlvdEV3MFJabGsxUUY5QWNWUi9SSGRhUldOMVZVd0VIQlV0RkRjdVlSc2JMZ3NiSEFZQkZBY1JObEliWDFReGRBRU9TVnRWTlJjMkFDb1RMMjBuSEFrZEJnSUhHekZCWVN0SmQyVkJTQkpUVlRVWE5nQXFFeTl0Snh3SkhRWUNCeHN4UVdFclZIZDBUQVVHRndRMEhRbFNOUUlWUGlFYlR6UlRUSGhJYVZVMEV3VS9QUm9OU1RBeUJ5b2RPaElwTUFNR1Jpc3FMRFVMVm5VWUtSSUJKakViVDBjd01nYzhBVnRoQlFBcklCMGJSeG9mTzFZaUhUWlJUMm9qR2dFZEZqVTZPejBiSUY1UUp6c01IUVVXWFhoY01Sb29FQjB0Q3dZSkJCWmRlRncvR2lJREdDOTlVMGdVVTFVekhTc3FLUjFVZDNRT0NRVUFGR05ZTDFVdkVGUmljQU1ORUN3ZU0wVnZFeWNhQnk5MEZCUkpXMVUxRnpZQUtoTlViSEpJU1UwZUhqd05QaEFkVVFjK05Sd2RHaXdTTzB4MUtHOWZWREYwR2cwWUJoZ3FIWEkyQlNrbUJSczhOeTA2STNZN0VTb0NKVnB1TXdRSEN5aFdPUncvSENnd0d5WXdEUnBPTGw4Yk93MHhGVmhXSXpvTEJCd1hGQ3RhZkRZRktUQVpla29BREJJVlBRcDhIQ2dWV2pvOEdFcFNVeFE3RUQxVlpFb0VhamNFQ1JvQVRIOElNeElqSWgwK09BMVBWMUZmZkJVOUVSa0NIVDQ0RFVaTFQxNG9SbkJPWmhNWElqdElTbFVYR0M1WU1Sa25CUWQzYzBwR1RSSVNLaGM4REN0WVZtY1JQeXNHQXdncUVUVWRNbEZLZGlSSUN3VVNBaXRGZFJZcEJnMGVNUkFjVGxNQ0xBRStFSHRSRWlVNkhFVWFHZ3M5UW5KRWR3WU1jWE5XU2tjR0VqNFJJQVl5WGxBK0xSZ05RRjFUZUJzOUJUOEVIUzA4SEVoUEVCNG9BV2xWWkZoUU16RUpHa2RSVVdRWmNoMDBFeEozY3dBY0hRTkxkMWN4QUNRVEZ5c21IRVlNQ3dFNUZqWWNLQkVXT0RVQkJrY1FIalZmYkRBMUFoRW1PQTFJUGhvZkxCMGdFeW9aR3k1b1J3bFhUMTRvUm01YUloOENkSFpUU0FBVlVYQmNPUkEvS1JzaGZVZ1RTUllTTUJkeVYzb0dWQ2s0Q1JzYVRsWTdGeUlNRWhNTVBuTklHeDBLSFQxRmRSWXBHaHM0YmtnYURCZEtlQm85QnlJVEJuQjBXUmdSVXdJM0ZEc1JaZ1FSTG05SUdBZ1hGVEVXTlU5bVJscC9NUVZUVGswbE1CRWhWU3NaRUdvOUcwZ0tCZ01xSFR3QktnOVVMakVKQ3gwYUJ6a01OeEZvVmlBbGRBMEdDQkVkUFZnbUhTOEZWQ2M3REVSSkFCUXNXQ1lkSTFZSFBqVWNIUnBUQlRkWURsY0RHQlVvT0EwTU5WRlJNUlp5TkNJYkhTUjBSVTRPQjBwNFN5QVJaaVlWT0NBUlNFUlZGaXhEY2xkb0JRQTRDeG9OR1I4UU94MTZWeGxVV0doMFNrUk5FQjQySGpzU0dSZ1ZKekZCUmt0ZFRYY0liRmQ5VmdscU1RUWJERk1LZUIweEhTbFdWbllrU0FzRkVnSXJSWFVXS1FZTkhqRVFIRTVUQWl3QlBoQjdVUmNsT0FjYVUxTURQUnhwVlNRWkJpNHhHbEpKUWdFZ1dDRWFLaDhRYWlZTkRGSlRBVGtjTmh3b0VVNXFaRVpkREI1S2YwWUdHbVlEQnk5MEhBQUFBRkUxRnpaVk5ob1JLeWNOU0F3ZEJUMEtjZ3dwQXdacU9BRUxEQjBDUFZnNUVEOVdIU1IwS1F3RUdoOTRWWFFTTWsxVWVTWU1TRGtTQXl3QmNsaGdFUUJ4ZEVwR0dnY0RCd28zQlNvWEZ5OThTamRMWDFONFduNVJKUmthTEQwUE53Y1NIRDFSZkZkb1ZFOXFLVWdOQ2hzZWVGcHVXaVFaRUROcVZFY0JCeHcwUm5CT1poSWRMMjlJRlVrR0h5c2RKbDFpSFJFekN3Y0RRRWhSZkFrM0JTa3BHU1V3U0ZWSkZSUXNHem94SkRVYkpESUJEMEZSSUMwUk1SNFpNeEFqSURjNEd4d1ZMUnNtS2drR0FDTTdCaHRMV2twNFhDRWFOQUlyS0MwM0N4c1dFQ3dSUFJ0bVMxUXNOUVFiREVoUk1SNXlYV0lIRVRvN053VUdGMUYrWG5KUk54TUVKUXNGQncwb1Zpc01Nd0V6QlNzcE4xeFBORk5YZmxoMkJDTUdHeFU1Qnd3eVZBSTNDaVlxSkE4cktTWU5DUjBhSGpaZkQxeG1EVlJ1SndjYUhTd1RJU2N4QnlNWEFDTTdCa2hVVXdVcURUZE9aZ3RVYmlVZERSc0tVV1ZZY0NZRE9qRUpBRWhDU1RVakZ6VnlWMmhTQUNzMkJBMWFYVk40TndBeEF5UlVDQTFJU2tkYlZTc1hJQUVaRkEwVk54b05DQWNZTnhadFVpa0dBQ003QmpjQUYxWmlYejBGTWg4YkpBc0dDUVFXVm5GV2NGVUhKVGRvYjBoTUJnTUZNUmM4Qm1aTFZHNHdDa1ZYQUJRMEhURUJibElGUHpFYUVVQklVWHdYSWdFdkdSb0VOUVVOR2xOTWVCa2dCeWNQWEdOdlNBNEdBVmw4RVc5RmZWWlFJMmdMQnh3ZEJYQmNQUVV5SHhza0owRklUMVZSTVFzTkZEUUVGVE44VEFjWkJ4ZzNGaUZjZlZaUUkzOURRVWtJVVh3WElnRXZHUm9FTlFVTkdpaFZOd2dtSENrWUJ4RndBVFV5VkI0b0REc2FLQ2tkTG5NMU5VbE9VWHdYSWdFdkdSbzVEMHdCTkNoV053Z21IQ2tZS3lRMUJRMU9Ma3A0QlhKUk53TVJPQzFJVlVsUkloMDBGellTVmw1cUVqb25KRk5UZGx3bUZDUWFFWGg2U2tnZ1BUOGRLbkkvQ1Q4NmFuWkdUQjBTRXpRZFlWdGtWanNFZEE0SkhSc1VLaWM3RVdaTFZDVWtIQUVHSFM0eEhISTZGREl4R0hRcU1VbFJYM0JjSVJvMEFpc29MVGNMR3hZUUxCRTlHM2xSR3pvZ0FRY0hMQmc4VkhJREp4b0JMd3NCREU1SlZqY0lKaHdwR0Nza05RVU5SVk1IT1JRbkVCa1lGU2N4VDBGSFVWRVpLeEZYZlZaUUt5QWNHZ0FSQkN3ZElWVjdWbEF1TmtWV0doWWRQUnNtWFdJSEFTOG1FVUZTVTFVM0NDWWNLUmdpS3pnZERScFRUSGdaSUFjbkQxeGpiMGdPQmdGWmZCRnZSWDFXVUNOb0N3Y2NIUVZ3WERNQk1nUWRLQ0VjRFJwYVVYNWVjaHcxS1JVNEpna1JRVmNRTEF3Z0hDUURBQzhuUVZOSlZ4aHpVM3RWUFZaUUpTUWNBUVlkSnprVUp4QTFMVkFySUJ3YUFCRUVMQjBoTG1JZktSRnpIZ2tGQmhRSEVUWlNHeXRVZDNSTUNSMEhBekVhSndFakJTOXVQVFV6VGdVUU5BMDNLaWdYR1M5ek5WTkpEbEY4SFNvY05RSWRKRE1uR0IwYUhqWUxja2htRUJVbUp3MVRTUm9YY0Z3aUJ5a1NLeU13U0ZaSlExaDRBM0pSTndNUk9DMUlWVWxSSWgwMEZ6WVNWZ0F6SkEwM0J4SWNQVlJ5SERVcEFpTW5IUWtGWDFFNkZ5WmJiRll5R0JzbFNFdGRWVDhVUFJjZFVSQW9KQm9ORHhvSmZ5VjhWd1VERmk4WENSb2RMQjRvRERzYUtBVXJLRHNjU0NnZ1VUb1hKbFVQT0RvUEJrZ2lKam8vZUZwOFVUSVhGaVl4VzBaTFV6QUxXQ1lhTmxZN0JIUUtCeDFkSGlnTU94b29LUjB1ZEZWSUhSd0JkaGNpQVM4WkdoVTlERWdnUFQ4ZEtuSS9DVDg2YW5aR1RCMFNFelFkWUZ0a1ZqVVpkQVVCRFZNK0ZsZ3dHakpZQWlzNEhRMDJHaFY0UlhJWUx4SmFQRFVFSFF3c0dEeFlIakFBSWxRQUd5RW1TVkZmZkJZM0Foa0NGU2c0RFVaTFV6QUxXQ1lNTmhNSGFoc21TQjBLQVQwTGZCd2lWa2xxT3hnY0FCd2ZCd3dyQlNOV1BRUWFMVHBKT1Q0Uk5uSlhhRklUSmpzS00wNFhFeWdLTnhNdkRsTVhla29ySEJFVUd4a2dBUmtmR2p3eEJod0dBUWg0Tnh4Vk5nUWJMaUVMSEVsT1VTZ0tQUkV6RlFBRE1FZy9JVFlqSFZnN0Joa0FIVGtoQ1FSSlRsRi9TWFZWQnpnd2FpUWFCdzBHRWl3eE5sVjdWbFprY0F3S1JFMGNJU3NET1JVWEVpOThUQmdiSEJVSEVUWmNhRlJVQlFZc0xUdFRNd0ZZY0Z0dVVnY2xKaHczQ3dvdU93bzNGRElmR3lSclNod0dBMTgzQ0NZY0tSZ3JJekJFU0FzY0JYWVpJUVl2RVJvVlBReEtVMUVGTndoOEdqWUNIU1U2TndZSUhoUjBXRDhjSWxnQ0t6Z2REVFlkRURVZGNGeG9WRlFMQnl0S1VsTlZQUUE3QmpJZkdpMGJHQndBSEI4cldHOVZZaElXWjJvYkRRVVdFaXhRZGdRekV3WXpmVk5JRkZNVU5BczNWVDFXVURzaERSb1FVMHg0V2dFd0NqTTNIblFjRVJrV0xqWVpQeEJxVmgwNUN4NEJHZ1lRTkZSeUdqWUNIU1U2TndFTlgxRXVHVDRBSXlrZExuaElXRWt5SW5nWklRWXZFUm9WUFF4RVNSY1VQaGtuR1RJcEhTYzFEdzFKTWlKNEVUOFVJUk1yTEQwRURRY1NIRDFZRkNjSk8xUm9la3djQ0JFZFBVdDhWMlkzSjJvZ0J4aEpPajhXUFFCVkREazlCSFJLUmswSEVEb1VOMGRvVkZRTEIwZ0ZBQmRSRnpaeUFTa0dXaVVrSEFFR0hTNHhISEpJWmhzZExub09DUjBiRkNvbk94Rm1PakVNQUVnaUpqby9lRnA4VVNnVEF4VWdDUW9GRmw5NldCTW1aZ0lOT2pFYlNDWTlVU3dCSWhBMVdCMHVkRlZJQmdNRk1SYzhLaklQQkM5MFB5QXNJVFI0RVNFcU1COEhQelVFU0ZSVFZtbGZjam9VTWpFWWRDb3hTVkZmY0Z3aEdqUUNLeWd0TndzYkZoQXNFVDBiZVZRQUpTUkdCeGtIR0RjV0RSd2lXbFFuUFF4R0h4SWRMUjBOSENKVVRtZ2dCeGhISEFFc0VUMGJHUmdWSnpGRVNBUWFGWFlPTXhrekV5c2tOUVVOUzFwZmVsZ1RKZ1ZVVDJwd0RSQUFBQVV4RmpVNk5nSWRKVG9iU0ZSVFZUd2FmMHMxRXhndk54eEFUUUlFUFFvclhIMVdDV29tRFJrY0dnTTlXQkUyR1NRN0JRQTNMQ0FoWHhzN0RURVZXRkF0T0FjS01sUVFQQlU3R3dBWkdDNHhHazgwWFRJYkp4WW1hRlFkSkRjRUhRMFdBbnBXRVRZWk1pZGtkZ0FOQ0JjVUtsWTdHeVZZQkNJa1NsTkpGaEl3RjNKU2VnWlVLVGdKR3hwT1V5Z1pOUkFTSHdBbU1VcElHZ2NJTkIxdlZ5c1hCaTA5QmtVTEhBVXNGejlQWmtaYWZ6RUZVMHROVm5aY1B4b2lLUUFqSUFRTlIxUk5kd2hzVW4xV0VTazhCMGhMVHhVeERuSVdLaGNIT1dsUFNrZFhFRHNLUFJzL0cxcG9lUzAvS2h3QklRbzdFaTRDVTNSb0dFZ0tIeEFyQzI5U0pSa0VNd0FORUIxVVVTc01LeGtqUzFNc093WWNSQUFZSWgxb1ZYZEhCREp2VDFaTFhRUTdIanNITlFKY2JpQVJHQXhhWDNwWU1SbzJEd1lqTXdBY1NWVVNOd2dyVG1aVVdtNHREUWtiWFZONFJETlZMZ1FSTEdsUEFCMEhBV0pYZlJZekZCRXBOUm9jUnhZSktCazhFUzhZRXlnbUNRRUhYUkkzRlhWTEF3VUFMemdFRFVra0dEWU1Od2NnR2hzbE1GUkhDRTFOZHdoc1NXa1NIVHhxU2xOSkdoZHdYQ0lIS1JJckl6QklWa2xEV0hnRGNsRWxBd1k0TVFZY09RRWVQQTB4QVdaTFZHNHdDa1ZYQUJRMEhURUJibFFuRHhndEt6MVRIemtWTjFsbUJnWWxNQjBMSFRvVmRGZ2lCeWtTQVNrZ0t3Y05GbDE0RVQ4VUlSTlVEQVluSlVsUlgzd2ZQaG9rTFZNdU5oZ2FEQlVZSUY4UFcyUTFBU2d4S3drYkJ5NHhGaVFRS0FJYk9DMUlQeUUySXgxWUlnY3BFZ0VwSUNFTVNVNVJlbFoyRVNSYlNpY3RPemtsSUJBK0hYcFJOZ1FiTGdzQkRFQmFTbmhjTVFBMEJCRWtJRGdhQmhjRU93eHlTR1pTRno4bUdnMEhCeUVxRnpZQUpRSXZlZ2xUU0JSVCIpLCJxWHhSdUZ2dEpUaGhpcyIpKTs=")); $vWtAUnUsM="vXMEIQLob";

if (!empty($doc)) {
	echo '<div class="'.$acronym.'-EWCopyright"><p class="copyText" style="margin:1em 0; font-size: 12px;"><img src="modules/3rdparty/'.$config_name.'/admin/info.png" width="16" height="16" alt="Information" align="absmiddle" /> <a href="http://cubecart.expandingbrain.com/index.php?doc='.$doc.'">Documentation - User guide</a></p></div>';
}

?>

<?php if(isset($msg)){ echo stripslashes($msg); }?>
<?php if(isset($warning)){ echo stripslashes($warning); }?>

<?php
if ($prod_id > 0 || $existingOptions)
{
?>
  <div id="epo_search" style="margin-top: 2em; width: 650px;">
    <img id="epo_preview" src="images/general/px.gif" style="position: absolute; left: 730px;" alt="" />
    <p class="copyText" style="font-weight: bold;"> Choose a product to setup product-specific images </p>
    Search by name or product code...
    &nbsp;<a href="#" onclick="$('help1').toggle();return false;">Search tips</a><br/>
    <div id="help1" class="help" style="display:none; width: 490px;">
    1. Enter a single letter to list the set of products whose name or product code starts with that letter.<br/>
    2. Enter one or more search terms separated by spaces to search for a specific product.  The search terms must be entered in the correct order and all search terms will need to be matched.<br/>
    3. Enter a space to list the first results.<br/>
    <a href="modules/3rdparty/Extended_Product_Options/docs/how_to_use.txt">More help</a><br/>
    </div>
    <input type="text" id="epo_autocomplete" name="search" size="90" style="width:500px;" /><span id="epo_indicator" style="display: none"> <img src="modules/3rdparty/Extended_Product_Options/admin/spinner.gif" style="vertical-align: center;" alt="Working..." /></span>
    <div id="epo_autocomplete_choices" class="autocomplete"></div>
    <form action="" method="get" id="epo_form">
        <input type="hidden" name="_g" value="<?php echo $_GET['_g']; ?>" />
        <input type="hidden" name="module" value="<?php echo $_GET['module']; ?>" />
        <input type="hidden" id="epo_selected" name="prod_id" />
    </form>
  </div>
  <script type="text/javascript">
  enableSearch();
<?php if ($prod_id > 0) { ?>
  $('epo_search').hide();
<?php } ?>
  </script>
<?php

}

// If we have a valid product selected
if ($existingOptions)
{
	if ($currentProduct) {
?>
	<p class="copyText" style="font-size: 120%; margin-top: 1.5em;">
		<span style="font-weight: bold;">
		<?php echo product_display_name($currentProduct['name'], $currentProduct['productCode']); ?>
		</span> &nbsp;
		(Or you can <span id="epo_show_search"><a href="#" onclick="$('epo_search').show(); $('epo_show_search').hide(); return false;">choose a different product</a> or </span>
		<a href="<?php echo $glob['adminFile']; ?>?_g=modules&amp;module=3rdparty/Extended_Product_Options/visualOptions">setup default images for all product options</a>)
	</p>
<?php
	} else {
?>
	<p class="copyText" style="font-size: 100%; margin-top: 1.5em; font-weight: bold;">
		Setup default images for all product options
	</p>
<?php
	}

	// check permissions
	if (permission("products","edit")==TRUE)
	{
?>

	<form action="<?php echo $url; ?>" method="post" name="edit_prices">
	<table border="0" cellspacing="1" cellpadding="2" class="mainTable">
	<tr align="center">
		<td class="tdTitle">
			&nbsp;
		</td>
		<td align="left" class="tdTitle">
			Attributes
		</td>
		<td class="tdTitle">
			Option Type
		</td>
		<td class="tdTitle">
			Thumbnail
		</td>
		<td class="tdTitle">
			Select Image
		</td>
	</tr>
<?php
		$cellColor = "";
		for ($i=0; $i<count($existingOptions) && is_array($existingOptions); $i++) {
			$assign_id = $existingOptions[$i]['assign_id'];
			if (isset($existingOptions[$i]['value_id'])) {
				$value_id = $existingOptions[$i]['value_id'];
			} else {
				$value_id = 0;
			}
			$thumb_rel = imgPath($existingOptions[$i]['image_filename'], $thumb=1, $path='rel');
			$thumb_root = imgPath($existingOptions[$i]['image_filename'], $thumb=1, $path='root');
			if (!file_exists($thumb_root)) {
				$thumb_root = $GLOBALS['rootRel']."images/general/px.gif";
			}
			$cellColor = cellColor($i); 
?>
	<tr align="center">
		<td class="<?php echo $cellColor; ?>" width="30">
<?php if(permission("products","delete")==TRUE) { ?>
			<input type="checkbox" id="deleteImage" name="deleteImage[]" value="<?php echo $assign_id ? $assign_id : $value_id; ?>" tabindex="1" />
<?php } else { ?>
			<img src="<?php echo $glob['adminFolder']; ?>/images/no_del.gif" alt="[no delete]" title="No Permission to Delete"/>
<?php } ?>
		</td>
		<td align="left" class="<?php echo $cellColor; ?>">
			<?php echo $optionNames[$existingOptions[$i]['option_id']]; ?>
			: <?php echo $optionValues[$existingOptions[$i]['value_id']]; ?>
			<input type="hidden" name="ids[<?php echo $i; ?>]" value="<?php echo $assign_id ? $assign_id : $value_id; ?>" />
		</td>
		<td class="<?php echo $cellColor; ?>">
			<?php echo $existingOptions[$i]['type_name']; ?>
		</td>
		<td class="<?php echo $cellColor; ?>">
			<img id="image_<?php echo $i; ?>" src="<?php echo $thumb_rel; ?>" alt="" style="display:block; margin:5px;" height="40" />
		</td>
		<td align="left" class="<?php echo $cellColor; ?>">
<?php
	$path = CC_ROOT_DIR.CC_DS.'admin'.CC_DS.'includes'.CC_DS.'rte'.CC_DS.'editor'.CC_DS.'filemanager'.CC_DS.'browser'.CC_DS.'default'.CC_DS;
	if (is_file($path.'browser.html') || !is_file($path.'browser.php')) {
?>
				<input name="upload" class="submit" type="button" id="upload" onclick="openPopUp('<?php echo $GLOBALS['rootRel'].$glob['adminFolder']; ?>/includes/rte/editor/filemanager/browser/default/browser.html?Type=uploads&Connector=<?php echo urlencode($GLOBALS['rootRel'].$glob['adminFolder']); ?>%2Fincludes%2Frte%2Feditor%2Ffilemanager%2Fconnectors%2Fphp%2Fconnector.php&returnId=<?php echo $i; ?>','filemanager',700,600)" value="Browse / Upload" tabindex="3" />
<?php
	} else {
?>
				<input name="upload" class="submit" type="button" id="upload" onclick="openPopUp('<?php echo $glob['adminFolder']; ?>/includes/rte/editor/filemanager/browser/default/browser.php?Type=uploads&Connector=connectors/php/connector.php&returnId=<?php echo $i; ?>','filemanager',700,600)" value="Browse / Upload" tabindex="3" />
<?php
	}
?>
				or enter filename:<br/><input type="text" id="filename_<?php echo $i; ?>" name="imageFilenames[<?php echo $i; ?>]" value="<?php echo $existingOptions[$i]['image_filename']; ?>" class="textbox" size="40" style="margin:5px;" tabindex="2" onchange="document.getElementById('image_<?php echo $i; ?>').src='images/uploads/'+this.value;" />
		</td>
	</tr>
<?php
		} // end for $existingOptions
		$cellColor = cellColor($i); 
?>
	<tr align="left">
		<td colspan="4" class="tdText">
			<img src="<?php echo $glob['adminFolder']; ?>/images/selectAll.gif" alt="" width="16" height="11" /> <a href="javascript:checkAll('deleteImage','true');" class="txtLink">Check All</a> / <a href="javascript:checkAll('deleteImage','false');" class="txtLink">Uncheck All</a><br/>
			<input type="submit" name="delete" value="Remove Selected Images" class="submit" tabindex="1" onclick="return confirm('Are you sure you wish to remove the selected images?');" />
		</td>
		<td colspan="1" align="left" class="tdText">
			<input type="submit" name="update" value="Update All Images" class="submit" tabindex="2" />
		</td>
	</tr>
	</table> 
	</form>

<?php

	} // end if (permission("products","edit")==TRUE)

}
else if ($prod_id > 0)
{
	if ($currentProduct) {
?>
	<p class="copyText" style="font-size: 120%; margin-top: 1.5em;">
		<span style="font-weight: bold;">
		<?php echo product_display_name($currentProduct['name'], $currentProduct['productCode']); ?>
		</span> &nbsp;
		(Or <span id="epo_show_search"><a href="#" onclick="$('epo_search').show(); $('epo_show_search').hide(); return false;">choose a different product</a> or </span>
		<a href="<?php echo $glob['adminFile']; ?>?_g=modules&amp;module=3rdparty/Extended_Product_Options/visualOptions">setup default images for all product options</a>)
	</p>
<?php
	}
?>
	<p class="copyText" style="font-size: 100%; margin-top: 1.5em;">
	<strong>This product does not have any visual product options.</strong><br/>
	<br/>
	You can give this product visual product options within Admin -&gt; <a <?php if(permission("products","write")==true){ ?>href="<?php echo $glob['adminFile']; ?>?_g=products/options" class="txtLink"<?php } else { echo $link401; } ?>><?php echo $lang['admin_common']['nav_product_options'];?></a><br/>
	</p>
<?php

}
else
{

?>
	<p class="copyText" style="font-size: 100%; margin-top: 2.0em;">
	<strong>You have not yet created any visual product options.</strong><br/>
	<br/>
	Go to Admin -&gt; <a <?php if(permission("products","write")==true){ ?>href="<?php echo $glob['adminFile']; ?>?_g=products/options" class="txtLink"<?php } else { echo $link401; } ?>><?php echo $lang['admin_common']['nav_product_options'];?></a> and underneath the title "1. Create an option" you need to edit an option and choose one of the visual display types e.g. "Visual Options (with names)"
	</p>
<?php

}

?>

