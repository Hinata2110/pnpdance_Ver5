<?php
/*-----------------------------------------------------------------------------
 * Stock Levels for Product Options
 *-----------------------------------------------------------------------------
 * admin1.inc.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood
 * Email:    cubecart@expandingbrain.com
 * Store:    http://cubecart.expandingbrain.com
 *
 * Date:     October 22, 2006
 * Updated:  January 6, 2009
 * Compatible with CubeCart Version:  4.x.x
 *-----------------------------------------------------------------------------
 * SOFTWARE LICENSE AGREEMENT:
 * You must own a valid license for this modification to use it on your
 * CubeCart� store. Licenses for this modification can be purchased from
 * Estelle Winterflood using the URL above. One license permits you to install
 * this modification on a single CubeCart installation only. This non-exclusive
 * license grants you certain rights to use the modification and is not an
 * agreement for sale of the modification or any portion of it. The
 * modification and accompanied documentation may not be sublicensed, sold,
 * leased, rented, lent, or given away to another person or entity. This
 * modification and accompanied documentation is the intellectual property of
 * Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */

$stock_window_width = "650";
$stock_window_height = "600";

if(!defined('CC_INI_SET')){ die("Access Denied"); }

$stock_mod = fetchDbConfig("Stock_Levels_for_Product_Opts");
if ($stock_mod && $stock_mod['status_cc4'])
{
	require_once('modules'.CC_DS.'3rdparty'.CC_DS.'Stock_Levels_for_Product_Opts'.CC_DS.'classes'.CC_DS.'stockopt.inc.php');
	$stock = new stock($db, $results[$i]['productId']);
	if ($stock->hasSelectedStockOptions()) {
		echo "<br/><a ";
		if (permission("products","read")==TRUE){
			$link = $glob['adminFile'].'?_g=modules&amp;module=3rdparty/Stock_Levels_for_Product_Opts/stockOptions&amp;prod_id='.$results[$i]['productId'];
			echo 'href="'.$link.'" target="stockOptions" onClick="openPopUp(\''.$link.'\',\'stockOptions\','.$stock_window_width.','.$stock_window_height.',1); return false;" class="txtLink"';
		} else {
			echo $link401;
		}
		echo ">Stock Levels</a>\n";
	}
}

?>
