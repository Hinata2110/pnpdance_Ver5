<?php
/*
+--------------------------------------------------------------------------
|   CubeCart 4
|   ========================================
|	CubeCart is a registered trade mark of Devellion Limited
|   Copyright Devellion Limited 2006. All rights reserved.
|   Devellion Limited,
|   5 Bridge Street,
|   Bishops Stortford,
|   HERTFORDSHIRE.
|   CM23 2JU
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Email: info (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/v4-software-license
+--------------------------------------------------------------------------
|	printLabel.inc.php
|   ========================================
|	Custom Print Packing Slip by Erik Wiedeman
+--------------------------------------------------------------------------
*/

if (!defined('CC_INI_SET')) die("Access Denied");

$lang = getLang("admin".CC_DS."admin_orders.inc.php");
$lang = getLang("orders.inc.php");

require_once($glob['adminFolder'].CC_DS."includes".CC_DS."header.inc.php");

?>
<script type="text/JavaScript">
<!--
function popupform(myform, windowname)
{
if (! window.focus)return true;
window.open('', windowname, 'height=600,width=700,scrollbars=yes');
myform.target=windowname;
return true;
}
//-->

</script>


<p class="pageTitle">
  Custom Shipping Label
<?php if (isset($msg)) echo msg($msg); ?>
<p>
 
<script type="text/javascript">
function CopyDIV(to, from) {
  document.getElementById(to).innerHTML=document.getElementById(from).value;
}

function CopyAllDivs() {
	CopyDIV('name2', 'name');
	CopyDIV('companyName2', 'companyName');
	CopyDIV('address1a', 'address1');
	CopyDIV('address2a', 'address2');
	CopyDIV('town2', 'town');
	CopyDIV('state2', 'state');
	CopyDIV('postcode2', 'postcode');
	CopyDIV('postcode2', 'postcode');
	CopyDIV('country2', 'country');
	CopyDIV('phone2', 'phone');
}
</script> 


<form method="get" action="<?php echo $glob['adminFile']; ?>" name="customPrint" onsubmit="popupform(this, 'join')">
<input type="hidden" name="_g" value="settings/printLabel" />
<table width="100%" cellspacing="1" cellpadding="3" class="mainTable">
  <tr>
    <td colspan="2" class="tdTitle">Custom Shipping Label</td>
  	
  </tr>
  <tr>
    <td width="150px"><strong>Name: </strong></td>
    <td><input type="textbox" name="name" id="name" size="60" value="" onblur="CopyDIV('name2', this.id)" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>Company: </strong></td>
    <td><input type="textbox" name="companyName" id="companyName" size="60" value="" onblur="CopyDIV('companyName2', this.id)" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>Address Line 1:</strong></td>
    <td><input type="textbox" name="address1" id="address1" size="60" value="" onblur="CopyDIV('address1a', 'address1')" /></td>
  </tr>
  <td width="150px"><strong>Address Line 2:</strong></td>
    <td><input type="textbox" name="address2" id="address2" size="60" value="" onblur="CopyDIV('address2a', 'address2')" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>City/Town/Village: </strong></td>
    <td><input type="textbox" name="town" id="town" size="60" value="" onblur="CopyDIV('town2', 'town')" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>State/Province: </strong></td>
    <td><input type="textbox" name="state" id="state" size="60" value="" onblur="CopyDIV('state2', 'state')" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>Postal Code: </strong></td>
    <td><input type="textbox" name="postcode" id="postcode" size="60" value="" onblur="CopyDIV('postcode2', 'postcode')" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>Country: </strong></td>
    <td><input type="textbox" name="country" id="country" size="60" value="" onblur="CopyDIV('country2', 'country')" /></td>
  </tr>
  <tr>
    <td width="150px"><strong>Phone: </strong></td>
    <td><input type="textbox" name="phone" id="phone" size="60" value="" onblur="CopyDIV('phone2', 'phone')" /></td>
  </tr>
  <tr>
  	<td width="150px"><strong>What it will look like:</strong></td>
    <td>
       <div style="background:#FFF;width:425px;height:150px;">
    	<div style="float:left;"><img src="admin/images/customLabelExample-left.png" width="147" height="123" alt="Example of What it will look like." /></div>
        
        <div style="float:left;font-weight:bold;">
            <div style="font-size:9px;"><strong>Deliver To:</strong></div>
            <div id="name2"></div>
            <div id="companyName2"></div>
            <div id="address1a"></div>
            <div id="address2a"></div>
            <span id="town2"></span>
            <span id="state2"></span>
            <span id="postcode2"></span>
            <div id="country2"></div>
            <div id="phone2"></div>
        </div>
       </div>
    </td>
  </tr>
  
  <tr>
  	<td align="right"><input type="button" onclick="CopyAllDivs()" class="submit" value="Preview"></td>
    <td align="left"><input type="hidden" name="completed" value="1" /><input type="submit" class="submit" value="Print Label" /></td>
  </tr>
</table>

</form>


</table>