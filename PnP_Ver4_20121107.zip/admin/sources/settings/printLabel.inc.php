<?php
/*
+--------------------------------------------------------------------------
|   CubeCart 4
|   ========================================
|	CubeCart is a registered trade mark of Devellion Limited
|   Copyright Devellion Limited 2006. All rights reserved.
|   Devellion Limited,
|   5 Bridge Street,
|   Bishops Stortford,
|   HERTFORDSHIRE.
|   CM23 2JU
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Email: info (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/v4-software-license
+--------------------------------------------------------------------------
|	printLabel.inc.php
|   ========================================
|	Custom Print Packing Slip by Erik Wiedeman
+--------------------------------------------------------------------------
*/

if(!defined('CC_INI_SET')){ die("Access Denied"); }

include("language".CC_DS.$config['defaultLang'].CC_DS."config.php");

$lang = getLang("admin".CC_DS."admin_orders.inc.php");

$msg = false;

if ($_GET['completed']==1) {
	$msg .= "<p class='infoText'>Custom Label has been made/printed.</p>";
}
if (isset($msg)) msg($msg);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Print Shipping Label</title>
  <meta http-equiv="Content-Type" content="text/html; charset=<?php echo $charsetIso; ?>" />
  <link rel="stylesheet" href="<?php echo $GLOBALS['rootRel'].$glob['adminFolder'];?>/styles/print.css" />
  <style>
  	.
  </style>
</head>
<body onload="window.print();">

<div id="header" style="border:none;">
  <div id="printLabel">
  	<strong><?php echo $lang['admin']['orders_delivered_to'];?></strong>
	<br />
	<div style="font-size:25px;">
	<?php echo $_GET['name'];
	 ?><br />
	<?php if (!empty($_GET['companyName'])) echo $_GET['companyName'].'<br/>'; ?>
	<?php echo $_GET['address1']; ?><br />
	<?php
	if (!empty($_GET['address2'])) {
		echo $_GET['address2']."<br />";
	}
	if (!empty($_GET['town'])) {
		echo $_GET['town'].', '; 
	}
	?> 
	<?php echo $_GET['state']; ?>
	<?php echo $_GET['postcode']; ?><br />
	<?php echo $_GET['country']; ?><br />
    <?php echo $_GET['phone']; ?>
	</div>
	
  </div>
  <div id="storeLabel">
  	<img src="<?php echo $glob['rootRel']; ?>images/getLogo.php?skin=<?php echo $config['skinDir']; ?>" width="200" alt="" /><br />
    <?php echo $lang['admin']['orders_return_address'];?>
    <br /><span class="senderSize"><?php echo $config['storeAddress']; ?></span>
  </div>
</div>



</body>
</html>
