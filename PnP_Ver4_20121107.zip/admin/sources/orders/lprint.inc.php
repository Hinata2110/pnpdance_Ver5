<?php
/*
+--------------------------------------------------------------------------
|   CubeCart v4.0.0
|   ========================================
|	CubeCart is a registered trade mark of Devellion Limited
|   Copyright Devellion Limited 2006. All rights reserved.
|   Devellion Limited,
|   5 Bridge Street,
|   Bishops Stortford,
|   HERTFORDSHIRE.
|   CM23 2JU
|   UNITED KINGDOM
|   http://www.devellion.com
|	UK Private Limited Company No. 5323904
|   ========================================
|   Web: http://www.cubecart.com
|   Email: info (at) cubecart (dot) com
|	License Type: CubeCart is NOT Open Source Software and Limitations Apply 
|   Licence Info: http://www.cubecart.com/site/faq/license.php
+--------------------------------------------------------------------------
|	print.inc.php
|   ========================================
|	Print Packing Slip	
+--------------------------------------------------------------------------
*/

if(!defined('CC_INI_SET')){ die("Access Denied"); }

$lang = getLang("admin".CC_DS."admin_orders.inc.php");

require($glob['adminFolder'].CC_DS."includes".CC_DS."currencyVars.inc.php");

permission("orders","read", true);

$result = $db->select("SELECT * FROM ".$glob['dbprefix']."CubeCart_order_sum INNER JOIN ".$glob['dbprefix']."CubeCart_customer ON ".$glob['dbprefix']."CubeCart_order_sum.customer_id = ".$glob['dbprefix']."CubeCart_customer.customer_id WHERE ".$glob['dbprefix']."CubeCart_order_sum.cart_order_id = ".$db->mySQLSafe($_GET['cart_order_id']));

// start: Flexible Taxes, by Estelle Winterflood
// count the number of additional taxes
$num_taxes = 1;
$config_tax_mod = fetchDbConfig("Multiple_Tax_Mod");
if ($config_tax_mod['status'])
{
	for ($i=1; $i<3; $i++)
	{
		if ($result[0]['tax'.($i+1).'_disp'] != "") {
			$num_taxes++;
		}
	}

	// tax registration number(s)
	$reg_number = $db->select("SELECT reg_number FROM ".$glob['dbprefix']."CubeCart_tax_details;");
	$reg_string = "";
	for ($i=0; is_array($reg_number) && $i<count($reg_number); $i++)
	{
		if ($reg_number[$i]['reg_number']!="") {
			$reg_string .= $reg_number[$i]['reg_number']."<br/>";
		}
	}
}
// end: Flexible Taxes

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title><?php echo sprintf($lang['admin']['orders_order_invoice'],$_GET['cart_order_id']);?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <link rel="stylesheet" href="<?php echo $GLOBALS['rootRel'].$glob['adminFolder'];?>/styles/print.css" />
  <SCRIPT LANGUAGE="JavaScript">

function ClipBoard() 
{
holdtext.innerText = copytext.innerText;
Copied = holdtext.createTextRange();
Copied.execCommand("RemoveFormat");
Copied.execCommand("Copy");
}

</SCRIPT>
</head>
<body onload="ClipBoard();">

<div id="header">
<div id="printLabel">
  <span id="copytext"><div>
	<?php echo $result[0]['name_d']; ?><br />
	<?php echo $result[0]['add_1_d']; ?>,<br />
	<?php
	if (!empty($result[0]['companyName'])) echo $result[0]['add_1_d'].'<br/>';
	if (!empty($result[0]['add_2_d'])) {
		echo $result[0]['add_2_d'].",<br />";
	}
	echo $result[0]['town_d']; ?>,<br />
	<?php echo $result[0]['county_d']; ?><br />
	<?php echo $result[0]['postcode_d']; ?><br />
	<?php echo $result[0]['country_d']; ?><br>
  <?php echo '---------------'; ?><br/>
<?php
$results = $db->select("SELECT * FROM ".$glob['dbprefix']."CubeCart_order_inv WHERE cart_order_id = ".$db->mySQLSafe($_GET['cart_order_id']));
for ($i=0; $i<count($results);$i++){
?>
  <?php
  echo sprintf('%d x %s (%s)', $results[$i]['quantity'], $results[$i]['name'], $results[$i]['productCode']);
  if (!empty($results[$i]['product_options'])) {
  	echo sprintf(' &raquo; <span class="options"><br />%s</span>', nl2br($results[$i]['product_options']));
  }
  ?>
</div></div></div>
</span>
<?php } ?>
<TEXTAREA ID="holdtext" STYLE="display:none;">
</TEXTAREA>

</body>
</html>
