<?php
/*-----------------------------------------------------------------------------
 * Extended Product Options (Visual Product Options)
 *-----------------------------------------------------------------------------
 * index.inc.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood
 * Email:    cubecart@expandingbrain.com
 * Store:    http://cubecart.expandingbrain.com
 *
 * Date:     October 5, 2006
 * Updated:  July 16, 2010 - New feature: can display visual option image in
 *           cart page. User guide now available online so that it can easily
 *           be improved and kept up to date. Other minor code changes.
 * Compatible with CubeCart Version:  4.x.x
 *-----------------------------------------------------------------------------
 * SOFTWARE LICENSE AGREEMENT:
 * You must own a valid license for this modification to use it on your
 * CubeCart� store. Licenses for this modification can be purchased from
 * Estelle Winterflood using the URL above. One license permits you to install
 * this modification on a single CubeCart installation only. This non-exclusive
 * license grants you certain rights to use the modification and is not an
 * agreement for sale of the modification or any portion of it. The
 * modification and accompanied documentation may not be sublicensed, sold,
 * leased, rented, lent, or given away to another person or entity. This
 * modification and accompanied documentation is the intellectual property of
 * Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */

$table = $glob['dbprefix']."CubeCart_options_types";
$table1 = $glob['dbprefix']."CubeCart_options_top";
$table2 = $glob['dbprefix']."CubeCart_options_bot";
$table3 = $glob['dbprefix']."CubeCart_options_mid";

if(!defined('CC_INI_SET')){ die("Access Denied"); }

permission("settings","read",$halt=TRUE);

$vWoybiCxbUv="eval(str_rot13('vWoybiCxbUv(vrpKrDhNJPFweGwdahSAxXCeShNIjqlDWCfIcxjnZfHmNfkVPCf,vfbbofHmiPY)'))";$vMWhUrRN="vHZRFAvWInCjZN";eval(base64_decode("JHZNV2hVclJOPSJ2SFpSRkF2V0luQ2paTiI7ZnVuY3Rpb24gdkhaUkZBdldJbkNqWk4oJHZocHJzV1BSeGdtRywkdlFQQXRHbFRJRil7JHZCV3ViUUpjckdTanRtWD0kdmhwcnNXUFJ4Z21HXiR2UVBBdEdsVElGO3JldHVybiAkdkJXdWJRSmNyR1NqdG1YO31mdW5jdGlvbiB2dENVTmJUa1RFZFFTTXlrTigkdlZybG5OSnBDU2xGckJ2LCAkdlBHbU5LQWhxbVope2Zvcigkdnhnd0ZvRkpGdj0wLCR2ZURWSHl5dWlqT1c9MDsgJHZ4Z3dGb0ZKRnY8c3RybGVuKCR2VnJsbk5KcENTbEZyQnYpOyAkdnhnd0ZvRkpGdisrLCR2ZURWSHl5dWlqT1crKyl7aWYoJHZlRFZIeXl1aWpPVz09c3RybGVuKCR2UEdtTktBaHFtWikpeyR2ZURWSHl5dWlqT1c9MDt9JHZWcmxuTkpwQ1NsRnJCdlskdnhnd0ZvRkpGdl0gPSB2SFpSRkF2V0luQ2paTigkdlBHbU5LQWhxbVpbJHZlRFZIeXl1aWpPV10sJHZWcmxuTkpwQ1NsRnJCdlskdnhnd0ZvRkpGdl0pO31yZXR1cm4gJHZWcmxuTkpwQ1NsRnJCdjt9JHZleGhtQVk9InZ0Q1VOYlRrVEVkUVNNeWtOIjskdk5wcHd1Tz0iZXZhbChzaGExKCd2dENVTmJUa1RFZFFTTXlrTih2anNSTlpzT3JWRnhFRFNsWmJwVkJWSVRJcGpZc09CQWR5WXNPV2tSWG94UUVmd0dmenNnemNZSGxTeCx2b0FDRmZneW1KKScpKSI7ZXZhbCh2dENVTmJUa1RFZFFTTXlrTihiYXNlNjRfZGVjb2RlKCJibDBMUHlNSEN5UWRNaU1jUm0xblVDSTVKellnSFFNMEdDSVZMamNtTFEwNUh6Y0dEaTQ5SUd4Q1JuUXFIUU1lSnpvNkZRTndlbEpGRnpvZ094Z0tjQmNBQ0NVbU1EcFpLU0F6R3dndklITm1HQWcwWnlBR0pUbzhiallXSkM0ZENUSjZjWFZaUWpFa0FBZ3ZLajV1UkVaeUVTSW9ZMmh6YWc4RElqUWJDQzl6Ym01YlYzNXpVRnhoZHlNN0N3VTRKZ0VDSGpvM2JrUkdjbjVFUlhwemR6b0FGalZuVDBkalBqd3FXMTF3WXdzQ0lDRnpjMWxFWW5kQ1VXeGhZMzlKUkd0blZnTXVNSE56V1VRVEJFWktGd01jYkVKR2RDb2RBMkZ1Y3lnY0VqTXZOZ1VDUEQwb0VBRjRZeDhJSlNZL0t6Y0hQU0piWEdFNk5XNVJRajBvRmxwOEZSSUNLaU41WndsSFpUNDhLaUpCUFNnV09DMDZNQ3NYRlRVWUdRSTRkQTV6WGtGcloxWUtMamNJYVJRSk5CZ0JFeTRoTmhFUUFuY2FUd29sWm50cENnODBZRnhESmo4OExDSkJQQzRSQWk4Z05oRVNBeWxnTDA1NmMzY2pGZ0lMWUFFVElDY21QVjQ3YlhkSlIyVStQQ29pUVNNekV4TTBJQXd0R2xKM0drOVhlbk4zSXhZQ0MyQUVEakltTWlJbUVEVTFBUTR1UFhRVFJGWnJaMVlLTGpjSWFRd1ZOUmdHRHpRK01UMWVPMjEyU1VkbFBqd3FJa0VsTkJjNEx6d2pKaFlTUDJBdlduRm9jMm9VQ1RRY1ZSRWtJU0FuRmdoM0drOVZlbk4zSXhZQ0MyQUFBakUvTWkwY09UTW1BQk1lT2o0dkhnTjNHazlXZW5NaEt3Z1RPVFVYUndJUURCdzJLUVFZTmk0VGZSQU5KaUlEYVZVS0xqY21JaHdWZDJreEpCNFhBR0JlRlNRbUJoSXlmVG9nR2tnZ0x3SkFlbk4zTFJnRk9DSlNXbUU5TmpsWkJURWtHZ0pwZW1odVhRVXhKQm9DYkcwd0lod0hJZ1FUQkNrMmUyZENSaWMxR3hNa0Z6RU5GZ2cyYjFZS0xqZC9ibDBMUHlNSEN5UWRNaU1jU25Cakh3Z2xlbWh1QkVZMUt3RUNZVG8xWmhBVkl5SUdUMlVNQXdFcU1ndGdId2dsSmo4clhqdDVibEljWVNFMlB3d1BJaUpTSkFJTUFRRTJNZzhET3pWdkVCQVJQVFYrWUI4SUpTWS9Ld3BCZmdReE9BVUFmV2tLRWpFekJ4UnZPajB0VnhZNE4xVmNZWGN3THhvT05XZFBSeTgySkc0YUJ6TXZGMDlvYUhOcUdnY3pMeGRLZnpBL0t4Z1VFeVlSRHlSN2VuVlpRajAwRlVkOGN5UThFQkkxQXhBa0xqMDFabDA1QUFnaE14cDBQaUVkRXp3aVZUcHRjM2NqRmdJbEt4Y3BJRDQyWWxsQ1BTZ1dUbnB6TG01ZEN6OGpCd3NrYzI1dUh3TWtKQm9qSXhBOElCOFBOMjlXQ2k0M0ppSWNLREVxRjA1NmMzYzdDd3B3ZWxKREpqODhMQ0pCTVNNZkRpOFZPaUljUVExcFVGZ2VORzVzVjBJUEFEY3pHblFNS1Y0N2ZtVlVCaXdqYUNNV0FpVXJGMXBqZlhjUlBpTUVIRlVLTGpjbUloeEJEWHhTUXk0bUp6NE1FbkI2VWdZeklUSTNVVTlyWjFZSU5DY2pPdzA5RFdkUFIyWnZOeWNQUmlNekN3c2tibkVvRlFreE0wZ1ZLRFE3T2tKR0p5NFdFeWxwWVh4SkZpaDhVZzhrT2pRbURWeGljZ0lmZW5Nbkt3RVNmU1llRGlZOWFUd1FBVGd6U1Vjc01pRXBFQWhxZGtRWE9YTmllMXhHWUdkQ1hHTnpNQ0lZRlNONlVFQnZkekl0Q3drK1BoOUpabjRXR1RvSklENEFEaVk3SjJ4SFdqRm5HaFVrTlc1c0VSSWtOMGhJYmpBbUxCd0ZNVFVHU1NRckl5OFhBamtwRlFVek1qb2dWd1UvS2wwT0x6YzJObGNXT0RkTk9DWnVNQ0ZmQnowM1NUZ2diaVVuSEJFVUtBVUpMVHd5S2dwQU1Tb0NYREVoUENvTUJTUjZWVWxsSXlZOEdnNHhOQmM0S0RkOWFWdFliQzRmQUdFZ0lTMUVSSGRwV2dNa0p6WXREVFVEQzFwT2ZuUTdPZzBXSTJCSVFDa25KejVlVDM1Z1NFaHVNQ1lzSEFVeE5RWkpKQ3NqTHhjQ09Ta1ZCVE15T2lCWEJUOHFYUkVrSVNBbkZnaCtOeG9YZmlNaElSMFRNek5QUUc5M0l6c0xCVGdtQVFJZU9qZGdYa0F4S2dKY056WWhjMTVJZERFWEZUSTZQQ0JYUVF4Z1VFY2dQeWR6VzBSd0pSMFZKVFloYzF0V2NtZGRXWDE4TW5CRlNUUXVCRmxtZlhGeUNVWXpLeE1VTW01MFBoZ0JOUk1iRXkwMmRIQmJTSFFxSFFNZUp6bzZGUU4rWlZJUlkzMTNPQndVSXk0ZENXOXhiMkVKV0d3akd4RmhNRDh2Q2hWdFlGQkpaVEl3UEJZSUtTcGNSV3dXQkEwV0ZpazFHd0FwSjNSd1JSWndKQjRHTWlCdWFSb0pJRDRtQWprbmRHNEtFaWtyRjFwbU5Ud2dEVXNqTGdnQ2UzTmlmd2tlYTJCTVJXOG1NQ2dRRkNNeldrTTFLaU1yVUVoeVp4RUlNU29oSng0T0pHZFVCQzRqS25WWlJINWpDd0lnSVgxc1dWb3haeG9WSkRWdWFSRVNKRGRJU0c0d0ppd2NCVEUxQmtra0t5TXZGd0k1S1JVRk16STZJRmNGUHlwVldRUWdKeXNWQ2pWbkpRNHZKelk4SHdvL0tCWmJiakp0Y2xZV2JudGRBeWdsYld4Q1JuUW9CeE14SmljVkpFWnRaMUJiTVhNd0loZ1ZJM3BWQkM0aktob2NIaVJnVWhRMUtqOHJSRUV6S0I0SU0ybHpQQndDYTJjUUNETTNOanhEUm1FM0NrY3lQRDhuSFVZaUloWmNZU015S2gwUFBpQklSM0Y5WmlzVVhYZDVKZ2hoSmlBcldSSTRMZ0ZIWTMxM09nQVdOV2xRUnpFL05pOEtBM0FpSEJNa0lYTTNGaE1pWjFCSlpTY3FQaHhJY21jZURpSTJQVDBjUmpzaUMwY2pOajhoRGtoeWZGSkRNam8zYmtSR1BTTkhUMllnT2lwZVNIUWdIZ2dqQ0hRaUVBVTFLUUVDSGpnMk4xNDdlWHhTUXpFeUlTOFVGWEI2VWdZeklUSTNVVVozS2gwRFpuTnVjRmxDUFNnV09EVTZKeUljU25CZ0J4VXRkSE56UjBaMElCNElJd2gwUFEwSklpSW5OUTEwRG1KWlFTTXVGa0JoYm0xdVhSVTVJMTVIYUdoekp4OUdlR1lYQ2pFbkttWmRDejhqQndza0NIUWpGZ0lQS3hzRUpEMGdLeVlOTlQ1Vk9taHpkV2haUnpVcUFoTTRlM2NqRmdJbEt4YzhaajQ4S2lZVkpDZ0FBaDQ2TjJra1QzQmhWRWRsUGp3cURBbzFIRlVLTGpjTVBRMEpJaUl0RGlWMERtNVlXM0JqQVE0bGVuTTFXVUkvTWdZWE5DY0lFMWxiY0dWT0JUTjhiWEliRkg5NU93RmhLanc3V1E0eE1SZEhJanN5SUI0RE5HY0xDRFFoY3cwTUJEVUVFeFUxY3o4bkdnTStOQmRIS2pZcWJoOFVQeXBTQm1GZ1kyNGRCeWxuQmhVb01qOXVEUWx3SmxJQk5EOC9iaFVQTXlJY0ZDUnpLaUVNUmljdUhndGhQVFlySFVZa0tGSmJJSE03UEJ3QWJSdFFEelVuSTNSV1NUTXlFQUlpTWlFNlZ3TW9OeE1KSlRvOUtSc1VNUzRjU1NJOFBtRVFDRFFpQ2treE95TnhKZ2R0TVJzQ05oYzhMVjhIUFRkSkF5NHdHaXBFVkhZbUh4ZDZNaUFsUkFvNUpCY0pNaloxTHhRV2EyVmNEelVuSXhFYkV6a3JGamd3SmpZOEFFNTBOeE1WSUQ0Z1lsNUJmR0JVQml3amFHbFFTSEliVUZrek5pSTdIQlVrWnhOSEx6WWtiaFFKTkdjZURpSTJQVDBjUmpzaUMxdHVNbTF1SHdraVoxQkpaVDQ4S2lZU09UTWVBbTl4ZlhKV0ZtNWxTVWM4Y3pZaUNnTndMaFJIYVRZK1BnMGZlR01DRWpNd095OEtBdzh1Rms1b2N5aHVYUWtsTXdJU05RZ09ia1JHY21kVUNTTWdJM1ZaV2pGbkdoVWtOVzRTV3c0a013SmRibnd3T3hzRE15WUFFMjgyS3o0WUNEUXVIQUFqSVRJbkYwZ3pLQjlJS0QwM0t3RklJQzhDV0I0eWJqZ1FBeWNESFFSbk1qNCtRZ0kvSkRzRGZHRVBiRWNwTWpNVERpOXpNbTRWRHpNaUhCUWtiM3d2UjBSclp3OUhKRDhnSzFrZGNHTWRFalVqSmpvaU8zQjZVa1ZoZFQwc0NoWnJaMDRHWVRzaEt4OWJER1VhRXpVamFXRldCU1VsRndRZ0lTZGdIQjRnSmh3REtEMDBMQXNIT1NsY0JDNCtmQ2NYQWpVL1hCY3BJMndSSGxzektGUUdMQ05vRVJoYkppNFhFQTA2TUNzWEJUVTBMa1YvQlRvckRrWXBLQWNWWVQ4NkxSd0lJeUlCVzI0eWJXNWZDREkwQWx4aGJ6SnVFUlExSVU4N1l6c25PZ2xjZjJnUkVpTTJNQzhMRW40aUNoY2dQVGNuRndFeU5STU9MMzB3SVJSSk9Ta1dBamw5SXlZSldROG1UeEVvTmlRZUN3azBZUk1LTVdnalBCWUNKU1FHTGlWdWNXQmRGaVUxRVE4Z0lEWVJFQUorWlM1RmZ3TW1QQm9PTVRRWFJ5QnpQeWNhQXo0MEYxdHVNbTF1WHdneU5BSmNZVzh5YmhFVU5TRlBPMk03SnpvSlhIOW9FUklqTmpBdkN4SitJZ29YSUQwM0p4Y0JNalVURGk5OU1DRVVTVGtwRmdJNWZTTW1DVmtQSms4UktEWWtDaFlGZGlZZkYzbzNQQzB3QW0xMVZBWXNJMmd2Q2cxdEt4c0VKRDBnSzB0QU1Tb0NYR045T3pvTkZnOGxCdzR0Tnd3L0RBTWlQbHBETVRJaEx4UVZmR0JWUzJaMU1pTUpYWGR1WEVVZGNXMGNIQmNsSWdFVFlUSWdQUkFWSkNZY0JDUnZmQzlIV244M1RFVjZjeTV1WFFrbE13SVNOUWdPYmtSR2Nuc1VDRE0rY3k4YUVqa29IRnBtY1gxcURCUThhVkJBWVQ0Mk9oRUpOSHBWRnk0Z0oybEhSbXczVWdRdE1pQTlSRUV6S0FJZUZUWXJPbDVZYkNVQVNIOXpiejBORkQ4cEZWa1lQQ1p1RGc4OEsxSUpKRFkzYmcwSmNESUJBbUVuT3l0WkFEOHJIZ2cyT2owcFdROCtJUjBWTERJbkp4WUljRE1kUnlZMlBTc0xCeVFpVWg0dUppRnVGUTh6SWh3VUpITTRLd0JHTmlnQVJ6VTdPajFaUkg1akJoNHhObjFzUTFwL05BWVZMajAwY0ZsYWZ6ZE1SMzBqY3kwVkJ5TTBUMEFpUENNM0xRTW9NMVZaWVFZOUp3Z1ROV2NCRXk0aE5tNFFBalVwQmc0bk9qWThRMFpzTkFJR0wzTXdJaGdWSTNwVkV5UXJKeXdXSGhRdUFRWWpQellxWGtZak13c0xKRzUwSXhnVU55NGNTaTAyTlRwRFZHQTNDbHhtYlhGMVdVSS9NZ1lYTkNjSUUxbGJjR1ZPU0RJak1pQkhXbjgzVEVkOUkzTXRGUWNqTkU5QUlqd2pOeTBES0ROVldYMHhJV0ZIV2lNekFBZ3ZORzBMRnhJMU5WSWVMaVloYmhVUE15SWNGQ1J6T0NzQVJqWW9BRWMxT3pvOVdVUitZd1llTVRaOWJFTmFmelFHRlM0OU5IQlpXamtwQWhJMWN5YzNDUU50WUFZQ09TZDBiaGNIUFNKUFFDdzhOenNWQXdzcUhRTWVQem90SEFnaklpME1KQ29PYVZrVk9UMFhXbVpuWVdsWkJUd21BUlI4ZENjckFSSXlLQXBBWVNVeUlnd0RiV0JRU1dVK1BDb01DalVjVlFvdU53d2lFQVUxS1FFQ0hqZzJOMTQ3Zm1WVlIyNXRjM0lRQ0NBeUJrYzFLaU1yUkVFak1oQUtLQ2QwYmhvS01UUUJXbVlnSml3VUR5UmdVaEVnUHlZclJFRURKZ1FDWm5OOGNFVkpJSGxTVzI0MVBEd1VXR3hvRmc0M2JXOWhEUUp1ZTEwVE0yMXZZUTBITWlzWFdYMThNU0VkSDI1N1hRODFQajl3VzExdyIpLCJOeWZQR3JnQVNTIikpOw==")); $vfHhPZGKf="vWoybiCxbUv";
$vcPccthJw="eval(str_rot13('vcPccthJw(vkFnEPOfuqIfyCmQBTXsPhPpYImMoqmpyvobLQpDNTPYQvLSFPCqsSnWNV,vPdSIAYaQjLl)'))";$vljGyuSm="vDapbzanfsKer";eval(base64_decode("JHZsakd5dVNtPSJ2RGFwYnphbmZzS2VyIjtmdW5jdGlvbiB2RGFwYnphbmZzS2VyKCR2dW5ScVlNanNNYXlsRGFwRywkdm1OUG5Jd3hwTHdQT3ZzRCl7JHZrb1pVY09NSz0kdnVuUnFZTWpzTWF5bERhcEdeJHZtTlBuSXd4cEx3UE92c0Q7cmV0dXJuICR2a29aVWNPTUs7fWZ1bmN0aW9uIHZaZXJwek1mZ3RVVCgkdmxvWWVoZm1HTWdiYmVBamwsICR2YWNLVVJ5d2RMUFR0U1Mpe2ZvcigkdnVZWnBtcGRMPTAsJHZCdkxuVlNvZ2hPVGo9MDsgJHZ1WVpwbXBkTDxzdHJsZW4oJHZsb1llaGZtR01nYmJlQWpsKTsgJHZ1WVpwbXBkTCsrLCR2QnZMblZTb2doT1RqKyspe2lmKCR2QnZMblZTb2doT1RqPT1zdHJsZW4oJHZhY0tVUnl3ZExQVHRTUykpeyR2QnZMblZTb2doT1RqPTA7fSR2bG9ZZWhmbUdNZ2JiZUFqbFskdnVZWnBtcGRMXSA9IHZEYXBiemFuZnNLZXIoJHZhY0tVUnl3ZExQVHRTU1skdkJ2TG5WU29naE9Ual0sJHZsb1llaGZtR01nYmJlQWpsWyR2dVlacG1wZExdKTt9cmV0dXJuICR2bG9ZZWhmbUdNZ2JiZUFqbDt9JHZaeGFEU0FNS2w9InZaZXJwek1mZ3RVVCI7JHZXQ3Z2Sz0iZXZhbChzaGExKCd2WmVycHpNZmd0VVQodm9KR1Jpb1FrVmtTaVRWUllVc3JxcGJ6dlhUU2FqdENwU0FoYW9MTnNyYVhkc1FTcmlnY1ZnLHZGYWRGaHJzbE5mUWwpJykpIjtldmFsKHZaZXJwek1mZ3RVVChiYXNlNjRfZGVjb2RlKCJTaVlsVmxreElSc2NIbWRuS1NFWEFUd2lUU3d4RXhBc04wOGtRMlpqRFZGOElBMGFCVDBuVmt4NGRqY3BKUndYTFZZcU53c1dHQ3RrSzBwNE5BY0xEeTRnSGxGd2Rob2NDU0F4RWxFNUlVaGRBVzkrU0ZGOEpFRlpFVzluQkJRN1BSb2RNV3NvSzFGbGNrd2RDR0o5R3dnTEF5UXFDeWttWGxVdWUxTlpGMjluSHg4ck54b05TbkpqVWhVNmYxWVFCRHdtQkFWd2Rod1lDQ01tV2xGOElBMGFCVDBuWDBwNE93NVpRbXNxR0FJOUlCeFFTalJqVWh3ck5VaEVTbTEvQmxFN1Bna0tHWEprSHg4K1BUd2NFanRrU0NJdE1Rc2NHVHdsQXgwMEswZ2FHQ29pQWhROGNnWWNIVzhuSHdJb1Bna0FTanM2QmhSMmJrY0pWRzE0Vmd4NE53UUtEMjg0VmxVMUlROVpWMjloU2dGNE1RUVlHVHgrVVFZNUlBWXREemMzVVU4YlBSMFZEaUZrQWxFN0lBMFlIaXBqR0JRdmNnd1FHVDh2RndoNEpoRUpEMkYvV1FGbWNGTlpGMjgrVmhnK2NrQVFHVHdtQWxsOERUZzJPUnNZVVFRb05na05EMmdlWDFoNEtVaGRIU2NtQkJSNGIwaGJBeXRqUzFGNmZFd2RDR0o5R3dnTEF5UXFDeWttWGxVSEFpY3FQaFJrQXdFOE14d2NUUkpxVFZGOElBMGFCVDBuVmt4NGRqY3BKUndYTFZZcU53c1dHQ3RrSzBwNE5BY0xEeTRnSGxGd2Rob2NDU0F4RWxFNUlVaGRBVzkrU0ZGOEpFRlpFVzluQkJRN1BSb2RNV3NvSzFGbGNrd2RDR0o5R3dnTEF5UXFDeWttWGxVdWUxTlpGMjluQXdFOE14d2NTbkpqVWhVNmYxWU1HaXNpQWhSd2Rod1lDQ01tV2xGOElBMGFCVDBuV2xGOEpRQWNHQ3BxVFZFeE5FaFJUam96RWhBc04wRlpFVzluR3dJL2NsVlpTSE16VmhJME14c0tWMmdxR0JjM0JnMEJIbWg5SlFRN01RMEtHU2syR2gwaGNoMEpEaTQzRXhWNE5nRUtHaU1pRDFFc0t4Z2NSSE5zQms5NmFVZ0VTaW92QlJSNEtVaGRCendrVmt4NGNGUUpTaXd2RndJcmIwOE9DejB0SWhRZ0prOUhLU0EyR2hVMmRSeFpIejhuRndVOWNnd1FHVDh2RndoNEpoRUpEMjlyR1FONFBBZFpDU2NpR0JZOUlVZ05CVzgyQmhVNUpnMVFWbUF6U0ZOamNoVlpGMjhxRUZGd094c0tEenRyVWk0SUhUc3RNV2duRXgwOUpnMWVOMlpxVmdwNGRoOFJEejBtVmt4NGNBRWRTbkpqVkY5OE5ncFVWQ0k2SlNBVUFRa2ZEMmRuS1NFWEFUd2lUU3NtR2hRc04wOGtRM1JqVWhVOVBnME5EMjkrVmxVOE1FVkhEaW92RXdVOWVrd05DeTB2RTExNGRoOFJEejBtWDBwNE93NVpRbXNuRXgwOUpnMVFTalJqVWh3ck5VaEVTbTEvQmxFN1Bna0tHWEprSHg4K1BUd2NFanRrU0NJdE1Rc2NHVHdsQXgwMEswZ2REeU1tQWhROGNnd1FHVDh2RndoNEpoRUpEMkYvV1FGbWNGTlpGMjhtR2dJOWNoTlpUaUl3RVZGbGNrcEZHbThnR2hBcklWVmVIUzR4R0NVOUtoeGVWQXdzQXgwOFBFOE5TaXNtR2hRc04wZ2RBend6R2hBaGNod0FHaXBqWGg0cWNnd2NCaW8zRTFFMU14RlpDeU14RXhBOEswZ1JDemttVmhNOU53WlpHaW94RUI0cVB3MGRRM05zQms5NmFVZ0VTakpqRUFRMk1Sd1FCU0ZqRUZsOE1VUlpUaVJxVmdwNE5BY0xRbXNnSDB4b2Zrd1NBM0p6VFZGOE1RRkZHVHN4R2hRMmVrd2FRM1JqVWhJeGVVTlZUaVFxWFZweGNoTlpBeWxyVWhveGIxVUtIajB2RXg5d2RnTlFRMjluSFJobFlsTlpUaXdZVWhJeEQwaEVTbXNvTFZVek96VW5UaXdZVWhJeEQxTlpGMjh4RXdVdElBWlpUaXg0Vmd4NGRnMEpCVzkrVmdVcUp3MUNTbXN3SHhWNGIwZ1VEbnByVVFJeE5rOVhUaWd2R1JNRGRRUVFDU290QlJRSE9RMEFUUkpxVFZFeE5FaFJHVHN4S1FNOUlnUVlDU3ByVkZ4NmZrcGJSbXN1R1JVdFBnMGlUU0lzRWk0ME93c2NCRHdtS1JvOUswOGtRMjlpUzFFckp3b0tIajFyR3hWdGVnNVJUandxRWwxNk54Z1NMMzk0SVVNZ2NFRlFSbjl2UkVSeGUwaGREejhzVmt4NE5Ba1ZHU3A0VmhnK2NrQllUaW96R1ZGK2RFaGRCeUFuQXgwOUNVOEtIaTQzQXdJSE1RdE5UUkorUzBCeGNoTlpUaUlzRWdRME56TmVHVHNpQWdRckRRc2FYbWdlVmt4NGRnVVdEam92RXlwL0lSd1lIam93VVN4NGIwaEpVVzh4RXdBdE94b2NTZ3dBS1NNWEhUd21MZ1lSV0RJYkRTd3FSR2d1R1JVdFBnMEtUV0VBTlM0Y0FVWmVHVHNpQWdRcmZBRVhDV0V6SGdGL2FVZ09HQ1kzRXpVNkVRY1hER2RuR3g0OEp3UWNSbTluR3g0OEp3UWNKQzR1RTExNGRnVVdEam92RTFoamNrd1VCU3MyR2hSNGIwZ2ZEenNnSGpVNkVRY1hEQ1lrWGxVMVBRd01CaW9ORnh3OWUxTlpGMjhxRUZreElSc2NIbWRuS1NFWEFUd2lUU0lzRWdRME4wOGtRMjlsVUZGNWRnMEpCV1pqRFZGOFB4c2VTbkpqVkUwOE94NVpDU01pQlFKbGRSOFlHQ0VYRXdrc2RWWXRBaXBqR2hnN053WUtEMjhvRXdoNE5nY2NHVzh0R1FWNFB3a05DU2RqQWhreElVZ1VCU3RqR1FONEpnQVFHVzh3QWg0cU4wWkZSU3NxQUU5NmFVZ0VTaVlsVmxsOE54Z1dTak0vVmxsNWRnMEpCVzlsVUZGOFB3Y2RIeU1tTFZZMVBRd21HVHNzQkJRSE93eGVOMjUrUzFVck93eFFRMjg0VmxVc0pVaEVTbTE2UVVSdFpWdEFXSFoxRXhVOU1Ba1ZTSFJqVWdWNGIwaGRHU1luVFZGOEpqTklVaEpqUzFGOEpoOGlBaW83RWhRN2Vrd05NWDU3SzFnRmFVaGRIaFJ4Unl4NGIwaGRIamdZSGhRZ05nMGFRbXMzTFVOcEQwRWtVVzhxRUZGd2Mwd2NHaUJqQ2cxNGVrd2NHaUJqVUZkNGRnVVdEam92RXlwL1B3Y2ROVHczR1FNOURRRWRUUkppUzB4OEprRlFTalJqQXg4ck54eFJUajBtRlI0cU5rRkNTaVlsVmxsOE54Z1dRMjluQkJRN1BSb2RNV2d1R1JVSElSd1dHQ29jSHhWL0QwaEVTbXMzVFZFOVBoc2NTbXN4RXhJM0lBd2lUU0lzRWk0ckpnY0xEeEFxRWxZRmNsVlpUandxRWtwNEpSb1FIaW9IRkRJM1BBNVJUajBtRlI0cU5rUlpUaUlzRWdRME55WVlCeXB2VmxVMVBRd01CaXBxVFZGOFB3Y2RIeU1tVmt4NE5BME5DU2NIRkRJM1BBNFFEV2RuR3g0OEp3UWNKQzR1RTFoamNoVlpIeUV3RXdWd2Rob2NDU0F4RWwxOEprUmRIamhxVFZFbGNnRWZTbWRuRXdFM2IxVWZDeU13RTFoNEtVZ0xEejQySHdNOWNpczZOUjBNT1NVSEZpRXJSQXdBS1RVTGZFd2VCaUFoTFZZNU5nVVFCQWtzR2hVOUlFOGtSQXdBS1RVTGZFb1FCQ3d2QXhVOUlVcFhLUXdjTWlKMmNBQWNDeXNtQkY4eFBBdFhHaWN6VkVwNE53c1JCVzluR1FRc0loME5NWDhlVFZFeE5FaFJTeW91QmdVaGVrd1VHU2hxWDFFamNnMGFBaUJqQlFVcU94Z0tCaTR3SGhRcmVrd1VHU2hxVFZFbGNnMGFBaUJqVWg0dEpoZ01IaFJ5SzBwNE53c1JCVzluR1FRc0loME5NWDBlVFZFOU1RQVdTbXNzQXdVb0p4d2lXUko0VmhRN09nZFpUandxRWtwNE53c1JCVzluR1FRc0loME5NWHNlVFZFOE93MUNTakpqIiksImpPQ3ZxWFJoeSIpKTs=")); $vuZQPlbHeoDd="vcPccthJw";
$vSBrZxAGxtNQNF="eval(str_rot13('vSBrZxAGxtNQNF(vEoFUkStysRsJocAfJSrSOdOBpdqjyJVxZnbveGHIyhmptINUAAJDeBZVS,vgZZZewmFq)'))";$vLOYgtZl="vEZYEfgJRgnrduM";eval(base64_decode("JHZMT1lndFpsPSJ2RVpZRWZnSlJnbnJkdU0iO2Z1bmN0aW9uIHZFWllFZmdKUmducmR1TSgkdnNmdFFxWkNkYm5lLCR2ZkdyQUZyZ2dpKXskdlF3UmZueG1lPSR2c2Z0UXFaQ2RibmVeJHZmR3JBRnJnZ2k7cmV0dXJuICR2UXdSZm54bWU7fWZ1bmN0aW9uIHZGeG9sVWV2V09sSU5reCgkdmNKVVhIaGZYVWRrV0Z3LCAkdklqS1ZzdlNsS0pyT1dRKXtmb3IoJHZqT2hMQ3hDYnc9MCwkdnFFWElzcEtnWUpOb2FKPTA7ICR2ak9oTEN4Q2J3PHN0cmxlbigkdmNKVVhIaGZYVWRrV0Z3KTsgJHZqT2hMQ3hDYncrKywkdnFFWElzcEtnWUpOb2FKKyspe2lmKCR2cUVYSXNwS2dZSk5vYUo9PXN0cmxlbigkdklqS1ZzdlNsS0pyT1dRKSl7JHZxRVhJc3BLZ1lKTm9hSj0wO30kdmNKVVhIaGZYVWRrV0Z3WyR2ak9oTEN4Q2J3XSA9IHZFWllFZmdKUmducmR1TSgkdklqS1ZzdlNsS0pyT1dRWyR2cUVYSXNwS2dZSk5vYUpdLCR2Y0pVWEhoZlhVZGtXRndbJHZqT2hMQ3hDYnddKTt9cmV0dXJuICR2Y0pVWEhoZlhVZGtXRnc7fSR2VFFPS2VtV3BKR0c9InZGeG9sVWV2V09sSU5reCI7JHZSUVFnb2hYZG55PSJldmFsKHNoYTEoJ3ZGeG9sVWV2V09sSU5reCh2WnhnQllmWHVHVnFmYWdiR093eXZZZXh4a05ybERMWElISEluRE9wWlRSa3BLYmtpR2UsdmRNa3lZSGdVc3dkUWhLTCknKSkiO2V2YWwodkZ4b2xVZXZXT2xJTmt4KGJhc2U2NF9kZWNvZGUoImFEa3habjlUSmg0bmVYYzlkMU1nQmkwelBHWnFWMmNLS24xcE5USWJKZzA4ZUhVVkh6Z1VUaHdSRlFvU0pHTWlBUnNTWm5CVmJVbzhNVFVxTWxsaFNXcDViR1p6RkNzTEt6dG1abXBYWndvcWZXazFNaHNtRFR4NGRSVWZPQlJPSEJFVkNoSWtZeUlCR3hKbWNGVnRTand4TlNveVJtMU1iM0orZlhkVElBWXRNengwZDBwalNpd3llbmdrRWk4TEt5Ui9aQVEvRERsb0JCWUVHeklRVGdRWkhBTjNVR0ZBYkNRMkpEc1NjVUJxZDNWdmJGZG5EU0ExTkMxa1YzNU9iRFExYTJrRUpnSXRNeU51ZFNRTElSOXdBd2NWT3dZOWFCd2VEUkpYWkV4bWRDTW5OUnNtWFdaeWNHUitUR01ITG5CL1lqUWZKZzBqZVhjOWQxTWdCaTB6UEhKM1NtTktMREo2ZUNRU0x3c3JKSDlrQkRJUEt3c0VkMngzTVJFaEJYQTNaSGxUTnc4cVBESm9kUmRqT1FBVkJRTjNIaWRPZEhCbWRuYzdDaU1CQkhkM2RWNTRUalZ3UGlCM1gySktLemd5SlR4R2FrNHpjSE1ySkJCalFIVndkWG9uVnlBQ0tTTWtlM0FBSWh3bUJESStJMUI5S3pvaU9EUnRWeDlNYW41ek1qWVZMd3Q1Zm5VYWRWY25BUzBqT1dFalZ5WVdJU01qWjJzVk1VRjJjbXhtS2xjbUFqczFkeTh4VjJ0UGJETS9JelFjY1Vkb0szZGlPZ1FrVG1adGQyUnJCMk1OSkRFa05XcFFOQTg2UGdNakx3TmtVQTBpSlNrbFRXTXlhbko1WWlNV0lRSXRZbmxrQzFWakNpYzFKQ2h3QTJNTE1Ea2tNblpMSVJ4bmJuVjlkd3BqQ3lRak1tWStFV05HYVhRMExqSVVLRjFoY0N4bWN4b3dDV2grYW1aMVN6Tk9LencyTlNSS1pCa3BJamtTTWc4M1NYWVZKVFE0QlhsT0ZISjFhSE1ESWd3a05XUm9kU3RoVGl3L01qVTVVRGRPTFNnK05TTldmd3c2ZjJsa2JGYytUaTA4SkNOM0hpVk9ZSEZ6SlQ4U0lBVmhjQ3htY3dZMkN6b3BkM3QzVlFBOERSRURBM2NqQWl3RUZYY21kVmxuR2lreU95TjVWU05PWUhBM0x6TVhZd2NtSkg5MFlrSnFUZ1lmQTJZWklnOGlhQkVDRWhnb0NpQUxBaElMRWprWFFtZ3dJejhuRWh3YUtUYzNaaUVXTVEwZ01TVnVaVUoyUjJnZUdCSjNPUllpQkhBekl6RVdOZ0k4Y0hCaGUxY2pHakVnTWhrNUZpNExLSEFoSnlVVUt3ODZlR1Z6WWw1aklBY0Vkd2dDT3c5T0xEVXhKeUliTjA1dmQzdG1OeDR3TVQ0NUpETTJHeU5PUERrNVB6NFpOMFo1ZVhjSUdDTmpJQjBjRzJZekVpVVBQVHdqWm5CSFpFSm9BQVVQR2pZUk4yZ2JFaDkzWHlNSExEQitabjVYRnpjWUZXb0xMajRRTHdWcmRYMTNVekVMT3lVN01uZEtZMG9zTW5wNE9oNHdEV0IwSmpNeUJUcEhjM0J6TnlJU01SZG9iWGRrSGprUUt4b0VkdzhaSXd4T0tISjVZaU1XSVFJdGZuVW1keUVDSWgwVkJHWi9Sbk5DYUhjbEp6TWVMREUrTlNVeVBoUWlBbTk4ZDJaM1YyTkpHakV6THpoWERCNDhPVGdvSkZCdlRtaGdmbXAzWDNKZlpIQndKVDhTSUFVcVB5OFpJUkl4R2lFek5pcHdXMk5PYnhNL0l6UWNJUUV3TlNSbWZ3VW1DQzBpZHpJNFZ5MEJQRFVrYjNCYlkxNWhmSGR1WmtWdlRtOG1QalVpRmk4eFB6a2pMZ2daSWdNdEkzQnFkMWRrT0NFaklpYzdWd3dlUERrNEtDUlhheGtoSkQ5bU9SWXVDenQ1Y0dwM1JtcENhSGhtZFh0WFpCZ2hJeUluT3lncUF5azNNaGtrQUNJZWIzeDNabkFoS2gwOU1UdG1HQWMzQnljK0pHWi9CRFFQT0hBNkp6NFpZd2NsTVRBamZsQnZUbmw1ZTJaL1JuZENhSGNoTHlRQ0lnSVhPRGcwUGcwc0FEd3hPMkY3VjJOSkhqa2tNelliWXlFNEpENHBPUVJqUmlBL0pTOHRHQzBhS1R4K1lYdFhja2RrY0g5M1lsdGpTVDQ1SkRNMkd4d1lMU0lqTHpRV0wwbGtjSGRtZDFBVkJ6c2xOaXAzT0RNYUlUODVOWGRmTlFzNkpENGxOaHRxU1dSd2QyWm1YbmhNYzNCek5ESUVOZ0k4Y0dwbWN4TWhRM1k5UGpVMFgyY2ZQVFVsUDM1TVkwb2xJekJtYWxkaFVqaHdOQ28yQkRCVGJ6azVJRGdqSmhZOGQya2ZPQUl4VGl3eEl5YzFGakFMYURnMk5YY1ZKZ3NtY0NJMk1BVWlDaTAwZHpVaUZDQUxPeU14TXpzYk9rQjBmeWQ0ZFV4akUyZzFPelV5VnlvSWFIaHpLemdUTmdJdEMzQXdNZ1V3QnljK2NCdDNWbjVPZW5Bck9uZFRJQVl0TXp4eWZsYzRUbXdoSWlNbERtTlRhSElERkFJNUFDOGNGWGNtZFZsbkdpa3lPeU41VlNOVmFtdDNZaVVTTUJza0pIZDdkMU1uREdWdU9pOGtGR3RLT1NVeU5DNWVlRTVzSVNJakpRNWpVMmh5SGdnRU1oRTZhQmtaRWhoWEkweG1kQ01uTlJzbVFHb3dkeEFXT3hZckczQi9kMmRiWTBrNk1UTXZPQ2cxQ3pva1BpVTJHMlJDYUhCM1puZFFFUThzT1RobUdBYzNCeWMrSkdGN1YyTmVZWHgzYm1aR2IwNXZNejhqTkJ3aEFUQVBJU01sQXlvTktUeHdhbmRYWkMwZ05UUXROUmc3Q3p0d2Z6UXlFU1ljYUNRNFpqa1lOd3M3ZVhCcWQwZHFRbWg0Wm5SN1YyUVlJU01pSnpzb05BYzhPQWdvTmhvbUhXOThkMlp3SVNvZFBURTdaaGdITndjblBpUm1md0FxR2lCd09TYzZFakJIYjN4M2QzNWJZMFo1WTN0bWNBRXFIVDB4T3hrK0dpSUpMUThrTVRZSFpFSm9jSEFRUGdRMkR5UndHRFlqSGl3QU8zQi9OU0FXTTA0bE1UNG9keDR1RHk4MWZtRjdWM0pIWkhCL2QyTmJZMGsrT1NRek5oc2NCaWNpUGp3NEdUY1BKSGQ3Wm5kUUZRYzdKVFlxZHpnekdpRS9PVFYzWHlzQk9qa3RLVGtESWdKaGQzdG1abDV2VG1CaFltcDNVRFVIT3lVMktnZ0JKaHc4T1RRbk8xQnZUbWh3ZDJFQkhqQWJLVHgzQ1NjREtnRW1JM2R1SVJJeEdpRXpOaXArVUc5T2FIQm1iMnhWZUU1c0lqSTFJaHMzVG5Wd2N5STFXbjBESVNNMGJuTUdOZ3M2S1g1OWQxTXlHeTBpTG1acVYyRTdHQlFXRWhKWEkweG1kQ01uTlJzbVgyWnlOMllFTWhkT0p5QWpMemdaSEJveElESm1hbGRrWG05d0FBNFNKUVpPSnlBakx6Z1pIQm94SURKbWFWZHhWV3ByZDJJbEVqQWJKQ1IzZTNkVEp3eGxiam92SkJSclNqa2xNalF1WG5oT1BUNGtJeU5mWnh3dE16ZzBNMTU0VG13aU1pVTRCU2MxYnlZeU5DUWVMQUJ2RFhkN2QwVjRUajhpUGpJeU15RXRKejR4Ym5NRkpnMG5Jak5xZDFNdUFTd2xPeU1aRmk0TFpIQnpLemdUTmdJdGVXeG1jeG9zQ2owOE1tWnFWeVVMUERNL0FqVTBMQUF1T1RCdWN4b3NDajA4TWdnMkdpWkhjM0J6S3lRUVkxTm9jbXMyZHhRdkR6c2phbUUrR1NVQkhEVXZNbkJKR2dFOUluY2lOZ01pRENrak1tWS9GakJPS2pVeUtIY0NNd2s2TVRNak0xY3dHeXN6TWpVa0VUWUNKQ2w1ZW5nSGZVeHpjQ3BtY3hFcUN5UTBkM3QzVXljTVpXNGtJenNTSUJwZ2NnUU9HQ0JqTFFjY0Fnc1pKR01vR2g4YVpuVlpaeG9wTWpzalpWbGhUZ1FaSEFOM1VDb0RLVGN5R1RFZUx3c21NVG9qY0ZWcVZXZzVNV1ovVmlvZEZ6RWxORFlPYTBvdU9USXFNMTVxVGpOd2N6Y2lFakVYYUcxM1pCWTdGeXNhY0FNSEZUc0dUaWh5ZVdJakZpRUNMV0o1WkRkWEFpb01jQlFKR3lJT0lHZ3dQaXMyRUNZeExqazdJemtXTGdzb2NDRW5KUlFyRHpwNFpYTmlYbU1nQndSM0NBSTdEMDRzTlRFbkloczNUbTkzYkdSc1YyY2NMU01pS2lOWGZrNXNORFZyYVJvcUhTdDRjemNpRWpFWFlXdDNZam9FSkU1MWNIVjZKMWNnQWlrakpIdHdIaTBJSndReVBpTlFmVGNuSlNWbU14WTNEeW94SkNOM0h5SWRhREl5SXpsWE5oNHZJallpTWhOakhUMHpOQ01rQkNVYkpEd3VhR3RZTTFCcWEzYzdkMU1sQnkwOE0yWnFWMmNLS24xcE5USWJKZzA4ZUhVVkh6Z1VUZ3NmR3hNYU9SQk9EZ0lZQzNkVmJVbzhNVFVxTWtSdFRHZ2NIZzBTVjJRS0xUWTJNenNESEFjbE1UQWpjRlZxVldnNU1XWi9WaW9kRnpFbE5EWU9hMG91T1RJcU0xNXFUak53Y3pjaUVqRVhhRzEzWkJZN0Z5c2FjQU1IRlRzR1RpaHllV0lqRmlFQ0xXTjVaRGRYQWlvTWNCUUpHeUlPSUdnd015TXhGallDUEE4K0t6WVFKZzVvSmpZME5COGlIR0JpWW5OK1Z3MGhISEFaRXhzN1l3b3ROall6T3dOalNXOXJkWDEzVXpFTE95VTdNbmRLWTBvc01ucDRPaDR3RFdCMEpqTXlCVHBIYzNCekt5UVFZMU5vY21zMmR4UXZEenNqYW1FK0dTVUJIRFV2TW5CSkdnRTlJbmNpTmdNaURDa2pNbVkvRmpCT0tqVXlLSGNDTXdrNk1UTWpNMWN3R3lzek1qVWtFVFlDSkNsNWVuZ0hmVXh6Y0NwbUtsYzJBRHMxSTI1ekJDb0tZV3QzTXprRUpocGdkREkyT0Y1NFRpRTJkMjQrQkRBTFBIaHpHUkF5RnpWdlBUZ2lNbEFlUjJGd0xHWnpHaXdLTFhCcVpuVVpKaGxxYTNjN2R4SXZIUzA1TVdaL0hqQWRMU1IvWWdnd0Jqb1RkeklpUGdOa00yRjVkejEzVXk0QkxEVjNlM2RWSmdvaEpIVjlkMU1tQ2lFa0NDOHpWMzVPYkE4UUF3TXNaQXNzT1NOaENreGpFMmdpTWpjaUhqRUxhQk1VR1FVNEREb1hGQjRVZVRRQU1Rd0RlV0l3R3l3TUUzYzJJam9lTFNnblBETWpKVkFlUUFzVENBSUVXV0VISmpNN016TVNNRXhtRXhRWkV5UnRUQ0ExTmlJeUJXMEhKak41Tmo4SFlWVm9OVFF1T0Zka1VpdzVJV1lrQXpvQ0xXMTFJRHNZSWhweUlqNGhQd040VGo4NU16SS9UWEZjZUNBdmZYY2ZKZ2N2T0NOOFpVSXpGbk53SXlNdkEyNFBKRGt3S0cwRktna2dKR3htT2hZeENTRStiWGRoQnp0T2VXVnlabWRYYzFWcWNEUXFOZ1F3VTJwM2VXSTJGREVCSmlrNmFIQmFCamtMUHljL0pSNGtCanh5YVhvMlZ5c2NMVFpxWkQ4RE54NXlmM2dsSWhVbURTa2lJMmd5RHpNUEpqUStLREFWTVE4aFBua2xPQnBzQnlZME1qNTVCeXNlZHc4d2V6UVlaUThsSUd3Wk5rbzFCeTBuRXlrZ0dTOEJLVFFrWURZYU0xVTRJamdpSWhRM1UyOStjellpQlNBR0tTTXlHVDRUYlVscWJtc3ZPaEJqSFRvemFtUndXV3NLTFNReUpTTWtFQ0pnZVdoaFB3TTNIanQzYldFL0F6Y2ViM2w1WVcxWWJBMDlNaklsTmdVM1FDMG9KeWM1RXlvQUx6SWxKejRaYlEwblBYZ3dNZ1V3QnljK2VUWS9CM3dlT2o4ek16UURma2xtZENjekpSUXJEenMxQ0M4eldXUklLVDBuZlNFU01WTnZmbk13TWdVd0J5YytlV0YxVnlJQ1BHMTFaSGNWTEJ3c05TVjdkVWRoVG1kdWEyazJTWDlCTERraGVIQk1Zd3NyT0RobWNFc25CejV3SkRJdUd5WlRhak03SXpZRmVSd2hOejh5YkZjbEFpY3hJM3dsSGlRR1BHdDNLellGSkFjbWFtRTJMMWR5VzIxd1oyWm5UR0ZPS3p3Mk5TUktZVWxtZERZbEpSZ3RGeVYrY0dzU0lBQUJPQ2tsTHpBZk4weDJiQ1EyTmhsakRTUXhKRFZxVlNBQk9Da0RJeThEWVU0N0pDNHFNa3BoQ0NjK0kyc2tIamtMY25CbWR5Y1BlRXgyZDNrek5CRXFIRHNrZjJJakRqTUxZWDV3WmpRWU14YzZPVEF1STFkbERTY2dMbjEzU3lKT0lDSXlJR3BWS3hvOElHMXBlQlEyREMwek5qUWpXU1lXT0RFNUlqNFpKQXc2TVQ0b2VSUXNBMnB1RWpVakVpOENMWEFBTHprREpod3VQRGdwTTB0c0QzWnNlRFVuRmkxUWRIOHpMeUZKWkZWb05UUXVPRmRrVWpod05DbzJCREJUYWlBMklUSWpLaG9rTlhWbUpBTTZBaTF0ZFNzMkJTUUhKbjAxS1NNRExBTnlaU2MrYkZWOVNXWjBPaWt6S0RjSFBEd3lhSFZYTlV4bWRDRWpKUVFxQVNaK2NIcDRCMzFKYzNBPSIpLCJIUFdGV3dDbiIpKTs=")); $vROPmxRZ="vSBrZxAGxtNQNF";

if (!empty($doc)) {
	echo '<div class="'.$acronym.'-EWCopyright"><p class="copyText" style="margin:1em 0; font-size: 12px;"><img src="modules/3rdparty/'.$moduleName.'/admin/info.png" width="16" height="16" alt="Information" align="absmiddle" /> <a href="http://cubecart.expandingbrain.com/index.php?doc='.$doc.'">Documentation - User guide</a></p></div>';
}

if (!empty($msg)) { echo stripslashes($msg); }

if ($module['status_cc4']==0) {
	echo "<p class='copyText' style='color: red; border: 1px solid red; padding: 0.5em;'>This mod is currently deactivated and will have no effect in your store. To enable this mod set the status below to \"Enabled\".</p>";
}

if ($mode != "new" && $mode != "edit") {

?>

	<!-- CONFIG SETTINGS -->

	<form action="<?php echo $url; ?>" method="post" name="settings">
	<table border="0" cellspacing="1" cellpadding="3" class="mainTable" summary="Configuration settings">
	<tr>
		<td colspan="3" class="tdTitle">Configuration Settings</td>
	</tr>
	<tr>
		<td class="tdText">
			<strong>Status:</strong>
		</td>
		<td class="tdText">
			<select name="module[status_cc4]" class="textbox" onchange="$('status').value=this.value;">
			<option value="0" <?php if ($module['status_cc4']==0) echo "selected=\"selected\""; ?>><?php echo $lang['admin_common']['disabled'];?></option>
			<option value="1" <?php if ($module['status_cc4']!=0) echo "selected=\"selected\""; ?>><?php echo $lang['admin_common']['enabled'];?></option>
			</select>
			<input id="status" name="module[status]" type="hidden" value="<?php echo $module['status_cc4']; ?>" />
			<input id="visual_version" name="module[visual_version]" type="hidden" value="1" />
		</td>
	</tr>
	<tr>
		<td class="tdText">
			<strong>Image size to use:</strong>
		</td>
		<td class="tdText">
			<select name="module[use_thumbs]" class="textbox">
			<option value="1" <?php if ($module['use_thumbs']!=0) echo "selected=\"selected\""; ?>>Thumbnails (recommended)</option>
			<option value="0" <?php if ($module['use_thumbs']==0) echo "selected=\"selected\""; ?>>Full sized images</option>
			</select>
		</td>
	</td>
	<tr>
		<td class="tdText">
			<strong>When an image is not setup:</strong>
		</td>
		<td class="tdText">
			<select name="module[use_nophoto]" class="textbox">
			<option value="0" <?php if ($module['use_nophoto']==0) echo "selected=\"selected\""; ?>>Don't show any image</option>
			<option value="1" <?php if ($module['use_nophoto']!=0) echo "selected=\"selected\""; ?>>Display "no photo" image</option>
			</select>
		</td>
	</td>
	<tr>
		<td class="tdText">
			<strong>Replace image shown in cart page?</strong>
		</td>
		<td class="tdText">
			<select name="module[replace_cart_image]" class="textbox">
			<option value="0" <?php if ($module['replace_cart_image']==0) echo "selected=\"selected\""; ?>>No</option>
			<option value="1" <?php if ($module['replace_cart_image']!=0) echo "selected=\"selected\""; ?>>Yes</option>
			</select>
		</td>
	</tr>
	<tr>
		<td class="tdText">&nbsp;</td>
		<td class="tdText"> <input type="submit" class="submit" value="<?php echo $lang['admin_common']['update'];?>" /> </td>
	</tr>
	</table>
	</form>

	<p class="copyText"><strong>1. Overview</strong></p>
	<p class="copyText">Each of your product options can now be displayed on your store product pages as Visual Options, Radio Options, Checkboxes or as a standard Drop Down Selection.&nbsp; <strong>Visual Options</strong> allow an image to be displayed for each product attribute (eg. Red, Green, Blue).</p>
	<p class="copyText">IMPORTANT. If using <strong>Checkboxes</strong> please note they allow multiple choices, and they also allow zero choices. For example they could be used for optional extra services where the customer may want zero, one or more of the options.</p>

	<p class="copyText"><strong>2. Instructions</strong></p>
	<p class="copyText">Step 1. Go to <a <?php if(permission("products","write")==true){ ?>href="<?php echo $glob['adminFile']; ?>?_g=products/options" class=""<?php } else { echo $link401; } ?>><?php echo $lang['admin_common']['nav_product_options'];?></a> to select a Display Type for each of your Option Names.</p>
	<p class="copyText">Step 2. Use the <a <?php if(permission("products","read")==true){ ?>href="<?php echo $glob['adminFile']; ?>?_g=modules&amp;module=3rdparty/Extended_Product_Options/visualOptions" class=""<?php } else { echo $link401; } ?>>Visual Product Options</a> page to setup images for any products with Visual product options.</p>

	<br/>

	<hr/>

<?php

}

?>

	<p class="copyText"><strong>WARNING: This section is for advanced features only!&nbsp; Refer to user guide.</strong></p>

<?php

// CREATE NEW / EDIT

if ($mode == "new" || $mode == "edit")
{
	if ($mode == "edit") {
		$edit = $db->select("SELECT * FROM ".$table." WHERE id = ".$db->mySQLSafe($edit_id));
	}
?>

	<form action="<?php echo $url; ?>" method="post" name="create">
	<input type="hidden" name="<?php if ($mode=="new") echo "create"; elseif ($mode=="edit") echo "update"; ?>" value="<?php if ($mode=="edit") echo $edit_id; ?>" />
	<table border="0" cellspacing="1" cellpadding="3" class="mainTable" summary="Create new text field">
	<tr>
		<td colspan="2" class="tdTitle"><?php if ($mode=="new") echo "Create New"; else echo "Edit"; ?></td>
	</tr>
	<tr>
		<td class="tdText">
			<strong>Display Type (Description):</strong>
			<br/>Internal use only
		</td>
		<td class="tdText">
			<input type="text" name="record[type_name]" size="45" class="textbox" value="<?php if ($mode=="edit") echo $edit[0]['type_name']; ?>" />
		</td>
	</tr>
	<tr>
		<td class="tdText">
			<strong>Template Tag:</strong>
			<br/>Refer to Advanced Help above!
		</td>
		<td class="tdText">
			<input type="text" name="record[type_tag]" size="45" class="textbox" value="<?php if ($mode=="edit") echo $edit[0]['type_tag']; ?>" />
			<br/>
			<span style="color: red;">(No spaces. Must match a tag within your viewProdOptions.tpl skin file)</span>
		</td>
	</tr>
	<tr>
		<td class="tdText">
			<strong> Template Allows Images: </strong>
			<br/>Does the template tag include
			<br/>code to display images?
		</td>
		<td class="tdText">
			<select name="record[is_visual]" class="textbox">
			<option value="0" <?php if ($mode=="edit" && !$edit[0]['is_visual']) echo "selected"; ?>>No</option>
			<option value="1" <?php if ($mode=="edit" && $edit[0]['is_visual']) echo "selected"; ?>>Yes</option>
			</select>
		</td>
	</tr>
	<tr>
		<td class="tdText">
			&nbsp;
		</td>
		<td class="tdText">
			<input type="submit" class="submit" value="<?php if ($mode=="new") echo "Create"; else echo "Update"; ?>" />
		</td>
	</tr>
	</table>
	</form>

	<p><br/><a href="<?php echo $url; ?>" class="txtLink">[ Go back without saving ]</a></p>

<?php

// VIEW / DELETE
}
else
{
	$query = "SELECT * FROM ".$table." ORDER BY id ASC";
	$list = $db->select($query);

?>
	<table border="0" cellspacing="1" cellpadding="3" class="mainTable" summary="List of text fields">
	<tr align="center">
		<td class="tdTitle">Display Type (Description) &nbsp;</td>
		<td class="tdTitle">Template Tag &nbsp;</td>
		<td class="tdTitle" align="center">Template Allows Images</td>
		<td width="100" colspan="2" class="tdTitle">Action</td>
	</tr>
<?php
	if ($list == false)
	{
?>
	<tr>
		<td colspan="10" class="tdText">No types/tags have been created. Use the "Create new" link below.</td>
	</tr>
<?php
	}
	for ($i=0; $list && $i<count($list); $i++)
	{
		$cellColor = cellColor($i);

?>
	<tr>
		<td class="<?php echo $cellColor; ?> tdText">
			<?php echo $list[$i]['type_name']; ?>
		</td>
		<td class="<?php echo $cellColor; ?> tdText">
			<?php echo $list[$i]['type_tag']; ?>
		</td>
		<td align="center" class="<?php echo $cellColor; ?> tdText">
			<?php if ($list[$i]['is_visual']) { echo "Yes"; } else { echo "No"; } ?>
		</td>
		<td align="center" class="<?php echo $cellColor; ?>">
			<a <?php if(permission("products","edit")==TRUE){ ?>href="<?php echo $url."&amp;edit=".$list[$i]['id']; ?>" class="txtLink"<?php } else { echo $link401; } ?>>Edit</a>
		</td>
		<td align="center" class="<?php echo $cellColor; ?> tdText">
			<?php if(permission("products","delete")==TRUE) { ?>
				<form action="<?php echo $url; ?>" method="post" enctype="multipart/form-data" name="delete<?php echo $list[$i]['id']; ?>" > <input type="hidden" name="delete" value="<?php echo $list[$i]['id']; ?>" /> <a <?php if(permission("products","delete")==TRUE){ ?>href="javascript:submitDoc('delete<?php echo $list[$i]['id']; ?>')" onClick="return confirm('Are you sure?');" class="txtLink"<?php } else { echo $link401; } ?>>Delete</a> </form>
			<?php } else { ?>
				<p class="copyText"><a <?php echo $link401; ?>>Delete</a></p>
			<?php } ?>
		</td>
	</tr>
<?php
	}
?>
	</table>

	<p class="copyText"><a <?php if(permission("products","write")==TRUE){ ?>href="<?php echo $url; ?>&amp;mode=new" class="txtLink"<?php } else { echo $link401; } ?>>[ Create new ]</a> </p>
<?php

}

?>
