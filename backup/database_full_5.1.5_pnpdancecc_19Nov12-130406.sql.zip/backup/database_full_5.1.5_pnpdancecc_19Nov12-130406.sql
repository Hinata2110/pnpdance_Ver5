-- --------------------------------------------------------
-- CubeCart SQL Dump
-- version 5.1.5
-- http://www.cubecart.com
-- 
-- Host: pnpdancecom.ipagemysql.com
-- Generation Time: 2012-11-19 13:04
-- Server version: 50091
-- PHP Version: 5.2.17
-- 
-- Database: `pnpdancecc`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_access_log`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_access_log`
--

CREATE TABLE `cc4_CubeCart_access_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `type` char(1) collate utf8_unicode_ci NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `username` varchar(100) collate utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned default NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL COMMENT 'Supports IPv6 addresses',
  `useragent` text collate utf8_unicode_ci NOT NULL,
  `success` enum('Y','N') collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_access_log`
--

INSERT INTO `cc4_CubeCart_access_log` VALUES('1', 'B', '1352290108', 'pnpdance_admin', '0', '195.212.29.85', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('2', 'B', '1352296800', 'pnpdance_admin', '0', '195.212.29.85', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('3', 'B', '1352301912', 'pnpdance_admin', '0', '195.212.29.85', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('4', 'F', '1352303368', 'mark@fabian-lovely.co.uk', '12', '195.212.29.84', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('5', 'F', '1352342514', 'dyndesmespi@aol.com', '59', '91.237.249.89', 'Opera/9.80 (Windows NT 5.2; U; en) Presto/2.10.229 Version/11.64', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('6', 'B', '1352366829', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('7', 'B', '1352376202', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('8', 'B', '1352381400', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('9', 'B', '1352384431', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('10', 'B', '1352391850', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('11', 'F', '1352426565', 'Deefumnnuth', '0', '31.129.164.182', 'Mozilla/5.0 (Windows NT 5.1; rv:5.0) Gecko/20100101 Firefox/5.0', 'N'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('12', 'B', '1352449009', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('13', 'B', '1352452648', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('14', 'B', '1352456205', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('15', 'B', '1352461691', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('16', 'B', '1352465273', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('17', 'B', '1352471250', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('18', 'B', '1352711185', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('19', 'B', '1352929388', 'pnpdance_admin', '0', '82.3.245.142', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:16.0) Gecko/20100101 Firefox/16.0', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('20', 'B', '1352970122', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('21', 'B', '1352975947', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('22', 'B', '1352979763', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('23', 'B', '1353319361', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
INSERT INTO `cc4_CubeCart_access_log` VALUES('24', 'B', '1353330231', 'pnpdance_admin', '0', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', 'Y'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_addressbook`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_addressbook`
--

CREATE TABLE `cc4_CubeCart_addressbook` (
  `address_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL,
  `billing` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `default` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `description` varchar(250) collate utf8_unicode_ci NOT NULL,
  `addressee` varchar(100) collate utf8_unicode_ci NOT NULL,
  `title` varchar(20) collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `company_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `line1` varchar(200) collate utf8_unicode_ci NOT NULL,
  `line2` varchar(200) collate utf8_unicode_ci NOT NULL,
  `town` varchar(100) collate utf8_unicode_ci NOT NULL,
  `state` varchar(100) collate utf8_unicode_ci NOT NULL,
  `postcode` varchar(15) collate utf8_unicode_ci NOT NULL,
  `country` smallint(3) unsigned NOT NULL,
  PRIMARY KEY  (`address_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_addressbook`
--

INSERT INTO `cc4_CubeCart_addressbook` VALUES('1', '8', '1', '1', '', '', 'Miss', 'Mariska', 'Garcia', 'Mariska Garcia', '70 hamstead hill', 'Handsworth wood', 'Birmingham', 'West Midlands', 'B201da', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('2', '6', '1', '1', '', '', 'miss', 'emma', 'crawley', '', '90', 'brynglas drive', 'newport', 'Gwent', 'np20 5qs', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('3', '9', '1', '1', '', '', 'Mrs', 'Sarah', 'Norris', '', '27 prunier drive', 'Peterhead', 'Scotland', 'Aberdeenshire', 'Ab421zf', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('4', '10', '1', '1', '', '', 'miss', 'sammy-jo', 'sharpe', '', '75 chedworth crescent', '', 'portsmouth', 'Hampshire', 'po64es', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('5', '11', '1', '1', '', '', 'mr', 'lewis', 'stephen', '', '3 mcgregor cres', '', 'peterhead', 'Aberdeenshire', 'ab421ge', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('6', '12', '1', '1', '', '', '', 'Mark', 'Fabian-Lovely', '', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('7', '13', '1', '1', '', '', 'miss', 'robine', 'young', '', '52 gruneisen road', 'stamshaw', 'portsmouth', 'Hampshire', 'po2 8qg', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('8', '14', '1', '1', '', '', 'mrs', 'sarah', 'norris', '', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('9', '16', '1', '1', '', '', 'mrs', 'jacqui', 'beaumont', '', '17 edgebaston house', 'sedgley close', 'portsmouth', 'Hampshire', 'po5 4pq', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('10', '17', '1', '1', '', '', 'mrs', 'anthea', 'haig', '', '22 clydebank road', 'buckland', 'portsmouth', 'Hampshire', 'PO2 7QG', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('11', '18', '1', '1', '', '', 'miss', 'Lorraine', 'Sankey', 'dancestyles', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('12', '19', '1', '1', '', '', 'MRS', 'LAURA', 'HICKMAN', '', '17 herne road', 'cosham', 'portsmouth', 'Hampshire', 'po6 3pb', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('13', '20', '1', '1', '', '', 'Mr', 'Paul', 'Renshall', 'Mott Macdonald', 'P O box 11302', 'DFC', 'Dubai', 'Dubai', 'Po box 11302', '784'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('14', '23', '1', '1', '', '', 'miss', 'kelly', 'jones', '', '14 cremlyn', 'bethel', 'caernarfon', 'Gwynedd', 'll551aj', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('15', '22', '1', '1', '', '', 'MRS', 'CAROL', 'OBRIEN', '', '3 Hesketh Court', '', 'GREAT HARWOOD', 'Lancashire', 'BB6 7TY', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('16', '24', '1', '1', '', '', 'mrs', 'helen', 'carvell', 'chandlers', '190 Allerton Road', 'Allerton', 'Liverpool', 'Merseyside', 'L18 5HU', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('17', '26', '1', '1', '', '', 'miss', 'leah', 'selwood', '', '11 annesley road', '', 'Newport', 'Gwent', 'np197ey', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('18', '25', '1', '1', '', '', '', 'lisa', 'watts', '', '3 glyngaer road', 'glyngaer', 'Hengoed', 'Gwent', 'CF828FJ', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('19', '28', '1', '1', '', '', 'Mrs', 'Dionne', 'Dunn', '', '3 CLEADON HILL ROAD', '', 'SOUTH SHIELDS', 'Tyne and Wear', 'NE34 8DR', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('20', '29', '1', '1', '', '', 'Mr', 'David', 'Williams', '', '254 Miller way', 'Thornbury', 'Plymouth', 'Devon', 'PL6 8UQ', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('21', '30', '1', '1', '', '', '', 'paul', 'duffin', '', '33, seaway crescent', 'milton', 'portsmouth', 'Hampshire', 'po4 8ll', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('22', '31', '1', '1', '', '', 'mrs', 'stephanie', 'hodson', '', '8 riverside cottage', 'roseworthy', 'camborne', 'Cornwall', 'tr14 0du', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('23', '32', '1', '1', '', '', 'MRS', 'Dawn', 'Waddell', '', '7 Pavilion Gardens', '', 'Irvine', 'Ayrshire', 'KA11 2FH', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('24', '33', '1', '1', '', '', 'miss', 'charlene', 'mcgrail', '', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('25', '34', '1', '1', '', '', 'Mrs', 'Jacqueline', 'Handley', 'none', '5 Hawfield Road', '', 'Tividale', 'West Midlands', 'B69 1LQ', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('26', '35', '1', '1', '', '', 'Mrs', 'Cheryl', 'Anderton', '', '4 Bonham Place', 'Carterton', 'Oxford', 'Oxfordshire', 'OX18 1EA', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('27', '36', '1', '1', '', '', 'Miss', 'Kate', 'Goldsack', '', '101 holly road', 'haydock', 'st helens', 'Merseyside', 'WA110JT', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('28', '37', '1', '1', '', '', 'Mrs', 'Stephanie', 'Nichols', '', '4 Newbridge Avenue', 'fulwell', 'Sunderland', 'Tyne and Wear', 'SR5 1LD', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('29', '38', '1', '1', '', '', 'Mrs', 'Lisa', 'Knowles', '', '22 Newquay Close', '', 'Hinckley', 'Leicestershire', 'LE10 1XN', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('30', '39', '1', '1', '', '', 'Miss', 'Nicole', 'Hayes', '', 'oak lodge', 'saltney gate, saracens head', 'holbeach', 'Lincolnshire', 'PE12 8AT', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('31', '40', '1', '1', '', '', 'Miss', 'Marianne', 'Pyfrom', '', '35 Brougham Rd', '', 'Southsea', 'Hampshire', 'Po5 4pa', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('32', '41', '1', '1', '', '', 'mrs', 'janet', 'mcgrail', '', '14 millview manor', '', 'dungannon', 'Tyrone', 'bt716us', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('33', '42', '1', '1', '', '', 'Dr', 'Suzana', 'Pavic', '', '61 Queenswood Drive', '', 'Sheffield', 'Yorkshire', 'S6 1RJ', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('34', '43', '1', '1', '', '', 'MRS', 'JULIE', 'NASH', '', '27 LIVESAY GARDENS', 'MILTON', 'PORTSMOUTH', 'Hampshire', 'PO3 6BN', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('35', '44', '1', '1', '', '', 'Mrs', 'Kellie', 'Johnson', '', '150 molesworth road', 'Stoke', 'Plymouth', '-- Please Select --', 'Pl34aj', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('36', '46', '1', '1', '', '', 'Miss', 'Nicki', 'Pearce', '', '49 crummock place', 'Bletchley', 'Milton keynes', 'Buckinghamshire', 'Mk2 3er', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('37', '47', '1', '1', '', '', '', 'Brianna', 'Robertson', '', 'PO Box 333', '', 'Otis', 'Oregon', '97368', '840'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('38', '48', '1', '1', '', '', 'Mrs', 'Danielle', 'Mullally', '', '10 Wyver Crescent', '', 'Coventry', 'West Midlands', 'CV25LQ', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('39', '49', '1', '1', '', '', 'mrs', 'margret', 'mcdonagh', '', '3 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('40', '50', '1', '1', '', '', 'Miss', 'Sophie', 'Rodwell', '', '1st james green', 'Castle acre', 'Kings Lynn', 'Norfolk', 'PE32 2BD', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('41', '51', '1', '1', '', '', 'Mrs', 'Margaret', 'Robertson', '', '74 Clifford Street', '', 'Glasgow', 'Lanarkshire', 'G51 1QB', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('42', '52', '1', '1', '', '', 'Miss', 'Helen', 'Ttofa', '', '130 Chorley new road', 'Horwich', 'Bolton', 'Lancashire', 'Bl65qn', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('43', '53', '1', '1', '', '', 'mrs', 'louise', 'grant', '', '38', 'st quintin park', 'brandesburton', 'Yorkshire', 'YO25 8SE', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('44', '54', '1', '1', '', '', 'Mrs', 'Julie', 'Jacobs-Jennings', '', '1008 Lady Jean Court', '', 'Midlothian, Va', 'Virginia', '23114', '840'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('45', '55', '1', '1', '', '', 'Mrs', 'Laura', 'Tyrer', '', '16 wicken bank', 'Heywood', 'Rochdale', 'Lancashire', 'Ol10 2lw', '826'); #EOQ
INSERT INTO `cc4_CubeCart_addressbook` VALUES('46', '57', '1', '1', '', '', 'Mrs', 'Denise', 'Townsend', '', '209 Farm View Road', 'Kimberworth', 'Rotherham', 'Yorkshire', 'S61 2BL', '826'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_admin_error_log`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_admin_error_log`
--

CREATE TABLE `cc4_CubeCart_admin_error_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `admin_id` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `read` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_admin_error_log`
--

INSERT INTO `cc4_CubeCart_admin_error_log` VALUES('1', '1', '1352290277', 'WARNING: Please delete the setup folder from your store directory, your store may be at risk until you do.', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_error_log` VALUES('2', '1', '1352290277', 'WARNING: Your includes/global.inc.php is currently writable, you should change the file permissions to read only. On Linux or Unix systems it should be CHMOD to 0444.', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_admin_log`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_admin_log`
--

CREATE TABLE `cc4_CubeCart_admin_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `description` text collate utf8_unicode_ci NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL,
  `admin_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`log_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=652 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_admin_log`
--

INSERT INTO `cc4_CubeCart_admin_log` VALUES('1', 'Admin logs have been deleted.', '1332329732', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('2', 'Cache cleared successfully.', '1332329737', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('3', 'Prices updated successfully.', '1332329818', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('4', 'Prices updated successfully.', '1332329933', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('5', '', '1332329984', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('6', 'Prices updated successfully.', '1332330324', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('7', 'Prices updated successfully.', '1332330357', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('8', 'Prices updated successfully.', '1332330357', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('9', 'Prices updated successfully.', '1332330373', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('10', 'Prices updated successfully.', '1332330447', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('11', 'Prices updated successfully.', '1332330479', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('12', 'Prices updated successfully.', '1332330501', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('13', 'Prices updated successfully.', '1332330517', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('14', 'Prices updated successfully.', '1332330540', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('15', 'Prices updated successfully.', '1332330559', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('16', 'Prices updated successfully.', '1332330585', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('17', 'Prices updated successfully.', '1332330611', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('18', 'Prices updated successfully.', '1332330625', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('19', 'Prices updated successfully.', '1332330643', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('20', 'Prices updated successfully.', '1332330662', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('21', 'Prices updated successfully.', '1332330706', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('22', '&#39;144 4mm Clear Silverback Rhinestones/Crystals&#39; updated successfully.', '1332330822', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('23', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1332330842', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('24', '&#39;144 4mm Orange AB Silverback Rhinestones&#39; updated successfully.', '1332330859', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('25', '&#39;144 4mm Lemon AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1332330883', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('26', '&#39;144 4mm Mint AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1332330904', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('27', '&#39;144 4mm Purple AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1332330919', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('28', '&#39;144 4mm Clear AB Hotfix Rhinestones&#39; updated successfully.', '1332330957', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('29', '&#39;144 4mm Emerald AB Hotfix Rhinestones&#39; updated successfully.', '1332331012', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('30', '&#39;144 4mm Clear AB Hotfix Rhinestones&#39; updated successfully.', '1332331038', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('31', '&#39;144 4mm Siam Ruby Hotfix Rhinestones&#39; updated successfully.', '1332334603', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('32', '&#39;144 4mm Sapphire Hotfix Rhinestones&#39; updated successfully.', '1332334649', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('33', '&#39;144 4mm Pink AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1332334675', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('34', '&#39;144 4mm Pink Silverback Rhinestones/Crystals&#39; updated successfully.', '1332334831', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('35', '&#39;144 5mm Topaz Silverback Rhinestones&#39; updated successfully.', '1332334924', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('36', '&#39;144 5mm Purple Silverback Rhinestones&#39; updated successfully.', '1332334957', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('37', '&#39;144 5mm Mint Green Silverback Rhinestones&#39; updated successfully.', '1332334981', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('38', '&#39;144 5mm Hot Pink Silverback Rhinestones&#39; updated successfully.', '1332335122', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('39', '&#39;144 5mm Aqua Blue Silverback Rhinestones&#39; updated successfully.', '1332335161', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('40', '&#39;144 4mm Aqua Blue Silverback Rhinestones/Crystals&#39; updated successfully.', '1332335341', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('41', '', '1332339203', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('42', 'Cache cleared successfully.', '1332339291', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('43', '', '1332342279', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('44', '', '1332505673', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('45', '', '1332752115', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('46', 'Cache cleared successfully.', '1332771871', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('47', 'Cache cleared successfully.', '1332772143', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('48', 'Cache cleared successfully.', '1332774022', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('49', 'Cache cleared successfully.', '1332774718', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('50', '&#39;144 2mm (SS6) Fushia Pink AB DMC Hotfix Rhinestones&#39; updated successfully.', '1332780535', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('51', '&#39;Childrens Dance Wear&#39; updated successfully.', '1332840303', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('52', '', '1332845044', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('53', 'Configuration Updated.', '1332845114', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('54', 'Cache cleared successfully.', '1332845397', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('55', '', '1332846073', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('56', 'Configuration Updated.', '1332846104', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('57', 'Configuration Updated.', '1332846120', '86.166.68.171', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('58', 'Configuration Updated.', '1332854715', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('59', '', '1333029053', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('60', 'Configuration Updated.', '1333029075', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('61', 'Configuration Updated.', '1333029091', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('62', 'Cache cleared successfully.', '1333029891', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('63', 'Cache cleared successfully.', '1333030467', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('64', '', '1333031239', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('65', 'Configuration Updated.', '1333031259', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('66', '', '1333031262', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('67', 'Configuration Updated.', '1333031270', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('68', '', '1333368488', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('69', 'Configuration Updated.', '1333368534', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('70', '', '1333369385', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('71', 'Configuration Updated.', '1333369400', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('72', '&#39;Up and Coming ISTD Dance Comps&#39; updated successfully.', '1333371855', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('73', '&#39;Up and Coming ISTD Dance Comps&#39; updated successfully.', '1333372153', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('74', 'Customer updated successfully.', '1334581903', '82.27.226.223', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('75', '&#39;Second Hand Pink Slow Costume&#39; added successfully.', '1335177069', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('76', '&#39;Second Hand Dancewear&#39; updated successfully.', '1335177341', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('77', 'Image database has been updated.', '1335177479', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('78', 'Image added to product.', '1335177529', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('79', 'Image added to product.', '1335177553', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('80', 'Image added to product.', '1335177556', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('81', 'Image removed from product.', '1335177595', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('82', 'Selected thumbnails have been created or rebuilt.', '1335177628', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('83', 'Image database has been updated.', '1335177912', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('84', 'Selected thumbnails have been created or rebuilt.', '1335177933', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('85', '&#39;Second Hand Crop Top and Shorts&#39; added successfully.', '1335179074', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('86', 'Image added to product.', '1335179165', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('87', 'Image database has been updated.', '1335179353', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('88', 'Selected thumbnails have been created or rebuilt.', '1335179376', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('89', '&#39;Second Hand Blue Disco Costume&#39; added successfully.', '1335179526', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('90', 'Image added to product.', '1335179564', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('91', 'Image database has been updated.', '1335180540', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('92', '&#39;Second Hand Aqua blue and pink poodle rock and roll outfit&#39; added successfully.', '1335180885', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('93', 'Product added to category.', '1335181004', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('94', '&#39;Second Hand Aqua blue and pink poodle rock and roll outfit&#39; updated successfully.', '1335181018', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('95', 'Image database has been updated.', '1335181028', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('96', 'Selected thumbnails have been created or rebuilt.', '1335181052', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('97', '&#39;Second Hand Pink Slow Costume&#39; updated successfully.', '1335183533', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('98', 'Image database has been updated.', '1335357770', '92.40.253.35', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('99', 'Selected thumbnails have been created or rebuilt.', '1335357815', '92.40.253.35', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('100', 'Selected thumbnails have been created or rebuilt.', '1335358115', '92.40.253.35', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('101', 'Image database has been updated.', '1335374188', '92.40.253.35', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('102', '&#39;Completed Disco Outfit&#39; added successfully.', '1335425545', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('103', '&#39;Completed Disco Outfit&#39; updated successfully.', '1335425615', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('104', 'Image added to product.', '1335425642', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('105', 'Image added to product.', '1335425647', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('106', 'Image added to product.', '1335425654', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('107', 'Image added to product.', '1335425663', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('108', 'Image added to product.', '1335425666', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('109', 'Image added to product.', '1335425670', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('110', '&#39;Completed Disco Outfit&#39; updated successfully.', '1335425692', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('111', 'Quick Assign of product options success.', '1335425712', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('112', '&#39;Completed Disco Outfit&#39; updated successfully.', '1335425786', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('113', '', '1335426334', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('114', 'Configuration Updated.', '1335426352', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('115', 'Configuration Updated.', '1335426379', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('116', '', '1335428017', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('117', '', '1335428033', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('118', '&#39;Your Basket&#39; added successfully.', '1335428060', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('119', '&#39;Complete Disco Outfit&#39; updated successfully.', '1335441272', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('120', '&#39;PnP Lycra Leotard&#39; added successfully.', '1335442228', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('121', 'Image added to product.', '1335442288', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('122', 'Image added to product.', '1335442293', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('123', 'Image added to product.', '1335442299', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('124', '&#39;PnP Lycra Leotard&#39; updated successfully.', '1335442332', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('125', 'Quick Assign of product options success.', '1335442353', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('126', '&#39;PnP Lycra Leotard&#39; updated successfully.', '1335443401', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('127', '', '1335443421', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('128', 'Configuration Updated.', '1335443449', '195.212.29.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('129', 'Language `/en/email.inc.php` updated successfully.', '1335514612', '86.178.179.21', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('130', '&#39;PnP 3/4 Length Lycra Catsuit with Puffed Sleeves&#39; added successfully.', '1335530623', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('131', 'Image added to product.', '1335530660', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('132', 'Image added to product.', '1335530664', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('133', 'Quick Assign of product options success.', '1335530685', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('134', '&#39;PnP 3/4 Length Lycra Catsuit with Puffed Sleeves&#39; updated successfully.', '1335598751', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('135', '&#39;2nd hand White Solo Slow Costume&#39; updated successfully.', '1335705358', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('136', '&#39;2nd hand Peach and White Slow Costume&#39; updated successfully.', '1335705432', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('137', '&#39;Second hand Peach and White Slow Costume&#39; updated successfully.', '1335705565', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('138', '&#39;Second hand White Solo Slow Costume&#39; updated successfully.', '1335705627', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('139', '&#39;PnP Lycra Leotard with Long Sleeves&#39; added successfully.', '1335787778', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('140', '&#39;PnP Lycra Leotard with Long Sleeves&#39; updated successfully.', '1335787855', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('141', 'Quick Assign of product options success.', '1335789287', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('142', 'Selected thumbnails have been created or rebuilt.', '1335790780', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('143', 'Image database has been updated.', '1335790892', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('144', 'Image added to product.', '1335790981', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('145', 'Image added to product.', '1335790985', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('146', '&#39;Kerry Fabian-Lovely&#39; updated successfully.', '1335870803', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('147', 'Image database has been updated.', '1335970588', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('148', 'Selected thumbnails have been created or rebuilt.', '1335970637', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('149', 'Image database has been updated.', '1335970660', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('150', '&#39; Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories&#39; added successfully.', '1335970858', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('151', 'Image added to product.', '1335970892', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('152', 'Image added to product.', '1335970896', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('153', 'Image added to product.', '1335970899', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('154', 'Image added to product.', '1335970902', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('155', 'Image added to product.', '1335970911', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('156', 'Image added to product.', '1335970925', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('157', 'Image added to product.', '1335970932', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('158', 'Image added to product.', '1335970937', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('159', 'Quick Assign of product options success.', '1335970963', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('160', '&#39;Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories&#39; updated successfully.', '1335971023', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('161', '&#39;Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories&#39; updated successfully.', '1335971183', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('162', '&#39;Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories&#39; updated successfully.', '1335971382', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('163', 'Configuration Updated.', '1336131275', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('164', 'Configuration Updated.', '1336131302', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('165', 'No changes have been made!', '1336131511', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('166', 'Configuration Updated.', '1336143124', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('167', '&#39;Rock &#39;n&#39; Roll Outfits&#39; updated successfully.', '1336143273', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('168', '&#39;Second Hand Dancewear&#39; updated successfully.', '1336143813', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('169', 'Image database has been updated.', '1336143832', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('170', 'Selected thumbnails have been created or rebuilt.', '1336143884', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('171', 'Selected thumbnails have been created or rebuilt.', '1336143913', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('172', '&#39;Previously Owned and Loved Hand Dancewear&#39; updated successfully.', '1336143962', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('173', '&#39;Second Hand Crop Top and Shorts&#39; updated successfully.', '1336144008', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('174', '&#39;Second Hand Blue Disco Costume&#39; updated successfully.', '1336144041', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('175', '&#39;Second Hand Pink Slow Costume&#39; updated successfully.', '1336144061', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('176', '&#39;Second Hand Aqua blue and pink poodle rock and roll outfit&#39; updated successfully.', '1336144083', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('177', '&#39;Previously Owned Freestyle Disco Solo Costume&#39; added successfully.', '1336144189', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('178', 'Image added to product.', '1336144246', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('179', 'Image added to product.', '1336144250', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('180', 'Image added to product.', '1336144254', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('181', 'Image added to product.', '1336144260', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('182', 'Image added to product.', '1336144264', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('183', '&#39;Previously Owned and Loved Dancewear&#39; updated successfully.', '1336144327', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('184', 'Configuration Updated.', '1336331386', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('185', 'Configuration Updated.', '1336331943', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('186', 'Configuration Updated.', '1336331964', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('187', 'Configuration Updated.', '1336331977', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('188', 'No changes have been made!', '1336332269', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('189', 'Deleted successfully.', '1336469329', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('190', 'Deleted successfully.', '1336469336', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('191', 'Deleted successfully.', '1336469341', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('192', '&#39;144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones&#39; updated successfully.', '1336552139', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('193', '&#39;144 4mm Lemon AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1336552189', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('194', '&#39;144 4mm Orange AB Silverback Rhinestones&#39; updated successfully.', '1336552292', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('195', '&#39;144 4mm Pink Silverback Rhinestones/Crystals&#39; updated successfully.', '1336552316', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('196', '&#39;144 4mm Mint AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1336552356', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('197', '&#39;144 4mm Purple AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1336552376', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('198', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1336552441', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('199', '&#39;144 5mm Hot Pink Silverback Rhinestones&#39; updated successfully.', '1336552518', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('200', '', '1336656370', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('201', 'Configuration Updated.', '1336656379', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('202', 'Configuration Updated.', '1336657930', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('203', 'Deleted successfully.', '1336658504', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('204', '', '1336659665', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('205', 'Configuration Updated.', '1336659675', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('206', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1336725607', '86.174.165.24', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('207', '&#39;144 2mm (SS6) Black AB DMC Hotfix Rhinestones&#39; updated successfully.', '1337167015', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('208', '&#39;144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones&#39; updated successfully.', '1337167037', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('209', 'Deleted successfully.', '1337196231', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('210', 'Deleted successfully.', '1337196246', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('211', '', '1337240006', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('212', 'Configuration Updated.', '1337240016', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('213', 'Configuration Updated.', '1337240082', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('214', 'Selected thumbnails have been created or rebuilt.', '1337240569', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('215', 'Selected thumbnails have been created or rebuilt.', '1337240595', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('216', 'Selected thumbnails have been created or rebuilt.', '1337240614', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('217', 'Selected thumbnails have been created or rebuilt.', '1337240627', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('218', 'Selected thumbnails have been created or rebuilt.', '1337240638', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('219', 'Selected thumbnails have been created or rebuilt.', '1337240663', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('220', 'Selected thumbnails have been created or rebuilt.', '1337240677', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('221', 'Image database has been updated.', '1337240696', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('222', 'Image database has been updated.', '1337241104', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('223', 'Configuration Updated.', '1337241107', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('224', 'Selected thumbnails have been created or rebuilt.', '1337241141', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('225', 'Selected thumbnails have been created or rebuilt.', '1337241162', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('226', '', '1337241429', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('227', 'Configuration Updated.', '1337241442', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('228', '', '1337596274', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('229', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1337598935', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('230', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1337598992', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('231', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1337754756', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('232', '&#39;144 SS20 5mm Clear AB Silverback Rhinestones/Crystals&#39; added successfully.', '1337755274', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('233', 'Configuration Updated.', '1337779730', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('234', 'Coupon added successfully.', '1337780090', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('235', '&#39;144 4mm Clear Silverback Rhinestones/Crystals&#39; updated successfully.', '1337780978', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('236', '&#39;144 SS20 5mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1337840793', '82.8.11.200', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('237', '&#39;144 5mm (SS20) Siam Ruby DMC Hotfix Rhinestones&#39; updated successfully.', '1338991645', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('238', 'Deleted successfully.', '1339081112', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('239', '', '1339421128', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('240', '', '1339492489', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('241', '', '1339495800', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('242', '', '1339496532', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('243', '', '1339496699', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('244', '', '1339499324', '82.18.103.109', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('245', 'Cache cleared successfully.', '1339583079', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('246', 'Cache cleared successfully.', '1339590740', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('247', '&#39;144 4mm Clear AB Silverback Rhinestones/Crystals&#39; updated successfully.', '1344505205', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('248', 'No changes have been made!', '1346319780', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('249', '', '1346319802', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('250', 'Configuration Updated.', '1346319810', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('251', '&#39;Blinged Competition pins&#39; added successfully.', '1346743829', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('252', '&#39;Blinged Competition pins&#39; updated successfully.', '1346743923', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('253', 'Option name added.', '1346743986', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('254', 'Product option name was not updated.', '1346744028', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('255', 'Option attribute added.', '1346744040', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('256', 'Option attribute added.', '1346744052', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('257', 'Option attribute added.', '1346744075', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('258', 'Option attribute added.', '1346744086', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('259', 'Option attribute added.', '1346744120', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('260', 'Option attribute added.', '1346744154', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('261', 'Option attribute added.', '1346744213', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('262', 'Option attribute added.', '1346744254', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('263', '&#39;Blinged Competition pins&#39; updated successfully.', '1346745094', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('264', '&#39;Blinged Competition pins&#39; updated successfully.', '1346745184', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('265', 'Selected thumbnails have been created or rebuilt.', '1346745321', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('266', 'Selected thumbnails have been created or rebuilt.', '1346745646', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('267', 'Selected thumbnails have been created or rebuilt.', '1346745659', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('268', 'Selected thumbnails have been created or rebuilt.', '1346745758', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('269', 'Selected thumbnails have been created or rebuilt.', '1346745799', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('270', 'Selected thumbnails have been created or rebuilt.', '1346745845', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('271', 'Selected thumbnails have been created or rebuilt.', '1346746002', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('272', 'Please check at least one thumbnail to build or rebuild.', '1346746459', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('273', 'Selected thumbnails have been created or rebuilt.', '1346746475', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('274', 'Selected thumbnails have been created or rebuilt.', '1346746495', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('275', 'Selected thumbnails have been created or rebuilt.', '1346746591', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('276', 'Selected thumbnails have been created or rebuilt.', '1346746607', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('277', 'Image database has been updated.', '1346746626', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('278', 'Selected thumbnails have been created or rebuilt.', '1346747194', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('279', '&#39;Green Butterfly Costume&#39; updated successfully.', '1346747956', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('280', '&#39;Previously loved Green Disco Costume&#39; added successfully.', '1346750048', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('281', 'Selected thumbnails have been created or rebuilt.', '1346750109', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('282', 'Image database has been updated.', '1346750387', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('283', 'Image added to product.', '1346750415', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('284', 'Updated successfully.', '1346760205', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('285', '&#39;Brand New Blinged Costumes&#39; updated successfully.', '1346760319', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('286', '&#39;Previously Owned and Loved Dancewear&#39; updated successfully.', '1346760365', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('287', '&#39;Brand New Blinged Costumes&#39; updated successfully.', '1346760411', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('288', 'Updated successfully.', '1346760416', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('289', '&#39;Rock n Roll Bright Pairs Costumes&#39; added successfully.', '1346760739', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('290', 'Image database has been updated.', '1346760751', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('291', 'Selected thumbnails have been created or rebuilt.', '1346760782', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('292', 'Selected thumbnails have been created or rebuilt.', '1346760801', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('293', 'Deleted successfully.', '1346760869', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('294', '&#39;Pair of Disco Blinged Costumes&#39; added successfully.', '1346761542', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('295', '&#39;Pair of Disco Blinged Costumes&#39; updated successfully.', '1346761595', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('296', '&#39;Pair of Disco Blinged Costumes&#39; updated successfully.', '1346761639', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('297', '&#39;WOW! Brand new Solo Costume&#39; added successfully.', '1346925185', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('298', '&#39;WOW! Brand new Solo Costume&#39; updated successfully.', '1346925212', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('299', 'Image database has been updated.', '1346925241', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('300', 'Selected thumbnails have been created or rebuilt.', '1346925308', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('301', 'Image added to product.', '1346925329', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('302', 'Image added to product.', '1346925332', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('303', 'Updated successfully.', '1346925365', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('304', '&#39;Brand New Blinged Costumes&#39; updated successfully.', '1346925405', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('305', 'Cache cleared successfully.', '1346941285', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('306', '&#39;Dancing Accessories&#39; added successfully.', '1348669513', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('307', '&#39;Blinged Competition pins&#39; updated successfully.', '1348669568', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('308', '', '1349358699', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('309', '', '1349358712', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('310', '', '1349365487', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('311', '&#39;Bespoke Costumes&#39; added successfully.', '1349369262', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('312', '', '1349369307', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('313', '', '1349369313', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('314', '', '1349369317', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('315', '', '1349369322', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('316', '', '1349369330', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('317', '', '1349369339', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('318', '', '1349369345', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('319', '', '1349369350', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('320', '', '1349369404', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('321', '', '1349369431', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('322', '&#39;Bespoke Costumes&#39; updated successfully.', '1349369443', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('323', '', '1349369458', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('324', '&#39;Bespoke Costumes&#39; updated successfully.', '1349369481', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('325', '', '1349369504', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('326', '&#39;Bespoke Costumes&#39; updated successfully.', '1349369517', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('327', '&#39;Brand New Blinged Costumes&#39; updated successfully.', '1349369758', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('328', '', '1349885902', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('329', 'Configuration Updated.', '1349885916', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('330', 'Configuration Updated.', '1349885933', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('331', 'Configuration Updated.', '1349885963', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('332', 'Configuration Updated.', '1349885989', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('333', '', '1349952659', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('334', 'Configuration Updated.', '1349952690', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('335', 'Configuration Updated.', '1349952984', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('336', 'Configuration Updated.', '1349953038', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('337', '`en` updated successfully.', '1349953213', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('338', '', '1349953259', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('339', 'Configuration Updated.', '1349953274', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('340', 'Configuration Updated.', '1349953349', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('341', 'Configuration Updated.', '1349953432', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('342', '`en` updated successfully.', '1349953740', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('343', '`en` updated successfully.', '1349953889', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('344', 'Cache cleared successfully.', '1349959135', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('345', '', '1349960126', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('346', 'Configuration Updated.', '1349960137', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('347', 'Configuration Updated.', '1349960145', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('348', 'Configuration Updated.', '1349962102', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('349', 'Configuration Updated.', '1349962115', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('350', 'Product option name updated successfully.', '1349964560', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('351', 'Product option name updated successfully.', '1349964610', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('352', 'Product option name updated successfully.', '1349964642', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('353', '', '1349964823', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('354', '', '1349966216', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('355', 'Cache cleared successfully.', '1349966290', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('356', '', '1349966467', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('357', '', '1349966662', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('358', '', '1349966764', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('359', '', '1349966786', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('360', '', '1349966799', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('361', '', '1349967027', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('362', '', '1349967055', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('363', '', '1349968041', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('364', 'Configuration Updated.', '1349968056', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('365', 'Configuration Updated.', '1350045479', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('366', 'Cache cleared successfully.', '1350046400', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('367', 'Cache cleared successfully.', '1350047178', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('368', '', '1350049458', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('369', 'Configuration Updated.', '1350049498', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('370', '', '1350049560', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('371', 'Cache cleared successfully.', '1350049713', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('372', 'Cache cleared successfully.', '1350050160', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('373', 'Category recount successfull.', '1350050167', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('374', 'Cache cleared successfully.', '1350051101', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('375', '', '1350052107', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('376', 'Configuration Updated.', '1350052128', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('377', '', '1350143153', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('378', '', '1350293173', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('379', 'Configuration Updated.', '1350293188', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('380', 'Configuration Updated.', '1350293461', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('381', 'Cache cleared successfully.', '1350294845', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('382', '', '1350295321', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('383', 'Configuration Updated.', '1350295407', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('384', 'Configuration Updated.', '1350295451', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('385', 'Configuration Updated.', '1350295914', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('386', 'Cache cleared successfully.', '1350295928', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('387', 'Cache cleared successfully.', '1350295959', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('388', 'Configuration Updated.', '1350296712', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('389', 'Cache cleared successfully.', '1350296751', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('390', 'Configuration Updated.', '1350296825', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('391', 'Cache cleared successfully.', '1350300365', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('392', '`en` updated successfully.', '1350300753', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('393', '`en` updated successfully.', '1350300779', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('394', '`en` updated successfully.', '1350300806', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('395', '`en` updated successfully.', '1350300827', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('396', '`en` updated successfully.', '1350300871', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('397', '`en` updated successfully.', '1350300935', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('398', '', '1350300939', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('399', 'Configuration Updated.', '1350300950', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('400', 'Cache cleared successfully.', '1350306434', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('401', '', '1350307295', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('402', 'Configuration Updated.', '1350307313', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('403', 'Configuration Updated.', '1350307389', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('404', 'Configuration Updated.', '1350307624', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('405', 'Configuration Updated.', '1350307648', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('406', 'Configuration Updated.', '1350309951', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('407', '`en` updated successfully.', '1350310181', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('408', '`en` updated successfully.', '1350310332', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('409', 'Configuration Updated.', '1350310587', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('410', 'Image database has been updated.', '1350310591', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('411', 'Cache cleared successfully.', '1350311142', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('412', '`en` updated successfully.', '1350311359', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('413', '`en` updated successfully.', '1350311369', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('414', '`en` updated successfully.', '1350311547', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('415', '`en` updated successfully.', '1350311578', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('416', 'Cache cleared successfully.', '1350312662', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('417', '', '1350313850', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('418', '', '1350313864', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('419', '&#39;Bespoke Measurement Form&#39; added successfully.', '1350315032', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('420', '', '1350315123', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('421', '&#39;Bespoke Measurement Form&#39; updated successfully.', '1350315216', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('422', '', '1350315411', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('423', '&#39;Bespoke Measurement Form&#39; updated successfully.', '1350318851', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('424', '', '1350318895', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('425', '&#39;Bespoke Measurement Form&#39; was not updated.', '1350318918', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('426', '', '1350318960', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('427', '&#39;Bespoke Measurement Form&#39; updated successfully.', '1350318967', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('428', '', '1350319121', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('429', '&#39;Bespoke Measurement Form&#39; updated successfully.', '1350320287', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('430', '', '1350320466', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('431', '&#39;Bespoke Measurement Form&#39; updated successfully.', '1350320523', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('432', 'Document deleted successfully.', '1350320542', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('433', '', '1350320558', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('434', 'Configuration Updated.', '1350320570', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('435', 'Cache cleared successfully.', '1350322415', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('436', 'Cache cleared successfully.', '1350322493', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('437', 'Cache cleared successfully.', '1350324465', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('438', 'Configuration Updated.', '1350328841', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('439', '', '1350331611', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('440', '&#39;Blinged Competition pins&#39; updated successfully.', '1350331728', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('441', '', '1350331786', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('442', '', '1350378586', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('443', '', '1350378601', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('444', '', '1350378648', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('445', '', '1350378672', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('446', '', '1350378681', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('447', '', '1350378689', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('448', '', '1350378694', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('449', '', '1350378697', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('450', '', '1350378720', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('451', '&#39;About Us&#39; updated successfully.', '1350378732', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('452', 'Configuration Updated.', '1350465997', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('453', 'Coupon added successfully.', '1350466995', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('454', 'Coupon status changed successfully.', '1350467009', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('455', 'Coupon status changed successfully.', '1350467024', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('456', 'Coupon deleted successfully.', '1350467036', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('457', '', '1350468709', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('458', '', '1350468716', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('459', '', '1350468791', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('460', '', '1350469068', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('461', '', '1350470315', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('462', '', '1350470337', '195.212.29.84', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('463', 'Cache cleared successfully.', '1350558101', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('464', 'Cache cleared successfully.', '1350653635', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('465', '', '1350891175', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('466', 'Configuration Updated.', '1350891231', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('467', '', '1350895664', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('468', 'Configuration Updated.', '1350895672', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('469', 'Review (id 1) is now unpublished and not live.', '1351025594', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('470', '', '1351069171', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('471', 'Update of Review/Comment failed.', '1351069644', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('472', 'Review (id 2) has been deleted.', '1351069651', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('473', 'No product reviews have been made or match that criteria.', '1351069654', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('474', '', '1351073890', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('475', 'Configuration Updated.', '1351073902', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('476', 'Configuration Updated.', '1351079650', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('477', 'Review (id 3) is now unpublished and not live.', '1351088205', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('478', 'No product reviews have been made or match that criteria.', '1351088215', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('479', 'No product reviews have been made or match that criteria.', '1351090968', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('480', '', '1351090972', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('481', 'Configuration Updated.', '1351091393', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('482', 'Configuration Updated.', '1351092233', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('483', 'Cache cleared successfully.', '1351092352', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('484', 'Cache cleared successfully.', '1351092626', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('485', 'Cache cleared successfully.', '1351092757', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('486', 'Cache cleared successfully.', '1351092985', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('487', 'Cache cleared successfully.', '1351093170', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('488', 'Cache cleared successfully.', '1351093249', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('489', 'Cache cleared successfully.', '1351093315', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('490', '', '1351093548', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('491', 'Configuration Updated.', '1351093556', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('492', 'Configuration Updated.', '1351093630', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('493', 'Configuration Updated.', '1351093745', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('494', 'Configuration Updated.', '1351093761', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('495', '', '1351098535', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('496', 'Configuration Updated.', '1351098567', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('497', '', '1351099743', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('498', 'Configuration Updated.', '1351099754', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('499', 'Configuration Updated.', '1351100001', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('500', 'Configuration Updated.', '1351100593', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('501', 'Configuration Updated.', '1351101207', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('502', '', '1351152066', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('503', 'Configuration Updated.', '1351152088', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('504', 'Cache cleared successfully.', '1351153699', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('505', '', '1351154420', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('506', 'Configuration Updated.', '1351154429', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('507', 'Configuration Updated.', '1351154554', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('508', 'Configuration Updated.', '1351154562', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('509', '', '1351154732', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('510', 'Configuration Updated.', '1351154932', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('511', 'Cache cleared successfully.', '1351155091', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('512', 'Configuration Updated.', '1351158926', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('513', '', '1351159212', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('514', 'Configuration Updated.', '1351159233', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('515', 'Coupon added successfully.', '1351169938', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('516', 'No product reviews have been made or match that criteria.', '1351420333', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('517', 'No product reviews have been made or match that criteria.', '1351586060', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('518', 'No product reviews have been made or match that criteria.', '1351591565', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('519', 'No product reviews have been made or match that criteria.', '1351672314', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('520', 'No product reviews have been made or match that criteria.', '1351678257', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('521', 'Review (id 8) has been deleted.', '1351849359', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('522', 'Review (id 7) has been deleted.', '1351849363', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('523', 'No product reviews have been made or match that criteria.', '1351849366', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('524', '&#39;PnP Dance Tracksuits&#39; added successfully.', '1352110958', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('525', 'Selected thumbnails have been created or rebuilt.', '1352111164', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('526', 'Image database has been updated.', '1352111265', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('527', 'Image added to product.', '1352111331', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('528', 'Image added to product.', '1352111337', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('529', 'Image added to product.', '1352111342', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('530', 'Image added to product.', '1352111348', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('531', 'Image added to product.', '1352111360', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('532', '&#39;PnP Dance Tracksuits&#39; updated successfully.', '1352111392', '82.14.1.87', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('533', '', '1352286624', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('534', 'Configuration Updated.', '1352286637', '195.212.29.85', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('535', 'Settings updated.', '1352290140', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('536', 'File(s) uploaded successfully.', '1352290223', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('537', 'Review statuses updated.', '1352290297', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('538', 'Module settings for &quot;Fusion&quot; saved.', '1352291589', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('539', 'Settings updated.', '1352292164', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('540', 'Settings updated.', '1352292198', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('541', 'File(s) uploaded successfully.', '1352292840', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('542', 'File(s) uploaded successfully.', '1352292867', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('543', 'File(s) uploaded successfully.', '1352292887', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('544', 'Settings updated.', '1352293553', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('545', 'Settings updated.', '1352293619', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('546', 'Settings updated.', '1352293660', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('547', '.htaccess file updated.', '1352293749', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('548', 'Settings updated.', '1352293880', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('549', 'Logo uploaded.', '1352294330', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('550', 'Settings updated.', '1352294330', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('551', 'Settings updated.', '1352297550', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('552', 'Cache has been cleared.', '1352297805', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('553', 'Cache has been cleared.', '1352297805', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('554', 'Cache has been cleared.', '1352297805', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('555', 'Image cache has been cleared.', '1352297806', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('556', 'Settings updated.', '1352299023', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('557', 'Settings updated.', '1352299179', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('558', 'Settings updated.', '1352299541', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('559', 'Logo uploaded.', '1352299606', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('560', 'Settings updated.', '1352299606', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('561', 'Settings updated.', '1352299665', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('562', '.htaccess file updated.', '1352300664', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('563', 'Module settings for &quot;Facebook&quot; saved.', '1352301422', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('564', 'Cache has been cleared.', '1352301875', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('565', 'Cache has been cleared.', '1352301875', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('566', 'Cache has been cleared.', '1352301875', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('567', 'Image cache has been cleared.', '1352301875', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('568', 'Settings updated.', '1352302700', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('569', 'Module settings for &quot;olark&quot; saved.', '1352303653', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('570', 'Module settings for &quot;olark&quot; saved.', '1352303661', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('571', 'Module settings for &quot;olark&quot; saved.', '1352303676', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('572', 'Module settings for &quot;Google Checkout&quot; saved.', '1352303768', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('573', 'Module settings for &quot;Google Checkout&quot; saved.', '1352303796', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('574', 'Module settings for &quot;Google Checkout&quot; saved.', '1352303808', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('575', 'Settings updated.', '1352304940', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('576', 'Settings updated.', '1352304951', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('577', 'Settings updated.', '1352305396', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('578', 'Order successfully deleted.', '1352305441', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('579', 'Settings updated.', '1352306731', '195.212.29.85', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('580', 'Settings updated.', '1352367004', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('581', 'Sitemap.xml successfully rebuilt.', '1352367132', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('582', 'Language status successfully updated.', '1352367201', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('583', 'Settings updated.', '1352367583', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('584', 'Settings updated.', '1352367648', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('585', 'Settings updated.', '1352367716', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('586', 'Settings updated.', '1352367791', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('587', 'Settings updated.', '1352368267', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('588', 'Settings updated.', '1352368343', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('589', 'Category successfully updated.', '1352370075', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('590', 'Category successfully updated.', '1352370094', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('591', 'Products found matching \'R\'.', '1352370432', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('592', 'Product successfully updated.', '1352370457', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('593', 'Products found matching \'R\'.', '1352370458', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('594', 'Module settings for &quot;PayPal Pro&quot; saved.', '1352371912', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('595', 'Settings updated.', '1352372010', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('596', 'Settings updated.', '1352372027', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('597', 'Settings updated.', '1352377207', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('598', 'Logo uploaded.', '1352381602', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('599', 'Settings updated.', '1352381602', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('600', 'Settings updated.', '1352381958', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('601', 'Customer accounts matching \'dyndesmespi@aol.com\'', '1352384969', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('602', 'Settings updated.', '1352385009', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('603', 'Products found matching \'P\'.', '1352392625', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('604', 'Products found matching \'P\'.', '1352392631', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('605', 'Product successfully updated.', '1352392697', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('606', 'Products found matching \'P\'.', '1352392697', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('607', 'Module settings for &quot;Fusion&quot; saved.', '1352449039', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('608', 'Cache has been cleared.', '1352452662', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('609', 'Cache has been cleared.', '1352452662', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('610', 'Cache has been cleared.', '1352452662', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('611', 'Image cache has been cleared.', '1352452662', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('612', 'Settings updated.', '1352453377', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('613', 'Cache has been cleared.', '1352456437', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('614', 'Cache has been cleared.', '1352456437', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('615', 'Cache has been cleared.', '1352456437', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('616', 'Image cache has been cleared.', '1352456437', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('617', 'Logo uploaded.', '1352471558', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('618', 'Settings updated.', '1352471558', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('619', 'Settings updated.', '1352471569', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('620', 'Logo removed', '1352471952', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('621', 'Logo removed', '1352471968', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('622', 'Logo uploaded.', '1352471992', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('623', 'Settings updated.', '1352471992', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('624', 'Settings updated.', '1352472003', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('625', 'Logo uploaded.', '1352472527', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('626', 'Settings updated.', '1352472527', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('627', 'Settings updated.', '1352472536', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('628', 'Cache has been cleared.', '1352473492', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('629', 'Logo uploaded.', '1352474693', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('630', 'Settings updated.', '1352474693', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('631', 'Settings updated.', '1352474709', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('632', 'Cache has been cleared.', '1352474897', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('633', 'Document successfully updated.', '1352475739', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('634', 'Document successfully updated.', '1352476044', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('635', 'Document successfully updated.', '1352476090', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('636', 'Settings updated.', '1352476910', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('637', 'Settings updated.', '1352478520', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('638', 'Settings updated.', '1352929691', '82.3.245.142', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('639', 'Settings updated.', '1352929970', '82.3.245.142', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('640', 'Settings updated.', '1352930208', '82.3.245.142', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('641', 'Settings updated.', '1352933032', '82.3.245.142', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('642', 'Settings updated.', '1352976001', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('643', 'Settings updated.', '1352979784', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('644', 'Cache has been cleared.', '1353319413', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('645', 'Cache has been cleared.', '1353319413', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('646', 'Image cache has been cleared.', '1353319414', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('647', 'Cache has been cleared.', '1353319426', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('648', 'Cache has been cleared.', '1353319435', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('649', 'Cache has been cleared.', '1353319677', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('650', 'Cache has been cleared.', '1353319677', '82.14.1.87', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_log` VALUES('651', 'Image cache has been cleared.', '1353319677', '82.14.1.87', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_admin_users`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_admin_users`
--

CREATE TABLE `cc4_CubeCart_admin_users` (
  `admin_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `username` varchar(150) collate utf8_unicode_ci NOT NULL,
  `password` varchar(128) collate utf8_unicode_ci default NULL,
  `salt` varchar(32) collate utf8_unicode_ci default NULL,
  `email` varchar(254) collate utf8_unicode_ci NOT NULL,
  `logins` int(10) unsigned NOT NULL default '0',
  `super_user` tinyint(1) unsigned NOT NULL default '0',
  `notes` text collate utf8_unicode_ci,
  `session_id` varchar(32) collate utf8_unicode_ci default NULL,
  `browser` text collate utf8_unicode_ci,
  `ip_address` varchar(45) collate utf8_unicode_ci default NULL,
  `failLevel` smallint(1) NOT NULL default '0',
  `blockTime` int(10) NOT NULL default '0',
  `lastTime` int(10) NOT NULL default '0',
  `customer_id` int(10) unsigned default NULL,
  `status` tinyint(1) unsigned NOT NULL default '0',
  `verify` varchar(32) collate utf8_unicode_ci default NULL,
  `language` varchar(5) collate utf8_unicode_ci NOT NULL default 'en-US',
  `dashboard_notes` text collate utf8_unicode_ci,
  `order_notify` tinyint(1) unsigned default NULL,
  `new_password` tinyint(1) NOT NULL default '1',
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_admin_users`
--

INSERT INTO `cc4_CubeCart_admin_users` VALUES('1', 'Mark Fabain-Lovely', 'pnpdance_admin', '259ad08236ff87f62c0ff2e1b68eb60ef58bd3507a17b5177c54cfc5baacbf6f813f144cfd6d631be4f11cc4e9d123494475e92212698f3f67ff93093ef3d490', '179e52d5', 'mark@pnpdance.com', '295', '1', 'This user was setup during installation.', 'cebd5c993e74e6656c9d2bea12ecf605', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', '82.14.1.87', '0', '0', '1353330231', '', '1', '', 'en-US', '', '', '1'); #EOQ
INSERT INTO `cc4_CubeCart_admin_users` VALUES('2', 'Kerry Fabian-Lovely', 'kerry', '91ac3accdd1769b49d01c1e147e00c71', 'LeCpeZ', 'kerry@pnpdance.com', '16', '0', '', '09359831df7fca76cb224d87df451232', 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100101 Firefox/11.0', '86.181.54.69', '0', '0', '1329821180', '', '1', '', 'en-US', '', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_admin_users` VALUES('5', 'Tuesday Young', 'Tuesday', '6c01ed2fca9acea962b10b16955b53ea', 'zcPHrS', 'needles.and.pins@hotmail.co.uk', '14', '0', '', '66abbcc674c44454fb89ff0b66dc3b36', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_5 like Mac OS X; en-gb) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8L1 Safari/6533.18.5', '2.123.166.239', '0', '0', '0', '', '1', '', 'en-US', '', '', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_alt_shipping`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_alt_shipping`
--

CREATE TABLE `cc4_CubeCart_alt_shipping` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `status` smallint(1) NOT NULL default '0',
  `byprice` smallint(1) NOT NULL,
  `global` smallint(1) NOT NULL,
  `notes` varchar(255) collate utf8_unicode_ci default NULL,
  `order` int(10) default '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_alt_shipping` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_alt_shipping_prices`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_alt_shipping_prices`
--

CREATE TABLE `cc4_CubeCart_alt_shipping_prices` (
  `id` int(10) NOT NULL auto_increment,
  `alt_ship_id` int(10) NOT NULL,
  `low` decimal(16,3) NOT NULL default '0.000',
  `high` decimal(16,3) NOT NULL default '0.000',
  `price` decimal(16,2) NOT NULL default '0.00',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_alt_shipping_prices` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_blocker`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_blocker`
--

CREATE TABLE `cc4_CubeCart_blocker` (
  `block_id` int(10) unsigned NOT NULL auto_increment,
  `level` tinyint(3) unsigned NOT NULL default '1',
  `last_attempt` int(10) unsigned NOT NULL default '0',
  `ban_expires` int(10) unsigned NOT NULL default '0',
  `username` text collate utf8_unicode_ci NOT NULL,
  `location` char(1) collate utf8_unicode_ci NOT NULL,
  `user_agent` text collate utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL COMMENT 'Supports IPv6 addresses',
  PRIMARY KEY  (`block_id`),
  KEY `location` (`location`),
  KEY `last_attempt` (`last_attempt`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_blocker` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_category`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_category`
--

CREATE TABLE `cc4_CubeCart_category` (
  `cat_id` int(10) unsigned NOT NULL auto_increment,
  `cat_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `cat_desc` text collate utf8_unicode_ci,
  `cat_parent_id` int(10) unsigned NOT NULL default '0',
  `cat_image` varbinary(250) NOT NULL default '',
  `per_ship` decimal(20,2) NOT NULL default '0.00',
  `item_ship` decimal(20,2) NOT NULL default '0.00',
  `item_int_ship` decimal(20,2) NOT NULL default '0.00',
  `per_int_ship` decimal(20,2) NOT NULL default '0.00',
  `hide` tinyint(1) NOT NULL default '0',
  `seo_meta_title` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_keywords` text collate utf8_unicode_ci NOT NULL,
  `priority` smallint(6) unsigned NOT NULL default '0',
  `status` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`cat_id`),
  KEY `cat_parent_id` (`cat_parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_category`
--

INSERT INTO `cc4_CubeCart_category` VALUES('17', 'Rock &#39;n&#39; Roll Outfits', '<p>&nbsp;This section is for Rock &#39;n&#39; Roll outfits, skirts and accessories. &nbsp;All outfits are available in various colours, netting colours (mix n match) and various sizes</p>', '0', '259', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '2', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('2', 'Hotfix Rhinestones', '<p>High quality hotfix Rhinestones, which can be hotfixed or glued in place. &nbsp;We can supply nearly all colours and sizes if it is not listed please drop us an email using the contact us page or&nbsp;<a href=\"javascript:void(location.href=&#39;mailto:&#39;+String.fromCharCode(105,110,102,111,64,112,110,100,97,110,99,101,46,99,111,109)+&#39;?&#39;)\">info@pndance.com</a></p>', '19', '179', '0.00', '0.00', '0.00', '0.00', '0', 'Hotfix Rhinestones', 'Rhinestones and Crystals', '', '2', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('21', 'DanceWear Size Guide', '<h2 style=\"text-align: center; \">&nbsp;</h2>\r\n<p style=\"text-align: center; \"><strong><cite>Please ensure that you check all measurements before ordering, the age guide is only a guide. &nbsp;Any questions please <a href=\"javascript:void(location.href=&#39;mailto:&#39;+String.fromCharCode(105,110,102,111,64,112,110,112,100,97,110,99,101,46,99,111,109)+&#39;?subject=Size%20Guide%20Question&#39;)\">contact us</a></cite></strong></p>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>Size Guide for Leotards and Leggings</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4</strong></td>\r\n            <td width=\"15%\"><strong>5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Height *(cm)</strong></td>\r\n            <td>41 (104)</td>\r\n            <td>44 (112)</td>\r\n            <td>47 (119)</td>\r\n            <td>50 (127)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Chest *(cm)</strong></td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n            <td>25 (63)</td>\r\n            <td>26 (66)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>21&frac12; (54)</td>\r\n            <td>22 (56)</td>\r\n            <td>22&frac12; (57)</td>\r\n            <td>23 (58)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Hip *(cm)</strong></td>\r\n            <td>23&frac12; (59)</td>\r\n            <td>24&frac12; (62)</td>\r\n            <td>25&frac12; (65)</td>\r\n            <td>27 (68)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Inside Leg to Floor *(cm)</strong></td>\r\n            <td>15&frac34; (40)</td>\r\n            <td>17&frac12; (44)</td>\r\n            <td>19&frac12; (49)</td>\r\n            <td>20&frac12; (52)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>&nbsp;</p>\r\n    <p>Size Guide for Skirts and Shorts</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4-5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7-8</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>22 (56)</td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>Size Guide for Catsuits</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4</strong></td>\r\n            <td width=\"15%\"><strong>5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Height *(cm)</strong></td>\r\n            <td>41 (104)</td>\r\n            <td>44 (112)</td>\r\n            <td>47 (119)</td>\r\n            <td>50 (127)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Chest *(cm)</strong></td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n            <td>25 (63)</td>\r\n            <td>26 (66)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>21&frac12; (54)</td>\r\n            <td>22 (56)</td>\r\n            <td>22&frac12; (57)</td>\r\n            <td>23 (58)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Hip *(cm)</strong></td>\r\n            <td>23&frac12; (59)</td>\r\n            <td>24&frac12; (62)</td>\r\n            <td>25&frac12; (65)</td>\r\n            <td>27 (68)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Back Waist Length *(cm)</strong></td>\r\n            <td>10 (25.5)</td>\r\n            <td>10&frac12; (27)</td>\r\n            <td>11 (28)</td>\r\n            <td>11&frac12; (29)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Inside Leg to Floor *(cm)</strong></td>\r\n            <td>15&frac34; (40)</td>\r\n            <td>17&frac12; (44)</td>\r\n            <td>19&frac12; (49)</td>\r\n            <td>20&frac12; (52)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>', '0', '169', '0.00', '0.00', '0.00', '0.00', '0', 'Dacnewear Size Guide', 'PnP Dancewear Size Guide', '', '7', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('3', 'Silverback Rhinestones', '<p>&nbsp;Silver back crystals or Rhinestones are not self adhesive, they require glue to attach them to the fabric or item. &nbsp;We only supply the best and most dazzling Rhinestones/Crystals at the best prices!</p>', '19', '186', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '3', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('6', '4mm (16ss)', '<p>&nbsp;4mm 16ss Hotfix rhinestones/crystals sold in quantities of 100</p>', '2', '180', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '6', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('7', '4mm AB (16ss)', '', '2', '179', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '7', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('8', '4mm (16ss)', '<p>&nbsp;4mm 16ss Rhinestones/ Crystals sold in quantities of 100. &nbsp;</p>', '3', '177', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '8', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('9', '4mm AB (16ss)', '<p>&nbsp;4mm 16ss Pearlesant rhinestones/crystals sold in quantities of 100</p>', '3', '178', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '9', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('12', '5mm (20ss)', '<p>&nbsp;&nbsp;5mm 20ss Rhinestones/ Crystals sold in quantities of 100. &nbsp;\r\n<meta charset=\"utf-8\" /></p>', '3', '', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '12', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('15', 'Childrens Dance Wear', '<p>&nbsp;All Dance Wear and costumes are made exclusively by Princess n Pickle, each costume is branded with the Princess &#39;n&#39; Pickle logo and are made from the best Lycra supplied by <a href=\"http://www.funkifabrics.co.uk\">Funki Fabrics</a>. &nbsp;</p>\r\n<p><img width=\"0\" height=\"0\" alt=\"\" src=\"/images/source/_images/ProductImages/Lycra/DanceWear/pnpLycra-18.jpg\" />Princess &#39;n&#39; Pickle dance wear is built to last from the finest quality materials with a unique brand. &nbsp;Each item is carefully wrapped and posted, don&#39;t forget you can get 10% off the order if you are in the Portsmouth area use the code PICKUP at checkout and we will contact you with details!</p>\r\n<p>PnP Dance Range is currently for under 8 years old, however we can take orders for Troop or Team costumes, please use the contact us form to let us know your requirmements, please make sure you leave a contact number and name and someone will get back to you</p>\r\n<p>We aim to provide childrens dance wear at affordable prices and the very highest quality!</p>', '0', '210', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '1', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('14', '5mm AB (20ss)', '<p>&nbsp;&nbsp;5mm 20ss Rhinestones/ Crystals sold in quantities of 100. &nbsp;\r\n<meta charset=\"utf-8\" /></p>', '3', '', '0.00', '0.00', '0.00', '0.00', '0', '', '', '', '14', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('18', 'Previously Owned', '<p><b>All the outfits listed here are for sale.  They are all pre-owned and will be be in excellent condition where stated.  Please note there is no returns on 2nd hand costumes. </b></p>', '0', '172', '0.00', '0.00', '0.00', '0.00', '0', 'Second Hand Dance Wear', 'Children\'s Second Hand Dance', '', '3', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('19', 'Rhinestones', '<p>We sell hotfix Rhinestones of the highest quality, if you wish to purchase Swarovski or Preciosa please contact us</p>\r\n<p>Even if you don&#39;t see the size or colour you require please contact us and we will let you know the delivery time, usually within a few days</p>', '0', '168', '0.00', '0.00', '0.00', '0.00', '0', '', 'High Quality Rhinestones hotfix and silver back in all sizes', '', '5', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('20', 'New Blinged Costumes', '<h2 style=\"text-align: center; \"> </h2>\r\n<p style=\"text-align: center; \"><span style=\"color: rgb(255, 0, 255); \"> **** Costumes Made and Sold by PnP Dance *****</span></p>\r\n<p> </p>\r\n<p>A range of brand new one of a kind disco solo / disco pairs, slow and rock \'n\' roll pairs costumes.  As these costumes are made they will sold on a first come first served basis.</p>\r\n<p> </p>\r\n<p> </p>\r\n<p><a href=\"http://www.pnpdance.com/bespoke-costumes/info_18.html\">If you would a costume designed please see here</a></p>', '0', '189', '0.00', '0.00', '0.00', '0.00', '0', '', 'one of a kind custom designed outfits for disco solo / disco pairs, slow and rock \'n\' roll pairs', '', '4', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('22', 'Up and Coming ISTD Dance Comps', '<p>&nbsp;Below is a list of all up and coming Disco, Freestyle and Rock &#39;n&#39; Roll ISTD dance competetions. &nbsp;For an exhaustive list please visit <a target=\"_blank\" href=\"http://www.istd.org/events/?keyword=&amp;faculty=8&amp;type=2&amp;x=47&amp;y=8\">The ISTD Web</a>&nbsp;Site. &nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div>\r\n<h3>&nbsp;</h3>\r\n<del>\r\n<h3><a href=\"http://www.istd.org/events/area-medallist-competition/\">Area Medallist Competition</a></h3>\r\n<p>Sunday 22 Jan&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Sussex/Surrey &ndash; East Grinstead</p>\r\n<p>DFR Area Medallist Compeition</p>\r\n<p><a title=\"Read full details for &#39;article&#39;\" href=\"http://www.istd.org/events/area-medallist-competition/\">Read more...</a></p>\r\n</del>\r\n<p>&nbsp;</p>\r\n<div>&nbsp;</div>\r\n<div>\r\n<h3>&nbsp;</h3>\r\n<del>\r\n<h3><a href=\"http://www.istd.org/events/area-medallist-competitions/\">Area Medallist Competitions</a></h3>\r\n<p>Sunday 29 Jan&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Southend Leisure &amp; Tennis Centre</p>\r\n<p>DFR Faculty Medallist Compettion</p>\r\n<p><a title=\"Read full details for &#39;article&#39;\" href=\"http://www.istd.org/events/area-medallist-competitions/\">Read more...</a></p>\r\n</del>\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div><a href=\"http://www.istd.org/events/imperial-championships/\"><img alt=\"Imperial Open Disco, Freestyle &amp; Rock &#39;n&#39; Roll Championships\" src=\"http://www.istd.org/themes/istd/front-end/gfx/build/transparent.gif\" /></a></div>\r\n<div>\r\n<h3>&nbsp;</h3>\r\n<del>\r\n<h3><a href=\"http://www.istd.org/events/imperial-championships/\">Imperial Open Disco, Freestyle &amp; Rock &#39;n&#39; Roll Championships</a></h3>\r\n<p>Sunday 4 Mar&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Staines</p>\r\n<p>To be held at Spelthorne Leisure Centre, Staines, Middlesex</p>\r\n</del>\r\n<p>&nbsp;</p>\r\n<p><a title=\"Read full details for &#39;article&#39;\" href=\"http://www.istd.org/events/imperial-championships/\">Read more...</a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h3 style=\"font-size: 1.1em; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial, sans-serif; text-align: left; \"><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--hantsdorset/\" style=\"color: rgb(0, 32, 159); text-decoration: none; \"><br class=\"Apple-interchange-newline\" />\r\n</a></h3>\r\n<del>\r\n<h3 style=\"font-size: 1.1em; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial, sans-serif; text-align: left; \"><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--hantsdorset/\" style=\"color: rgb(0, 32, 159); text-decoration: none; \">DFR Area Medallist Competition &ndash;&nbsp;Hants/Dorset</a></h3>\r\n<p class=\"date\" style=\"text-align: left; line-height: 2em; color: rgb(51, 51, 51); font-size: 0.85em; font-family: Arial, sans-serif; \">Sunday 1 Apr&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Littledown</p>\r\n<p class=\"summary\" style=\"text-align: left; line-height: 1.4; color: rgb(102, 102, 102); font-family: Arial, sans-serif; font-size: 13px; \">Medallist Competition</p>\r\n</del>\r\n<p class=\"summary\" style=\"text-align: left; line-height: 1.4; color: rgb(102, 102, 102); font-family: Arial, sans-serif; font-size: 13px; \">&nbsp;</p>\r\n<p class=\"more\" style=\"text-align: left; line-height: 1.4; color: rgb(102, 102, 102); font-family: Arial, sans-serif; font-size: 13px; \"><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--hantsdorset/\" title=\"Read full details for &#39;article&#39;\" style=\"color: rgb(0, 32, 159); text-decoration: none; \">Read more...</a></p>\r\n<p class=\"more\" style=\"text-align: left; line-height: 1.4; color: rgb(102, 102, 102); font-family: Arial, sans-serif; font-size: 13px; \">&nbsp;</p>\r\n<h3 style=\"color: rgb(0, 0, 0); font-size: 1.1em; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; line-height: normal; \">&nbsp;</h3>\r\n</div>\r\n<div>\r\n<h3><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--londonkent/\">DFR Area Medallist Competition &ndash; London/Kent</a></h3>\r\n<p>Sunday 6 May&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Gillingham, Kent</p>\r\n<p>Medallist Competition</p>\r\n<p><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--londonkent/\" title=\"Read full details for &#39;article&#39;\">Read more...</a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h3><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--wiltshirewest/\"><br />\r\nDFR Area Medallist Competition &ndash; Wiltshire/West</a></h3>\r\n<p>Sunday 1 Jul&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Oasis Leisure Centre, Swindon</p>\r\n<p>Medallist Competition</p>\r\n<p><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--wiltshirewest/\" title=\"Read full details for &#39;article&#39;\">Read more...</a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h3><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--the-north-2/\"><br />\r\nDFR Area Medallist Competition &ndash; the North 2</a></h3>\r\n<p>Sunday 15 Jul&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Horbury School, Horbury, Wakefield</p>\r\n<p>Medallist Competition</p>\r\n<p><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--the-north-2/\" title=\"Read full details for &#39;article&#39;\">Read more...</a></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<h3><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--berksbucksmiddx/\"><br />\r\nDFR Area Medallist Competition &ndash; Berks/Bucks/Middx</a></h3>\r\n<p>Sunday 16 Sep&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Spelthorne Leisure Centre, Staines</p>\r\n<p>Medallist Competition</p>\r\n<p><a href=\"http://www.istd.org/events/dfr-area-medallist-competition--berksbucksmiddx/\" title=\"Read full details for &#39;article&#39;\">Read more...</a></p>\r\n</div>', '0', '1', '0.00', '0.00', '0.00', '0.00', '1', 'ISTD Comps', 'Up and coming Disco, Freestyle and Rock &#39;n&#39; Roll ISTD dance competetions', '', '8', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('23', 'DMC Hotfix Rhinestones', '<p>DMC Rhinestone, also known as Imitated Preciosa Rhinestone, has similar brightness and polished facets to Preciosa rhinestones, available in hotfix and a range of sizes. &nbsp;Please let us know if you require any colours not shown.</p>\r\n<p>&nbsp;</p>', '19', '166', '0.00', '0.00', '0.00', '0.00', '0', 'DMC Hotfix Rhinestones', 'DMC Rhinestone, also known as Imitated Preciosa Rhinestone, has similar brightness and polished facets to Preciosa rhinestones, available in hotfix and a range of sizes.  Please let us know if you require any colours not shown.\r\n', '', '1', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category` VALUES('24', 'Dancing Accessories', '<p>&nbsp;All dancing accessories are here, we can order shoes on request for next day delivery to our shop or 3 day delivery to you.</p>', '0', '195', '0.00', '0.00', '0.00', '0.00', '0', 'Dance Accessories', 'All dancing accessories are here, we can order shoes on request for next day delivery to our shop or 3 day delivery to you.', '', '6', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_category_index`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_category_index`
--

CREATE TABLE `cc4_CubeCart_category_index` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `primary` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cat_id` (`cat_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=440 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_category_index`
--

INSERT INTO `cc4_CubeCart_category_index` VALUES('416', '8', '2', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('419', '9', '3', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('403', '9', '4', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('402', '9', '5', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('405', '9', '6', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('406', '9', '7', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('303', '6', '8', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('354', '7', '9', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('353', '6', '10', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('355', '6', '11', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('356', '6', '12', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('177', '17', '19', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('185', '17', '25', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('357', '9', '15', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('404', '8', '16', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('82', '3', '2', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('83', '3', '3', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('84', '3', '4', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('85', '3', '5', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('86', '3', '6', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('87', '3', '7', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('88', '2', '8', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('89', '2', '9', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('90', '2', '10', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('91', '2', '11', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('92', '2', '15', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('93', '3', '16', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('226', '15', '17', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('277', '15', '18', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('222', '15', '19', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('165', '15', '20', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('166', '15', '21', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('167', '15', '22', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('183', '17', '23', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('181', '15', '24', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('178', '17', '20', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('179', '17', '22', '0'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('293', '15', '26', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('359', '12', '34', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('214', '15', '28', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('424', '20', '29', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('430', '18', '60', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('388', '18', '31', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('437', '24', '62', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('360', '12', '35', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('361', '12', '36', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('408', '12', '37', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('363', '12', '38', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('364', '8', '39', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('411', '23', '40', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('341', '23', '41', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('418', '23', '42', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('365', '23', '43', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('410', '23', '45', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('417', '14', '56', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('435', '24', '57', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('378', '15', '50', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('399', '18', '49', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('381', '15', '51', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('383', '15', '52', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('391', '15', '53', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('438', '17', '54', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('439', '18', '55', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('425', '18', '58', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('426', '18', '59', '1'); #EOQ
INSERT INTO `cc4_CubeCart_category_index` VALUES('432', '20', '61', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_category_language`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_category_language`
--

CREATE TABLE `cc4_CubeCart_category_language` (
  `translation_id` int(10) unsigned NOT NULL auto_increment,
  `cat_id` int(10) unsigned NOT NULL default '0',
  `language` varchar(5) collate utf8_unicode_ci default NULL,
  `cat_name` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `cat_desc` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_title` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_keywords` text collate utf8_unicode_ci NOT NULL,
  KEY `cat_master_id` (`cat_id`),
  KEY `translation_id` (`translation_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_category_language` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_config`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_config`
--

CREATE TABLE `cc4_CubeCart_config` (
  `name` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `array` mediumtext collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_config`
--

INSERT INTO `cc4_CubeCart_config` VALUES('Free_Shipping', 'a:2:{s:6:\"status\";s:1:\"0\";s:7:\"trigger\";s:4:\"5.00\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Print_Order_Form', 'a:16:{s:6:\"status\";s:1:\"0\";s:7:\"default\";s:1:\"1\";s:13:\"multiCurrency\";s:1:\"1\";s:4:\"desc\";s:17:\"Postal Order Form\";s:6:\"cheque\";s:1:\"1\";s:9:\"payableTo\";s:16:\"Company Name Ltd\";s:4:\"card\";s:1:\"1\";s:5:\"cards\";s:35:\"Mastercard,Visa,Switch,Maestro,AMEX\";s:4:\"bank\";s:1:\"1\";s:8:\"bankName\";s:13:\"Your Bank Plc\";s:7:\"accName\";s:12:\"Company Name\";s:8:\"sortCode\";s:8:\"xx-xx-xx\";s:4:\"acNo\";s:8:\"xxxxxxxx\";s:9:\"swiftCode\";s:8:\"xxxxxxxx\";s:7:\"address\";s:70:\"Address Line 1\r\nAddress Line 2\r\nAddress Line 3\r\nAddress Line 4\r\nxxxxxx\";s:5:\"notes\";s:44:\"We can only accept payments in xxx currency.\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('config', 'eyJzdG9yZV9uYW1lIjoiUHJpbmNlc3MgJ24nICBQaWNrbGUiLCJzdG9yZV9hZGRyZXNzIjoiODAgTG9ja3N3YXkgUm9hZFxyXG5Qb3J0c21vdXRoXHJcbiIsInN0b3JlX2NvdW50cnkiOiI4MjYiLCJzdG9yZV96b25lIjoiNDU4Iiwic3RvcmVfcG9zdGNvZGUiOiJQTzQgOEpQIiwiZGVmYXVsdF9sYW5ndWFnZSI6ImVuLUdCIiwiZGVmYXVsdF9jdXJyZW5jeSI6IkdCUCIsInByb2R1Y3RfcHJpY2VzX2luY2x1ZGVfdGF4IjoiMCIsImJhc2tldF90YXhfYnlfZGVsaXZlcnkiOiIwIiwiZ29vZ2xlX2FuYWx5dGljcyI6IiIsImVuYWJsZV9yZXZpZXdzIjoiIiwiYmFza2V0X29yZGVyX2V4cGlyZSI6IiIsImNhdGFsb2d1ZV9zYWxlX21vZGUiOiIwIiwiY2F0YWxvZ3VlX3NhbGVfcGVyY2VudGFnZSI6IiIsImNhdGFsb2d1ZV9zYWxlX2l0ZW1zIjoiIiwicmVjYXB0Y2hhIjoiMSIsImFkbWluX25vdGlmeV9zdGF0dXMiOiIyIiwibm9fc2tpcF9wcm9jZXNzaW5nX2NoZWNrIjoiIiwiY2F0YWxvZ3VlX2hpZGVfcHJpY2VzIjoiIiwiY2F0YWxvZ3VlX21vZGUiOiIiLCJhdXRvX3NhdmVfY2FydCI6IjEiLCJhbGxvd19ub19zaGlwcGluZyI6IiIsImRpc2FibGVfc2hpcHBpbmdfZ3JvdXBzIjoiIiwiY29va2llX2RpYWxvZ3VlIjoiMSIsImNhdGFsb2d1ZV9wcm9kdWN0c19wZXJfcGFnZSI6IjgiLCJjYXRhbG9ndWVfc2hvd19lbXB0eSI6IjAiLCJwcm9kdWN0X3ByZWNpcyI6IiIsImRlZmF1bHRfZGlyZWN0b3J5X3N5bWJvbCI6IiB8ICIsImNhdGFsb2d1ZV9leHBhbmRfdHJlZSI6IjEiLCJiYXNrZXRfanVtcF90byI6IjAiLCJkaXNhYmxlX2NoZWNrb3V0X3Rlcm1zIjoiIiwiZGVmYXVsdF9yc3NfZmVlZCI6IiIsImNhdGFsb2d1ZV9sYXRlc3RfcHJvZHVjdHMiOiIxIiwiY2F0YWxvZ3VlX2xhdGVzdF9wcm9kdWN0c19jb3VudCI6IjgiLCJjYXRhbG9ndWVfcG9wdWxhcl9wcm9kdWN0c19jb3VudCI6IjgiLCJjYXRhbG9ndWVfcG9wdWxhcl9wcm9kdWN0c19zb3VyY2UiOiIwIiwic2tpbl9mb2xkZXIiOiJ2ZWN0b3IiLCJza2luX3N0eWxlIjoiY2hyb21lIiwiYWRtaW5fc2tpbiI6ImRlZmF1bHQiLCJza2luX2NoYW5nZSI6IjAiLCJza2luX2ZvbGRlcl9tb2JpbGUiOiJtb2JpbGUiLCJza2luX3N0eWxlX21vYmlsZSI6InJlZCIsImRpc2FibGVfbW9iaWxlX3NraW4iOiIiLCJkb3dubG9hZF9leHBpcmUiOiIiLCJkb3dubG9hZF9jb3VudCI6IiIsImRvd25sb2FkX2N1c3RvbV9wYXRoIjoiIiwic3RvY2tfbGV2ZWwiOiIiLCJiYXNrZXRfb3V0X29mX3N0b2NrX3B1cmNoYXNlIjoiIiwic3RvY2tfd2Fybl90eXBlIjoiMCIsInN0b2NrX3dhcm5fbGV2ZWwiOiIiLCJwcm9kdWN0X3dlaWdodF91bml0IjoiTGIiLCJzaG93X2Jhc2tldF93ZWlnaHQiOiIiLCJiYXNrZXRfYWxsb3dfbm9uX2ludm9pY2VfYWRkcmVzcyI6IiIsInN0b2NrX2NoYW5nZV90aW1lIjoiMiIsImhpZGVfb3V0X29mX3N0b2NrIjoiIiwic3RvcmVfdGl0bGUiOiJQcmluY2VzcyBuIFBpY2tsZSA6OiBDaGlsZHJlbnMgRGFuY2UgV2VhciAiLCJzdG9yZV9tZXRhX2Rlc2NyaXB0aW9uIjoiRGFuY2UsIEJhbGxldCwgSmF6eiwgVGFwLCBEYW5jZSBEZXBvdCwgZGFuY2Utc2hvZXMsIHNob2VzLCBkYW5jZXdlYXIsIGRhbmNlciwgYmVnaW5uZXIsIHByb2Zlc3Npb25hbCwgIHN0YWdlLCBDYXBlemlvLCBMZW8ncywgRGFuc2tpbiwgZm9vdHdlYXIsIHRpZ2h0cywgVUssIDI0IGhvdXIgZGVsaXZlcnksIHN0b3JlLCBzaG9wLCBidXksIGRhbmNlIHNob3AsIGRhbmNlIHN0b3JlLCBjaGlsZHJlbidzIGRhbmNlIHdlYXIsIGxlb3RhcmRzLCBjYXRzdWl0cywgc2hvdGVzLCBseWNyYSIsInN0b3JlX21ldGFfa2V5d29yZHMiOiJEYW5jZXdlYXIgYW5kIERhbmNlIFNob2VzIFx1MjAxMyBkaXNjb3VudHMgYW5kIHNhdmluZ3MgYXQgUG5QIERhbmNlLiBMZW90YXJkcywgZGFuY2V3ZWFyLCwgZGFuY2Ugc2hvZXMsIGNoaWxkcmVuJ3MgZGFuY2V3ZWFyIGZvciBCYWxsZXQsIEphenosIFRhcCBhbmQgYmFsbHJvb20uIEdyZWF0IHNlcnZpY2UgYW5kIGdyZWF0IHByaWNlcyBcdTIwMTMgTm8gam9iIHRvbyBiaWcgb3Igc21hbGwiLCJzZW9fbWV0YWRhdGEiOiIwIiwic2VvIjoiMSIsInNlb19tZXRob2QiOiIwIiwic2VvX3RyYWNrYmFja3MiOiIxIiwic3NsIjoiMSIsInNzbF9mb3JjZSI6IjAiLCJzc2xfcGF0aCI6IlwvaG9tZVwvdXNlcnNcL3dlYlwvYjE4MDNcL2lwZy5wbnBkYW5jZWNvbVwvIiwic3NsX3VybCI6Imh0dHBzOlwvXC93d3cucG5wZGFuY2UuY29tIiwic3RhbmRhcmRfdXJsIjoiaHR0cDpcL1wvd3d3LnBucGRhbmNlLmNvbSIsIm9mZmxpbmUiOiIwIiwib2ZmbGluZV9hbGxvd19hZG1pbiI6IjEiLCJvZmZsaW5lX2NvbnRlbnQiOiI8cD5cclxuXHQmbmJzcDs8XC9wPlxyXG48cCBzdHlsZT1cImNvbG9yOiByZ2IoMCwgMCwgMCk7IGZvbnQtZmFtaWx5OiBUaW1lczsgZm9udC1zaXplOiBtZWRpdW07IHRleHQtYWxpZ246IGNlbnRlcjsgXCI+XHJcblx0Jm5ic3A7PFwvcD5cclxuPHAgc3R5bGU9XCJjb2xvcjogcmdiKDAsIDAsIDApOyBmb250LWZhbWlseTogVGltZXM7IGZvbnQtc2l6ZTogbWVkaXVtOyB0ZXh0LWFsaWduOiBjZW50ZXI7IFwiPlxyXG5cdCZuYnNwOzxcL3A+XHJcbjxoMSBzdHlsZT1cImNvbG9yOiByZ2IoMCwgMCwgMCk7IGZvbnQtZmFtaWx5OiBUaW1lczsgdGV4dC1hbGlnbjogY2VudGVyOyBcIj5cclxuXHRKdXN0IGNhcnJ5aW5nIG91dCBzb21lIGVzZW50aWFsIG1haW50ZW5hbmNlIG9uIHRoZSBzaG9wIEJlIEJhY2sgU29vbiE8XC9oMT5cclxuPGRpdj5cclxuXHQmbmJzcDs8XC9kaXY+XHJcbiIsImxpY2Vuc2Vfa2V5IjoiNzEwNjYtNzEyNzEtNzczMDUtNzk4MzYtODg2NDMtNDAzMTYiLCJlbWFpbF9tZXRob2QiOiJtYWlsIiwiZW1haWxfbmFtZSI6IiIsImVtYWlsX2FkZHJlc3MiOiIiLCJlbWFpbF9zbXRwX2hvc3QiOiIiLCJlbWFpbF9zbXRwX3BvcnQiOiIiLCJlbWFpbF9zbXRwIjoiMCIsImVtYWlsX3NtdHBfdXNlciI6IiIsImVtYWlsX3NtdHBfcGFzc3dvcmQiOiIiLCJkZWJ1ZyI6IjAiLCJkZWJ1Z19pcF9hZGRyZXNzZXMiOiI4Mi4xNC4xLjg3IiwiY2FjaGUiOiIxIiwiY2FjaGVfbWVtY2FjaGVfbGlzdCI6IiIsInByb3h5IjoiMCIsInByb3h5X2hvc3QiOiIiLCJwcm94eV9wb3J0IjoiIiwidGltZV9mb3JtYXQiOiIlWS0lbS0lZCAlSDolTSIsInRpbWVfb2Zmc2V0IjoiIiwidGltZV96b25lIjoiRXVyb3BlXC9Mb25kb24iLCJmZWVkX2FjY2Vzc19rZXkiOiIiLCJhbm9uX3N0YXRzIjoiIiwic3RvcmVfY29weXJpZ2h0IjoiIiwicHJvZHVjdF9jbG9uZSI6IjAiLCJwcm9kdWN0X2Nsb25lX2ltYWdlcyI6IiIsInByb2R1Y3RfY2xvbmVfb3B0aW9ucyI6IiIsInByb2R1Y3RfY2xvbmVfYWNhdHMiOiIiLCJwcm9kdWN0X2Nsb25lX2NvZGUiOiIxIiwicHJvZHVjdF9jbG9uZV90cmFuc2xhdGlvbnMiOiIiLCJwcm9kdWN0X2Nsb25lX3JlZGlyZWN0IjoiIiwibGt2IjoiMTEwMzI1LTEzNTIwNy04MzY5In0='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Quick_Checkout', 'a:7:{s:6:\"status\";s:1:\"1\";s:10:\"direct_reg\";s:1:\"1\";s:8:\"register\";s:1:\"1\";s:7:\"pp_hide\";s:1:\"0\";s:11:\"pp_advanced\";s:1:\"0\";s:4:\"logo\";s:1:\"1\";s:8:\"security\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('OBT', 'a:14:{s:6:\"status\";s:1:\"0\";s:5:\"email\";s:17:\"mark@pnpdance.com\";s:6:\"iframe\";s:1:\"1\";s:7:\"logoURL\";s:64:\"http://www.pnpdance.com/images/getLogo.php?skin=FieldOfDreamsCC4\";s:7:\"default\";s:1:\"0\";s:4:\"logo\";s:1:\"1\";s:9:\"more_link\";s:53:\"http://www.nextgenerationpayments.com/en/customerinfo\";s:4:\"desc\";s:20:\"Online Bank Transfer\";s:5:\"quick\";s:1:\"1\";s:11:\"quickbefore\";s:1:\"1\";s:13:\"emailVerified\";s:1:\"1\";s:14:\"secretVerified\";s:0:\"\";s:7:\"cust_id\";s:8:\"28560253\";s:6:\"secret\";s:0:\"\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('PayPal', 'a:5:{s:6:\"status\";s:1:\"1\";s:4:\"desc\";s:6:\"PayPal\";s:5:\"email\";s:18:\"kerry@pnpdance.com\";s:7:\"default\";s:1:\"1\";s:8:\"testMode\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Nochex_APC', 'a:8:{s:6:\"status\";s:1:\"1\";s:4:\"desc\";s:48:\"Secure Credit Card Payments up to Â£100 (NoChex)\";s:5:\"email\";s:24:\"mark@fabian-lovely.co.uk\";s:7:\"accType\";s:8:\"merchant\";s:11:\"merchant_id\";s:24:\"mark@fabian-lovely.co.uk\";s:12:\"passTemplate\";s:1:\"0\";s:8:\"testMode\";s:1:\"0\";s:7:\"default\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Stock_Levels_for_Product_Opts', 'a:10:{s:15:\"mod_license_key\";s:29:\"9fe40-d8fda-a1139-ee26f-8dd45\";s:12:\"mod_store_id\";s:32:\"24c3ca480c9a9a41cb9d1c7ca98292e9\";s:17:\"total_stock_level\";s:1:\"1\";s:10:\"status_cc4\";s:1:\"0\";s:6:\"status\";s:1:\"0\";s:11:\"append_code\";s:1:\"1\";s:11:\"append_char\";s:1:\"/\";s:25:\"hide_out_of_stock_options\";s:1:\"1\";s:21:\"sort_products_by_code\";s:1:\"0\";s:25:\"show_list_of_all_products\";s:1:\"1\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('gift_certs', 'a:8:{s:6:\"status\";s:1:\"1\";s:3:\"tax\";s:1:\"1\";s:3:\"max\";s:3:\"500\";s:3:\"min\";s:2:\"10\";s:8:\"delivery\";s:1:\"3\";s:6:\"weight\";s:0:\"\";s:11:\"productCode\";s:5:\"GV001\";s:7:\"taxType\";s:1:\"3\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Extended_Product_Options', 'a:9:{s:15:\"mod_license_key\";s:29:\"fa588-8acd0-74f58-549c0-0c035\";s:12:\"mod_store_id\";s:32:\"24c3ca480c9a9a41cb6d1e7ca98292e9\";s:7:\"version\";s:1:\"2\";s:10:\"status_cc4\";s:1:\"0\";s:6:\"status\";s:1:\"0\";s:14:\"visual_version\";s:1:\"1\";s:10:\"use_thumbs\";s:1:\"0\";s:11:\"use_nophoto\";s:1:\"1\";s:18:\"replace_cart_image\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Free_Shipping', 'a:2:{s:6:\"status\";s:1:\"0\";s:7:\"trigger\";s:4:\"5.00\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Print_Order_Form', 'a:16:{s:6:\"status\";s:1:\"0\";s:7:\"default\";s:1:\"1\";s:13:\"multiCurrency\";s:1:\"1\";s:4:\"desc\";s:17:\"Postal Order Form\";s:6:\"cheque\";s:1:\"1\";s:9:\"payableTo\";s:16:\"Company Name Ltd\";s:4:\"card\";s:1:\"1\";s:5:\"cards\";s:35:\"Mastercard,Visa,Switch,Maestro,AMEX\";s:4:\"bank\";s:1:\"1\";s:8:\"bankName\";s:13:\"Your Bank Plc\";s:7:\"accName\";s:12:\"Company Name\";s:8:\"sortCode\";s:8:\"xx-xx-xx\";s:4:\"acNo\";s:8:\"xxxxxxxx\";s:9:\"swiftCode\";s:8:\"xxxxxxxx\";s:7:\"address\";s:70:\"Address Line 1\r\nAddress Line 2\r\nAddress Line 3\r\nAddress Line 4\r\nxxxxxx\";s:5:\"notes\";s:44:\"We can only accept payments in xxx currency.\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('By_Price', 'a:5:{s:6:\"status\";s:1:\"1\";s:5:\"level\";s:4:\"5.00\";s:6:\"amount\";s:4:\"1.00\";s:8:\"handling\";s:4:\"0.50\";s:3:\"tax\";s:1:\"3\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Multiple_Tax_Mod', 'a:2:{s:6:\"status\";s:1:\"0\";s:5:\"debug\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('UK_Flat_Shipping_Rates', 'a:4:{s:6:\"status\";s:1:\"0\";s:3:\"tax\";s:1:\"3\";s:8:\"handling\";s:4:\"0.00\";s:7:\"methods\";s:125:\"a:1:{i:0;a:3:{s:4:\"name\";s:47:\"Local Pickup (use Code PICKUP for 10% discount)\";s:4:\"rate\";s:4:\"0.00\";s:6:\"status\";s:1:\"1\";}}\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Product_Quantity_Discounts', 'a:8:{s:15:\"mod_license_key\";s:29:\"51931-4f2f0-e5fb9-fcd68-36478\";s:12:\"mod_store_id\";s:32:\"24c3ca480c9a9a41cb9d7c7ca99292e9\";s:6:\"status\";s:1:\"0\";s:10:\"status_cc4\";s:1:\"0\";s:20:\"savings_display_type\";s:1:\"1\";s:14:\"show_discounts\";s:1:\"1\";s:15:\"pricing_display\";s:1:\"1\";s:5:\"debug\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Custom_registration', 'a:2:{s:6:\"status\";s:1:\"1\";s:7:\"default\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('MagicThumb', 'a:1:{s:6:\"status\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Google_Analytics', 'a:3:{s:6:\"status\";s:1:\"1\";s:10:\"status_cc4\";s:1:\"1\";s:18:\"ga_tracking_number\";s:13:\"UA-22399941-1\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('MagicZoomPlus', 'a:1:{s:6:\"status\";s:1:\"1\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Google_Checkout', 'eyJzY29wZSI6ImJvdGgiLCJtZXJjaElkIjoiMzY0MDM1Mzg1NjMwMDAzIiwibWVyY2hLZXkiOiJDTjF6dHF2YUR4Vk9sZUxBOFRLdjJnIiwic2l6ZSI6ImxhcmdlIiwibW9kZSI6ImxpdmUiLCJjb3VudHJpZXMiOiJhOjM6e2k6MDtzOjM6XCI3MTBcIjtpOjE7czozOlwiODI2XCI7aToyO3M6MzpcIjg0MFwiO30iLCJkaXNhYmxlZF9jb3VudHJpZXMiOiIifQ=='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Pick_Up', 'a:1:{s:6:\"status\";s:1:\"0\";}'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('PayPal_Pro', 'eyJzY29wZSI6ImJvdGgiLCJtb2RlIjoiMiIsInVzZXJuYW1lIjoia2VycnlfYXBpMS5wbnBkYW5jZS5jb20iLCJwYXNzd29yZCI6IldOOVVFVUg1M0tGU0xFSjQiLCJzaWduYXR1cmUiOiJBVFVSZnhQekVIV2RZU1FkdUlob0ZwRWdKdzYtQURtbnpMSGh3cEIuYkJsTklYdG95Ty1IMXBvbyIsInBhcnRuZXIiOiIiLCJ2ZW5kb3IiOiIiLCJhbWV4IjoiIiwiZ2F0ZXdheSI6IjEiLCJwYXltZW50QWN0aW9uIjoiU2FsZSIsImNvbmZBZGRyZXNzIjoiMSIsIjNkc19zdGF0dXMiOiIwIiwiM2RzX21lcmNoYW50IjoiIiwiM2RzX3Bhc3N3b3JkIjoiIiwiY291bnRyaWVzIjoiIiwiZGlzYWJsZWRfY291bnRyaWVzIjoiIn0='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('logos', 'eyJrdXJvdXRvYmx1ZSI6InNraW5zXC9rdXJvdXRvXC9pbWFnZXNcL2JsdWVcL2xvZ29cL2RlZmF1bHQucG5nIiwia3Vyb3V0b2dyZWVuIjoic2tpbnNcL2t1cm91dG9cL2ltYWdlc1wvZ3JlZW5cL2xvZ29cL2RlZmF1bHQucG5nIiwia3Vyb3V0b2dyZXkiOiJza2luc1wva3Vyb3V0b1wvaW1hZ2VzXC9ncmV5XC9sb2dvXC9kZWZhdWx0LnBuZyIsImt1cm91dG9vcmFuZ2UiOiJza2luc1wva3Vyb3V0b1wvaW1hZ2VzXC9vcmFuZ2VcL2xvZ29cL2RlZmF1bHQucG5nIiwia3Vyb3V0b3B1cnBsZSI6InNraW5zXC9rdXJvdXRvXC9pbWFnZXNcL3B1cnBsZVwvbG9nb1wvZGVmYXVsdC5wbmciLCJrdXJvdXRvcmVkIjoic2tpbnNcL2t1cm91dG9cL2ltYWdlc1wvcmVkXC9sb2dvXC9kZWZhdWx0LnBuZyIsIm1hdXJpcyI6InNraW5zXC9tYXVyaXNcL2ltYWdlc1wvbG9nb1wvZGVmYXVsdC5wbmciLCJtaWNhbmJsdWUiOiJza2luc1wvbWljYW5cL2ltYWdlc1wvYmx1ZVwvbG9nb1wvZGVmYXVsdC5wbmciLCJtaWNhbnBpbmsiOiJza2luc1wvbWljYW5cL2ltYWdlc1wvcGlua1wvbG9nb1wvZGVmYXVsdC5wbmciLCJtaWNhbmJsYWNrIjoic2tpbnNcL21pY2FuXC9pbWFnZXNcL2JsYWNrXC9sb2dvXC9kZWZhdWx0LnBuZyIsIm1vYmlsZWJsdWUiOiJza2luc1wvbW9iaWxlXC9pbWFnZXNcL2JsdWVcL2xvZ29cL2RlZmF1bHQucG5nIiwibW9iaWxlZ3JlZW4iOiJza2luc1wvbW9iaWxlXC9pbWFnZXNcL2dyZWVuXC9sb2dvXC9kZWZhdWx0LnBuZyIsIm1vYmlsZXJlZCI6InNraW5zXC9tb2JpbGVcL2ltYWdlc1wvcmVkXC9sb2dvXC9kZWZhdWx0LnBuZyIsIm5vdGFibHVlIjoic2tpbnNcL25vdGFcL2ltYWdlc1wvYmx1ZVwvbG9nb1wvZGVmYXVsdC5wbmciLCJub3RhYnJvd24iOiJza2luc1wvbm90YVwvaW1hZ2VzXC9icm93blwvbG9nb1wvZGVmYXVsdC5wbmciLCJub3RhZ3JlZW4iOiJza2luc1wvbm90YVwvaW1hZ2VzXC9ncmVlblwvbG9nb1wvZGVmYXVsdC5wbmciLCJub3RhcHVycGxlIjoic2tpbnNcL25vdGFcL2ltYWdlc1wvcHVycGxlXC9sb2dvXC9kZWZhdWx0LnBuZyIsIm5vdGFyZWQiOiJza2luc1wvbm90YVwvaW1hZ2VzXC9yZWRcL2xvZ29cL2RlZmF1bHQucG5nIiwidmFuaWxsYSI6InNraW5zXC92YW5pbGxhXC9pbWFnZXNcL2xvZ29cL2RlZmF1bHQucG5nIiwidmVjdG9yY2hyb21lIjoiaW1hZ2VzXC9sb2dvc1wvdmVjdG9yX2xvZ28zLmpwZyIsInZlY3RvcmRhcmsiOiJpbWFnZXNcL2xvZ29zXC92ZWN0b3JfbG9nbzMuanBnIiwidmVjdG9ycmVkIjoiaW1hZ2VzXC9sb2dvc1wvdmVjdG9yX2xvZ28zLmpwZyIsInZlY3RvcmJsdWUiOiJpbWFnZXNcL2xvZ29zXC92ZWN0b3JfbG9nbzMuanBnIiwidmVjdG9yZ3JlZW4iOiJpbWFnZXNcL2xvZ29zXC92ZWN0b3JfbG9nbzMuanBnIiwidmVjdG9yeWVsbG93IjoiaW1hZ2VzXC9sb2dvc1wvdmVjdG9yX2xvZ28zLmpwZyIsInZlY3Rvcm9yYW5nZSI6ImltYWdlc1wvbG9nb3NcL3ZlY3Rvcl9sb2dvMy5qcGciLCJ2ZWN0b3J2aW9sZXQiOiJpbWFnZXNcL2xvZ29zXC92ZWN0b3JfbG9nbzMuanBnIiwiZW1haWxzIjoiaW1hZ2VzXC9sb2dvc1wvdmVjdG9yX2xvZ28zLmpwZyIsImludm9pY2VzIjoiaW1hZ2VzXC9sb2dvc1wvdmVjdG9yX2xvZ28zLmpwZyJ9'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Fusion', 'eyJjb3VudHJpZXMiOiIiLCJkaXNhYmxlZF9jb3VudHJpZXMiOiIifQ=='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('VECTOR', 'eyJsb2NhbF9rZXkiOiI5dGpJemN6Tnhrak15VXpNeElpT3dFak96dGpJbFJYWWt0MllsaDJZaW9UTzZNM09pVW1abUpXT3lJaU8yb3pjN0lTZXk5R2RqVm1jcFJHWlxucHhXWTJKaU8wRWpPenRqSXdFakx5VVRNdVlUT3VZak5pb2pNeG96YzdJQ2NwUldhc0ZtZGlvek42TTNPaTAyYmo1U1pqNVdZa0JuYnc1eWRcbjNkSEx0OTJZdVUyWXVGR1p3NUdjaW9UT3lvemM3SWlicEZXYnZSR1pweFdZMkppT3hFak96dGpJbDFXYVVCU1p1OWtJNmdqT3p0aklseDJZXG41TjJadWxHYnNsbVlpb2pNeG96YzdJQ013MENNdzBDTXdBRE1pb0RNeG96YzdJU1owRkdabFZIWjBoWFp1SmlPeEVqT3p0akkzQVRMeEVUTFxueUVETXlJaU93RWpPenRqSWxSWFlrZFdaeUppTzNvemM3SVNLbE5uYmxOV2FNQkNaeUZHWnVGR2RUaENJMVlGSXk5R2RqVm1WaW9ET3lvemNcbjdJU1p0Rm1iME5XZGs5bWN3SmlPeEVqT3p0akl5RWpJNklqT3p0aklrbEdkalZIWnZKSGNpb1RPNk0zT2lNVE15RWpJNlFqT3p0aklrbFdaXG5qbG1keVYyY2lvVE82TTNPaXNXZHU4Mll1a0hibFozYnMxaWJobG1ZaFpHUXJKWFl0SmlPMElqT3p0aklzbFdZdFZtSTZVak96dGpJNXhXWlxuMjlHVHQ0V1lwSldZR0J5YXlGV1Rpb0RPeG96YzdJU1p0Rm1ia1ZtY2xSM2NwZFdaeUppTzBFak96dGpJbFpYYTBOV1Fpb2pONk0zT2lNWGRcbjBGR2R6SmlPMm96Yzdwek14b1RZMmI5NjIxZTE4Njc5MzRiYjJiYWUyNDAyNjEzMzE4ZTFjMTdlMDhhZDM0Y2VmODgzMjdmODQ2MTVlMmM3XG4zMzA5In0='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('Facebook', 'eyJhcHBpZCI6IjQzODExNDQ1OTU1MTk3MCIsImxpa2Vfc3RhdHVzIjoiMSIsImxpa2VfbG9jYXRpb24iOiJhbGwiLCJidXR0b25fdGV4dCI6Imxpa2UiLCJidXR0b25fc2hvd2ZhY2VzIjoiIiwiYnV0dG9uX3dpZHRoIjoiMjMwIiwiYnV0dG9uX2NvbG9yIjoibGlnaHQiLCJidXR0b25fbGF5b3V0Ijoic3RhbmRhcmQiLCJjb21tZW50c19zdGF0dXMiOiIxIiwiY29tbWVudHNfbG9jYXRpb24iOiJhbGwiLCJjb21tZW50c193aWR0aCI6IjQyNSIsImNvbW1lbnRzX251bXBvc3RzIjoiNSIsImNvdW50cmllcyI6IiIsImRpc2FibGVkX2NvdW50cmllcyI6IiJ9'); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('olark', 'eyJzaXRlX2lkIjoiOTYzOS02ODAtMTAtNzU5NCIsImNvdW50cmllcyI6ImE6MTp7aTowO3M6MzpcIjgyNlwiO30iLCJkaXNhYmxlZF9jb3VudHJpZXMiOiIifQ=='); #EOQ
INSERT INTO `cc4_CubeCart_config` VALUES('languages', 'eyJkZS1ERSI6IjAiLCJlbi1HQiI6IjEiLCJlbi1VUyI6IjAiLCJlcy1FUyI6IjAiLCJmci1GUiI6IjAiLCJubC1OTCI6IjAifQ=='); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_coupons`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_coupons`
--

CREATE TABLE `cc4_CubeCart_coupons` (
  `coupon_id` int(10) unsigned NOT NULL auto_increment,
  `status` tinyint(1) NOT NULL default '1',
  `code` varchar(25) collate utf8_unicode_ci NOT NULL,
  `product_id` text collate utf8_unicode_ci,
  `discount_percent` decimal(5,2) NOT NULL default '0.00',
  `discount_price` decimal(16,2) NOT NULL default '0.00',
  `expires` date NOT NULL,
  `allowed_uses` int(10) unsigned NOT NULL default '0',
  `count` int(10) unsigned NOT NULL default '0',
  `description` text collate utf8_unicode_ci NOT NULL,
  `cart_order_id` varchar(18) collate utf8_unicode_ci default NULL,
  `archived` tinyint(1) unsigned NOT NULL default '0',
  `min_subtotal` decimal(16,2) unsigned NOT NULL default '0.00',
  `shipping` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`coupon_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_coupons`
--

INSERT INTO `cc4_CubeCart_coupons` VALUES('2', '1', 'PICKUP', '0', '10.00', '0.00', '0000-00-00', '0', '6', 'Local Pickup 10% discount', '', '0', '0.00', '0'); #EOQ
INSERT INTO `cc4_CubeCart_coupons` VALUES('6', '1', 'FORUM10', '0', '10.00', '0.00', '2012-01-31', '0', '0', 'Forum 10% off until end of January 2012', '', '0', '0.00', '0'); #EOQ
INSERT INTO `cc4_CubeCart_coupons` VALUES('10', '1', '48HOURS', '0', '10.00', '0.00', '2012-05-25', '0', '0', '48 Hour 10% code', '', '0', '0.00', '0'); #EOQ
INSERT INTO `cc4_CubeCart_coupons` VALUES('12', '1', 'SHOP10', '0', '10.00', '0.00', '2010-11-25', '1', '0', 'Discount for', '', '0', '0.00', '0'); #EOQ
INSERT INTO `cc4_CubeCart_coupons` VALUES('11', '1', 'OCT10', '0', '10.00', '0.00', '2012-10-31', '0', '2', 'Facebook 10%  off', '', '0', '0.00', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_currency`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_currency`
--

CREATE TABLE `cc4_CubeCart_currency` (
  `currency_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `code` varchar(3) collate utf8_unicode_ci NOT NULL,
  `symbol_left` varchar(10) collate utf8_unicode_ci default NULL,
  `symbol_right` varchar(10) collate utf8_unicode_ci default NULL,
  `value` decimal(10,5) NOT NULL default '0.00000',
  `decimal_places` tinyint(2) unsigned default '2',
  `updated` int(10) unsigned NOT NULL default '0',
  `active` tinyint(1) unsigned NOT NULL default '1',
  `symbol_decimal` tinyint(1) unsigned NOT NULL default '0',
  `iso` int(3) unsigned zerofill default NULL,
  KEY `curencyId` (`currency_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_currency`
--

INSERT INTO `cc4_CubeCart_currency` VALUES('2', 'US Dollars', 'USD', '$', '', '1.56090', '2', '1325677871', '0', '0', '840'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('3', 'Euro', 'EUR', '€', '', '1.45161', '2', '1123759040', '0', '1', '978'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('4', 'Japanese Yen', 'JPY', '¥', '', '198.95500', '0', '1123759040', '0', '0', '392'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('5', 'Canadian Dollars', 'CAD', '$', '', '2.17642', '2', '1123759040', '0', '0', '124'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('6', 'Australian Dollars', 'AUD', '$', '', '2.33844', '2', '1123759040', '0', '0', '036'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('7', 'Swiss Francs', 'CHF', 'CHF', '', '2.25431', '2', '1123759040', '0', '0', '756'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('8', 'Russian Rubles', 'RUB', '', 'R', '51.11620', '0', '1123759040', '0', '0', '643'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('9', 'Chinese Yuan', 'CNY', '', 'Yuan', '14.59770', '2', '1123759040', '0', '0', '156'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('11', 'Mexican Peso', 'MXN', '$', '', '19.06320', '2', '1123759040', '0', '0', '484'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('12', 'British Pounds', 'GBP', '£', '', '1.00000', '2', '1321028285', '1', '0', '826'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('2', 'US Dollars', 'USD', '$', '', '1.56090', '2', '1325677871', '0', '0', '840'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('3', 'Euro', 'EUR', '€', '', '1.45161', '2', '1123759040', '0', '1', '978'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('4', 'Japanese Yen', 'JPY', '¥', '', '198.95500', '0', '1123759040', '0', '0', '392'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('5', 'Canadian Dollars', 'CAD', '$', '', '2.17642', '2', '1123759040', '0', '0', '124'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('6', 'Australian Dollars', 'AUD', '$', '', '2.33844', '2', '1123759040', '0', '0', '036'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('7', 'Swiss Francs', 'CHF', 'CHF', '', '2.25431', '2', '1123759040', '0', '0', '756'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('8', 'Russian Rubles', 'RUB', '', 'R', '51.11620', '0', '1123759040', '0', '0', '643'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('9', 'Chinese Yuan', 'CNY', '', 'Yuan', '14.59770', '2', '1123759040', '0', '0', '156'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('13', 'South African Rand', 'ZAR', 'R', '', '12.40000', '2', '1325677916', '1', '0', '710'); #EOQ
INSERT INTO `cc4_CubeCart_currency` VALUES('11', 'Mexican Peso', 'MXN', '$', '', '19.06320', '2', '1123759040', '0', '0', '484'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_customer`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_customer`
--

CREATE TABLE `cc4_CubeCart_customer` (
  `customer_id` int(10) unsigned NOT NULL auto_increment,
  `email` varchar(254) collate utf8_unicode_ci NOT NULL,
  `password` varchar(128) collate utf8_unicode_ci default NULL,
  `salt` varchar(32) collate utf8_unicode_ci default NULL,
  `title` varchar(10) collate utf8_unicode_ci default NULL,
  `first_name` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `last_name` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `country` smallint(3) unsigned NOT NULL default '0',
  `phone` varchar(50) collate utf8_unicode_ci NOT NULL default '',
  `mobile` varchar(50) collate utf8_unicode_ci NOT NULL default '',
  `registered` int(10) unsigned NOT NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL,
  `order_count` int(10) unsigned NOT NULL default '0',
  `type` tinyint(1) unsigned default '1',
  `status` tinyint(1) unsigned NOT NULL default '1',
  `language` varchar(5) collate utf8_unicode_ci NOT NULL default 'en-US',
  `verify` varchar(32) collate utf8_unicode_ci default NULL,
  `new_password` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`customer_id`),
  UNIQUE KEY `email` (`email`),
  FULLTEXT KEY `fulltext` (`first_name`,`last_name`,`email`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_customer`
--

INSERT INTO `cc4_CubeCart_customer` VALUES('8', 'mariskagarcia@yahoo.co.uk', 'dfc1464ebfe4aaf3713d45442dc5860e', '9xmrsy', 'Miss', 'Mariska', 'Garcia', '225', '07811546487', '', '1324899537', '2.96.86.51', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('6', 'fishgirlcrawley@sky.com', 'afbf3a755970497327d220292fd06790', 'biZRk8', 'miss', 'emma', 'crawley', '225', '07521273518', '', '1323963333', '86.140.115.191', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('9', 'Saraglvsdrew2@tiscali.co.uk', 'fecae876d13a3d361aef545ea8d7db2c', 'pEJhZV', 'Mrs', 'Sarah', 'Norris', '225', '01779472103', '', '1325245580', '212.183.128.98', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('10', 'sammyjosharpe@hotmail.co.uk', 'dbadaa59f82e96ddc77b955524470776', 'R4VXIF', 'miss', 'sammy-jo', 'sharpe', '225', '07857552569', '', '1325625172', '90.220.79.53', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('11', 'lewisgsc22@hotmail.co.uk', 'f5363ced00475b28175e6ce8e5b42338', '12ITTd', 'mr', 'lewis', 'stephen', '225', '01779481157', '', '1325712481', '95.146.87.121', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('12', 'mark@fabian-lovely.co.uk', 'bfb89a99e0fc024fb668824c5850a71cf4840ea6e7d76f6386aef9b254e2f68ab782c4711bb06e2df99b9fa75899d82f7aa045371ff9dcf764311c210e90cfa9', '50688727', '', 'Mark', 'Fabian-Lovely', '225', '12345656', '12345667', '1325844927', '82.27.226.223', '5', '1', '1', 'en-US', '', '1'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('13', 'ellipsisdance@hotmail.com', 'b3ccfa7b38e8caf05e1a25ce5ef83fe5', 'K9lWsM', 'miss', 'robine', 'young', '225', '07702236416', '07702236416', '1326121570', '81.96.52.232', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('14', 'sarahlvsdrew2@tiscali.co.uk', '7342950c9e862098d0e941779e32e775', 'Ypo3k7', 'mrs', 'sarah', 'norris', '225', '01779472103', '', '1326815891', '88.104.220.107', '3', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('16', 'jaczandrobbie@live.co.uk', 'aa7014de4d6d7c386a2a96ebb2351995', 'kFcdlE', 'mrs', 'jacqui', 'beaumont', '225', '07961858978', '', '1327007142', '81.97.4.183', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('17', 'antz08@live.co.uk', 'a268a7c6ed0a0df283da6de7005bdd3c', 'ejmk8l', 'mrs', 'anthea', 'haig', '225', '02392420871', '07564253447', '1327192463', '82.24.228.125', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('18', 'lorrainesankey@hotmail.co.uk', '8f5653441a4caf9fa22687998606372c', 'NBujmG', 'miss', 'Lorraine', 'Sankey', '225', '01257 368248', '', '1327616031', '81.158.96.111', '3', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('19', 'laulau_laulau@hotmail.co.uk', '9511e98742ac65a7e30685c9a41802dd', 'hRzpa2', 'MRS', 'LAURA', 'HICKMAN', '225', '02392341762', '07732072808', '1332368381', '82.24.228.112', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('20', 'Debbie.renshall@gmail.com', '94f069c2e67f57ebda8cede536718daa', 'dKagYn', 'Mr', 'Paul', 'Renshall', '224', '00971552369355', '', '1328639242', '87.201.100.189', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('23', 'kelly-rus@hotmail.com', 'b136ace7caba8994ef43112b6bd6bbf0', '9DSuH6', 'miss', 'kelly', 'jones', '225', '01248679192', '07748767558', '1329577284', '86.141.97.204', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('22', 'carolruthobrien@yahoo.co.uk', 'c5656b2b770aed99766564b43bb48a53', 'iYb1e3', 'MRS', 'CAROL', 'OBRIEN', '225', '01254882037', '', '1329340338', '2.100.212.108', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('24', 'helen.carvell@yahoo.co.uk', '26e04043182959e8381913b386041e8c', 'VJegif', 'mrs', 'helen', 'carvell', '225', '01514878704', '', '1330039257', '90.219.183.73', '2', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('26', 'leahselwood@live.co.uk', 'd56b2997306c0e3709fa8a2544084561', 'ob0h76', 'miss', 'leah', 'selwood', '225', '07717686739', '07717686739', '1330187200', '212.183.128.142', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('25', 'shannonroberts.roberts24@googlemail.com', '545cc387a1b410bb552e68ffa1412bba', 'WKzy1a', '', 'lisa', 'watts', '225', '441443836055', '441443836055', '1329929662', '90.214.31.57', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('28', 'dionnedunn68@yahoo.co.uk', '50dbe7808e780ebb74ed44f397e49d78', 'kLVkoD', 'Mrs', 'Dionne', 'Dunn', '225', '07747136693', '', '1331740207', '77.103.53.244', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('29', 'debzwills@blueyonder.co.uk', '28637e652070edf4416383b760c7eaab', 'RRA44j', 'Mr', 'David', 'Williams', '225', '01752291304', '', '1331844005', '94.169.237.53', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('30', 'paulduffin02@live.co.uk', '7d2d65664c0969ba91c94297971fc0e3', 'r0IEbh', '', 'paul', 'duffin', '225', '02392737356', '', '1332940411', '92.24.122.132', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('31', 's-hodson@hotmail.co.uk', '6c721d20bd80848e155ba36dc905ea3b', 'bsCdNh', 'mrs', 'stephanie', 'hodson', '225', '01209718084', '', '1334578729', '2.125.22.75', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('32', 'mrsbunchies@yahoo.co.uk', 'd1c33be99e7ec2f60d6d7649af7981db', 'tvbhTw', 'MRS', 'Dawn', 'Waddell', '225', '07592841033', '07592841033', '1334694851', '90.213.253.20', '1', '2', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('33', 'candt20112011@hotmail.co.uk', 'a7d72eb5fbdcc05d9bd1937d25adf11c', 'V2iNLD', 'miss', 'charlene', 'mcgrail', '225', '07521325738', '07521325738', '1335120182', '89.242.111.118', '4', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('34', 'jay.handley@sky.com', 'fab09a1ec09b4f8424813c941fefbf9d', '2Xkht3', 'Mrs', 'Jacqueline', 'Handley', '225', '01384230639', '07960961272', '1335773948', '94.5.59.234', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('35', 'andertonmx@aol.com', '4546d6d8b32e3557bf8aa9845b5c65a1', 'cIw5rw', 'Mrs', 'Cheryl', 'Anderton', '225', '01993 842664', '07580491131', '1335788933', '213.83.112.138', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('36', 'boys_r_gr8@hotmail.com', 'e0039a270253854d03b495cc2dab545b', '3PwN06', 'Miss', 'Kate', 'Goldsack', '225', '01744601490', '07528521433', '1335824582', '94.172.224.203', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('37', 'stephanie.nichols@mypostoffice.co.uk', 'bfccfcba7adedf5b268c6b7bbc67b3b0', 'XMktGF', 'Mrs', 'Stephanie', 'Nichols', '225', '0191 5498802', '', '1336069048', '86.175.90.194', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('38', 's.knowles4@sky.com', 'a842443c700f198465de44cc051be5ae', '79wHFL', 'Mrs', 'Lisa', 'Knowles', '225', '01455450023', '', '1336078240', '90.195.3.159', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('39', 'chelnicky@hotmail.co.uk', '77eceb3fd181c51941759ef07b0ba88e', '4UyjhD', 'Miss', 'Nicole', 'Hayes', '225', '01406424225', '', '1336330582', '88.104.123.184', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('40', 'Colinandmarianne@btinternet.com', '4cfb8dd3032c01b06e2f28eb4b108a42', 'i71q6u', 'Miss', 'Marianne', 'Pyfrom', '225', '07753103214', '', '1336632300', '82.132.216.178', '2', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('41', 'fmorgan123@hotmail.co.uk', '325227a0d1b3648eebaef9fd3ba9a1a5', 'VGNy3b', 'mrs', 'janet', 'mcgrail', '225', '07752770828', '07752770828', '1337433438', '109.153.206.37', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('42', 's.pavic@shu.ac.uk', '513b4e552ad2974ec52fba2047c58a84', 'rTgIop', 'Dr', 'Suzana', 'Pavic', '225', '01142321365', '', '1337518571', '86.167.28.217', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('43', 'POMPEYKIDS2@HOTMAIL.COM', '56a08e30a1ca539dcafe5d89587aa2e2', '1lzJ2F', 'MRS', 'JULIE', 'NASH', '225', '02392360795', '', '1337601500', '94.13.150.221', '2', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('44', 'Arrywizard@googlemail.com', '23ecc0f74e853c19872264edea149731', 'Uaxvlv', 'Mrs', 'Kellie', 'Johnson', '225', '01752559555', '07752217764', '1338660618', '77.100.103.199', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('46', 'n.pearce432@googlemail.com', '39e5c94e290e1ad68bc4b2c7518d8200', 'YBdheR', 'Miss', 'Nicki', 'Pearce', '225', '01908460258', '', '1341949575', '176.27.84.41', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('47', 'bri90291@yahoo.com', '20824c4dde8392254e91a38c537313a9', '9zKR6A', '', 'Brianna', 'Robertson', '226', '5414181203', '', '1342043133', '71.53.68.125', '2', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('48', 'Sales@roadwholesale.co.uk', 'ec67be6d2db406458bb779cef2109d64', 'BBcjor', 'Mrs', 'Danielle', 'Mullally', '225', '07980588309', '', '1343850365', '2.126.47.186', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('49', 'mmcdonagh81@hotmail.co.uk', 'ce3a2359ad39f55d05112edbea3df9ec', 'LIsSMF', 'mrs', 'margret', 'mcdonagh', '225', '07881453024', '07881453024', '1344463284', '90.214.66.37', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('50', 'sophie.rodwell@nhs.net', '7b788fee539faa7b58078fffe9df592a', 'kNtGtZ', 'Miss', 'Sophie', 'Rodwell', '225', '07940725311', '07940725311', '1346499275', '86.165.244.121', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('51', 'Rbrtsn@fsmail.net', 'd4c9053572f1ad2fbc2f6de64c0c218a', '7Sb3O6', 'Mrs', 'Margaret', 'Robertson', '225', '07531033672', '07531033672', '1348165977', '95.145.212.221', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('52', 'Helenttofa@hotmail.co.uk', '2d436ad056f90df18ea241f7ff270d9f', 'uTavGD', 'Miss', 'Helen', 'Ttofa', '225', '07969546591', '', '1348688620', '82.2.130.246', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('53', 'l.grant8se@btinternet.com', '3472c147f5341c3a91929c396d3488f7', 'yOLQac', 'mrs', 'louise', 'grant', '225', '01964541885', '', '1349264625', '90.209.182.143', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('54', 'ilvdggs@verizon.net', '04cdee222450ceaa45898b87180e4a43', 'RgtiSU', 'Mrs', 'Julie', 'Jacobs-Jennings', '226', '804 370 9418', '', '1349378399', '198.228.195.57', '0', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('55', 'Lauratyy@live.co.uk', 'c2340d497f8130fba7b8718a5ae017d7', 'TouVjC', 'Mrs', 'Laura', 'Tyrer', '225', '07885856743', '', '1350329443', '82.132.245.135', '2', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('57', 'rayndenise209@virginmedia.com', '4f808dd824190396a105b4cbae63d7c5', 'XkXIqW', 'Mrs', 'Denise', 'Townsend', '225', '01709556339', '07770991639', '1351091616', '77.102.208.59', '1', '1', '1', 'en-US', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_customer` VALUES('59', 'dyndesmespi@aol.com', '4739be15ca3899113d094b56e10a41da7dcd301e7d24468259c175a66db6276272ed30b442069164a3a08f5af12d0cf86aaa8d700c51153f3b9ef3b7a80bc3b2', '6026e623', '', 'BiobroonsOE', 'BiobroonsOE', '0', '123456', '07756557475', '1352342514', '', '0', '1', '1', 'en-US', '', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_customer_group`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_customer_group`
--

CREATE TABLE `cc4_CubeCart_customer_group` (
  `group_id` int(10) unsigned NOT NULL auto_increment,
  `group_name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `group_description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_customer_group` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_customer_membership`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_customer_membership`
--

CREATE TABLE `cc4_CubeCart_customer_membership` (
  `membership_id` int(10) unsigned NOT NULL auto_increment,
  `group_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`membership_id`),
  KEY `group_id` (`group_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_customer_membership` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_documents`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_documents`
--

CREATE TABLE `cc4_CubeCart_documents` (
  `doc_id` int(10) unsigned NOT NULL auto_increment,
  `doc_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `doc_content` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_title` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_keywords` text collate utf8_unicode_ci NOT NULL,
  `doc_order` int(10) unsigned NOT NULL default '0',
  `doc_terms` tinyint(1) unsigned NOT NULL default '0',
  `doc_url` varchar(200) collate utf8_unicode_ci default NULL,
  `doc_url_openin` tinyint(1) unsigned default NULL,
  `doc_view` int(2) NOT NULL default '1',
  `doc_type` int(2) NOT NULL default '1',
  `box_name` varchar(50) collate utf8_unicode_ci default NULL,
  `catId` int(11) NOT NULL default '0',
  `doc_parent_id` int(10) unsigned NOT NULL default '0',
  `doc_status` tinyint(1) unsigned NOT NULL default '1',
  `doc_home` tinyint(1) unsigned NOT NULL default '0',
  `doc_lang` varchar(5) collate utf8_unicode_ci NOT NULL,
  `navigation_link` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`doc_id`),
  KEY `doc_parent_id` (`doc_parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_documents`
--

INSERT INTO `cc4_CubeCart_documents` VALUES('1', 'About Us', '<p><span class=\"navTitle\">PnP Dance is a family run business that&nbsp;</span><span class=\"navTitle\">provides dance wear and rhinestones of all sizes and grades. &nbsp;We understand how expensive dancing can be, that is why we have started to make basic costumes at great prices using high quality lycra from Funki Fabrics. &nbsp;We have such a great deal with them that we can offer the cost of a basic costume for not much more than the cost of the actual lycra at normal prices. &nbsp;We also make custom design costumes and all our outfits are hand stonned with either high quality rhinestones or Swavorski crystals. &nbsp;</span></p>\r\n<p>We have just opened our first shop in Portsmouth and welcome anyone to visit and have a chat with us about your dancing needs, we are very experienced and have provided many costumes for various events. &nbsp;Our details can be found on the <a href=\"http://www.pnpdance.com/contact-us/info_2.html\">Contact Us</a> page.</p>\r\n<p>If you have any questions about what we can do or supply please <a href=\"javascript:void(location.href=&#39;mailto:&#39;+String.fromCharCode(105,110,102,111,64,112,110,112,100,97,110,99,101,46,99,111,109)+&#39;?subject=About&#39;)\">email</a> us!</p>', 'About Us', 'About PnPDance.com', 'About, pnpdance, rhinestones, ss16, ss20, ss32', '1', '0', '', '0', '4', '1', 'ABOUT', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('2', 'Contact Us', '<p>Want to get in touch? &nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Princess &#39;n&#39; Pickle has a shop in Portsmouth the address is</p>\r\n<p>80 Locksway Road<br />\r\nPortsmouth<br />\r\nHampshire<br />\r\nPO4 8JP</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;<u><strong>Opening Hours</strong></u></p>\r\n<table width=\"200\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <tbody>\r\n        <tr>\r\n            <td><strong>Day</strong></td>\r\n            <td><strong>Opening Hours</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td>Monday</td>\r\n            <td>9:00am - 4:30pm</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Tuesday</td>\r\n            <td>9:00am - 4:30pm</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Wednesday</td>\r\n            <td>Closed</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Thursday</td>\r\n            <td>9:00am - 4:30pm</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Friday</td>\r\n            <td>9:00am - 4:30pm</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Saturday</td>\r\n            <td>Closed</td>\r\n        </tr>\r\n        <tr>\r\n            <td>Sunday</td>\r\n            <td>Closed</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>You can call durring normal business hours on 02392 754432 or 07564 790 059</p>\r\n<p>&nbsp;</p>\r\n<p>Text (SMS) us on 07564 790 059</p>\r\n<p>&nbsp;</p>\r\n<p><a href=\"skype:pnpdance?call\">Skpe us on PnPDance</a></p>\r\n<p><a href=\"http://www.facebook.com/pnpdance\">Facebook is pnpdance</a></p>\r\n<p><a href=\"https://twitter.com/pnpdance\">Twitter is @pnpdance</a></p>\r\n<p>&nbsp;</p>\r\n<p>Please also feel free to drop us an email to&nbsp;<a href=\"javascript:void(location.href=&#39;mailto:&#39;+String.fromCharCode(105,110,102,111,64,112,110,112,100,97,110,99,101,46,99,111,109)+&#39;?subject=Help!&#39;)\">info@pnpdance.com</a><br />\r\n&nbsp;</p>', 'Contact Us', 'Contact Princess n Pickle, contact pnpdance.com,', 'contact, pnpdance, dancewear, locksway road, shop, online', '2', '0', '', '0', '4', '1', 'CONTACT', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('3', 'Terms & Conditions', '<p>\r\n<meta name=\"Title\" content=\"\" />\r\n<meta name=\"Keywords\" content=\"\" />\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n<meta name=\"ProgId\" content=\"Word.Document\" />\r\n<meta name=\"Generator\" content=\"Microsoft Word 14\" />\r\n<meta name=\"Originator\" content=\"Microsoft Word 14\" />\r\n<link rel=\"File-List\" href=\"file://localhost/Users/Mark/Library/Caches/TemporaryItems/msoclip/0clip_filelist.xml\" /> <!--[if gte mso 9]><xml>\r\n<o:OfficeDocumentSettings>\r\n<o:PixelsPerInch>96</o:PixelsPerInch>\r\n<o:TargetScreenSize>800x600</o:TargetScreenSize>\r\n</o:OfficeDocumentSettings>\r\n</xml><![endif]-->\r\n<link rel=\"themeData\" href=\"file://localhost/Users/Mark/Library/Caches/TemporaryItems/msoclip/0clip_themedata.xml\" /> <!--[if gte mso 9]><xml>\r\n<w:WordDocument>\r\n<w:View>Normal</w:View>\r\n<w:Zoom>0</w:Zoom>\r\n<w:TrackMoves />\r\n<w:TrackFormatting />\r\n<w:PunctuationKerning />\r\n<w:ValidateAgainstSchemas />\r\n<w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\r\n<w:IgnoreMixedContent>false</w:IgnoreMixedContent>\r\n<w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\r\n<w:DoNotPromoteQF />\r\n<w:LidThemeOther>EN-US</w:LidThemeOther>\r\n<w:LidThemeAsian>JA</w:LidThemeAsian>\r\n<w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>\r\n<w:Compatibility>\r\n<w:BreakWrappedTables />\r\n<w:SnapToGridInCell />\r\n<w:WrapTextWithPunct />\r\n<w:UseAsianBreakRules />\r\n<w:DontGrowAutofit />\r\n<w:SplitPgBreakAndParaMark />\r\n<w:EnableOpenTypeKerning />\r\n<w:DontFlipMirrorIndents />\r\n<w:OverrideTableStyleHps />\r\n</w:Compatibility>\r\n<m:mathPr>\r\n<m:mathFont m:val=\"Cambria Math\" />\r\n<m:brkBin m:val=\"before\" />\r\n<m:brkBinSub m:val=\"&#45;-\" />\r\n<m:smallFrac m:val=\"off\" />\r\n<m:dispDef />\r\n<m:lMargin m:val=\"0\" />\r\n<m:rMargin m:val=\"0\" />\r\n<m:defJc m:val=\"centerGroup\" />\r\n<m:wrapIndent m:val=\"1440\" />\r\n<m:intLim m:val=\"subSup\" />\r\n<m:naryLim m:val=\"undOvr\" />\r\n</m:mathPr></w:WordDocument>\r\n</xml><![endif]--><!--[if gte mso 9]><xml>\r\n<w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"\r\nDefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"\r\nLatentStyleCount=\"276\">\r\n<w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"0\" QFormat=\"true\" Name=\"heading 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\" />\r\n<w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\" />\r\n<w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\" />\r\n<w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Default Paragraph Font\" />\r\n<w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\" />\r\n<w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\" />\r\n<w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"0\" Name=\"Normal (Web)\" />\r\n<w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Table Grid\" />\r\n<w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\" />\r\n<w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\" />\r\n<w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\" />\r\n<w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\" />\r\n<w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\" />\r\n<w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\" />\r\n<w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\" />\r\n<w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\" />\r\n</w:LatentStyles>\r\n</xml><![endif]--> <style type=\"text/css\">\r\n<!--\r\n /* Style Definitions */\r\np.MsoNormal, li.MsoNormal, div.MsoNormal\r\n	{mso-style-unhide:no;\r\n	mso-style-qformat:yes;\r\n	mso-style-parent:\"\";\r\n	margin:0cm;\r\n	margin-bottom:.0001pt;\r\n	mso-pagination:widow-orphan;\r\n	font-size:12.0pt;\r\n	font-family:\"Times New Roman\";\r\n	mso-fareast-font-family:\"Times New Roman\";\r\n	mso-bidi-font-family:\"Times New Roman\";\r\n	mso-fareast-language:EN-GB;}\r\nh3\r\n	{mso-style-unhide:no;\r\n	mso-style-qformat:yes;\r\n	mso-style-link:\"Heading 3 Char\";\r\n	mso-margin-top-alt:auto;\r\n	margin-right:0cm;\r\n	mso-margin-bottom-alt:auto;\r\n	margin-left:0cm;\r\n	mso-pagination:widow-orphan;\r\n	mso-outline-level:3;\r\n	font-size:13.5pt;\r\n	font-family:\"Times New Roman\";\r\n	mso-fareast-language:EN-GB;\r\n	font-weight:bold;}\r\np\r\n	{mso-style-unhide:no;\r\n	mso-margin-top-alt:auto;\r\n	margin-right:0cm;\r\n	mso-margin-bottom-alt:auto;\r\n	margin-left:0cm;\r\n	mso-pagination:widow-orphan;\r\n	font-size:12.0pt;\r\n	font-family:\"Times New Roman\";\r\n	mso-fareast-font-family:\"Times New Roman\";\r\n	mso-bidi-font-family:\"Times New Roman\";\r\n	mso-fareast-language:EN-GB;}\r\nspan.Heading3Char\r\n	{mso-style-name:\"Heading 3 Char\";\r\n	mso-style-unhide:no;\r\n	mso-style-locked:yes;\r\n	mso-style-link:\"Heading 3\";\r\n	mso-ansi-font-size:13.5pt;\r\n	mso-bidi-font-size:13.5pt;\r\n	mso-ansi-language:EN-GB;\r\n	mso-fareast-language:EN-GB;\r\n	font-weight:bold;}\r\n.MsoChpDefault\r\n	{mso-style-type:export-only;\r\n	mso-default-props:yes;\r\n	font-size:10.0pt;\r\n	mso-ansi-font-size:10.0pt;\r\n	mso-bidi-font-size:10.0pt;\r\n	mso-ansi-language:EN-US;}\r\n@page WordSection1\r\n	{size:595.3pt 841.9pt;\r\n	margin:72.0pt 90.0pt 72.0pt 90.0pt;\r\n	mso-header-margin:35.4pt;\r\n	mso-footer-margin:35.4pt;\r\n	mso-paper-source:0;}\r\ndiv.WordSection1\r\n	{page:WordSection1;}\r\n-->\r\n</style> <!--[if gte mso 10]>\r\n<style>\r\n/* Style Definitions */\r\ntable.MsoNormalTable\r\n{mso-style-name:\"Table Normal\";\r\nmso-tstyle-rowband-size:0;\r\nmso-tstyle-colband-size:0;\r\nmso-style-noshow:yes;\r\nmso-style-priority:99;\r\nmso-style-parent:\"\";\r\nmso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\nmso-para-margin:0cm;\r\nmso-para-margin-bottom:.0001pt;\r\nmso-pagination:widow-orphan;\r\nfont-size:10.0pt;\r\nfont-family:\"Times New Roman\";\r\nmso-ansi-language:EN-US;}\r\n</style>\r\n<![endif]-->    <!--StartFragment--></p>\r\n<h3 align=\"center\" style=\"text-align:center\">Terms and Conditions for Use and Sales<o:p></o:p></h3>\r\n<p>Last updated 11 May 2011<o:p></o:p></p>\r\n<p><br />\r\n1. <strong>Our website</strong><br />\r\nYour use of this website and any service contained within constitutes acceptance of these Terms &amp; Conditions <o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>2. <strong>Customer Information</strong><br />\r\n2.1 You should always check that the contact information you provide is correct before creating a customer account or proceeding to payment. <o:p></o:p></p>\r\n<p>2.2 You are responsible for maintaining your own username and password, where required to access your customer account. You should ensure that you store your username and password securely and that the details required to access your customer account are not provided to another party.<o:p></o:p></p>\r\n<p>2.3 As a customer you are responsible for your customer account and actions taken within it. If you are aware or suspect that your customer account username and password or other details have become known to a third party, you should inform us immediately.<o:p></o:p></p>\r\n<p>2.4 Our website is only intended for use by adults. Adults may purchase products for children as long as the products purchased are intended by the manufacturer for use or consumption by children.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>3.<strong> Privacy</strong><br />\r\nPnPDance.com takes your privacy seriously. We comply with the Data Protection Act 1998. For further details please see our Privacy Policy.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>4. <strong>Product Pricing and Title</strong><br />\r\n4.1 We make every effort to ensure that the pricing displayed on our website is correct. However, if an error in the pricing of a product is found we reserve the right to either cancel your order or contact you to arrange payment of any extra sum due or refund any over-payment made by you (as applicable). The processing of an order can be cancelled or corrected by us at anytime up to the shipment of that order and any related items. <o:p></o:p></p>\r\n<p>4.2 We reserve the right to alter all product pricing without notice.<o:p></o:p></p>\r\n<p>4.3 Title in any products ordered from us does not pass to you, the purchaser until we have received and processed a valid payment, and that payment has been made into our own bank account and your order has been shipped.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>5. <strong>Your Order</strong><br />\r\n5.1 When you place an order you will automatically receive a confirmation email from us to confirm your order. Your order constitutes an offer made to us to purchase the goods specified in the order.<o:p></o:p></p>\r\n<p>5.2 Your offer is only accepted by us once we have emailed you to confirm the dispatch of your order.<o:p></o:p></p>\r\n<p>5.3 Product items not included within the dispatch email are not included in the order and contract between you and us.<o:p></o:p></p>\r\n<p>5.4 We reserve the right to delay or refuse orders where a transaction contains incomplete details or details that cannot be verified or where fraud is suspected. <o:p></o:p></p>\r\n<p>5.5 If we are unable to reasonably ascertain these details or resolve these issues a full refund will be made against the card used at the time of purchase. No other form of refund or credit will be offered nor will a refund be made to any third party card or account.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>6. <strong>Shipping and Customs Duty</strong><br />\r\n6.1 All orders received by us are shipped subject to availability. <o:p></o:p></p>\r\n<p>6.2 We reserve the right to ship products at a later date (up to 28 days after purchase) where the product ordered is not in stock at the time of purchase. In this situation you will be contacted and offered a full refund instead of delivery of the product.<o:p></o:p></p>\r\n<p>6.3 We cannot be held responsible for disruption to shipping caused by industrial disputes or action outside our direct control. If such disruption occurs you will be offered delivery via an alternative delivery or fulfilment company or a full refund.<o:p></o:p></p>\r\n<p>6.4 If you are ordering a product from outside the UK the recipient of the product is responsible for all customs duties or tariffs incurred in the country to which the products are shipped. Furthermore your order may be subject to delay or be opened and searched by local customs authorities when entering the destination country. Please note we are unable to provide specific advice on customs duties or tariffs.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>7. <strong>Cancellation Rights, Returns and Refunds</strong><br />\r\n7.1 Under the Consumer Protection (Distance Selling) Regulations 2000 you have a right to cancel your purchase. However, to exercise this right you must notify us in writing, (email or letter) within [specify number of working days - by law this must be a minimum of 7, however some websites offer a 30 day returns policy] working days from the day after you receive your goods.<o:p></o:p></p>\r\n<p>7.2 As stated above notification of cancellation must be in writing, a telephone call is not a valid cancellation.<o:p></o:p></p>\r\n<p>7.3 No right of cancellation, refund or return exists under the Consumer Protection (Distance Selling) Regulations 2000 once you have used your product, unless the product is defective and you are returning it for this reason. <o:p></o:p></p>\r\n<p>7.4 Goods that are sealed or shrink-wrapped and this is removed can only be returned if they are defective.<o:p></o:p></p>\r\n<p>7.5 No right of cancellation exists for personalised goods or goods that are intimate in their nature or goods where there may be hygiene issues, unless defective.<o:p></o:p></p>\r\n<p>7.6 Please observe the following procedure for all returns to us:<o:p></o:p></p>\r\n<p>7.6.1 On the back of your delivery note or on another piece of paper, (if you no longer have your delivery note), include your order number and the reason for the return.<o:p></o:p></p>\r\n<p>7.6.2 If you are returning your product because it is defective, please state the defect or defects.<o:p></o:p></p>\r\n<p>7.6.3 Repackage the product in its original packaging, including any accessories, brochures, manuals, guarantees or warranties that came with the product. Unfortunately we will be unable to issue a refund where the product is in an incomplete state.<o:p></o:p></p>\r\n<p>7.7 If the original packaging surrounding the product has been damaged or destroyed we will only issue a refund if the product is being returned due to a defect. If the original packaging of a defective product has been damaged or destroyed you should ensure that the returned product is adequately packed for shipment back to us.<o:p></o:p></p>\r\n<p>7.8 You are responsible for paying any postage or shipping costs incurred when returning the product.<o:p></o:p></p>\r\n<p>7.9 We recommend that all returns be sent by registered post, so that a record of the return is available for you.<o:p></o:p></p>\r\n<p>7.10 We will not issue refunds for any items lost or stolen in transit to us. <o:p></o:p></p>\r\n<p>7.11 Where a return is lost or stolen in transit to us, you should claim compensation from the company that shipped the return.<o:p></o:p></p>\r\n<p>7.12 If you fail to return a product to us, we may make arrangements to have the product collected from you. The cost of this collection will be passed on to you.<o:p></o:p></p>\r\n<p>7.13 Unused products may be returned promptly by customers to the address listed below: <o:p></o:p></p>\r\n<p>PnPDance.com<br />\r\n8 Edgerly Gardens<br />\r\nPortsmouth<br />\r\nHampshire <o:p></o:p></p>\r\n<p><o:p>&nbsp;</o:p></p>\r\n<p>7.14 Subject to the above, we will refund the purchase price of a returned product within thirty days of receiving written notification of your intention to return the product.<o:p></o:p></p>\r\n<p>7.15 We will also refund the cost of standard or recorded postage incurred returning a product, if incorrectly sent by us or where the product has been returned due to a defect. Please note that we will not refund any courier, overnight or express element of any delivery or postage charge, including Royal Mail Special Delivery.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>8. <strong>Customer Complaints</strong><br />\r\nWe endeavour to respond to all customer complaints or queries within five working days. <o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>9. <strong>Faulty Products</strong><br />\r\nWhere a Customer experiences a fault with a product it can be returned to PnPDance.com, subject to our returns policy above.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>10. <strong>Events outside our control</strong><br />\r\nPnPDance.com shall not be liable for delay or failure to perform any obligation under these Terms &amp; Conditions if the delay or failure is caused by any circumstances beyond our reasonable control, including, but not limited to, acts of god, war, civil disorder or industrial dispute. <o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>11. <strong>Licence</strong><br />\r\n11.1 PnPDance.com grants you a licence to access the content, information and services contained within our website for personal use only.<o:p></o:p></p>\r\n<p>11.2 This licence allows you to download and cache (using your browser) individual pages from our website.<o:p></o:p></p>\r\n<p>11.3 This licence does not allow you to download and modify individual pages or substantial parts of our website nor to make our website available via an intranet, where our website or a substantial part of it is hosted locally on the intranet in question.<o:p></o:p></p>\r\n<p>11.4 Our website design, layout, content or text cannot be copied, edited or otherwise manipulated without our express prior written permission.<o:p></o:p></p>\r\n<p>11.5 Our website cannot be placed within the frame-set of another site.<o:p></o:p></p>\r\n<p>11.6 Third parties are not allowed to &ldquo;deep link&rdquo; to pages within our website, without our express prior written permission. All links (unless expressly permitted by us) should be to the main index page of our website. Furthermore, the content of such links, whether graphic or text should not be misleading, false, derogatory or in any other way offensive.<o:p></o:p></p>\r\n<p>11.7 The restriction on &ldquo;deep linking&rdquo; does not apply to affiliate partners who wish to send customers directly to a particular page or product in order to increase their affiliate sales.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>12. <strong>Copyright</strong><br />\r\n12.1 All content, databases, graphics, buttons, icons, logos, layouts and look &amp; feel are the copyright of PnPDance.com, unless expressly acknowledged as otherwise. <o:p></o:p></p>\r\n<p>12.2 The data mining, extraction or utilisation of product information from our website is not permitted without our express prior written permission.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>13.<strong> Reasonably Foreseeable Losses</strong><br />\r\n13.1 PnPDance.com will be liable for any losses incurred by you due to breaches of these Terms &amp; Conditions by us, where such losses were reasonably foreseeable at the time the contract between you and us was made.<o:p></o:p></p>\r\n<p>13.2 All business, indirect or consequential losses not reasonably foreseeable at the time of the contract between you and us are excluded.<o:p></o:p></p>\r\n<p>13.3 PnPDance.com does not exclude or limit liability for death or personal injury caused by the negligence or breach of duty by us, our employees or officers.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>14. <strong>Severability</strong><br />\r\nThe foregoing paragraphs, sub-paragraphs and clauses of these Terms &amp; Conditions shall be read and construed independently of each other. Should any part of this agreement or its paragraphs, sub-paragraphs or clauses be found invalid it shall not affect the remaining paragraphs, sub-paragraphs and clauses. <o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>15. <strong>Waiver</strong><br />\r\nFailure by PnPDance.com to enforce any accrued rights under these Terms &amp; Conditions is not to be taken as or deemed to be a waiver of those rights unless we acknowledge the waiver in writing. <o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>16. <strong>Entire Terms &amp; Conditions</strong><br />\r\nThese Terms &amp; Conditions set out the entire agreement and understanding between you and PnPDance.com. We reserve the right to change these Terms &amp; Conditions at any time, without giving notice to you.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>17. <strong>Jurisdiction</strong><br />\r\nThese Terms &amp; Conditions shall be interpreted, construed and enforced in accordance with English law and shall be subject to the exclusive jurisdiction of the English Courts. <br />\r\n<br />\r\nYour statutory rights are unaffected.<o:p></o:p></p>\r\n<p>&nbsp;<o:p></o:p></p>\r\n<p>Our contact details are as follows:<o:p></o:p></p>\r\n<p>info@pnpdance.com<o:p></o:p></p>\r\n<p class=\"MsoNormal\"><o:p>&nbsp;</o:p></p>\r\n<!--EndFragment-->', 'Terms and Conditions', 'PnPDance T&Cs', 'Terms, conditions, pnpdance, rhinestones', '3', '1', '', '0', '1', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('4', 'Privacy Policy', '<div style=\"text-align: center; \"><span style=\"font-size: large; \"><strong><span style=\"font-size: x-large; \">Privacy Policy for PnPDance.com&nbsp;</span></strong></span></div>\r\n<div style=\"text-align: center; \">&nbsp;</div>\r\n<div style=\"text-align: center; \"><strong><span style=\"font-size: large; \">Welcome to PnPDance.com (the &quot;Site&quot;).</span></strong></div>\r\n<div>&nbsp;</div>\r\n<div>We understand that privacy online is important to users of our Site, especially when conducting business.&nbsp;</div>\r\n<div>This statement governs our privacy policies with respect to those users of the Site (&quot;Visitors&quot;) who visit without&nbsp;transacting business and Visitors who register to transact business on the Site and make use of the various services offered by PnPDance.com (collectively, &quot;Services&quot;) (&quot;Authorized Customers&quot;).</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>&quot;Personally Identifiable Information&quot;&nbsp;</strong></span></div>\r\n<div>refers to any information that identifies or can be used to identify, contact, or locate the person to whom such information pertains, including, but not limited to, name, address, phone number, fax number, email address, financial profiles, social security number, and credit card information. Personally Identifiable Information does not include information that is collected anonymously (that is, without identification of the individual user)&nbsp;</div>\r\n<div>or demographic information not connected to an identified individual.</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>What Personally Identifiable Information is collected?&nbsp;</strong></span></div>\r\n<div>We may collect basic user profile information from all of our Visitors. We collect the following additional information from our Authorized Customers: the names, addresses, phone numbers and email addresses of Authorized Customers, the nature and size of the business, and the nature and size of the advertising inventory that the Authorized Customer intends to purchase or sell.</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>What organizations are collecting the information?&nbsp;</strong></span></div>\r\n<div>In addition to our direct collection of information, our third party service vendors (such as credit card companies, clearinghouses and banks) who may provide such services as credit, insurance, and escrow services may collect this information from our Visitors and Authorized Customers. We do not control how these third parties use such information, but we do ask them to disclose how they use personal information provided to them from Visitors and Authorized Customers. Some of these third parties may be intermediaries that act solely as links in the distribution chain, and do not store, retain, or use the information given to them.</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>How does the Site use Personally Identifiable Information?</strong></span></div>\r\n<div>We use Personally Identifiable Information to customize the Site, to make appropriate service offerings, and to fulfill buying and selling requests on the Site. We may email Visitors and Authorized Customers about research or purchase and selling opportunities on the Site or information related to the subject matter of the Site. We may also use Personally Identifiable Information to contact Visitors and Authorized Customers in response to specific inquiries, or to provide requested information.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>With whom may the information may be shared?</strong></span></div>\r\n<div>Personally Identifiable Information about Authorized Customers may be shared with other Authorized Customers who wish to evaluate potential transactions with other Authorized Customers. We may share aggregated information about our Visitors, including the demographics of our Visitors and Authorized Customers, with our affiliated agencies and third party vendors. We also offer the opportunity to &quot;opt out&quot; of receiving information or being contacted by us or by any agency acting on our behalf.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>How is Personally Identifiable Information stored?</strong></span></div>\r\n<div>Personally Identifiable Information collected by PnPDance.com is securely stored and is not accessible to third parties or employees of PnPDance.com except for use as indicated above.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>What choices are available to Visitors regarding collection, use and distribution of the information?</strong></span></div>\r\n<div>Visitors and Authorized Customers may opt out of receiving unsolicited information from or being contacted by us and/or our vendors and affiliated agencies by responding to emails as instructed, or by contacting us at info@pnpdance.com</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>Are Cookies Used on the Site?</strong></span></div>\r\n<div>Cookies are used for a variety of reasons. We use Cookies to obtain information about the preferences of our Visitors and the services they select. We also use Cookies for security purposes to protect our Authorized Customers. For example, if an Authorized Customer is logged on and the site is unused for more than 10 minutes, we will automatically log the Authorized Customer off.</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>How does PnPDance.com use login information?&nbsp;</strong></span></div>\r\n<div>PnPDance.com uses login information, including, but not limited to, IP addresses, ISPs, and browser types, to analyze trends, administer the Site, track a user&#39;s movement and use, and gather broad demographic information.</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>What partners or service providers have access to Personally Identifiable Information from Visitors and/or Authorized Customers on the Site?</strong></span></div>\r\n<div>PnPDance.com has entered into and will continue to enter into partnerships and other affiliations with a number of vendors.</div>\r\n<div>Such vendors may have access to certain Personally Identifiable Information on a need to know basis for evaluating Authorized Customers for service eligibility.&nbsp;</div>\r\n<div>Our privacy policy does not cover their collection or use of this information.&nbsp;</div>\r\n<div>Disclosure of Personally Identifiable Information to comply with law. We will disclose Personally Identifiable Information in order to comply with a court order or subpoena or a request from a law enforcement agency to release information. We will also disclose Personally Identifiable Information when reasonably necessary to protect the safety of our Visitors and Authorized Customers.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>How does the Site keep Personally Identifiable Information secure?</strong></span></div>\r\n<div>All of our employees are familiar with our security policy and practices. The Personally Identifiable Information of our Visitors and Authorized Customers is only accessible to a limited number of qualified employees who are given a password in order to gain access to the information. We audit our security systems and processes on a regular basis. Sensitive information, such as credit card numbers or social security numbers, is protected by encryption protocols, in place to protect information sent over the Internet. While we take commercially reasonable measures to maintain a secure site, electronic communications and databases are subject to errors, tampering and break-ins, and we cannot guarantee or warrant that such events will not take place and we will not be liable to Visitors or Authorized Customers for any such occurrences.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><span style=\"font-size: medium; \"><strong>How can Visitors correct any inaccuracies in Personally Identifiable Information?</strong></span></div>\r\n<div>Visitors and Authorized Customers may contact us to update Personally Identifiable Information about them or to correct any inaccuracies by emailing us at info@pnpdance.com&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><strong><span style=\"font-size: medium; \">Can a Visitor delete or deactivate Personally Identifiable Information collected by the Site?</span></strong></div>\r\n<div>We provide Visitors and Authorized Customers with a mechanism to delete/deactivate Personally Identifiable Information from the Site&#39;s database by contacting info@pnpdance.com. However, because of backups and records of deletions, it may be impossible to delete a Visitor&#39;s entry without retaining some residual information. An individual who requests to have Personally Identifiable Information deactivated will have this information functionally deleted, and we will not sell, transfer, or use Personally Identifiable Information relating to that individual in any way moving forward.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><strong><span style=\"font-size: medium; \">What happens if the Privacy Policy Changes?</span></strong></div>\r\n<div>We will let our Visitors and Authorized Customers know about changes to our privacy policy by posting such changes on the Site. However, if we are changing our privacy policy in a manner that might cause disclosure of Personally Identifiable Information that a Visitor or Authorized Customer has previously requested not be disclosed, we will contact such Visitor or Authorized Customer to allow such Visitor or Authorized Customer to prevent such disclosure.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div><strong>Links:</strong></div>\r\n<div>This web site contains links to other web sites. Please note that when you click on one of these links, you are moving to another web site. We encourage you to read the privacy statements of these linked sites as their privacy policies may differ from ours.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div style=\"text-align: center; \"><strong><em><span style=\"font-size: small; \">&copy; 2011 PnPDance.com , All rights reserved.</span></em></strong></div>\r\n<div style=\"text-align: center; \"><strong><em><span style=\"font-size: small; \">Unauthorized duplication or publication of any materials from this Site is expressly prohibited.&nbsp;</span></em></strong></div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', 'Privacy Policy', 'pnpDance Privacy policy', 'pnpdance, privacy, policy, rhinestones', '4', '0', '', '0', '1', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('10', 'Dance Wear Size Guide', '<h2 style=\"text-align: center; \">&nbsp;</h2>\r\n<p style=\"text-align: center; \"><strong><cite>Please ensure that you check all measurements before ordering, the age guide is only a guide. &nbsp;Any questions please <a href=\"javascript:void(location.href=&#39;mailto:&#39;+String.fromCharCode(105,110,102,111,64,112,110,112,100,97,110,99,101,46,99,111,109)+&#39;?subject=Size%20Guide%20Question&#39;)\">contact us</a></cite></strong></p>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>Size Guide for Leotards and Leggings</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4</strong></td>\r\n            <td width=\"15%\"><strong>5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Height *(cm)</strong></td>\r\n            <td>41 (104)</td>\r\n            <td>44 (112)</td>\r\n            <td>47 (119)</td>\r\n            <td>50 (127)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Chest *(cm)</strong></td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n            <td>25 (63)</td>\r\n            <td>26 (66)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>21&frac12; (54)</td>\r\n            <td>22 (56)</td>\r\n            <td>22&frac12; (57)</td>\r\n            <td>23 (58)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Hip *(cm)</strong></td>\r\n            <td>23&frac12; (59)</td>\r\n            <td>24&frac12; (62)</td>\r\n            <td>25&frac12; (65)</td>\r\n            <td>27 (68)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Inside Leg to Floor *(cm)</strong></td>\r\n            <td>15&frac34; (40)</td>\r\n            <td>17&frac12; (44)</td>\r\n            <td>19&frac12; (49)</td>\r\n            <td>20&frac12; (52)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>&nbsp;</p>\r\n    <p>Size Guide for Skirts and Shorts</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4-5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7-8</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>22 (56)</td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<table width=\"100%\" border=\"1\" cellpadding=\"1\" cellspacing=\"1\">\r\n    <caption>\r\n    <p>Size Guide for Catsuits</p>\r\n    <p>&nbsp;</p>\r\n    </caption>\r\n    <tbody>\r\n        <tr>\r\n            <td width=\"40%\"><strong>Size (Age)</strong></td>\r\n            <td width=\"15%\"><strong>4</strong></td>\r\n            <td width=\"15%\"><strong>5</strong></td>\r\n            <td width=\"15%\"><strong>6</strong></td>\r\n            <td width=\"15%\"><strong>7</strong></td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Height *(cm)</strong></td>\r\n            <td>41 (104)</td>\r\n            <td>44 (112)</td>\r\n            <td>47 (119)</td>\r\n            <td>50 (127)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Chest *(cm)</strong></td>\r\n            <td>23 (58)</td>\r\n            <td>24 (61)</td>\r\n            <td>25 (63)</td>\r\n            <td>26 (66)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Waist *(cm)</strong></td>\r\n            <td>21&frac12; (54)</td>\r\n            <td>22 (56)</td>\r\n            <td>22&frac12; (57)</td>\r\n            <td>23 (58)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Hip *(cm)</strong></td>\r\n            <td>23&frac12; (59)</td>\r\n            <td>24&frac12; (62)</td>\r\n            <td>25&frac12; (65)</td>\r\n            <td>27 (68)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Back Waist Length *(cm)</strong></td>\r\n            <td>10 (25.5)</td>\r\n            <td>10&frac12; (27)</td>\r\n            <td>11 (28)</td>\r\n            <td>11&frac12; (29)</td>\r\n        </tr>\r\n        <tr>\r\n            <td><strong>Inside Leg to Floor *(cm)</strong></td>\r\n            <td>15&frac34; (40)</td>\r\n            <td>17&frac12; (44)</td>\r\n            <td>19&frac12; (49)</td>\r\n            <td>20&frac12; (52)</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p>&nbsp;</p>', 'Dance Wear Size Guide', 'PnP Dancewear Size guide for children', '', '10', '0', '', '1', '999', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('9', 'Rhinestone Size Chart', '<!-- HiddenDocument -->\r\n<p style=\"text-align: center; \"><img width=\"390\" height=\"296\" alt=\"\" src=\"/images/source/_images/rhinestone-size-chart.jpg\" /></p>', 'Rhinestone Size Guide', 'Rhinestone Size Guide', 'Rhinestone, Size, Guide, ss16, ss20, ss5, ss9, ss12, ss30, ss40, ss48, crystals', '9', '0', 'rhinestones', '0', '999', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('11', 'Returns Policy', '<p>&nbsp;       <!--[if gte mso 9]><xml>\r\n<o:OfficeDocumentSettings>\r\n<o:AllowPNG />\r\n</o:OfficeDocumentSettings>\r\n</xml><![endif]-->  <!--[if gte mso 9]><xml>\r\n<w:WordDocument>\r\n<w:View>Normal</w:View>\r\n<w:Zoom>0</w:Zoom>\r\n<w:TrackMoves />\r\n<w:TrackFormatting />\r\n<w:PunctuationKerning />\r\n<w:ValidateAgainstSchemas />\r\n<w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>\r\n<w:IgnoreMixedContent>false</w:IgnoreMixedContent>\r\n<w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>\r\n<w:DoNotPromoteQF />\r\n<w:LidThemeOther>EN-US</w:LidThemeOther>\r\n<w:LidThemeAsian>JA</w:LidThemeAsian>\r\n<w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>\r\n<w:Compatibility>\r\n<w:BreakWrappedTables />\r\n<w:SnapToGridInCell />\r\n<w:WrapTextWithPunct />\r\n<w:UseAsianBreakRules />\r\n<w:DontGrowAutofit />\r\n<w:SplitPgBreakAndParaMark />\r\n<w:EnableOpenTypeKerning />\r\n<w:DontFlipMirrorIndents />\r\n<w:OverrideTableStyleHps />\r\n<w:UseFELayout />\r\n</w:Compatibility>\r\n<m:mathPr>\r\n<m:mathFont m:val=\"Cambria Math\" />\r\n<m:brkBin m:val=\"before\" />\r\n<m:brkBinSub m:val=\"&#45;-\" />\r\n<m:smallFrac m:val=\"off\" />\r\n<m:dispDef />\r\n<m:lMargin m:val=\"0\" />\r\n<m:rMargin m:val=\"0\" />\r\n<m:defJc m:val=\"centerGroup\" />\r\n<m:wrapIndent m:val=\"1440\" />\r\n<m:intLim m:val=\"subSup\" />\r\n<m:naryLim m:val=\"undOvr\" />\r\n</m:mathPr></w:WordDocument>\r\n</xml><![endif]--><!--[if gte mso 9]><xml>\r\n<w:LatentStyles DefLockedState=\"false\" DefUnhideWhenUsed=\"true\"\r\nDefSemiHidden=\"true\" DefQFormat=\"false\" DefPriority=\"99\"\r\nLatentStyleCount=\"276\">\r\n<w:LsdException Locked=\"false\" Priority=\"0\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Normal\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"heading 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 7\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 8\" />\r\n<w:LsdException Locked=\"false\" Priority=\"9\" QFormat=\"true\" Name=\"heading 9\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 7\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 8\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" Name=\"toc 9\" />\r\n<w:LsdException Locked=\"false\" Priority=\"35\" QFormat=\"true\" Name=\"caption\" />\r\n<w:LsdException Locked=\"false\" Priority=\"10\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Title\" />\r\n<w:LsdException Locked=\"false\" Priority=\"1\" Name=\"Default Paragraph Font\" />\r\n<w:LsdException Locked=\"false\" Priority=\"11\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtitle\" />\r\n<w:LsdException Locked=\"false\" Priority=\"22\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Strong\" />\r\n<w:LsdException Locked=\"false\" Priority=\"20\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"59\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Table Grid\" />\r\n<w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Placeholder Text\" />\r\n<w:LsdException Locked=\"false\" Priority=\"1\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"No Spacing\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" UnhideWhenUsed=\"false\" Name=\"Revision\" />\r\n<w:LsdException Locked=\"false\" Priority=\"34\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"List Paragraph\" />\r\n<w:LsdException Locked=\"false\" Priority=\"29\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Quote\" />\r\n<w:LsdException Locked=\"false\" Priority=\"30\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Quote\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 1\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 2\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 3\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 4\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 5\" />\r\n<w:LsdException Locked=\"false\" Priority=\"60\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Shading Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"61\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"62\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Light Grid Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"63\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"64\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Shading 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"65\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"66\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium List 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"67\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 1 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"68\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 2 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"69\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Medium Grid 3 Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"70\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Dark List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"71\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Shading Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"72\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful List Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"73\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" Name=\"Colorful Grid Accent 6\" />\r\n<w:LsdException Locked=\"false\" Priority=\"19\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"21\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Emphasis\" />\r\n<w:LsdException Locked=\"false\" Priority=\"31\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Subtle Reference\" />\r\n<w:LsdException Locked=\"false\" Priority=\"32\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Intense Reference\" />\r\n<w:LsdException Locked=\"false\" Priority=\"33\" SemiHidden=\"false\"\r\nUnhideWhenUsed=\"false\" QFormat=\"true\" Name=\"Book Title\" />\r\n<w:LsdException Locked=\"false\" Priority=\"37\" Name=\"Bibliography\" />\r\n<w:LsdException Locked=\"false\" Priority=\"39\" QFormat=\"true\" Name=\"TOC Heading\" />\r\n</w:LatentStyles>\r\n</xml><![endif]-->  <!--[if gte mso 10]>\r\n<style>\r\n/* Style Definitions */\r\ntable.MsoNormalTable\r\n{mso-style-name:\"Table Normal\";\r\nmso-tstyle-rowband-size:0;\r\nmso-tstyle-colband-size:0;\r\nmso-style-noshow:yes;\r\nmso-style-priority:99;\r\nmso-style-parent:\"\";\r\nmso-padding-alt:0cm 5.4pt 0cm 5.4pt;\r\nmso-para-margin-top:0cm;\r\nmso-para-margin-right:0cm;\r\nmso-para-margin-bottom:10.0pt;\r\nmso-para-margin-left:0cm;\r\nmso-pagination:widow-orphan;\r\nfont-size:12.0pt;\r\nfont-family:Cambria;\r\nmso-ascii-font-family:Cambria;\r\nmso-ascii-theme-font:minor-latin;\r\nmso-hansi-font-family:Cambria;\r\nmso-hansi-theme-font:minor-latin;\r\nmso-ansi-language:EN-US;\r\nmso-fareast-language:JA;}\r\n</style>\r\n<![endif]-->    <!--StartFragment--></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt;mso-outline-level:1\"><b><span style=\"font-family: Arial; \">Returns Policy<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 10.5pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">Here at PnP Dance want you to be happy with your purchase from Princess &lsquo;n&rsquo; Pickle (www.pnpdance) but if for any reason you are not satisfied with your order then you can return it for a refund or an exchange.<br />\r\n<br />\r\nAll we ask is that you return the item in the condition that you receive it, in its original packaging, with tags, unused, clean and free from odour, make up or deodorant within 14 days of purchase to:<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">Princess &lsquo;n&rsquo; Pickle (www.pnpdance),<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">80 Locksway Road<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">Portsmouth<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">Hampshire<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">PO4 8JP<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><b><span style=\"font-size: 9pt; font-family: Arial; \">Please note that exchanges can take up to 28 days to process.&nbsp;&nbsp;<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:12.0pt;line-height:12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:6.0pt;line-height:12.0pt;mso-outline-level:\r\n2\"><b><span style=\"font-size: 10.5pt; font-family: Arial; \">Exclusions<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">All sale items, personalised or made-to-order items are excluded from the returns policy so please check carefully before ordering.&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">As soon as you place an order for a personalised or made-to-order item you have entered into a contract to purchase that item. Therefore once you have submitted the order you cannot cancel or return the item either before or after dispatch.<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">A full charge will be made on goods that have been returned in a used or unsalable. &nbsp;A &pound;5 charge will be made to replace any missing packaging or labelling upon return.&nbsp;&nbsp;&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">Post and Packaging costs can only be refunded if the reason for return is because of an error on our part. The cost of P&amp;P will be deducted from refunds on returned goods that attracted a Free P&amp;P offer upon ordering.<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt;line-height:\r\n12.0pt\"><span style=\"font-size: 9pt; font-family: Arial; \">For your protection we recommend that you obtain proof of posting or use a recorded delivery service. We cannot be held responsible for any packages that we do not receive.<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom:0cm;margin-bottom:.0001pt\"><span lang=\"EN-US\"><o:p>&nbsp;</o:p></span></p>\r\n<!--EndFragment-->', 'Returns', 'Princess n pickle returns, a no quibble return policy', '', '11', '0', '', '0', '1', '1', 'RETURNS', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('12', 'Returns Policy', '<div style=\"padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; \">\r\n<p>&nbsp;</p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-family: Arial; \">Returns Policy<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 10.5pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">Here at PnP Dance want you to be happy with your purchase from Princess &lsquo;n&rsquo; Pickle (www.pnpdance) but if for any reason you are not satisfied with your order then you can return it for a refund or an exchange.<br />\r\n<br />\r\nAll we ask is that you return the item in the condition that you receive it, in its original packaging, with tags, unused, clean and free from odour, make up or deodorant within 14 days of purchase to:<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">Princess &lsquo;n&rsquo; Pickle (www.pnpdance),<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">80 Locksway Road<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">Portsmouth<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">Hampshire<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">PO4 8JP<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><b><span style=\"font-size: 9pt; font-family: Arial; \">Please note that exchanges can take up to 28 days to process.&nbsp;&nbsp;<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 12pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \"><o:p>&nbsp;</o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 6pt; line-height: 12pt; \"><b><span style=\"font-size: 10.5pt; font-family: Arial; \">Exclusions<o:p></o:p></span></b></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">All sale items, personalised or made-to-order items are excluded from the returns policy so please check carefully before ordering.&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">As soon as you place an order for a personalised or made-to-order item you have entered into a contract to purchase that item. Therefore once you have submitted the order you cannot cancel or return the item either before or after dispatch.<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">A full charge will be made on goods that have been returned in a used or unsalable. &nbsp;A &pound;5 charge will be made to replace any missing packaging or labelling upon return.&nbsp;&nbsp;&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">Post and Packaging costs can only be refunded if the reason for return is because of an error on our part. The cost of P&amp;P will be deducted from refunds on returned goods that attracted a Free P&amp;P offer upon ordering.<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">&nbsp;<o:p></o:p></span></p>\r\n<p class=\"MsoNormal\" style=\"margin-bottom: 0.0001pt; line-height: 12pt; \"><span style=\"font-size: 9pt; font-family: Arial; \">For your protection we recommend that you obtain proof of posting or use a recorded delivery service. We cannot be held responsible for any packages that we do not receive.<o:p></o:p></span></p>\r\n</div>\r\n<p>&nbsp;&nbsp;</p>', '', '', '', '12', '0', '', '0', '999', '1', 'RETURNS_BOT', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('13', 'Home', '', '', '', '', '13', '0', '/index.php', '0', '4', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('14', 'My Account', '', '', '', '', '14', '0', 'index.php?_a=login&redir=%2Findex.php', '0', '4', '1', '', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('15', 'Blog', '', 'Blog', 'Princess n Pickle Blog, latest news from the dance world', '', '15', '0', '/blog', '0', '999', '1', 'BLOG', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('16', 'Feedback', '<div id=\"surveyMonkeyInfo\"><div><script src=\"http://www.surveymonkey.com/jsEmbed.aspx?sm=NaYwaWq0RuvhaLokdolWZQ_3d_3d\"> </script></div>Create your <a href=\"http://www.surveymonkey.com/\">free online surveys</a> with SurveyMonkey, the world&#39;s leading questionnaire tool.</div>', '', 'PnP Dance feedback', '', '16', '0', '', '0', '999', '1', 'FEEDBACK', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('17', 'Your Basket', '', '', '', '', '17', '0', 'https://www.pnpdance.com/index.php?_g=co&_a=cart', '0', '999', '1', 'BASKET', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('18', 'Bespoke Costumes', '<p>&nbsp;At PnP Dance we love making bespoke costumes, we have made so many beautiful costumes for dancers from all around the country. &nbsp;To have a costume made to your design and specification this is the process:</p>\r\n<p><img src=\"/images/source/_images/PnP%20Dance-1.jpg\" width=\"0\" height=\"0\" alt=\"\" /></p>\r\n<ul>\r\n    <li>Decide on a design</li>\r\n    <li>Choose a fabric and let us know what it is</li>\r\n    <li>Do you want bling? Let us know how much and what colour stones etc</li>\r\n    <li>Let us know your measurements using the forms below</li>\r\n    <li>Give us your phone number and we will give you a call to have a chat and make sure we have it just right</li>\r\n    <li>We send you an invoice via PayPal, once it is paid we will make your designer costume</li>\r\n    <li>We post it to you when it is finished!</li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>Please download the form below (online form coming soon) - You will need Adobe Acrobat to read this available <a href=\"http://get.adobe.com/reader/\">here</a></p>\r\n<p>The form can be filled in within Acrobat too</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p><font face=\"Lucida Grande\"><span style=\"font-size: 11px;\"><a href=\"http://www.pnpdance.com/images/source/PnPDS_Form.pdf\"><span style=\"font-size: large; \">PnP Dance Bespoke Measurement Form</span></a></span></font></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Any questions please get in <a href=\"http://www.pnpdance.com/contact-us/info_2.html\">contact</a>&nbsp;</p>', 'PnP Dance Bespoke Costumes', 'Bespoke, hand made, dance, costumes, bling', '', '18', '0', '', '0', '4', '1', 'BESPOKE', '0', '0', '1', '0', 'en-US', '1'); #EOQ
INSERT INTO `cc4_CubeCart_documents` VALUES('20', 'Welcome to Princess \'n\' Pickle', '<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	Princess &#39;n&#39; Pickle is moving it&#39;s shop location!!</h3>\r\n<p>\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Due to staff holiday and shop relocating the opening times&nbsp;</span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Will be: </span></p>\r\n<p>\r\n	<u><strong><span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Week Commencing&nbsp;</span><span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">12th November</span></strong></u><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Monday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;09:00 - 16:30</span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Tuesday &nbsp; &nbsp; &nbsp; &nbsp; 09:00 - 18:00</span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color:#ff0000;\"><span style=\"font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Wednesday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;closed</span></span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Thursday &nbsp; &nbsp; &nbsp; &nbsp;09:00 - 14:00</span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	<span style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">Friday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 09:00 - 14:00</span><br style=\"color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \" />\r\n	&nbsp;</p>\r\n<div class=\"text_exposed_show\" style=\"display: inline; color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">\r\n	<u><strong>Week commencing&nbsp;19 November&nbsp;</strong></u></div>\r\n<div class=\"text_exposed_show\" style=\"display: inline; color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">\r\n	&nbsp;</div>\r\n<div class=\"text_exposed_show\" style=\"display: inline; color: rgb(51, 51, 51); font-family: \'lucida grande\', tahoma, verdana, arial, sans-serif; font-size: 13px; line-height: 18px; text-align: left; \">\r\n	<br />\r\n	Monday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;09:00 - 16:30<br />\r\n	Tuesday &nbsp; &nbsp; &nbsp; &nbsp; 09:00 - 18:00<br />\r\n	<span style=\"color: rgb(255, 0, 0); \">Wednesday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;closed</span><br />\r\n	Thursday &nbsp; &nbsp; &nbsp; &nbsp;09:00 - 18:00<br />\r\n	Friday &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 09:00 - 16:30<br />\r\n	<br />\r\n	<strong>Please keep an eye out for the following week</strong></div>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '', '', '0', '0', '', '0', '1', '1', '', '0', '0', '1', '1', 'en-GB', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_downloads`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_downloads`
--

CREATE TABLE `cc4_CubeCart_downloads` (
  `digital_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL,
  `downloads` int(10) unsigned NOT NULL default '0',
  `expire` int(10) unsigned NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `accesskey` varchar(32) collate utf8_unicode_ci NOT NULL,
  `order_inv_id` int(10) unsigned NOT NULL,
  KEY `id` (`digital_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_downloads` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_email_content`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_email_content`
--

CREATE TABLE `cc4_CubeCart_email_content` (
  `content_id` int(10) unsigned NOT NULL auto_increment,
  `content_type` varchar(70) collate utf8_unicode_ci NOT NULL,
  `language` varchar(5) collate utf8_unicode_ci NOT NULL,
  `subject` varchar(250) collate utf8_unicode_ci NOT NULL,
  `content_html` text collate utf8_unicode_ci NOT NULL,
  `content_text` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`content_id`),
  KEY `content_type` (`content_type`),
  KEY `language` (`language`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_email_content`
--

INSERT INTO `cc4_CubeCart_email_content` VALUES('1', 'admin.password_recovery', 'de-DE', '\n      Admin-Passwortwiederherstellung\n    ', '<p>Sehr geehrte/r {$DATA.name},</p> \n        <p>um wieder Zugriff auf die Administrationsbedienkonsole des Shops zu bekommen, folgen Sie bitte dem nachfolgenden Link:</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n        <p>Wenn der obige Link nicht funktioniert, kopieren Sie Ihn bitte in die Adressleiste Ihres Browsers.</p>', 'Sehr geehrte/r {$DATA.name},\n        \n        um wieder Zugriff auf die Administrationsbedienkonsole des Shops zu bekommen, folgen Sie bitte dem nachfolgenden Link:\n        \n        {$DATA.link}\n        \n        Wenn der obige Link nicht funktioniert, kopieren Sie ihn bitte in die Adressleiste Ihres Browsers.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('2', 'cart.order_complete', 'de-DE', '\n      Bestellung fertiggestellt\n    ', '<p>Hallo {$DATA.first_name},</p> \n        <p>wir freuen uns, Ihnen mitteilen zu kÃ¶nnen, dass Bestellung Nummer {$DATA.cart_order_id} fertiggestellt wurde. Wenn Sie materielle Waren bestellt haben, sollten sie in KÃ¼rze ankommen.</p>', 'Hallo {$DATA.first_name},\n        \n        wir freuen uns, Ihnen mitteilen zu kÃ¶nnen, dass Bestellung Nummer {$DATA.cart_order_id} fertiggestellt wurde. Wenn Sie materielle Waren bestellt haben, sollten sie in KÃ¼rze ankommen.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('3', 'cart.order_cancelled', 'de-DE', '\n      Bestellung storniert\n    ', '<p>Hallo {$DATA.first_name},</p> \n        <p>Bestellung Nummer {$DATA.cart_order_id} wurde storniert.</p>', 'Hallo {$DATA.first_name},\n        \n        Bestellung Nummer {$DATA.cart_order_id} wurde storniert.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('4', 'cart.order_confirmation', 'de-DE', '\n      BestÃ¤tigung der Bestellung #{$DATA.cart_order_id}\n    ', '<p>Danke, {$DATA.first_name}!</p>\n        <p>Ihre Bestellung {$DATA.cart_order_id}, die am {$DATA.order_date} aufgegeben wurde, ist bei uns eingegangen. Bitte bewahren Sie diese E-Mail fÃ¼r Ihre Unterlagen auf. Es ist mÃ¶glich, den Status Ihrer Bestellung online einzusehen.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Rechnungsadresse:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>E-Mail-Adresse:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Lieferadresse:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Artikel</strong></td>\n        <td><strong>Menge</strong></td>\n        <td><strong>Preis</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Versand: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Rabatt:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Zwischensumme:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Bestellsumme: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', 'Danke, {$DATA.first_name}!\n        \n        Ihre Bestellung {$DATA.cart_order_id}, die am {$DATA.order_date} aufgegeben wurde, ist bei uns eingegangen. Bitte bewahren Sie diese E-Mail fÃ¼r Ihre Unterlagen auf. Es ist mÃ¶glich, den Status Ihrer Bestellung online einzusehen. \n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Rechnungsadresse:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        E-Mail-Adresse:\n        {$BILLING.email}\n        \n        Lieferadresse:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Artikel in Ihrer Bestellung\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Artikelnummer: {$product.product_code}\n        StÃ¼ckpreis: {$product.price}\n        Menge: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Zwischensumme: {$DATA.subtotal}\n        Rabatt: {$DATA.discount}\n        Versand: {$DATA.shipping} {if $DATA.ship_method}{if $DATA.ship_method}({$DATA.ship_method}){/if}{/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Bestellsumme: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('5', 'cart.payment_fraud', 'de-DE', '\n      Problem mit Ihrer Bestellung\n    ', '<p>Hallo {$DATA.first_name},</p> \n        <p>es tut uns sehr leid, aber wir waren nicht in der Lage, die Bezahlung fÃ¼r Bestellung {$DATA.cart_order_id} anzunehmen. Bitte wenden Sie sich jederzeit an einen unserer Mitarbeiter, wenn Sie Fragen haben.</p>', 'Hallo {$DATA.first_name},\n        \n        es tut uns sehr leid, aber wir waren nicht in der Lage, die Bezahlung fÃ¼r Bestellung {$DATA.cart_order_id} anzunehmen. Bitte wenden Sie sich jederzeit an einen unserer Mitarbeiter, wenn Sie Fragen haben.</p>'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('6', 'account.password_recovery', 'de-DE', '\n      Passwortwiederherstellung\n    ', '<p>Sehr geehrte/r {$DATA.first_name} {$DATA.last_name},<br /> \n        <br /> \n        klicken Sie bitte auf den nachfolgenden Link oder kopieren Sie die Adresse in die Adresszeile Ihres Browsers, um Ihr Passwort zurÃ¼ckzusetzen. Sobald Sie auf der Webseite sind, erhalten Sie die Anweisung, Ihr neues Passwort einzugeben und zu bestÃ¤tigen.<br /> \n        <br /> \n        {$DATA.reset_link}<br /> \n        <br /> \n        Wenn Sie weitere UnterstÃ¼tzung bei der RÃ¼cksetzung Ihres Passworts brauchen, wenden Sie sich bitte an uns.</p>', 'Hallo {$DATA.first_name},\n        \n        klicken Sie bitte auf den nachfolgenden Link oder kopieren Sie die Adresse in die Adresszeile Ihres Browsers, um Ihr Passwort zurÃ¼ckzusetzen. Sobald Sie auf der Webseite sind, erhalten Sie die Anweisung, Ihr neues Passwort einzugeben und zu bestÃ¤tigen.\n        \n        {$DATA.reset_link}\n        \n        Wenn Sie weitere UnterstÃ¼tzung bei der RÃ¼cksetzung Ihres Passworts brauchen, wenden Sie sich bitte an uns.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('7', 'admin.order_received', 'de-DE', '\n      Neue Bestellung #{$DATA.cart_order_id}\n    ', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} hat soeben Bestellung Nummer {$DATA.cart_order_id} am {$DATA.order_date} aufgegeben.</p>\n        <p>Diese Bestellung kann online unter dem nachfolgenden Link verwaltet werden.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Rechnungsadresse:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>E-Mail-Adresse:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Lieferadresse:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Artikel</strong></td>\n        <td><strong>Menge</strong></td>\n        <td><strong>Preis</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Versand: {if $DATA.ship_method}{if $DATA.ship_method}({$DATA.ship_method}){/if}{/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Rabatt:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Zwischensumme:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Bestellsumme: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} hat soeben Bestellung Nummer {$DATA.cart_order_id} am {$DATA.order_date} aufgegeben.\n        \n        Diese Bestellung kann online unter dem nachfolgenden Link verwaltet werden.\n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Rechnungsadresse:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        E-Mail-Adresse:\n        {$BILLING.email}\n        \n        Lieferadresse:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Artikel in Ihrer Bestellung\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Artikelnummer: {$product.product_code}\n        StÃ¼ckpreis: {$product.price}\n        Menge: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Zwischensumme: {$DATA.subtotal}\n        Rabatt: {$DATA.discount}\n        Versand: {$DATA.shipping} {if $DATA.ship_method}{if $DATA.ship_method}({$DATA.ship_method}){/if}{/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Bestellsumme: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('8', 'admin.review_added', 'de-DE', '\n      Neue Produktrezension\n    ', '{$DATA.name} hat eine neue Rezension/einen neuen Kommentar Ã¼ber \'{$DATA.product_name}\' eingeschickt. Sie/er kann unter dem nachfolgenden Link moderiert werden.\n        <p><strong>Moderationslink:</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n        <p><strong>Rezensionstext:</strong><br />{$DATA.review}</p>', '{$DATA.name} hat eine neue Rezension/einen neuen Kommentar Ã¼ber \'{$DATA.product_name}\' eingeschickt. Sie/er kann unter dem nachfolgenden Link moderiert werden.\n        \n        Moderationslink: \n        {$DATA.link}\n        Rezensionstext:\n        {$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('9', 'cart.digital_download', 'de-DE', '\n      Ihre gekauften Downloads\n    ', '<p>Hallo {$DATA.first_name},</p> \n        <p>Ihre digitalen Dateien stehen jetzt zum Download bereit. Bitte benutzen Sie die nachfolgenden Links, um darauf zuzugreifen:</p> \n        {foreach from=$DOWNLOADS item=download} \n        <p><strong>{$download.name}:</strong> (Link verfÃ¤llt am {$download.expire}<strong>)</strong><br /> \n        {$download.url}</p> \n        {/foreach}\n        <p>Wenn die obigen Links nicht funktionieren, versuchen Sie bitte, sie in die Adressleiste Ihres Browsers zu kopieren. Sie kÃ¶nnen auf diese Dateien auch von Ihrem Kundenbereich unserer Webseite aus zugreifen.</p> \n        <p>&nbsp;</p>', 'Hallo {$DATA.first_name},\n        \n        Ihre digitalen Dateien stehen jetzt zum Download bereit. Bitte benutzen Sie die nachfolgenden Links, um darauf zuzugreifen:\n        \n        {foreach from=$DOWNLOADS item=download} \n        {$download.name}: (Link verfÃ¤llt am {$download.expire})\n        {$download.url}\n        {/foreach}\n        \n        Wenn die obigen Links nicht funktionieren, versuchen Sie bitte, sie in die Adressleiste Ihres Browsers zu kopieren. Sie kÃ¶nnen auf diese Dateien auch von Ihrem Kundenbereich unserer Webseite aus zugreifen.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('10', 'cart.gift_certificate', 'de-DE', '\n      Ihr Geschenkgutschein\n    ', '<p>Sehr geehrte/r {$DATA.name},</p> \n        <p>wir freuen uns, Ihnen diesen Gutschein zuschicken zu dÃ¼rfen, mit dem Sie beliebige Artikel auf unserer Webseite kaufen kÃ¶nnen.</p> \n        <p>Viel SpaÃŸ beim Einkaufen!</p> \n        <p><strong>Von: </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n        <strong>Betrag: </strong>{$DATA.value}<br /> \n        <strong>Gutscheincode:</strong> {$DATA.code}<br /> \n        <strong>Nachricht des Schenkenden:</strong> {$DATA.message}</p> \n        <p>-------------------</p> \n        <p>Um diesen Geschenkgutschein einzulÃ¶sen, geben Sie bitte an der Kasse den obigen &quot;Gutscheincode&quot; in das Textfeld mit der Aufschrift &quot;Geschenkgutschein oder Gutschein hinzufÃ¼gen&quot; ein.</p> \n        <p>LÃ¶sen Sie ihn doch gleich ein!</p>', 'Sehr geehrte/r {$DATA.name},\n        \n        wir freuen uns, Ihnen diesen Gutschein zuschicken zu dÃ¼rfen, mit dem Sie beliebige Artikel auf unserer Webseite kaufen kÃ¶nnen.\n        \n        Viel SpaÃŸ beim Einkaufen!\n        \n        Von: {$DATA.first_name} {$DATA.last_name}\n        Betrag: {$DATA.value}\n        Gutscheincode: {$DATA.code}\n        Nachricht des Schenkenden: {$DATA.message}\n        \n        -------------------\n        \n        Um diesen Geschenkgutschein einzulÃ¶sen, geben Sie bitte an der Kasse den obigen \"Gutscheincode\" in das Textfeld mit der Aufschrift \"Geschenkgutschein oder Gutschein hinzufÃ¼gen\" ein.\n        \n        LÃ¶sen Sie ihn doch gleich ein!'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('11', 'catalogue.tell_friend', 'de-DE', '\n      {$DATA.from} hat etwas fÃ¼r Sie empfohlen\n    ', 'Sehr geehrte/r{$DATA.to},\n        <p>Ihr Freund <strong>{$DATA.from}</strong> dachte, dass <strong>{$DATA.name}</strong> Sie vielleicht interessieren kÃ¶nnte.</p> \n        <p><strong>Link zum Produkt:</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n        <p>{$DATA.message}</p>', 'Sehr geehrte/r {$DATA.to},\n        \n        Ihr Freund {$DATA.from} dachte, dass \'{$DATA.name}\' Sie vielleicht interessieren kÃ¶nnte.\n        \n        {$DATA.name}\n        Link zum Produkt: {$DATA.link}\n        \n        {$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('12', 'cart.payment_received', 'de-DE', '\n      Danke fÃ¼r Ihre Zahlung!\n    ', '<p>Hallo {$DATA.first_name},</p> \n        <p>vielen Dank. Wir haben eine Zahlung von {$DATA.total} fÃ¼r Bestellung Nummer {$DATA.cart_order_id} erhalten.</p>', 'Hallo {$DATA.first_name},\n        \n        vielen Dank. Wir haben eine Zahlung von {$DATA.total} fÃ¼r Bestellung Nummer {$DATA.cart_order_id} erhalten.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('13', 'admin.password_recovery', 'en-GB', '\n      Admin Password Recovery\n    ', '<p>Dear {$DATA.name},</p> \n        <p>To regain access to the stores administration control panel. Please follow the link below:</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n        <p>If the link above doesn\'t work, please copy and paste it into your browser address bar.</p>', 'Dear {$DATA.name},\n        \n        To regain access to the stores administration control panel. Please follow the link below:\n        \n        {$DATA.link}\n        \n        If the link above doesn\'t work, please copy and paste it into your browser address bar.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('14', 'cart.order_complete', 'en-GB', '\n      Order Complete\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>We are pleased to say that order number {$DATA.cart_order_id} is complete. If you have ordered physical goods they should arrive shortly.</p>', 'Hi {$DATA.first_name},\n        \n        We are pleased to say that order number {$DATA.cart_order_id} is complete. If you have ordered physical goods they should arrive shortly.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('15', 'cart.order_cancelled', 'en-GB', '\n      Order Cancelled\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Order number {$DATA.cart_order_id} has been cancelled.</p>', 'Hi {$DATA.first_name},\n        \n        Order number {$DATA.cart_order_id} has been cancelled.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('16', 'cart.order_confirmation', 'en-GB', '\n      Order Confirmation #{$DATA.cart_order_id}\n    ', '<p>Thank You {$DATA.first_name}!</p>\n        <p>Your order {$DATA.cart_order_id} has been received which was placed on {$DATA.order_date}. Please keep this email for your records. It is possible to view the status of your order online.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Billing address:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>Email:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Shipping address:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Item</strong></td>\n        <td><strong>Quantity</strong></td>\n        <td><strong>Cost</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Shipping: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Discount:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Subtotal:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Order Total: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', 'Thank You {$DATA.first_name}!\n        \n        Your order {$DATA.cart_order_id} has been received which was placed on {$DATA.order_date}. Please keep this email for your records. It is possible to view the status of your order online. \n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Billing address:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        Email:\n        {$BILLING.email}\n        \n        Shipping address:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Items in Your Order\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Part Number: {$product.product_code}\n        Unit Price: {$product.price}\n        Qty: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Subtotal: {$DATA.subtotal}\n        Discount: {$DATA.discount}\n        Shipping: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Order Total: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('17', 'cart.payment_fraud', 'en-GB', '\n      Order Problem\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>We are very sorry but we have not been able to accept the payment for order {$DATA.cart_order_id}. Please feel free to contact a member of staff if you have any questions.</p>', 'Hi {$DATA.first_name},\n        \n        We are very sorry but we have not been able to accept the payment for order {$DATA.cart_order_id}. Please feel free to contact a member of staff if you have any questions.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('18', 'account.password_recovery', 'en-GB', '\n      Password Recovery\n    ', '<p>Dear {$DATA.first_name} {$DATA.last_name},<br /> \n        <br /> \n        To reset your password, please click on the link below or copy and paste the address onto your web browser\'s address window. Once you\'re on the web page, you will be instructed to enter and confirm your new password.<br /> \n        <br /> \n        {$DATA.reset_link}<br /> \n        <br /> \n        If you require further assistance in resetting your password, please contact us.</p>', 'Hi {$DATA.first_name},\n        \n        To reset your password, please click on the link below or copy and paste the address onto your web browser\'s address window. Once you\'re on the web page, you will be instructed to enter and confirm your new password.\n        \n        {$DATA.reset_link}\n        \n        If you require further assistance in resetting your password, please contact us.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('19', 'admin.order_received', 'en-GB', '\n      New Order #{$DATA.cart_order_id}\n    ', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} just placed order number {$DATA.cart_order_id} on {$DATA.order_date}.</p>\n        <p>This order can be managed online by following the link below.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Billing address:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>Email:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Shipping address:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Item</strong></td>\n        <td><strong>Quantity</strong></td>\n        <td><strong>Cost</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Shipping: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Discount:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Subtotal:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Order Total: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} just placed order number {$DATA.cart_order_id} on {$DATA.order_date}.\n        \n        This order can be managed online by following the link below.\n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Billing address:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        Email:\n        {$BILLING.email}\n        \n        Shipping address:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Items in Your Order\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Part Number: {$product.product_code}\n        Unit Price: {$product.price}\n        Qty: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Subtotal: {$DATA.subtotal}\n        Discount: {$DATA.discount}\n        Shipping: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Order Total: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('20', 'admin.review_added', 'en-GB', '\n      New Product Review\n    ', '{$DATA.name} has submit a new review/comment about \'{$DATA.product_name}\'. This can be moderated following the link below.\n        <p><strong>Moderation Link:</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n        <p><strong>Review Text:</strong><br />{$DATA.review}</p>', '{$DATA.name} has submit a new review/comment about \'{$DATA.product_name}\'. This can be moderated following the link below.\n        \n        Moderation Link: \n        {$DATA.link}\n        Review Text:\n        {$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('21', 'cart.digital_download', 'en-GB', '\n      Your Purchased Downloads\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Your digital files are now ready for download. Please use the links provided below to access them below:</p> \n        {foreach from=$DOWNLOADS item=download} \n        <p><strong>{$download.name}:</strong> (Link expires on {$download.expire}<strong>)</strong><br /> \n        {$download.url}</p> \n        {/foreach}\n        <p>If the links above don\'t work, please try copy and pasting them it into your browser address bar. You can also find access to these files from your the customer area of our website.</p> \n        <p>&nbsp;</p>', 'Hi {$DATA.first_name},\n        \n        Your digital files are now ready for download. Please use the links provided below to access them below:\n        \n        {foreach from=$DOWNLOADS item=download} \n        {$download.name}: (Link expires on {$download.expire})\n        {$download.url}\n        {/foreach}\n        \n        If the links above don\'t work, please try copy and pasting them it into your browser address bar. You can also find access to these files from your the customer area of our website.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('22', 'cart.gift_certificate', 'en-GB', '\n      Your Gift Certificate\n    ', '<p>Dear {$DATA.name},</p> \n        <p>We are please to be sending you this gift certificate which you can use towards the purchase of any item(s) on our website.</p> \n        <p>Happy shopping!</p> \n        <p><strong>From: </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n        <strong>Amount: </strong>{$DATA.value}<br /> \n        <strong>Claim Code:</strong> {$DATA.code}<br /> \n        <strong>Gift Message:</strong> {$DATA.message}</p> \n        <p>-------------------</p> \n        <p>To reedeem this gift certificate please enter the &quot;Claim Code&quot; above into the text field labeled &quot;Add Gift Certificate or Coupon&quot; during checkout.</p> \n        <p>Why not spend it now?</p>', 'Dear {$DATA.name},\n        \n        We are please to  be sending you this gift certificate which you can use towards the purchase of any item(s) on our website.\n        \n        Happy shopping!\n        \n        From: {$DATA.first_name} {$DATA.last_name}\n        Amount: {$DATA.value}\n        Claim Code: {$DATA.code}\n        Gift Message: {$DATA.message}\n        \n        -------------------\n        \n        To reedeem this gift certificate please enter the \"Claim Code\" above into the text field labeled \"Add Gift Certificate or Coupon\" during checkout.\n        \n        Why not spend it now?'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('23', 'catalogue.tell_friend', 'en-GB', '\n      {$DATA.from} has recommended something\n    ', 'Dear {$DATA.to},\n        <p>Your friend <strong>{$DATA.from}</strong> thought that you might be interested in <strong>{$DATA.name}</strong>.</p> \n        <p><strong>Product Link:</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n        <p>{$DATA.message}</p>', 'Dear {$DATA.to},\n        \n        Your friend {$DATA.from} thought that you might be interested in \'{$DATA.name}\'.\n        \n        {$DATA.name}\n        Product Link: {$DATA.link}\n        \n        {$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('24', 'cart.payment_received', 'en-GB', '\n      Thank you for your payment!\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Thank you. We have received a payment of {$DATA.total} for order number {$DATA.cart_order_id}.</p>', 'Hi {$DATA.first_name},\n        \n        Thank you. We have received a payment of {$DATA.total} for order number {$DATA.cart_order_id}.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('25', 'admin.password_recovery', 'en-US', '\n      Admin Password Recovery\n    ', '<p>Dear {$DATA.name},</p> \n        <p>To regain access to the stores administration control panel. Please follow the link below:</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n        <p>If the link above doesn\'t work, please copy and paste it into your browser address bar.</p>', 'Dear {$DATA.name},\n        \n        To regain access to the stores administration control panel. Please follow the link below:\n        \n        {$DATA.link}\n        \n        If the link above doesn\'t work, please copy and paste it into your browser address bar.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('26', 'cart.order_complete', 'en-US', '\n      Order Complete\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>We are pleased to say that order number {$DATA.cart_order_id} is complete. If you have ordered physical goods they should arrive shortly.</p>', 'Hi {$DATA.first_name},\n        \n        We are pleased to say that order number {$DATA.cart_order_id} is complete. If you have ordered physical goods they should arrive shortly.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('27', 'cart.order_cancelled', 'en-US', '\n      Order Cancelled\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Order number {$DATA.cart_order_id} has been cancelled.</p>', 'Hi {$DATA.first_name},\n        \n        Order number {$DATA.cart_order_id} has been cancelled.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('28', 'cart.order_confirmation', 'en-US', '\n      Order Confirmation #{$DATA.cart_order_id}\n    ', '<p>Thank You {$DATA.first_name}!</p>\n        <p>Your order {$DATA.cart_order_id} has been received which was placed on {$DATA.order_date}. Please keep this email for your records. It is possible to view the status of your order online.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Billing address:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>Email:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Shipping address:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Item</strong></td>\n        <td><strong>Quantity</strong></td>\n        <td><strong>Cost</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Shipping: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Discount:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Subtotal:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Order Total: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', 'Thank You {$DATA.first_name}!\n        \n        Your order {$DATA.cart_order_id} has been received which was placed on {$DATA.order_date}. Please keep this email for your records. It is possible to view the status of your order online. \n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Billing address:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        Email:\n        {$BILLING.email}\n        \n        Shipping address:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Items in Your Order\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Part Number: {$product.product_code}\n        Unit Price: {$product.price}\n        Qty: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Subtotal: {$DATA.subtotal}\n        Discount: {$DATA.discount}\n        Shipping: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Order Total: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('29', 'cart.payment_fraud', 'en-US', '\n      Order Problem\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>We are very sorry but we have not been able to accept the payment for order {$DATA.cart_order_id}. Please feel free to contact a member of staff if you have any questions.</p>', 'Hi {$DATA.first_name},\n        \n        We are very sorry but we have not been able to accept the payment for order {$DATA.cart_order_id}. Please feel free to contact a member of staff if you have any questions.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('30', 'account.password_recovery', 'en-US', '\n      Password Recovery\n    ', '<p>Dear {$DATA.first_name} {$DATA.last_name},<br /> \n        <br /> \n        To reset your password, please click on the link below or copy and paste the address onto your web browser\'s address window. Once you\'re on the web page, you will be instructed to enter and confirm your new password.<br /> \n        <br /> \n        {$DATA.reset_link}<br /> \n        <br /> \n        If you require further assistance in resetting your password, please contact us.</p>', 'Hi {$DATA.first_name},\n        \n        To reset your password, please click on the link below or copy and paste the address onto your web browser\'s address window. Once you\'re on the web page, you will be instructed to enter and confirm your new password.\n        \n        {$DATA.reset_link}\n        \n        If you require further assistance in resetting your password, please contact us.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('31', 'admin.order_received', 'en-US', '\n      New Order #{$DATA.cart_order_id}\n    ', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} just placed order number {$DATA.cart_order_id} on {$DATA.order_date}.</p>\n        <p>This order can be managed online by following the link below.</p> \n        <p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n        <table width=\"100%\">\n        <tr>\n        <td valign=\"top\" width=\"50%\"><strong>Billing address:</strong><br />\n        {$BILLING.first_name} {$BILLING.last_name}<br />\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n        {/if}\n        {$BILLING.line1}<br />\n        {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n        {/if}\n        {$BILLING.town}<br />\n        {$BILLING.state}<br />\n        {$BILLING.postcode}<br />\n        {$BILLING.country}<br />\n        {$BILLING.phone}<br />\n        <br />\n        <strong>Email:</strong><br />\n        {$BILLING.email}</td>\n        <td valign=\"top\" width=\"50%\"><strong>Shipping address:</strong><br />\n        {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n        {/if}{$SHIPPING.line1}<br />\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n        {/if}{$SHIPPING.town}<br />\n        {$SHIPPING.state}<br />\n        {$SHIPPING.postcode}<br />\n        {$SHIPPING.country}</td>\n        </tr>\n        </table>\n        <table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n        <tbody>\n        <tr>\n        <td><strong>Item</strong></td>\n        <td><strong>Quantity</strong></td>\n        <td><strong>Cost</strong></td>\n        </tr>\n        <!--{foreach from=$PRODUCTS item=product}-->\n        <tr>\n        <td>{$product.name} <br />{$product.product_options}</td>\n        <td>{$product.quantity}</td>\n        <td>{$product.price}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> Shipping: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n        <td> {$DATA.shipping}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Discount:</td>\n        <td> {$DATA.discount}</td>\n        </tr>\n        <tr>\n        <td>&nbsp;</td>\n        <td> Subtotal:</td>\n        <td> {$DATA.subtotal}</td>\n        </tr>\n        <!--{foreach from=$TAXES item=tax}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n        <td> {$tax.tax_amount}</td>\n        </tr>\n        <!--{/foreach}-->\n        <tr>\n        <td>&nbsp;</td>\n        <td><strong>Order Total: </strong></td>\n        <td><strong>{$DATA.total}</strong></td>\n        </tr>\n        </tbody>\n        \n        </table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} just placed order number {$DATA.cart_order_id} on {$DATA.order_date}.\n        \n        This order can be managed online by following the link below.\n        \n        {$DATA.link}\n        \n        ----------------------------------------------------------------------\n        Billing address:\n        {$BILLING.first_name} {$BILLING.last_name}\n        {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n        {/if}{$BILLING.line1}\n        {if !empty({$BILLING.line2})}{$BILLING.line2}\n        {/if}{$BILLING.town}\n        {$BILLING.state}\n        {$BILLING.postcode}\n        {$BILLING.country}\n        {$BILLING.phone}\n        \n        Email:\n        {$BILLING.email}\n        \n        Shipping address:\n        {$SHIPPING.first_name} {$SHIPPING.last_name}\n        {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n        {/if}{$SHIPPING.line1}\n        {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n        {/if}{$SHIPPING.town}\n        {$SHIPPING.state}\n        {$SHIPPING.postcode}\n        {$SHIPPING.country}\n        \n        ----------------------------------------------------------------------\n        Items in Your Order\n        \n        {foreach from=$PRODUCTS item=product}\n        -----------------------------------\n        {$product.name}\n        {$product.product_options}\n        \n        Part Number: {$product.product_code}\n        Unit Price: {$product.price}\n        Qty: {$product.quantity}\n        \n        {/foreach}\n        -----------------------------------\n        Subtotal: {$DATA.subtotal}\n        Discount: {$DATA.discount}\n        Shipping: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n        {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n        {/foreach}\n        --------------------------\n        Order Total: {$DATA.total}\n        =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('32', 'admin.review_added', 'en-US', '\n      New Product Review\n    ', '{$DATA.name} has submit a new review/comment about \'{$DATA.product_name}\'. This can be moderated following the link below.\n        <p><strong>Moderation Link:</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n        <p><strong>Review Text:</strong><br />{$DATA.review}</p>', '{$DATA.name} has submit a new review/comment about \'{$DATA.product_name}\'. This can be moderated following the link below.\n        \n        Moderation Link: \n        {$DATA.link}\n        Review Text:\n        {$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('33', 'cart.digital_download', 'en-US', '\n      Your Purchased Downloads\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Your digital files are now ready for download. Please use the links provided below to access them below:</p> \n        {foreach from=$DOWNLOADS item=download} \n        <p><strong>{$download.name}:</strong> (Link expires on {$download.expire}<strong>)</strong><br /> \n        {$download.url}</p> \n        {/foreach}\n        <p>If the links above don\'t work, please try copy and pasting them it into your browser address bar. You can also find access to these files from your the customer area of our website.</p> \n        <p>&nbsp;</p>', 'Hi {$DATA.first_name},\n        \n        Your digital files are now ready for download. Please use the links provided below to access them below:\n        \n        {foreach from=$DOWNLOADS item=download} \n        {$download.name}: (Link expires on {$download.expire})\n        {$download.url}\n        {/foreach}\n        \n        If the links above don\'t work, please try copy and pasting them it into your browser address bar. You can also find access to these files from your the customer area of our website.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('34', 'cart.gift_certificate', 'en-US', '\n      Your Gift Certificate\n    ', '<p>Dear {$DATA.name},</p> \n        <p>We are please to be sending you this gift certificate which you can use towards the purchase of any item(s) on our website.</p> \n        <p>Happy shopping!</p> \n        <p><strong>From: </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n        <strong>Amount: </strong>{$DATA.value}<br /> \n        <strong>Claim Code:</strong> {$DATA.code}<br /> \n        <strong>Gift Message:</strong> {$DATA.message}</p> \n        <p>-------------------</p> \n        <p>To reedeem this gift certificate please enter the &quot;Claim Code&quot; above into the text field labeled &quot;Add Gift Certificate or Coupon&quot; during checkout.</p> \n        <p>Why not spend it now?</p>', 'Dear {$DATA.name},\n        \n        We are please to  be sending you this gift certificate which you can use towards the purchase of any item(s) on our website.\n        \n        Happy shopping!\n        \n        From: {$DATA.first_name} {$DATA.last_name}\n        Amount: {$DATA.value}\n        Claim Code: {$DATA.code}\n        Gift Message: {$DATA.message}\n        \n        -------------------\n        \n        To reedeem this gift certificate please enter the \"Claim Code\" above into the text field labeled \"Add Gift Certificate or Coupon\" during checkout.\n        \n        Why not spend it now?'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('35', 'catalogue.tell_friend', 'en-US', '\n      {$DATA.from} has recommended something\n    ', 'Dear {$DATA.to},\n        <p>Your friend <strong>{$DATA.from}</strong> thought that you might be interested in <strong>{$DATA.name}</strong>.</p> \n        <p><strong>Product Link:</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n        <p>{$DATA.message}</p>', 'Dear {$DATA.to},\n        \n        Your friend {$DATA.from} thought that you might be interested in \'{$DATA.name}\'.\n        \n        {$DATA.name}\n        Product Link: {$DATA.link}\n        \n        {$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('36', 'cart.payment_received', 'en-US', '\n      Thank you for your payment!\n    ', '<p>Hi {$DATA.first_name},</p> \n        <p>Thank you. We have received a payment of {$DATA.total} for order number {$DATA.cart_order_id}.</p>', 'Hi {$DATA.first_name},\n        \n        Thank you. We have received a payment of {$DATA.total} for order number {$DATA.cart_order_id}.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('37', 'admin.password_recovery', 'es-ES', 'RecuperaciÃ³n de contraseÃ±a del Admin.', '<p>Estimado/a {$DATA.name},</p> \n<p>Para poder volver a acceder al panel de control de administraciÃ³n de las tiendas. Por favor, siga el enlace siguiente:</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n<p>Si el enlace anterior no funciona, por favor, copie y pÃ©guelo en la barra de direcciones de su navegador.</p>', 'Estimado/a {$DATA.name},\n \nPara poder volver a acceder al panel de control de administraciÃ³n de las tiendas. Por favor, siga el enlace siguiente:\n \n{$DATA.link}\n \nSi el enlace anterior no funciona, por favor, copie y pÃ©guelo en la barra de direcciones de su navegador.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('38', 'cart.order_complete', 'es-ES', 'Pedido completado', '<p>Hola, {$DATA.first_name},</p> \n<p>Nos complace indicarle que el pedido nÃºmero {$DATA.cart_order_id} ha sido completado. Si ha pedido mercancÃ­as fÃ­sicas, estas no tardarÃ¡n en llegar.</p>', 'Hola, {$DATA.first_name},\n \nNos complace indicarle que el pedido nÃºmero {$DATA.cart_order_id} ha sido completado. Si ha pedido mercancÃ­as fÃ­sicas, estas no tardarÃ¡n en llegar.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('39', 'cart.order_cancelled', 'es-ES', 'Pedido cancelado', '<p>Hola, {$DATA.first_name},</p> \n<p>El pedido nÃºmero {$DATA.cart_order_id} ha sido cancelado.</p>', 'Hola, {$DATA.first_name},\n \nEl pedido nÃºmero {$DATA.cart_order_id} ha sido cancelado.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('40', 'cart.order_confirmation', 'es-ES', 'ConfirmaciÃ³n de pedido #{$DATA.cart_order_id}', '<p>Muchas gracias, {$DATA.first_name}!</p>\n<p>Hemos recibido su pedido {$DATA.cart_order_id} que fue realizado el {$DATA.order_date}. Por favor, conserve este mensaje para sus registros. Puede ver el estado de su pedido en lÃ­nea.</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n<table width=\"100%\">\n  <tr>\n    <td valign=\"top\" width=\"50%\"><strong>DirecciÃ³n de facturaciÃ³n:</strong><br />\n      {$BILLING.first_name} {$BILLING.last_name}<br />\n      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n      {/if}\n      {$BILLING.line1}<br />\n      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n      {/if}\n      {$BILLING.town}<br />\n      {$BILLING.state}<br />\n      {$BILLING.postcode}<br />\n      {$BILLING.country}<br />\n      {$BILLING.phone}<br />\n      <br />\n      <strong>Correo electrÃ³nico:</strong><br />\n      {$BILLING.email}</td>\n    <td valign=\"top\" width=\"50%\"><strong>DirecciÃ³n de envÃ­o:</strong><br />\n      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n      {/if}{$SHIPPING.line1}<br />\n      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n      {/if}{$SHIPPING.town}<br />\n      {$SHIPPING.state}<br />\n      {$SHIPPING.postcode}<br />\n      {$SHIPPING.country}</td>\n  </tr>\n</table>\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n  <tbody>\n    <tr>\n      <td><strong>ArtÃ­culo</strong></td>\n      <td><strong>Cantidad</strong></td>\n      <td><strong>Coste</strong></td>\n    </tr>\n  <!--{foreach from=$PRODUCTS item=product}-->\n  <tr>\n    <td>{$product.name} <br />{$product.product_options}</td>\n    <td>{$product.quantity}</td>\n    <td>{$product.price}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> EnvÃ­o: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n    <td> {$DATA.shipping}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Descuento:</td>\n    <td> {$DATA.discount}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Subtotal:</td>\n    <td> {$DATA.subtotal}</td>\n  </tr>\n  <!--{foreach from=$TAXES item=tax}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n    <td> {$tax.tax_amount}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td><strong>Total del pedido: </strong></td>\n    <td><strong>{$DATA.total}</strong></td>\n  </tr>\n  </tbody>\n  \n</table>', 'Muchas gracias, {$DATA.first_name}!\n\nHemos recibido su pedido {$DATA.cart_order_id} que fue realizado el {$DATA.order_date}. Por favor, conserve este mensaje para sus registros. Puede ver el estado de su pedido en lÃ­nea. \n\n{$DATA.link}\n\n----------------------------------------------------------------------\nDirecciÃ³n de facturaciÃ³n:\n  {$BILLING.first_name} {$BILLING.last_name}\n  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n  {/if}{$BILLING.line1}\n  {if !empty({$BILLING.line2})}{$BILLING.line2}\n  {/if}{$BILLING.town}\n  {$BILLING.state}\n  {$BILLING.postcode}\n  {$BILLING.country}\n  {$BILLING.phone}\n\nCorreo electrÃ³nico:\n  {$BILLING.email}\n\nDirecciÃ³n de envÃ­o:\n  {$SHIPPING.first_name} {$SHIPPING.last_name}\n  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n  {/if}{$SHIPPING.line1}\n  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n  {/if}{$SHIPPING.town}\n  {$SHIPPING.state}\n  {$SHIPPING.postcode}\n  {$SHIPPING.country}\n\n----------------------------------------------------------------------\nArtÃ­culos en su pedido\n\n{foreach from=$PRODUCTS item=product}\n-----------------------------------\n{$product.name}\n{$product.product_options}\n\n  NÃºmero de pieza: {$product.product_code}\n  Precio por unidad: {$product.price}\n  Cdad.: {$product.quantity}\n\n{/foreach}\n-----------------------------------\n  Subtotal: {$DATA.subtotal}\n  Descuento: {$DATA.discount}\n  EnvÃ­o: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n  {/foreach}\n  --------------------------\n  Total del pedido: {$DATA.total}\n  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('41', 'cart.payment_fraud', 'es-ES', 'Problema con el pedido', '<p>Hola, {$DATA.first_name},</p> \n<p>Lo sentimos mucho, pero no hemos podido aceptar el pago del pedido {$DATA.cart_order_id}. Por favor, no dude en contactar con un miembro de nuestro personal si tiene alguna pregunta.</p>', 'Hola, {$DATA.first_name},\n \nLo sentimos mucho, pero no hemos podido aceptar el pago del pedido {$DATA.cart_order_id}. Por favor, no dude en contactar con un miembro de nuestro personal si tiene alguna pregunta.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('42', 'account.password_recovery', 'es-ES', 'RecuperaciÃ³n de contraseÃ±a', '<p>Estimado/a {$DATA.first_name} {$DATA.last_name},<br /> \n<br /> \nPara borrar su contraseÃ±a y crear otra, haga clic en el siguiente vÃ­nculo o copie y pegue la direcciÃ³n en la barra de direcciones de su navegador. Una vez que estÃ© en la pÃ¡gina web, recibirÃ¡ instrucciones para introducir y confirmar su nueva contraseÃ±a.<br /> \n<br /> \n{$DATA.reset_link}<br /> \n<br /> \nSi necesita mÃ¡s ayuda para restablecer su contraseÃ±a, por favor, pÃ³ngase en contacto con nosotros.</p>', 'Hola, {$DATA.first_name},\n \nPara borrar su contraseÃ±a y crear otra, haga clic en el siguiente vÃ­nculo o copie y pegue la direcciÃ³n en la barra de direcciones de su navegador. Una vez que estÃ© en la pÃ¡gina web, recibirÃ¡ instrucciones para introducir y confirmar su nueva contraseÃ±a.\n \n{$DATA.reset_link}\n \nSi necesita mÃ¡s ayuda para restablecer su contraseÃ±a, por favor, pÃ³ngase en contacto con nosotros.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('43', 'admin.order_received', 'es-ES', 'Nuevo pedido #{$DATA.cart_order_id}', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} acaba de realizar el pedido nÃºmero {$DATA.cart_order_id} el {$DATA.order_date}.</p>\n<p>Este pedido puede gestionarse en lÃ­nea siguiendo el enlace que aparece a continuaciÃ³n.</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n<table width=\"100%\">\n  <tr>\n    <td valign=\"top\" width=\"50%\"><strong>DirecciÃ³n de facturaciÃ³n:</strong><br />\n      {$BILLING.first_name} {$BILLING.last_name}<br />\n      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n      {/if}\n      {$BILLING.line1}<br />\n      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n      {/if}\n      {$BILLING.town}<br />\n      {$BILLING.state}<br />\n      {$BILLING.postcode}<br />\n      {$BILLING.country}<br />\n      {$BILLING.phone}<br />\n      <br />\n      <strong>Correo electrÃ³nico:</strong><br />\n      {$BILLING.email}</td>\n    <td valign=\"top\" width=\"50%\"><strong>DirecciÃ³n de envÃ­o:</strong><br />\n      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n      {/if}{$SHIPPING.line1}<br />\n      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n      {/if}{$SHIPPING.town}<br />\n      {$SHIPPING.state}<br />\n      {$SHIPPING.postcode}<br />\n      {$SHIPPING.country}</td>\n  </tr>\n</table>\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n  <tbody>\n    <tr>\n      <td><strong>ArtÃ­culo</strong></td>\n      <td><strong>Cantidad</strong></td>\n      <td><strong>Coste</strong></td>\n    </tr>\n  <!--{foreach from=$PRODUCTS item=product}-->\n  <tr>\n    <td>{$product.name} <br />{$product.product_options}</td>\n    <td>{$product.quantity}</td>\n    <td>{$product.price}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> EnvÃ­o: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n    <td> {$DATA.shipping}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Descuento:</td>\n    <td> {$DATA.discount}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Subtotal:</td>\n    <td> {$DATA.subtotal}</td>\n  </tr>\n  <!--{foreach from=$TAXES item=tax}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n    <td> {$tax.tax_amount}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td><strong>Total del pedido: </strong></td>\n    <td><strong>{$DATA.total}</strong></td>\n  </tr>\n  </tbody>\n  \n</table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} acaba de realizar el pedido nÃºmero {$DATA.cart_order_id} el {$DATA.order_date}.\n\nEste pedido puede gestionarse en lÃ­nea siguiendo el enlace que aparece a continuaciÃ³n.\n\n{$DATA.link}\n\n----------------------------------------------------------------------\nDirecciÃ³n de facturaciÃ³n:\n  {$BILLING.first_name} {$BILLING.last_name}\n  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n  {/if}{$BILLING.line1}\n  {if !empty({$BILLING.line2})}{$BILLING.line2}\n  {/if}{$BILLING.town}\n  {$BILLING.state}\n  {$BILLING.postcode}\n  {$BILLING.country}\n  {$BILLING.phone}\n\nCorreo electrÃ³nico:\n  {$BILLING.email}\n\nDirecciÃ³n de envÃ­o:\n  {$SHIPPING.first_name} {$SHIPPING.last_name}\n  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n  {/if}{$SHIPPING.line1}\n  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n  {/if}{$SHIPPING.town}\n  {$SHIPPING.state}\n  {$SHIPPING.postcode}\n  {$SHIPPING.country}\n\n----------------------------------------------------------------------\nArtÃ­culos en su pedido\n\n{foreach from=$PRODUCTS item=product}\n-----------------------------------\n{$product.name}\n{$product.product_options}\n\n  NÃºmero de pieza: {$product.product_code}\n  Precio por unidad: {$product.price}\n  Cdad.: {$product.quantity}\n\n{/foreach}\n-----------------------------------\n  Subtotal: {$DATA.subtotal}\n  Descuento: {$DATA.discount}\n  EnvÃ­o: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n  {/foreach}\n  --------------------------\n  Total del pedido: {$DATA.total}\n  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('44', 'admin.review_added', 'es-ES', 'Nueva opiniÃ³n sobre un producto', '{$DATA.name} ha enviado una nueva opiniÃ³n/comentario sobre \'{$DATA.product_name}\'. Puede ser moderado siguiendo el enlace que aparece a continuaciÃ³n.\n<p><strong>Enlace de moderaciÃ³n:</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n<p><strong>Texto de la opiniÃ³n:</strong><br />{$DATA.review}</p>', '{$DATA.name} ha enviado una nueva opiniÃ³n/comentario sobre \'{$DATA.product_name}\'. Puede ser moderado siguiendo el enlace que aparece a continuaciÃ³n.\n \nEnlace de moderaciÃ³n: \n{$DATA.link}\nTexto de la opiniÃ³n:\n{$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('45', 'cart.digital_download', 'es-ES', 'Sus descargas compradas', '<p>Hola, {$DATA.first_name},</p> \n<p>Sus archivos digitales estÃ¡n listos para su descarga. Por favor, utilice los enlaces que se proporcionan a continuaciÃ³n para acceder a ellos:</p> \n{foreach from=$DOWNLOADS item=download} \n<p><strong>{$download.name}:</strong> (El enlace caduca en {$download.expire}<strong>)</strong><br /> \n{$download.url}</p> \n{/foreach}\n<p>Si los enlaces anteriores no funcionan, por favor, intente copiar y pegar las direcciones en la barra de direcciones de su navegador. TambiÃ©n puede encontrar acceso a estos archivos desde el Ã¡rea del cliente de su sitio web.</p> \n<p>&nbsp;</p>', 'Hola, {$DATA.first_name},\n \nSus archivos digitales estÃ¡n listos para su descarga. Por favor, utilice los enlaces que se proporcionan a continuaciÃ³n para acceder a ellos:\n \n{foreach from=$DOWNLOADS item=download} \n{$download.name}: (El enlace caduca en {$download.expire})\n{$download.url}\n{/foreach}\n \nSi los enlaces anteriores no funcionan, por favor, intente copiar y pegar las direcciones en la barra de direcciones de su navegador. TambiÃ©n puede encontrar acceso a estos archivos desde el Ã¡rea del cliente de su sitio web.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('46', 'cart.gift_certificate', 'es-ES', 'Su certificado de regalo', '<p>Estimado/a {$DATA.name},</p> \n<p>Nos complace enviarle este certificado de regalo que podrÃ¡ utilizar para la compra de cualquier artÃ­culo de nuestro sitio web.</p> \n<p>Â¡Feliz compra!</p> \n<p><strong>De: </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n<strong>Importe: </strong>{$DATA.value}<br /> \n<strong>CÃ³digo del certificado:</strong> {$DATA.code}<br /> \n<strong>Mensaje del regalo:</strong> {$DATA.message}</p> \n<p>-------------------</p> \n<p>Para canjear este ceritficado de regalo, por favor, introduzca el &quot;CÃ³digo del certificado&quot; que aparece mÃ¡s arriba en el campo de texto con la etiqueta &quot;AÃ±adir Certificado o CupÃ³n de regalo&quot; durante el paso por caja.</p> \n<p>Â¿Por quÃ© no gastarlo ahora mismo?</p>', 'Estimado/a {$DATA.name},\n \nNos complace enviarle este certificado de regalo que podrÃ¡ utilizar para la compra de cualquier artÃ­culo de nuestro sitio web.\n \nÂ¡Felices compras!\n \nDe: {$DATA.first_name} {$DATA.last_name}\nImporte: {$DATA.value}\nCÃ³digo del certificado: {$DATA.code}\nMensaje del regalo: {$DATA.message}\n \n-------------------\n \nParra canjear este certificado de regalo, por favor, introduzca el \"CÃ³digo del certificado\" que aparece mÃ¡s arriba en el campo de texto con la etiqueta \"AÃ±adir Certificado o CupÃ³n de regalo\" durante el paso por caja.\n \nÂ¿Por quÃ© no gastarlo ahora mismo?'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('47', 'catalogue.tell_friend', 'es-ES', '{$DATA.from} ha recomendado algo', 'Estimado/a {$DATA.to},\n<p>Su amigo/a <strong>{$DATA.from}</strong> pensÃ³ que quizÃ¡ le interesarÃ­a <strong>{$DATA.name}</strong>.</p> \n<p><strong>Enlace al producto:</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n<p>{$DATA.message}</p>', 'Estimado/a {$DATA.to},\n \nSu amigo/a {$DATA.from} pensÃ³ que quizÃ¡ le interesarÃ­a \'{$DATA.name}\'.\n \n{$DATA.name}\nEnlace al producto: {$DATA.link}\n \n{$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('48', 'cart.payment_received', 'es-ES', 'Â¡Gracias por su pago!', '<p>Hola, {$DATA.first_name},</p> \n<p>Gracias. Hemos recibido un pago de {$DATA.total} correspondiente al pedido nÃºmero {$DATA.cart_order_id}.</p>', 'Hola, {$DATA.first_name},\n \nGracias. Hemos recibido un pago de {$DATA.total} correspondiente al pedido nÃºmero {$DATA.cart_order_id}.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('49', 'admin.password_recovery', 'fr-FR', 'RÃ©cupÃ©ration du mot de passe Admin', '<p>Cher {$DATA.name},</p> \n<p>Pour avoir Ã  nouveau accÃ¨s au panneau de contrÃ´le d\'administration des boutiques. Veuillez suivre le lien ci-dessousÂ :</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n<p>Si le lien ci-dessus ne fonctionne pas, veuillez le copier et coller dans la barre d\'adresse de votre navigateur.</p>', 'Cher {$DATA.name},\n \nPour avoir Ã  nouveau accÃ¨s au panneau de contrÃ´le d\'administration des boutiques. Veuillez suivre le lien ci-dessousÂ :\n \n{$DATA.link}\n \nSi le lien ci-dessus ne fonctionne pas, veuillez le copier et coller dans la barre d\'adresse de votre navigateur.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('50', 'cart.order_complete', 'fr-FR', 'Commande terminÃ©e', '<p>Bonjour {$DATA.first_name},</p> \n<p>Nous sommes ravis de vous indiquer votre numÃ©ro de commande {$DATA.cart_order_id} est complet. Si vous avez commandÃ© des biens physiques, ils devraient arriver sous peu.</p>', 'Bonjour {$DATA.first_name},\n \nNous sommes ravis de vous indiquer votre numÃ©ro de commande {$DATA.cart_order_id} est complet. Si vous avez commandÃ© des biens physiques, ils devraient arriver sous peu.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('51', 'cart.order_cancelled', 'fr-FR', 'Commande annulÃ©e', '<p>Bonjour {$DATA.first_name},</p> \n<p>NumÃ©ro de commande {$DATA.cart_order_id} a Ã©tÃ© annulÃ©.</p>', 'Bonjour {$DATA.first_name},\n \nNumÃ©ro de commande {$DATA.cart_order_id} a Ã©tÃ© annulÃ©.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('52', 'cart.order_confirmation', 'fr-FR', 'Confirmation de commande #{$DATA.cart_order_id}', '<p>Merci {$DATA.first_name}!</p>\n<p>Votre commande {$DATA.cart_order_id} a bien Ã©tÃ© reÃ§ue et a Ã©tÃ© effectuÃ©e le {$DATA.order_date}. Veuillez conserver cet e-mail pour vos archives. Il est possible de voir le statut de votre commande en ligne.</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n<table width=\"100%\">\n  <tr>\n    <td valign=\"top\" width=\"50%\"><strong>Adresse de facturation :</strong><br />\n      {$BILLING.first_name} {$BILLING.last_name}<br />\n      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n      {/if}\n      {$BILLING.line1}<br />\n      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n      {/if}\n      {$BILLING.town}<br />\n      {$BILLING.state}<br />\n      {$BILLING.postcode}<br />\n      {$BILLING.country}<br />\n      {$BILLING.phone}<br />\n      <br />\n      <strong>E-mailÂ :</strong><br />\n      {$BILLING.email}</td>\n    <td valign=\"top\" width=\"50%\"><strong>Adresse de livraisonÂ :</strong><br />\n      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n      {/if}{$SHIPPING.line1}<br />\n      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n      {/if}{$SHIPPING.town}<br />\n      {$SHIPPING.state}<br />\n      {$SHIPPING.postcode}<br />\n      {$SHIPPING.country}</td>\n  </tr>\n</table>\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n  <tbody>\n    <tr>\n      <td><strong>Article</strong></td>\n      <td><strong>QuantitÃ©</strong></td>\n      <td><strong>CoÃ»t</strong></td>\n    </tr>\n  <!--{foreach from=$PRODUCTS item=product}-->\n  <tr>\n    <td>{$product.name} <br />{$product.product_options}</td>\n    <td>{$product.quantity}</td>\n    <td>{$product.price}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> LivraisonÂ : {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n    <td> {$DATA.shipping}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> RemiseÂ :</td>\n    <td> {$DATA.discount}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Sous-totalÂ :</td>\n    <td> {$DATA.subtotal}</td>\n  </tr>\n  <!--{foreach from=$TAXES item=tax}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n    <td> {$tax.tax_amount}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td><strong>Total de la commandeÂ : </strong></td>\n    <td><strong>{$DATA.total}</strong></td>\n  </tr>\n  </tbody>\n  \n</table>', 'Merci {$DATA.first_name}!\n\nVotre commande {$DATA.cart_order_id} a bien Ã©tÃ© reÃ§ue et a Ã©tÃ© effectuÃ©e le {$DATA.order_date}. Veuillez conserver cet e-mail pour vos archives. Il est possible de voir le statut de votre commande en ligne. \n\n{$DATA.link}\n\n----------------------------------------------------------------------\nAdresse de facturationÂ :\n  {$BILLING.first_name} {$BILLING.last_name}\n  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n  {/if}{$BILLING.line1}\n  {if !empty({$BILLING.line2})}{$BILLING.line2}\n  {/if}{$BILLING.town}\n  {$BILLING.state}\n  {$BILLING.postcode}\n  {$BILLING.country}\n  {$BILLING.phone}\n\nE-mailÂ :\n  {$BILLING.email}\n\nAdresse de livraisonÂ :\n  {$SHIPPING.first_name} {$SHIPPING.last_name}\n  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n  {/if}{$SHIPPING.line1}\n  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n  {/if}{$SHIPPING.town}\n  {$SHIPPING.state}\n  {$SHIPPING.postcode}\n  {$SHIPPING.country}\n\n----------------------------------------------------------------------\nArticles de votre commande\n\n{foreach from=$PRODUCTS item=product}\n-----------------------------------\n{$product.name}\n{$product.product_options}\n\n  Code articleÂ : {$product.product_code}\n  Prix unitaireÂ : {$product.price}\n  QtÃ©Â : {$product.quantity}\n\n{/foreach}\n-----------------------------------\n  Sous-totalÂ : {$DATA.subtotal}\n  RemiseÂ : {$DATA.discount}\n  LivraisonÂ : {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n  {/foreach}\n  --------------------------\n  Total de la commandeÂ : {$DATA.total}\n  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('53', 'cart.payment_fraud', 'fr-FR', 'ProblÃ¨me de la commande', '<p>Bonjour {$DATA.first_name},</p> \n<p>Nous sommes dÃ©solÃ©s mais nous ne pouvons pas accepter le paiement pour la commande {$DATA.cart_order_id}. N\'hÃ©sitez pas Ã  contacter un membre du personnel si vous avez des questions.<p>', 'Bonjour {$DATA.first_name},\n \nNous sommes dÃ©solÃ©s mais nous ne pouvons pas accepter le paiement pour la commande {$DATA.cart_order_id}. N\'hÃ©sitez pas Ã  contacter un membre du personnel si vous avez des questions.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('54', 'account.password_recovery', 'fr-FR', 'RÃ©cupÃ©ration du mot de passe', '<p>Cher {$DATA.first_name} {$DATA.last_name},<br /> \n<br /> \nPour rÃ©initialiser votre mot de passe, veuillez cliquer sur le lien ci-dessous ou copier et coller l\'adresse dans la fenÃªtre d\'adresse de votre navigateur Web. Une fois que vous Ãªtes sur la page Web, il vous sera demandÃ© d\'entrer et de confirmer votre nouveau mot de passe.<br /> \n<br /> \n{$DATA.reset_link}<br /> \n<br /> \nSi vous avez besoin davantage d\'assistance pour la rÃ©initialisation de votre mot de passe, veuillez nous contacter.</p>', 'Bonjour {$DATA.first_name},\n \nPour rÃ©initialiser votre mot de passe, veuillez cliquer sur le lien ci-dessous ou copier et coller l\'adresse dans la fenÃªtre d\'adresse de votre navigateur Web. Une fois que vous Ãªtes sur la page Web, il vous sera demandÃ© d\'entrer et de confirmer votre nouveau mot de passe.\n \n{$DATA.reset_link}\n \nSi vous avez besoin davantage d\'assistance pour la rÃ©initialisation de votre mot de passe, veuillez nous contacter.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('55', 'admin.order_received', 'fr-FR', 'Nouvelle commande #{$DATA.cart_order_id}', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} vient juste d\'Ãªtre passÃ©e, numÃ©ro de commande {$DATA.cart_order_id} on {$DATA.order_date}.</p>\n<p>Cette commande peut Ãªtre gÃ©rÃ©e en ligne en suivant le lien suivant.</p> \n<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n<table width=\"100%\">\n  <tr>\n    <td valign=\"top\" width=\"50%\"><strong>Adresse de facturation :</strong><br />\n      {$BILLING.first_name} {$BILLING.last_name}<br />\n      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n      {/if}\n      {$BILLING.line1}<br />\n      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n      {/if}\n      {$BILLING.town}<br />\n      {$BILLING.state}<br />\n      {$BILLING.postcode}<br />\n      {$BILLING.country}<br />\n      {$BILLING.phone}<br />\n      <br />\n      <strong>E-mailÂ :</strong><br />\n      {$BILLING.email}</td>\n    <td valign=\"top\" width=\"50%\"><strong>Adresse de livraisonÂ :</strong><br />\n      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n      {/if}{$SHIPPING.line1}<br />\n      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n      {/if}{$SHIPPING.town}<br />\n      {$SHIPPING.state}<br />\n      {$SHIPPING.postcode}<br />\n      {$SHIPPING.country}</td>\n  </tr>\n</table>\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n  <tbody>\n    <tr>\n      <td><strong>Article</strong></td>\n      <td><strong>QuantitÃ©</strong></td>\n      <td><strong>CoÃ»t</strong></td>\n    </tr>\n  <!--{foreach from=$PRODUCTS item=product}-->\n  <tr>\n    <td>{$product.name} <br />{$product.product_options}</td>\n    <td>{$product.quantity}</td>\n    <td>{$product.price}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> LivraisonÂ : {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n    <td> {$DATA.shipping}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> RemiseÂ :</td>\n    <td> {$DATA.discount}</td>\n  </tr>\n  <tr>\n    <td>&nbsp;</td>\n    <td> Sous-totalÂ :</td>\n    <td> {$DATA.subtotal}</td>\n  </tr>\n  <!--{foreach from=$TAXES item=tax}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n    <td> {$tax.tax_amount}</td>\n  </tr>\n  <!--{/foreach}-->\n  <tr>\n    <td>&nbsp;</td>\n    <td><strong>Total de la commandeÂ : </strong></td>\n    <td><strong>{$DATA.total}</strong></td>\n  </tr>\n  </tbody>\n  \n</table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} numÃ©ro de commande juste passÃ© {$DATA.cart_order_id} on {$DATA.order_date}.\n\nCette commande peut Ãªtre gÃ©rÃ©e en ligne en suivant le lien ci-dessous.\n\n{$DATA.link}\n\n----------------------------------------------------------------------\nAdresse de facturationÂ :\n  {$BILLING.first_name} {$BILLING.last_name}\n  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n  {/if}{$BILLING.line1}\n  {if !empty({$BILLING.line2})}{$BILLING.line2}\n  {/if}{$BILLING.town}\n  {$BILLING.state}\n  {$BILLING.postcode}\n  {$BILLING.country}\n  {$BILLING.phone}\n\nE-mailÂ :\n  {$BILLING.email}\n\nAdresse de livraisonÂ :\n  {$SHIPPING.first_name} {$SHIPPING.last_name}\n  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n  {/if}{$SHIPPING.line1}\n  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n  {/if}{$SHIPPING.town}\n  {$SHIPPING.state}\n  {$SHIPPING.postcode}\n  {$SHIPPING.country}\n\n----------------------------------------------------------------------\nArticles de votre commande\n\n{foreach from=$PRODUCTS item=product}\n-----------------------------------\n{$product.name}\n{$product.product_options}\n\n  Code articleÂ : {$product.product_code}\n  Prix unitaireÂ : {$product.price}\n  QtÃ©Â : {$product.quantity}\n\n{/foreach}\n-----------------------------------\n  Sous-totalÂ : {$DATA.subtotal}\n  RemiseÂ : {$DATA.discount}\n  LivraisonÂ : {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n  {/foreach}\n  --------------------------\n  Total de la commandeÂ : {$DATA.total}\n  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('56', 'admin.review_added', 'fr-FR', 'Avis relatif au nouveau produit', '{$DATA.name} a soumis un nouvel avis/commentaire sur \'{$DATA.product_name}\'. Cette commande peut Ãªtre modÃ©rÃ©e en suivant le lien ci-dessous.\n<p><strong>Lien de modÃ©rationÂ :</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n<p><strong>Texte de l\'avisÂ :</strong><br />{$DATA.review}</p>', '{$DATA.name} a soumis un nouvel avis/commentaire sur \'{$DATA.product_name}\'. Cette commande peut Ãªtre modÃ©rÃ©e en suivant le lien ci-dessous.\n \nLien de modÃ©rationÂ : \n{$DATA.link}\nTexte de l\'avisÂ :\n{$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('57', 'cart.digital_download', 'fr-FR', 'Vos tÃ©lÃ©chargements achetÃ©s', '<p>Bonjour {$DATA.first_name},</p> \n<p>Vos fichiers numÃ©riques sont dÃ©sormais prÃªts pour le tÃ©lÃ©chargement. Veuillez utiliser les liens fournis ci-dessous pour y accÃ©der ensuiteÂ :</p> \n{foreach from=$DOWNLOADS item=download} \n<p><strong>{$download.name}:</strong> (Lien expire le {$download.expire}<strong>)</strong><br /> \n{$download.url}</p> \n{/foreach}\n<p>Si les liens ci-dessus ne fonctionnent pas, veuillez essayer de les copier et coller dans la barre d\'adresse de votre navigateur. Vous pouvez Ã©galement accÃ©der Ã  ces fichiers Ã  partir de votre espace client de notre site Web.</p> \n<p>&nbsp;</p>', 'Bonjour {$DATA.first_name},\n \nVos fichiers numÃ©riques sont dÃ©sormais prÃªts pour le tÃ©lÃ©chargement. Veuillez utiliser les liens fournis ci-dessous pour y accÃ©der ensuiteÂ :\n \n{foreach from=$DOWNLOADS item=download} \n{$download.name}: (Lien expire le {$download.expire})\n{$download.url}\n{/foreach}\n \nSi les liens ci-dessus ne fonctionnent pas, veuillez essayer de les copier et coller dans la barre d\'adresse de votre navigateur. Vous pouvez Ã©galement accÃ©der Ã  ces fichiers Ã  partir de votre espace client de notre site Web.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('58', 'cart.gift_certificate', 'fr-FR', 'Votre bon-cadeau', '<p>Cher{$DATA.name},</p> \n<p>Nous sommes ravis de vous envoyer ce bon-cadeau que vous pouvez utiliser pour l\'achat d\'un/des article(s) sur notre site Web.</p> \n<p>Bon shoppingÂ !</p> \n<p><strong>DeÂ : </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n<strong>MontantÂ : </strong>{$DATA.value}<br /> \n<strong>Code du bon-cadeauÂ :</strong> {$DATA.code}<br /> \n<strong>Message cadeauÂ :</strong> {$DATA.message}</p> \n<p>-------------------</p> \n<p>Pour utiliser ce bon-cadeau, veuillez entrer le &quot;code&quot; figurant sur ce dernier ci-dessus dans le champ texte appelÃ© &quot;Ajouter bon-certificat ou coupon&quot; lors du passage en caisse.</p> \n<p>Pourquoi ne pas l\'utiliser maintenantÂ ?</p>', 'Cher {$DATA.name},\n \nNous sommes ravis de vous envoyer ce bon-cadeau que vous pouvez utiliser pour l\'achat d\'un/des article(s) sur notre site Web.\n \nBon shoppingÂ !\n \nDeÂ : {$DATA.first_name} {$DATA.last_name}\nMontantÂ : {$DATA.value}\nCode du bon-cadeauÂ : {$DATA.code}\nMessage cadeauÂ : {$DATA.message}\n \n-------------------\n \nPour utiliser ce bon-cadeau, veuillez entrer le Â«Â code bon-cadeauÂ Â» ci-dessus dans le champ texte appelÃ© Â«Â Ajouter bon-certificat ou couponÂ Â» lors du passage en caisse.\n \nPourquoi ne pas l\'utiliser maintenantÂ ?'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('59', 'catalogue.tell_friend', 'fr-FR', '{$DATA.from} a recommandÃ© quelque chose', 'Cher {$DATA.to},\n<p>Votre ami <strong>{$DATA.from}</strong> a pensÃ© que vous pourriez Ãªtre intÃ©ressÃ© par <strong>{$DATA.name}</strong>.</p> \n<p><strong>Lien du produitÂ :</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n<p>{$DATA.message}</p>', 'Cher {$DATA.to},\n \nVotre ami {$DATA.from} a pensÃ© que vous pourriez Ãªtre intÃ©ressÃ© par \'{$DATA.name}\'.\n \n{$DATA.name}\nLien du produitÂ : {$DATA.link}\n \n{$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('60', 'cart.payment_received', 'fr-FR', 'Merci pour votre paiementÂ !', '<p>Bonjour {$DATA.first_name},</p> \n<p>Merci. Nous avons reÃ§u un paiement de {$DATA.total} pour le numÃ©ro de commande {$DATA.cart_order_id}.</p>', 'Bonjour {$DATA.first_name},\n \nMerci. Nous avons reÃ§u un paiement de {$DATA.total} pour le numÃ©ro de commande {$DATA.cart_order_id}.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('61', 'admin.password_recovery', 'nl-NL', '\n	Beheerders Wachtwoord Herstellen \n	  ', '<p>Beste {$DATA.name},</p> \n	<p>Klik op onderstaande link om weer toegang te krijgen tot het beheerders bedieningspaneel:</p> \n	<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p> \n	<p>Kopieer en plak bovenstaande link in de adresbalk van uw browser, mits de link niet werkt.</p>', 'Beste {$DATA.name},\n	 \n	Klik op onderstaande link om weer toegang te krijgen tot het beheerders bedieningspaneel:\n	 \n	{$DATA.link}\n	 \n	Kopieer en plak bovenstaande link in de adresbalk van uw browser, mits de link niet werkt.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('62', 'cart.order_complete', 'nl-NL', '\n	Bestelling voltooid \n	  ', '<p>Hallo {$DATA.first_name},</p> \n	<p>Het verheugd ons om te vertellen dat order nummer {$DATA.cart_order_id} is voltooid. Wanneer u een fysiek product heeft besteld dan zal deze binnenkort arriveren.</p>', 'Hallo {$DATA.first_name},\n	 \n	Het verheugd ons om te vertellen dat order nummer {$DATA.cart_order_id} is voltooid. Wanneer u een fysiek product heeft besteld dan zal deze binnenkort arriveren.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('63', 'cart.order_cancelled', 'nl-NL', '\n	Bestelling geannuleerd \n	  ', '<p>Hallo {$DATA.first_name},</p> \n	<p>Bestelnummer {$DATA.cart_order_id} is geannuleerd.</p>', 'Hallo {$DATA.first_name},\n	 \n	Bestelnummer {$DATA.cart_order_id} is geannuleerd.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('64', 'cart.order_confirmation', 'nl-NL', '\n	Bestellingsbevestiging #{$DATA.cart_order_id} \n	  ', '<p>Bedankt {$DATA.first_name}!</p>\n	<p>uw bestelling {$DATA.cart_order_id} is ontvangen en is geplaatst op {$DATA.order_date}. Bewaar alstublief deze email ter referentie. U kunt de status van uw bestelling online bekijken.</p> \n	<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n	<table width=\"100%\">\n	  <tr>\n	    <td valign=\"top\" width=\"50%\"><strong>Factuuradres:</strong><br />\n	      {$BILLING.first_name} {$BILLING.last_name}<br />\n	      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n	      {/if}\n	      {$BILLING.line1}<br />\n	      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n	      {/if}\n	      {$BILLING.town}<br />\n	      {$BILLING.state}<br />\n	      {$BILLING.postcode}<br />\n	      {$BILLING.country}<br />\n	      {$BILLING.phone}<br />\n	      <br />\n	      <strong>Email:</strong><br />\n	      {$BILLING.email}</td>\n	    <td valign=\"top\" width=\"50%\"><strong>Bezorgadres:</strong><br />\n	      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n	      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n	      {/if}{$SHIPPING.line1}<br />\n	      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n	      {/if}{$SHIPPING.town}<br />\n	      {$SHIPPING.state}<br />\n	      {$SHIPPING.postcode}<br />\n	      {$SHIPPING.country}</td>\n	  </tr>\n	</table>\n	<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n	  <tbody>\n	    <tr>\n	      <td><strong>Item</strong></td>\n	      <td><strong>Hoeveelheid</strong></td>\n	      <td><strong>Kosten</strong></td>\n	    </tr>\n	  {foreach from=$PRODUCTS item=product}\n	  <tr>\n	    <td>{$product.name} <br />{$product.product_options}</td>\n	    <td>{$product.quantity}</td>\n	    <td>{$product.price}</td>\n	  </tr>\n	  {/foreach}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Verzendmethode: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n	    <td> {$DATA.shipping}</td>\n	  </tr>\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Korting:</td>\n	    <td> {$DATA.discount}</td>\n	  </tr>\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Subtotaal:</td>\n	    <td> {$DATA.subtotal}</td>\n	  </tr>\n	  {foreach from=$TAXES item=tax}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n	    <td> {$tax.tax_amount}</td>\n	  </tr>\n	  {/foreach}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td><strong>Bestelling Totaal: </strong></td>\n	    <td><strong>{$DATA.total}</strong></td>\n	  </tr>\n	  </tbody>\n	  \n	</table>', 'Bedankt {$DATA.first_name}!\n	\n	Uw bestelling {$DATA.cart_order_id} is ontvangen en is geplaatst op {$DATA.order_date}. Bewaar alstublief deze email ter referentie. U kunt de status van uw bestelling online bekijken.\n	\n	{$DATA.link}\n	\n	----------------------------------------------------------------------\n	Factuuradres:\n	  {$BILLING.first_name} {$BILLING.last_name}\n	  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n	  {/if}{$BILLING.line1}\n	  {if !empty({$BILLING.line2})}{$BILLING.line2}\n	  {/if}{$BILLING.town}\n	  {$BILLING.state}\n	  {$BILLING.postcode}\n	  {$BILLING.country}\n	  {$BILLING.phone}\n	\n	Email:\n	  {$BILLING.email}\n	\n	Bezorgadres:\n	  {$SHIPPING.first_name} {$SHIPPING.last_name}\n	  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n	  {/if}{$SHIPPING.line1}\n	  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n	  {/if}{$SHIPPING.town}\n	  {$SHIPPING.state}\n	  {$SHIPPING.postcode}\n	  {$SHIPPING.country}\n	\n	----------------------------------------------------------------------\n	Items in uw bestelling\n	\n	{foreach from=$PRODUCTS item=product}\n	-----------------------------------\n	{$product.name}\n	{$product.product_options}\n	\n	  Producttype Nummer: {$product.product_code}\n	  Stuk Prijs: {$product.price}\n	  Hoeveelheid: {$product.quantity}\n	\n	{/foreach}\n	-----------------------------------\n	  Subtotaal: {$DATA.subtotal}\n	  korting: {$DATA.discount}\n	  Verzending: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n	  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n	  {/foreach}\n	  --------------------------\n	  Bestelling totaal: {$DATA.total}\n	  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('65', 'cart.payment_fraud', 'nl-NL', '\n	Bestelling probleem \n	  ', '<p>Hallo {$DATA.first_name},</p> \n	<p>Het spijt ons heel erg maar We konden de betaling niet ontvangen voor bestelling {$DATA.cart_order_id}. Mochten er vragen zijn dan kunt u het beste contact opnemen met onze medewerkers.</p>', 'Hallo {$DATA.first_name},\n	 \n	Het spijt ons heel erg maar We konden de betaling niet ontvangen voor bestelling {$DATA.cart_order_id}. Mochten er vragen zijn dan kunt u het beste contact opnemen met onze medewerkers.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('66', 'account.password_recovery', 'nl-NL', '\n	Wachtwoord herstellen \n	', '<p>Beste {$DATA.first_name} {$DATA.last_name},<br /> \n	<br /> \n	Om uw wachtwoord te herestellen kunt u op onderstaande link klikken of deze kopieren en plakken in de adresbalk van uw browser. Op de pagina wordt u gevraagd uw nieuwe wachtwoord in te voeren en te veriefieren.<br /> \n	<br /> \n	{$DATA.reset_link}<br /> \n	<br /> \n	Wanneer u meer ondersteuning nodigt heeft, dan kunt u altijd contact met ons opnemen.</p>', 'Hi {$DATA.first_name},\n	 \n	Om uw wachtwoord te herestellen kunt u op onderstaande link klikken of deze kopieren en plakken in de adresbalk van uw browser. Op de pagina wordt u gevraagd uw nieuwe wachtwoord in te voeren en te veriefieren.\n	 \n	{$DATA.reset_link}\n	 \n	Wanneer u meer ondersteuning nodigt heeft, dan kunt u altijd contact met ons opnemen.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('67', 'admin.order_received', 'nl-NL', '\n	Nieuwe bestelling #{$DATA.cart_order_id} \n	  ', '<p>{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if} zojuist geplaatst order nummer {$DATA.cart_order_id} op {$DATA.order_date}.</p>\n	<p>Deze bestelling kan online worden beheerd door op de onderstaande link te klikken.</p> \n	<p><a href=\"{$DATA.link}\">{$DATA.link}</a></p>\n	<table width=\"100%\">\n	  <tr>\n	    <td valign=\"top\" width=\"50%\"><strong>Factuuradres:</strong><br />\n	      {$BILLING.first_name} {$BILLING.last_name}<br />\n	      {if !empty({$BILLING.company_name})}{$BILLING.company_name}<br />\n	      {/if}\n	      {$BILLING.line1}<br />\n	      {if !empty({$BILLING.line2})}{$BILLING.line2}<br />\n	      {/if}\n	      {$BILLING.town}<br />\n	      {$BILLING.state}<br />\n	      {$BILLING.postcode}<br />\n	      {$BILLING.country}<br />\n	      {$BILLING.phone}<br />\n	      <br />\n	      <strong>Email:</strong><br />\n	      {$BILLING.email}</td>\n	    <td valign=\"top\" width=\"50%\"><strong>Bezorgadres:</strong><br />\n	      {$SHIPPING.first_name} {$SHIPPING.last_name}<br />\n	      {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name} <br />\n	      {/if}{$SHIPPING.line1}<br />\n	      {if !empty({$SHIPPING.line2})}{$SHIPPING.line2} <br />\n	      {/if}{$SHIPPING.town}<br />\n	      {$SHIPPING.state}<br />\n	      {$SHIPPING.postcode}<br />\n	      {$SHIPPING.country}</td>\n	  </tr>\n	</table>\n	<table border=\"0\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\">\n	  <tbody>\n	    <tr>\n	      <td><strong>Item</strong></td>\n	      <td><strong>Hoeveelheid</strong></td>\n	      <td><strong>Kosten</strong></td>\n	    </tr>\n	  {foreach from=$PRODUCTS item=product}\n	  <tr>\n	    <td>{$product.name} <br />{$product.product_options}</td>\n	    <td>{$product.quantity}</td>\n	    <td>{$product.price}</td>\n	  </tr>\n	  {/foreach}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Verzendmethode: {if $DATA.ship_method}({$DATA.ship_method}){/if}</td>\n	    <td> {$DATA.shipping}</td>\n	  </tr>\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Korting:</td>\n	    <td> {$DATA.discount}</td>\n	  </tr>\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> Subtotaal:</td>\n	    <td> {$DATA.subtotal}</td>\n	  </tr>\n	  {foreach from=$TAXES item=tax}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td> {$tax.tax_name}: ({$tax.tax_percent}%)</td>\n	    <td> {$tax.tax_amount}</td>\n	  </tr>\n	  {/foreach}\n	  <tr>\n	    <td>&nbsp;</td>\n	    <td><strong>Bestelling Totaal: </strong></td>\n	    <td><strong>{$DATA.total}</strong></td>\n	  </tr>\n	  </tbody>\n	  \n	</table>', '{$DATA.first_name} {$DATA.last_name} {if !empty({$BILLING.company_name})}({$BILLING.company_name}){/if}  zojuist geplaatst order nummer {$DATA.cart_order_id} op {$DATA.order_date}.\n	\n	Deze bestelling kan online worden beheerd door op de onderstaande link te klikken.\n	\n	{$DATA.link}\n	\n	----------------------------------------------------------------------\n	Factuuradres:\n	  {$BILLING.first_name} {$BILLING.last_name}\n	  {if !empty({$BILLING.company_name})}{$BILLING.company_name}\n	  {/if}{$BILLING.line1}\n	  {if !empty({$BILLING.line2})}{$BILLING.line2}\n	  {/if}{$BILLING.town}\n	  {$BILLING.state}\n	  {$BILLING.postcode}\n	  {$BILLING.country}\n	  {$BILLING.phone}\n	\n	Email:\n	  {$BILLING.email}\n	\n	Bezorgadres:\n	  {$SHIPPING.first_name} {$SHIPPING.last_name}\n	  {if !empty({$SHIPPING.company_name})}{$SHIPPING.company_name}\n	  {/if}{$SHIPPING.line1}\n	  {if !empty({$SHIPPING.line2})}{$SHIPPING.line2}\n	  {/if}{$SHIPPING.town}\n	  {$SHIPPING.state}\n	  {$SHIPPING.postcode}\n	  {$SHIPPING.country}\n	\n	----------------------------------------------------------------------\n	Items in uw bestelling\n	\n	{foreach from=$PRODUCTS item=product}\n	-----------------------------------\n	{$product.name}\n	{$product.product_options}\n	\n	  Producttype Nummer: {$product.product_code}\n	  Stuk Prijs: {$product.price}\n	  Hoeveelheid: {$product.quantity}\n	\n	{/foreach}\n	-----------------------------------\n	  Subtotaal: {$DATA.subtotal}\n	  korting: {$DATA.discount}\n	  Verzending: {$DATA.shipping} {if $DATA.ship_method}({$DATA.ship_method}){/if}\n	  {foreach from=$TAXES item=tax}{$tax.tax_name} ({$tax.tax_percent}%): {$tax.tax_amount}\n	  {/foreach}\n	  --------------------------\n	  Bestelling totaal: {$DATA.total}\n	  =========================='); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('68', 'admin.review_added', 'nl-NL', '\n	Nieuwe product beoordeling \n	  ', '{$DATA.name} heeft een nieuwe beoordeling/reactie geplaatst over \'{$DATA.product_name}\'. Deze kan met de onderstande link worden beheerd.\n	<p><strong>Beheer Link:</strong><br /><a href=\'{$DATA.link}\'>{$DATA.link}</a></p> \n	<p><strong>Beoordeling Tekst:</strong><br />{$DATA.review}</p>', '{$DATA.name} heeft een nieuwe beoordeling/reactie geplaatst over \'{$DATA.product_name}\'. Deze kan met de onderstande link worden beheerd.\n	 \n	Beheer Link: \n	{$DATA.link}\n	Beoordeling Tekst:\n	{$DATA.review}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('69', 'cart.digital_download', 'nl-NL', '\n	 Uw Gekochte Downloads \n	  ', '<p>Hallo {$DATA.first_name},</p> \n	<p>Uw digitale bestanden zijn klaar om gedownload te worden. Om toegang tot ze te krijgen kunt u de onderstaande links gebruiken:</p> \n	{foreach from=$DOWNLOADS item=download} \n	<p><strong>{$download.name}:</strong> (Link vervalt op {$download.expire}<strong>)</strong><br /> \n	{$download.url}</p> \n	{/foreach}\n	<p>Wanneer bovenstaande links niet werken, kunt ut proberen ze te kopieren en te plakken in de adresbalk van uw browser. U kunt ook toegang tot deze bestanden krijgen via de klanten sectie van onze website.</p> \n	<p>&nbsp;</p>', 'Hallo {$DATA.first_name},\n	 \n	Uw digitale bestanden zijn klaar om gedownload te worden. Om toegang tot ze te krijgen kunt u de onderstaande links gebruiken:\n	 \n	{foreach from=$DOWNLOADS item=download} \n	{$download.name}: (Link expires on {$download.expire})\n	{$download.url}\n	{/foreach}\n	 \n	Wanneer bovenstaande links niet werken, kunt ut proberen ze te kopieren en te plakken in de adresbalk van uw browser. U kunt ook toegang tot deze bestanden krijgen via de klanten sectie van onze website.'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('70', 'cart.gift_certificate', 'nl-NL', '\n	Uw Cadeaubon \n	  ', '<p>Beste {$DATA.name},</p> \n	<p>Wij zijn verheugd dat wij u deze cadeaubon toe mogen sturen, welke u kan gebruiken voor ieder gewenst product op de website.</p> \n	<p>Veel Winkel Plezier!</p> \n	<p><strong>Van: </strong>{$DATA.first_name} {$DATA.last_name}<br /> \n	<strong>Waarde: </strong>{$DATA.value}<br /> \n	<strong>Claim Code:</strong> {$DATA.code}<br /> \n	<strong>Bericht bij Cadeau:</strong> {$DATA.message}</p> \n	<p>-------------------</p> \n	<p>Om uw cadeaubon in te gebruiken voer a.u.b de &quot;Cadeaubon Code&quot; boven in het tekstveld genaamd &quot;Voeg Cadeaubon of Coupon toe&quot; tijdens het afrekenen.</p> \n	<p>Waarom zou u het nu niet uitgeven?</p>', 'Beste {$DATA.name},\n	 \n	Wij zijn verheugd dat wij u deze cadeaubon toe mogen sturen, welke u kan gebruiken voor ieder gewenst product op de website.\n	 \n	Veel Winkel Plezier!\n	 \n	From: {$DATA.first_name} {$DATA.last_name}\n	Amount: {$DATA.value}\n	Claim Code: {$DATA.code}\n	Gift Message: {$DATA.message}\n	 \n	-------------------\n	 \n	Om uw cadeaubon in te gebruiken voer a.u.b de &quot;Cadeaubon Code&quot; boven in het tekstveld genaamd &quot;Voeg Cadeaubon of Coupon toe&quot; tijdens het afrekenen.</p>\n	 \n	Waarom zou u het nu niet uitgeven?'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('71', 'catalogue.tell_friend', 'nl-NL', '\n	{$DATA.from} heeft iets aangeraden \n	  ', 'Beste {$DATA.to},\n	<p>Uw vriend <strong>{$DATA.from}</strong> dacht dat u misschien geintreseerd zou zijn in <strong>{$DATA.name}</strong>.</p> \n	<p><strong>Product Link:</strong> <a href=\"{$DATA.link}\">{$DATA.name}</a></p> \n	<p>{$DATA.message}</p>', 'Beste {$DATA.to},\n	 \n	Uw vriend {$DATA.from} dacht dat u misschien geintreseerd zou zijn in \'{$DATA.name}\'.\n	 \n	{$DATA.name}\n	Product Link: {$DATA.link}\n	 \n	{$DATA.message}'); #EOQ
INSERT INTO `cc4_CubeCart_email_content` VALUES('72', 'cart.payment_received', 'nl-NL', '\n	 Bedankt voor uw betaling \n	  ', '<p>Hallo {$DATA.first_name},</p> \n	<p>Bedankt. We hebben een betaling van {$DATA.total} ontvangen voor bestelnummer {$DATA.cart_order_id}.</p>', 'Hallo {$DATA.first_name},\n	 \n	We hebben een betaling van {$DATA.total} ontvangen voor bestelnummer {$DATA.cart_order_id}.'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_email_template`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_email_template`
--

CREATE TABLE `cc4_CubeCart_email_template` (
  `template_id` int(10) unsigned NOT NULL auto_increment,
  `template_default` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `content_html` text collate utf8_unicode_ci NOT NULL,
  `content_text` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_email_template`
--

INSERT INTO `cc4_CubeCart_email_template` VALUES('1', '1', 'Default Emails', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n<style type=\"text/css\">\r\nhtml, body, table {\r\n	font-family: Arial;\r\n	font-size: 14px;\r\n}\r\n</style>\r\n<title>Default HTML Template</title>\r\n</head>\r\n<body bgcolor=\"#f7f7f7\">\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n  <tbody>\r\n    <tr>\r\n      <td align=\"center\"><table bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"15\" cellspacing=\"0\" width=\"580\">\r\n          <tbody>\r\n            <tr>\r\n              <td><a href=\"{$DATA.storeURL}\"><img alt=\"{$DATA.storeName}\" border=\"0\" src=\"{$DATA.logoURL}\" /></a></td>\r\n            </tr>\r\n            <tr>\r\n              <td> {$EMAIL_CONTENT}</td>\r\n            </tr>\r\n            <tr>\r\n              <td><p> Kind regards,</p>\r\n                <p> The {$DATA.storeName} Staff<br />\r\n                  <a href=\"{$DATA.storeURL}\">{$DATA.storeURL}</a></p></td>\r\n            </tr>\r\n          </tbody>\r\n        </table></td>\r\n    </tr>\r\n  </tbody>\r\n</table>\r\n</body>\r\n</html>', '{$EMAIL_CONTENT}\r\n\r\nKind regards,\r\n\r\nThe {$DATA.storeName} Staff\r\n{$DATA.storeURL}'); #EOQ
INSERT INTO `cc4_CubeCart_email_template` VALUES('2', '0', 'Default Newsletter', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<html>\r\n<head>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n<style type=\"text/css\">\r\nhtml, body, table {\r\n	font-family: Arial;\r\n	font-size: 14px;\r\n}\r\n</style>\r\n<title>Default HTML Newsletter Template</title>\r\n</head>\r\n<body bgcolor=\"#f7f7f7\">\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n  <tbody>\r\n    <tr>\r\n      <td align=\"center\"><table bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"15\" cellspacing=\"0\" width=\"580\">\r\n          <tbody>\r\n            <tr>\r\n              <td><a href=\"{$DATA.storeURL}\"><img src=\"{$DATA.logoURL}\" alt=\"{$DATA.storeName}\" border=\"0\" /></a></td>\r\n            </tr>\r\n            <tr>\r\n              <td>{$EMAIL_CONTENT}</td>\r\n            </tr>\r\n            <tr>\r\n              <td><p>Kind regards,</p>\r\n                <p>The {$DATA.storeName} Staff<br />\r\n                  <a href=\"{$DATA.storeURL}\">{$DATA.storeURL}</a></p>\r\n                <hr size=\"1\" />\r\n                <p><font size=\"2\">To unsubscribe please follow the link below:<br />\r\n                  <a href=\"{$DATA.unsubscribeURL}\">{$DATA.unsubscribeURL}</a></font></p></td>\r\n            </tr>\r\n          </tbody>\r\n        </table></td>\r\n    </tr>\r\n  </tbody>\r\n</table>\r\n</body>\r\n</html>', '{$EMAIL_CONTENT}\r\n\r\nKind regards,\r\n\r\nThe {$DATA.storeName} Staff\r\n{$DATA.storeURL}\r\n\r\n-------------------\r\n\r\nTo unsubscribe please follow the link below:\r\n{$DATA.unsubscribeURL}'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_ems_quantity_discounts`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_ems_quantity_discounts`
--

CREATE TABLE `cc4_CubeCart_ems_quantity_discounts` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `quantity_prices` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_ems_quantity_discounts` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_filemanager`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_filemanager`
--

CREATE TABLE `cc4_CubeCart_filemanager` (
  `file_id` int(10) unsigned NOT NULL auto_increment,
  `type` int(1) NOT NULL default '1',
  `disabled` int(1) NOT NULL default '0',
  `filepath` varchar(255) collate utf8_unicode_ci default NULL,
  `filename` varchar(255) collate utf8_unicode_ci NOT NULL,
  `filesize` int(11) NOT NULL,
  `mimetype` varchar(50) collate utf8_unicode_ci NOT NULL,
  `md5hash` varchar(32) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=373 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_filemanager`
--

INSERT INTO `cc4_CubeCart_filemanager` VALUES('1', '1', '0', 'Headers/', 'default-event.gif', '4321', 'image/gif', '8d38753118eba7ffc3d2a3e0439a38ad', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('2', '1', '0', 'Headers/', 'header.jpg', '62355', 'image/jpeg', '8dc4fac5a8e816c38f045f71fb90f79f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('3', '1', '0', 'Headers/', 'header_promo1.jpg', '73721', 'image/jpeg', '207ba335c89662f0ea42c41db978df78', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('4', '1', '0', 'Headers/', 'header_promo2.jpg', '73748', 'image/jpeg', 'd0405f9ae2406959407284221cd5f359', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('5', '1', '0', 'Headers/', 'header_promo3.jpg', '80304', 'image/jpeg', '5a272cce89de3bec94df73313b4ee3c8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('6', '1', '0', 'Headers/', 'header_promo4.jpg', '71333', 'image/jpeg', '71799fc8f6908a53b27a92a58f73dbfe', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('7', '1', '0', 'Headers/', 'header_promo5.jpg', '68415', 'image/jpeg', '5ac0c40fa642fc16795e56f36470246e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('8', '1', '0', 'Headers/', 'header_promo6.jpg', '81188', 'image/jpeg', 'dbc5b39e439805c37a2a23f5157d7227', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('9', '1', '0', 'Headers/', 'header_promo7.jpg', '69382', 'image/jpeg', '008f5d61819718f24aedcd3de6d4d469', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('10', '1', '0', 'Headers/', 'header_promo8.jpg', '83499', 'image/jpeg', 'a4b7bd9b5a8556ec65bd9602a6caad07', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('11', '1', '0', 'Headers/', 'header_promo9.jpg', '72442', 'image/jpeg', 'ba187074cf031745a312434bdc7fe791', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('12', '1', '0', 'Headers/', 'ISTD_event.gif', '49', 'image/gif', '627d039a18c4604e4bd0668b77cecc7f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('13', '1', '0', 'Headers/', 'writereview.jpg', '37507', 'image/jpeg', '3f60cc3b7486262caaaf9f53e18e66a6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('19', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/selector100x100/', '714b6d5035db085b42ce458d6fcdc0d5.jpg', '25889', 'image/jpeg', 'd3c32c3b7bd42456f5298e3aa5226117', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('20', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/selector100x100/', 'aa9fff913ffbd94917b8442bdd628465.jpg', '29645', 'image/jpeg', 'e277fbd3475bd6839432eed3a47d5094', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('21', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/selector100x100/', 'e0e1405e3dbdbfa40bc0b22bbfd5e012.jpg', '27558', 'image/jpeg', '07ee02f00ca1738968d3d3a38ac703a1', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('22', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/thumb200x200/', '714b6d5035db085b42ce458d6fcdc0d5.jpg', '41419', 'image/jpeg', '4a497d35337a4577f9dc8ceb39e09c3d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('23', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/thumb200x200/', 'aa9fff913ffbd94917b8442bdd628465.jpg', '48042', 'image/jpeg', 'ddc63fbec0c1f6c667094fa553faf01c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('24', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/1/7/17/thumb200x200/', 'e0e1405e3dbdbfa40bc0b22bbfd5e012.jpg', '44303', 'image/jpeg', '667c661ca3b4ecff3f53a5fd852c25de', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('52', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/2/6/26/thumb200x200/', '3d9a0aa7a36073d34490b24f404c2422.jpg', '51335', 'image/jpeg', '54effdfcce5cf1dda9c3966a20569a86', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('58', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/2/thumb200x200/', 'bcc1e7191930330e3fdf8462aa439097.jpg', '38874', 'image/jpeg', 'ad70fb6eb4f7953fda4e02832dbf153c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('59', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/3/1/31/thumb200x200/', 'f80e7f641505301309818a2a4ef5f9ba.jpg', '32533', 'image/jpeg', '3ea983eb21223c7d6a5698164093318a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('63', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/3/8/38/thumb200x200/', 'a52f7d51042cc789470f6b20ff348ada.jpg', '37376', 'image/jpeg', '007cc85ab59f5e5a4c2c1e6cb8d2ae73', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('65', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/3/thumb200x200/', 'c8a027fd911c7ed5959b7dc83a6d7f11.jpg', '39147', 'image/jpeg', '91b70d9f37aabe7117f6f2298149ccc0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('72', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/4/thumb200x200/', '772f04caf7a37069af817953ee7bcb1e.jpg', '21303', 'image/jpeg', '1d792d84dad7090cd1857ccd00844f75', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('107', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '0be71242d6ddf14f819fff265b627944.jpg', '18918', 'image/jpeg', '8792ac61ebe1e1fba85e5b2126d86103', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('108', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '1eba873004458d9f17225246ac867244.jpg', '15460', 'image/jpeg', '3c94535510b3d345fb16fb75bf8778e6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('109', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '3d9a0aa7a36073d34490b24f404c2422.jpg', '31587', 'image/jpeg', 'd1d348c95e046544dfd00c2bd03ddf69', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('110', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '5b65b4ce623d949b234e6d80593660af.jpg', '21762', 'image/jpeg', '277fd8a8df042a3640ecb4686c1ceb37', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('111', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '59d881f2532a70a29ba0095a05f21b98.jpg', '29630', 'image/jpeg', '0e9ace8b11cfbfbedc646bb827791adb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('112', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', '143e0997fe78e4336994132f33ed32dc.jpg', '23703', 'image/jpeg', 'a0d4fb9da7fed71097e6715cb5df0291', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('113', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', 'b22f71afb661d463ba1d8cf9c3964081.jpg', '26009', 'image/jpeg', '3fa9c84ddc485dae32126c56c476bb2a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('114', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', 'c59f842ddaec372b5b1942680b22ca34.jpg', '25584', 'image/jpeg', '67ed8e696d15675c4df4dea3d696b8b4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('115', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/selector100x100/', 'e6713bf2c81133317699723a2d696418.jpg', '31179', 'image/jpeg', '6ba4ee74fc1ee36f4206827e5a6accad', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('116', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '0be71242d6ddf14f819fff265b627944.jpg', '34515', 'image/jpeg', '08aa0aef12b6b8b1bec68c3593976200', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('117', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '1eba873004458d9f17225246ac867244.jpg', '28629', 'image/jpeg', '9328006c0f1d2508f1ff24947fcfe371', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('118', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '3d9a0aa7a36073d34490b24f404c2422.jpg', '51335', 'image/jpeg', '54effdfcce5cf1dda9c3966a20569a86', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('119', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '5b65b4ce623d949b234e6d80593660af.jpg', '40594', 'image/jpeg', '33dc5e58c991ea3c13a07c4540053654', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('120', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '59d881f2532a70a29ba0095a05f21b98.jpg', '48104', 'image/jpeg', '8d8aced52b36f8c32f9a852d1392c710', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('121', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', '143e0997fe78e4336994132f33ed32dc.jpg', '45093', 'image/jpeg', 'bff56260a7405a91853e54f8b5a9ec0a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('122', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', 'b22f71afb661d463ba1d8cf9c3964081.jpg', '41336', 'image/jpeg', '168d6a48e8c364356099d78db6c41bf8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('123', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', 'c59f842ddaec372b5b1942680b22ca34.jpg', '39838', 'image/jpeg', 'cf62c89d215417547f494793d0d7d988', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('124', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/4/54/thumb200x200/', 'e6713bf2c81133317699723a2d696418.jpg', '53089', 'image/jpeg', '0e272d043ccf5279e6f7fc700977d3d4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('125', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', '3ce404cadc5ac235782be66078d53f7e.jpg', '15775', 'image/jpeg', '30d5a103525a726263be314ed5e2824e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('126', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', '568fc43409c81d55f91bbdbbce754343.jpg', '31294', 'image/jpeg', '1b7a0f8b8fd97c52c03904a54d0aa089', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('127', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', '9954bf6d03534f7b1c8da6f24497ff2a.jpg', '14480', 'image/jpeg', '2f46db7c3eeeca593a697cb27da278c5', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('128', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', '9631420681a8f828718adac17fdd7099.jpg', '16621', 'image/jpeg', '19a70ac9a6bf245d72330151139c69f0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('129', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', 'a48d7afa443c89a97d4d8d3986d38bf0.jpg', '30095', 'image/jpeg', 'a6463bba59e061a5050f5796cd17477b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('130', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/selector100x100/', 'ca03ecbf2f6e1e2a882f9300b61f56f9.jpg', '16633', 'image/jpeg', 'd81ce211837efe2fdf0ca03f3bf20416', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('131', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', '3ce404cadc5ac235782be66078d53f7e.jpg', '30021', 'image/jpeg', '33db79cd03d696f3533155d341af2194', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('132', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', '568fc43409c81d55f91bbdbbce754343.jpg', '61534', 'image/jpeg', '27f20a27b08bba30f61ad89ce1a53a5c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('133', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', '9954bf6d03534f7b1c8da6f24497ff2a.jpg', '27157', 'image/jpeg', '76e159a4e49eedac716f5efc75f2d781', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('134', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', '9631420681a8f828718adac17fdd7099.jpg', '30951', 'image/jpeg', '2318325ff64401e496e2bc7cbb77e3eb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('135', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', 'a48d7afa443c89a97d4d8d3986d38bf0.jpg', '58749', 'image/jpeg', '7631b72d8ec4272325743f4eadcf70f7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('136', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/5/55/thumb200x200/', 'ca03ecbf2f6e1e2a882f9300b61f56f9.jpg', '31772', 'image/jpeg', '5bbad066a80b66f82b9393d20ec9b23b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('144', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/5/thumb200x200/', 'cbfde4f48a9d90b2e8abd754134c3f87.jpg', '40149', 'image/jpeg', '0cd3dd87458efba71087e04f3d0c2ed5', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('152', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/6/thumb200x200/', '69ecb21cb45bc01556adc12774022bd5.jpg', '45079', 'image/jpeg', '66cd4c17f9f4aa674a4c0fa99b3e1be0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('153', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/7/thumb200x200/', 'ea4a523cd6301ae493130ca290f3945e.jpg', '34190', 'image/jpeg', 'd6247477b4b0c9e3d69d279c24361630', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('154', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/8/thumb200x200/', 'b1d7f32083ea17a5c9b6305e12780bd6.jpg', '33379', 'image/jpeg', '2b35ea8b827f580a3c7d00460e7c5cde', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('155', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/9/thumb200x200/', 'cca1b9a769d462458b6f77f6d323c8f1.jpg', '42633', 'image/jpeg', 'a43772621887b1cdadd7d74399cb8f57', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('156', '1', '0', 'Rhinestones/4mm/', 'pink.jpg', '245005', 'image/jpeg', '8dabaea1d68cf217c47fb31f3de00d9e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('157', '1', '0', 'Rhinestones/4mm/', 'pink_ab.jpg', '140022', 'image/jpeg', '853feb4b8341c866a0eeb4d5fce50b8a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('158', '1', '0', 'Rhinestones/5mm/', '5mm_Aqua_Blue.jpg', '224947', 'image/jpeg', '82107fccafeab912240e1ab2580465ef', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('159', '1', '0', 'Rhinestones/5mm/', '5mm_Hot_Pink.jpg', '244265', 'image/jpeg', '26a1837ea6fc4c5d3e591e2984ff4536', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('160', '1', '0', 'Rhinestones/5mm/', '5mm_Mint_Green.jpg', '25890', 'image/jpeg', '5d7262d4df93286ccc8b994f29c5ad43', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('161', '1', '0', 'Rhinestones/5mm/', 'ss20_silver_topaz.jpg', '193923', 'image/jpeg', 'f74f1cd82c92d3cab3acf575f268cc47', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('162', '1', '0', 'Rhinestones/DMC/', 'DMC.gif', '6902', 'image/gif', '3e0f5185504c68e0a3b1cc9e30075dac', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('163', '1', '0', 'Rhinestones/DMC/SS6/', 'ss6_black.jpg', '242157', 'image/jpeg', '40ab02a77e843e81c527f871448b973e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('164', '1', '0', 'Rhinestones/DMC/SS6/', 'ss6_fushcia.jpg', '344779', 'image/jpeg', '5cc69ce8cd72de2f9217d5731cc68a2f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('165', '1', '0', 'Rhinestones/DMC/SS20/', 'ss20_AB.jpg', '304764', 'image/jpeg', '3b22d1d14abbb4bfa45ee8799b37bc85', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('166', '1', '0', 'Rhinestones/DMC/SS20/', 'ss20_crystal.jpg', '303151', 'image/jpeg', '5666e6812574a40d3b326dbf11ff8f27', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('167', '1', '0', 'Rhinestones/DMC/SS20/', 'ss20_siam_ruby.jpg', '379255', 'image/jpeg', '21296bf69927c106bff3d846b8ff4821', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('168', '1', '0', 'Rhinestones/DMC/SS20/', 'ss20_siam_ruby_1.jpg', '230142', 'image/jpeg', 'cb27534849c940ef2f81ede4fee6fb80', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('169', '1', '0', '_images/', 'ballet1Plate.jpg', '41848', 'image/jpeg', 'dba5df7aa75204b0a6d61e0ef8545df4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('170', '1', '0', '_images/', 'header6.jpg', '112859', 'image/jpeg', '3e6875cd74341098b85230a26c3f34bb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('171', '1', '0', '_images/', 'PnP_Dance-1.jpg', '435793', 'image/jpeg', '1b0abb8f8cbafcad5d7ec790f2475cab', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('172', '1', '0', '_images/ProductImages/2nd_Hand/', 'green_frills.jpeg', '62620', 'image/jpeg', '10b1aac52262b0ce9e60e2c5c25df53a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('173', '1', '0', '_images/ProductImages/2nd_Hand/', 'green_frills_back.jpeg', '171505', 'image/jpeg', 'b9c98e03a7a4b40ac46f7d8260306135', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('174', '1', '0', '_images/ProductImages/2nd_Hand/', 'rocknroll.jpeg', '198604', 'image/jpeg', '4e276bf2b9978e7d49d804856599f0c8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('175', '1', '0', '_images/ProductImages/', '4mmOrangeAB.jpg', '32013', 'image/jpeg', '827589ee7eddb866a606354cfbffc011', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('176', '1', '0', '_images/ProductImages/', '4mm_aqua_blue.jpg', '765197', 'image/jpeg', '80793a6827e07763cc49cc625abbcd1b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('177', '1', '0', '_images/ProductImages/', '4mm_crystal.jpg', '512288', 'image/jpeg', '71d62e9b5e251e93bd61a895a1e4e929', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('178', '1', '0', '_images/ProductImages/', '4mm_crystal_AB.jpg', '445516', 'image/jpeg', '46dba4dd4e6a93612465af5406ff0f41', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('179', '1', '0', '_images/ProductImages/', '4mm_crystal_AB_hotfix.jpg', '494224', 'image/jpeg', '77dfa25ecc2aac8d86c4b9d6af6ab6e8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('180', '1', '0', '_images/ProductImages/', '4mm_crystal_hotfix.jpg', '317313', 'image/jpeg', '17eae8900e74b715edd4af35497a8aad', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('181', '1', '0', '_images/ProductImages/', '4mm_Emerald_hotfix.jpg', '490576', 'image/jpeg', '5b5044127398e4097363aa49f9037295', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('182', '1', '0', '_images/ProductImages/', '4mm_lemon_AB.jpg', '557788', 'image/jpeg', '036eb41ee7e2ffb6392425ef3bea930f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('183', '1', '0', '_images/ProductImages/', '4mm_mint_AB.jpg', '402613', 'image/jpeg', 'b61c2e89e971f35972f22f6fa4c870cd', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('184', '1', '0', '_images/ProductImages/', '4mm_pink.jpg', '394470', 'image/jpeg', 'c0177a47678acea8a7a5cb0ff74a98e9', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('185', '1', '0', '_images/ProductImages/', '4mm_pink_AB.jpg', '366416', 'image/jpeg', 'bec12a713059cd2c496a8e0fa205f3ca', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('186', '1', '0', '_images/ProductImages/', '4mm_purple_AB.jpg', '489323', 'image/jpeg', 'c0948f5c0db9f1e08260e931d08fe6ce', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('187', '1', '0', '_images/ProductImages/', '4mm_sapphire_hotfix.jpg', '455638', 'image/jpeg', 'c424b3f320b704e3a0b86d3a551fd4e2', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('188', '1', '0', '_images/ProductImages/', '4mm_siam_ruby_hotfix.jpg', '558891', 'image/jpeg', '0834652f986d097fca564812d25fa823', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('189', '1', '0', '_images/ProductImages/Brand_New_PnP/', 'PnP_Dance-1.jpg', '435793', 'image/jpeg', '1b0abb8f8cbafcad5d7ec790f2475cab', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('190', '1', '0', '_images/ProductImages/Brand_New_PnP/', 'PnP_Dance-2.jpg', '388694', 'image/jpeg', '1f3587641f9e342240fca1dbfb23416e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('191', '1', '0', '_images/ProductImages/Brand_New_PnP/', 'PnP_Dance-3.jpg', '430808', 'image/jpeg', 'ecb3782e37f4a897d100e118eef63ddb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('192', '1', '0', '_images/ProductImages/Comp_Pins/', 'aqua_blue.jpg', '22600', 'image/jpeg', '8956476a43c5e2dcb78a5bf57961d5ab', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('193', '1', '0', '_images/ProductImages/Comp_Pins/', 'crystal.jpg', '26526', 'image/jpeg', 'f8fd5d26c23287bcd7b097f5309303b0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('194', '1', '0', '_images/ProductImages/Comp_Pins/', 'Crystal_AB.jpg', '19127', 'image/jpeg', 'e349f27dcf3dce0babc5fe41b24bdc0b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('195', '1', '0', '_images/ProductImages/Comp_Pins/', 'Dance_Comp_Pins.jpg', '271146', 'image/jpeg', '0be7afc9239e678469b6c11a34d503c5', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('196', '1', '0', '_images/ProductImages/Comp_Pins/', 'hot_pink.jpg', '21559', 'image/jpeg', '6dae46535f6225a7e758d77e96378157', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('197', '1', '0', '_images/ProductImages/Comp_Pins/', 'mint_green.jpg', '26622', 'image/jpeg', '57bb4b9307e8ac63b3b035e08ca3ea63', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('198', '1', '0', '_images/ProductImages/Comp_Pins/', 'orange.jpg', '21113', 'image/jpeg', '634ab26f0b46540c7c06308bc42fda5b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('199', '1', '0', '_images/ProductImages/Comp_Pins/', 'pink.jpg', '19891', 'image/jpeg', 'af136812bbd700b9571579f90b85d4ef', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('200', '1', '0', '_images/ProductImages/Comp_Pins/', 'ruby.jpg', '20987', 'image/jpeg', '7b8d03909686ab54aced541a11ae851c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('201', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'ComingSoon-1.jpg', '147308', 'image/jpeg', '577f5eb05ec10d288b8fac7e7b0655a0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('202', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'ComingSoon-2.jpg', '100253', 'image/jpeg', '5d7aaff7b8d95f5f8c8eb8ee24158f54', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('203', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'ComingSoon-3.jpg', '87511', 'image/jpeg', '31af45b6673c48efbbce704655b811ff', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('204', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'ComingSoon-4.jpg', '196025', 'image/jpeg', '24dd15d8c44f58691a00e71e4151a132', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('205', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'ComingSoon-5.jpg', '91171', 'image/jpeg', '1c7018e5bc0cc917b7890930607051d6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('206', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-11.jpg', '383852', 'image/jpeg', '532bda081fabe4a020c9193ddc3bea6f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('207', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-12.jpg', '548034', 'image/jpeg', '9d55c584d9fe9dd1bc71bdfcbe96bbc6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('208', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-13.jpg', '305238', 'image/jpeg', '64072d88e6095cc182623e2946cfe644', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('209', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-14.jpg', '294963', 'image/jpeg', '02debf7e594f78e334ca4b1e76e67d96', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('210', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-15.jpg', '214488', 'image/jpeg', '2f9c2356eb89d436fb5c4ab0f4f9aa29', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('211', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-16.jpg', '338481', 'image/jpeg', 'cacdff93df13c11faa8a4c0ba5a417e7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('212', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-17.jpg', '343856', 'image/jpeg', '5ad3b18a5e52282e10079600f03a9f22', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('213', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-18.jpg', '279354', 'image/jpeg', '51b179f217e3c4308487bbca0da603ae', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('214', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-19.jpg', '333245', 'image/jpeg', 'b53679921d949ebf27d5dbf2fbdb9772', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('215', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-20.jpg', '316486', 'image/jpeg', '767a346c04da2aaea96ec8c7ed646315', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('216', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-21.jpg', '458003', 'image/jpeg', 'e2bafec97dea33a124ef9e3cc2ff40ec', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('217', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-22.jpg', '349402', 'image/jpeg', '450404e8764f0e51d2c0043e029aa6ae', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('218', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-23.jpg', '449794', 'image/jpeg', 'b7c5a0ddf065debbb246c9a4937008b0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('219', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-24.jpg', '238147', 'image/jpeg', 'ed4f0a208f57864278684109e40830fc', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('220', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-25.jpg', '261807', 'image/jpeg', '332425a3089a2cba4b035b3dcdb59bd2', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('221', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-26.jpg', '637439', 'image/jpeg', 'b02791c0a943ad2b839475cc8c2347d3', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('222', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-27.jpg', '570659', 'image/jpeg', '57a27ebbe446b64704f1729141ed7c57', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('223', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-28.jpg', '482084', 'image/jpeg', '5bb7ce831f16452a2940346b71d01727', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('224', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'Dancewear-29.jpg', '457687', 'image/jpeg', 'c0ea661e307b39282b578d5b1c65e24c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('225', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'DanceWear-30.jpg', '386773', 'image/jpeg', '4b2c51a08c5df473a4a4f7fdd4adb69f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('226', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'DanceWear-31.jpg', '398714', 'image/jpeg', '8d4e3f15c2911da73a2f90c5fdc0a3d9', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('227', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'DanceWear-32.jpg', '268215', 'image/jpeg', 'd70fd11d45121ebbd0de29f13f0ccd8a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('228', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-1.jpg', '348766', 'image/jpeg', '72a32dc9dbe9b51f6c9722a0d290a910', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('229', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-2.jpg', '384693', 'image/jpeg', '251ab71fa67a20c6ed8d4cb21e112df1', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('230', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-3.jpg', '345536', 'image/jpeg', '1ddc518ff74740fb29f049491cac2b8e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('231', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-4.jpg', '275779', 'image/jpeg', '546147f53dea35969256bed07176bed3', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('232', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-5.jpg', '376450', 'image/jpeg', '8a259ffac6daa2c18bb07e73e4b12483', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('233', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-6.jpg', '322185', 'image/jpeg', 'a2dda531141c0db18b358e33a244c827', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('234', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-7.jpg', '109869', 'image/jpeg', '86f76ccfeb78b819e75baa581af15f0c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('235', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-8.jpg', '369847', 'image/jpeg', '77aaaa247264e3caec6e0db87aa5b2cf', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('236', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-9.jpg', '264288', 'image/jpeg', '45c8c1ffe2238ade6847ba13a0f2cb62', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('237', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-10.jpg', '163000', 'image/jpeg', '894696b1a8130da7d8d0e00968270e47', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('238', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-11.jpg', '109587', 'image/jpeg', 'f1433386dff729c5bbe7d2218bdda4f9', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('239', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-12.jpg', '206957', 'image/jpeg', 'e80edbf1cd89bcb3fac49f7146e3230a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('240', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-15.jpg', '277584', 'image/jpeg', '5c0b977e28fa3eb829b0f143e71eef51', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('241', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-16.jpg', '290560', 'image/jpeg', 'a836bed654da5569554cdb9c937700fc', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('242', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-17.jpg', '278260', 'image/jpeg', '7c18e8d563ede50a6e9f44ddd08c4919', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('243', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-18.jpg', '287374', 'image/jpeg', '388b9d261e8ed9edf18cfa128dfb2a85', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('244', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-19.jpg', '140220', 'image/jpeg', '002e66758017d840e31300bb75b97b48', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('245', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-20.jpg', '155570', 'image/jpeg', '745266f941bf3b16e7ce34ccd8fc79f2', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('246', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-21.jpg', '189775', 'image/jpeg', '86257769001cc22686c8225d185ec73d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('247', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-22.jpg', '136536', 'image/jpeg', '43d4476a6b2335f85300bc1fbd94ec28', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('248', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-23.jpg', '130257', 'image/jpeg', 'f2071cdf3afe1723ed268899da03f196', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('249', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-24.jpg', '9972', '', '2d5791f988e8e45a6a84d86c1d9048c4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('250', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-25.jpg', '147473', 'image/jpeg', '5aead808f14a301c75564294bcf8d03f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('251', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-26.jpg', '159235', 'image/jpeg', '7922bdfbb58e3c04736904721cd0478c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('252', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-27.jpg', '177660', 'image/jpeg', 'a5678291bd5915c1295b526d9ff9be36', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('253', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-28.jpg', '135532', 'image/jpeg', '8c314222285e7ddb13c36785ee97cbe7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('254', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-29.jpg', '156641', 'image/jpeg', '339121352451300094f7b766229b43c7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('255', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-30.jpg', '188351', 'image/jpeg', '2a8d4c103c1b07acc191567abd432288', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('256', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-31.jpg', '130439', 'image/jpeg', '5a07aeb26fab2f2b6d0161acc6e487e7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('257', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-32.jpg', '162720', 'image/jpeg', '14c83d17793243697cb96a5305cc24aa', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('258', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-33.jpg', '228735', 'image/jpeg', 'af138d46071334c54a158b8cbfebde5d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('259', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-34.jpg', '179570', 'image/jpeg', 'b3488a5104c40d3d5ac9ef9c943742e8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('260', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-35.jpg', '157254', 'image/jpeg', '8369d558479b3eb46a6a27130ce3be7a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('261', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-36.jpg', '308862', 'image/jpeg', '27e3144dc08e7e0cdb23cab5ed1ea233', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('262', '1', '0', '_images/ProductImages/Lycra/DanceWear/', 'pnpLycra-37.jpg', '210963', 'image/jpeg', '447eb4ff8758d2ad181078f6e3fc5294', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('263', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'AquaBlueMF5014.jpg', '8902', 'image/jpeg', 'e7f1b715443cb9f7e716437d83557277', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('264', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'Aqua_Matt_-_MF5016.jpg', '9692', 'image/jpeg', '398094e23052a3c089a2a465b73074d4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('265', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'BlackMF5001.jpg', '10439', 'image/jpeg', '24e9f55ee0f8981158f49446e40103e0', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('266', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'Black_white_grey_animal.jpg', '24723', 'image/jpeg', 'ad0ac74698dba6218104186fdd2cf651', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('267', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'blue_bubbles.jpg', '31862', 'image/jpeg', 'd47c70637efad63a2375a071441351d9', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('268', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'BlueStripes.jpg', '24576', 'image/jpeg', '6ae116d9d0466ca8e4206b9d46a4ecf6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('269', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'GreenMF5020.jpg', '16393', 'image/jpeg', 'e9f4bc5817943f6c6eb889771e9d927d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('270', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'Leopard.jpg', '27172', 'image/jpeg', '120da66e3820b73a62faf201b402fb6f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('271', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'PinkMF5032.jpg', '8143', 'image/jpeg', '48e98bc2783c550a9ec93f72ad30a941', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('272', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'PurpleLeopard.jpg', '29799', 'image/jpeg', '9ff34077f51977c501d2eb6a720a2b73', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('273', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'Red_Matt_-_MF5035.jpg', '9365', 'image/jpeg', '1faeba8f1a14dde32d8712981f60d642', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('274', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'RedMF5036.jpg', '7600', 'image/jpeg', '91f11774480d2f461b2449a903acc72a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('275', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'WhiteMF5002.jpg', '16843', 'image/jpeg', 'd588051cbfecbc2b2ad50e677416e0ef', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('276', '1', '0', '_images/ProductImages/Lycra/Swatches/', 'YellowMF5022.jpg', '9344', 'image/jpeg', '87147847ca4c7ef785a75a54bbbf1437', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('289', '1', '0', '_images/', 'rhinestone-size-chart.jpg', '18386', 'image/jpeg', '514a2a9d8bcde8231e87b207e57b9a17', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('290', '1', '0', '_images/', 'Rhinestones.jpg', '42505', 'image/jpeg', 'fc141af115ca2f8f6bb7a56e029ba45e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('291', '1', '0', '_images/SecondHand/', 'BlueSilver-1.jpg', '70051', 'image/jpeg', '3f2a353fb661665047076775d8d34872', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('292', '1', '0', '_images/SecondHand/', 'BlueSilver-2.jpg', '61258', 'image/jpeg', '5d65be124cfe3f9618a85393ec5bdc57', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('293', '1', '0', '_images/SecondHand/', 'BlueSwirl-1.jpg', '72644', 'image/jpeg', '9cd20d2c341890f50f23beea00c2fbdb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('294', '1', '0', '_images/SecondHand/', 'BlueSwirl-2.jpg', '63150', 'image/jpeg', '35d5b5cb5e7dd122fdc23f5d69468f6d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('295', '1', '0', '_images/SecondHand/', 'ComingSoon-4.jpg', '12624', 'image/jpeg', '7dfdf95539105f17b794b254e88b3653', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('296', '1', '0', '_images/SecondHand/', 'PinkSlow_1.jpg', '64002', 'image/jpeg', '26d6b1b90d5314be377aa2cbd979a05e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('297', '1', '0', '_images/SecondHand/', 'PinkSlow_2.jpg', '66527', 'image/jpeg', '46ed46e1ea1123ef1aadf177767868b7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('298', '1', '0', '_images/SecondHand/', 'PinkSlow_3.jpg', '53037', 'image/jpeg', 'd09e0bb59b1c451dd7a141ee35d92263', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('299', '1', '0', '_images/SecondHand/', 'pnpSecondhand-1.jpg', '191975', 'image/jpeg', '469d8efa99c4ffcc6f5a8decf9d7b0fd', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('300', '1', '0', '_images/SecondHand/', 'pnpSecondhand-2.jpg', '211797', 'image/jpeg', '7656bf77e819e404b76d97f322564eeb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('301', '1', '0', '_images/SecondHand/', 'pnpSecondhand-3.jpg', '202041', 'image/jpeg', '50e565df9558bcaafc858e0e5ea82c45', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('302', '1', '0', '_images/SecondHand/', 'pnpSecondhand-4.jpg', '178225', 'image/jpeg', 'e4f581a4766422c81437680939ff9c17', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('303', '1', '0', '_images/SecondHand/', 'pnpSecondhand-5.jpg', '425573', 'image/jpeg', 'b3ead0c441ddbe5497855bf80be8feb1', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('304', '1', '0', '_images/SecondHand/', 'pnpSecondhand-6.jpg', '440696', 'image/jpeg', '23545dac9cc0b1ab6fdd0853a33fb30d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('305', '1', '0', '_images/SecondHand/', 'pnpSecondhand-7.jpg', '206313', 'image/jpeg', '0c95bbb530bcbd19e1736a9177692934', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('306', '1', '0', '_images/SecondHand/', 'Poodle-1.jpg', '81288', 'image/jpeg', 'a01631a0a7c96c32bcd25ce19d8e098a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('307', '1', '0', '_images/SecondHand/', 'zebra_print_catsuit_2.jpg', '16040', 'image/jpeg', '3d69d5bbaeda3994000e25fa31cd7fc1', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('308', '1', '0', '_images/SecondHand/', 'ZebraRock-1.jpeg', '144267', 'image/jpeg', '891d2429c98c09fd577f94c58cec0ab5', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('309', '1', '0', '', 'PnPDS_Form.pdf', '106223', 'application/octet-stream', 'b92a83f4fb6d0d3c95ac122e5c7effcf', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('310', '1', '0', '', 'PnPDWSheet.pdf', '97954', 'application/octet-stream', 'c4223164d05aa102810c8a92ebfcbfb7', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('311', '1', '0', '_images/ProductImages/', '4mm_crystal_thumb.jpg', '61655', 'image/jpeg', '375ab4e948cae9575ac4e63bb2f24d8d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('312', '1', '0', '_images/_notes/', 'dwsync.xml', '157', 'application/octet-stream', 'ffad8c2ab4796f8dfd8e8d52aa24a2c8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('313', '1', '0', '', 'index.php', '34', 'application/octet-stream', '874acf023d69fc283a9d967c74a333dc', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('314', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/10/thumb200x200/', '4550126157f794d1284bbd98a06b5000.jpg', '42969', 'image/jpeg', 'ce573641d5dbc964db45969caa61ba08', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('315', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/11/thumb200x200/', '1bbd423f2093a71287555f19b8198448.jpg', '43469', 'image/jpeg', '09853136cc9a3f927b5e03d095c9dd29', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('316', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/12/thumb200x200/', 'd8958883077232fab40296b037949744.jpg', '55735', 'image/jpeg', 'd067416fec6116f8aa4deea20604d141', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('317', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/15/thumb200x200/', '00d5acaa030e2ab77187669096d9d813.jpg', '43616', 'image/jpeg', '0aaf477d96e0176774ffa073b8e5ca86', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('318', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/16/thumb200x200/', 'a2100161bec35dd102a183c8eee35447.jpg', '45937', 'image/jpeg', '1e2085c79437216ad4b15fd1ee2cc9fb', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('319', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/selector100x100/', '714b6d5035db085b42ce458d6fcdc0d5.jpg', '33253', 'image/jpeg', 'bf2b703d4be7f148f27573e169106244', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('320', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/selector100x100/', 'aa9fff913ffbd94917b8442bdd628465.jpg', '39379', 'image/jpeg', 'bddbb78f00107a06320eb7363d0495d4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('321', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/selector100x100/', 'e0e1405e3dbdbfa40bc0b22bbfd5e012.jpg', '36326', 'image/jpeg', 'c3dd8d695ab52f3bd21a874305562c0a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('322', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/thumb200x200/', '714b6d5035db085b42ce458d6fcdc0d5.jpg', '48783', 'image/jpeg', 'cd6a51d75ec14ae4e52203e99c938791', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('323', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/thumb200x200/', 'aa9fff913ffbd94917b8442bdd628465.jpg', '57776', 'image/jpeg', '100e5effc853e090e98e6b568189f36a', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('324', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/17/thumb200x200/', 'e0e1405e3dbdbfa40bc0b22bbfd5e012.jpg', '53061', 'image/jpeg', '41bf8ef0029197e2fcfa8c84e318cc84', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('325', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/selector100x100/', '21fdbcb9c2e3c14c09dbe2ff6483684b.jpg', '36210', 'image/jpeg', '52af3dc06a5266371e217a7e682804e3', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('326', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/selector100x100/', '47742b4ed2a8bcfdd48df59880d2bd75.jpg', '29616', 'image/jpeg', 'b75275abdc33ebd160669a0b4a2e9e67', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('327', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/selector100x100/', 'fea61d7a78e7a353ab4cb98f16218b4a.jpg', '33059', 'image/jpeg', 'b5ecc70ddccf029102e1dca4759d212c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('328', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/thumb200x200/', '21fdbcb9c2e3c14c09dbe2ff6483684b.jpg', '51855', 'image/jpeg', '615aa8401ee5978bdd1f61d8791eb993', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('329', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/thumb200x200/', '47742b4ed2a8bcfdd48df59880d2bd75.jpg', '43320', 'image/jpeg', 'c1d55c581667e4fc8fa67038eb8ebf6f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('330', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/18/thumb200x200/', 'fea61d7a78e7a353ab4cb98f16218b4a.jpg', '46748', 'image/jpeg', '80aeae81806f460858207300fc77d843', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('331', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/19/selector100x100/', '67050e522bfd16dd6f5366b3ac01359e.jpg', '25985', 'image/jpeg', 'aa1c92c5ac6e6835fda8024fa1125618', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('332', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/19/selector100x100/', '6fc25532ea96c4cdc3ccd0b03ea7a2cc.jpg', '23844', 'image/jpeg', '4fc91a1459239bc8d79879c65d6f4dd4', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('333', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/19/thumb200x200/', '67050e522bfd16dd6f5366b3ac01359e.jpg', '42140', 'image/jpeg', 'a03683c949cfef12c6fdd7905872e7e2', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('334', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/19/thumb200x200/', '6fc25532ea96c4cdc3ccd0b03ea7a2cc.jpg', '37807', 'image/jpeg', 'ff950e6eab612e1615b9460afc23bc12', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('335', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/20/thumb200x200/', '5a884483499fbda2c853f45633b0ff68.jpg', '39926', 'image/jpeg', 'e71d167d99dac55fca6939b4cbf92d5d', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('336', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/21/selector100x100/', '4245fbafce6844206719e4eda8aca587.jpg', '30142', 'image/jpeg', 'e5776e4817768534fb6f2651d06baf3b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('337', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/21/selector100x100/', '778b9adabbf341e763fcbb2d10de5f5e.jpg', '23826', 'image/jpeg', '5f33fdb72d2f5deac51114711b93904f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('338', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/21/thumb200x200/', '4245fbafce6844206719e4eda8aca587.jpg', '43724', 'image/jpeg', 'cb3a5ccaead0346ed05b594a661328ff', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('339', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/21/thumb200x200/', '778b9adabbf341e763fcbb2d10de5f5e.jpg', '39452', 'image/jpeg', 'ea2de68356f8d1b4b27ee0dd2a5c104c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('340', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/22/selector100x100/', '3fcea502e62b0929ef9eeaacebb800e4.jpg', '30388', 'image/jpeg', 'dcf3b6841df4c87adbb12e06399cdeaf', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('341', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/22/selector100x100/', '5971d913f49e01048c7424dac538eae3.jpg', '31199', 'image/jpeg', '7b10d36cc16e042fddabad6533652b39', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('342', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/22/thumb200x200/', '3fcea502e62b0929ef9eeaacebb800e4.jpg', '43782', 'image/jpeg', 'cc0f506ea9500fc6a70ce5a2ee519b7f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('343', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/22/thumb200x200/', '5971d913f49e01048c7424dac538eae3.jpg', '45653', 'image/jpeg', 'e671fbcf7dde37701e248edf86575dcf', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('344', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/23/thumb200x200/', '5ed85f2e99cdc205010cfb5f53c930db.jpg', '51429', 'image/jpeg', 'cd929154ed0a9d4abd8173f5e9ef3148', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('345', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/selector100x100/', '3d27e87e2f486f394c96496ae61779b9.jpg', '38191', 'image/jpeg', '0628413e1f6f107cf865301518c9c5fa', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('346', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/selector100x100/', '7ef6eb2bbbb8d75cc0b9ec6e6e391225.jpg', '36639', 'image/jpeg', 'b189a76354d3beb4e74d405373c1e619', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('347', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/selector100x100/', 'b2623daead138f7ebcc55dc2f9d8e589.jpg', '34432', 'image/jpeg', '02cfd04c9ad958721c941f4062619a2c', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('348', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/thumb200x200/', '3d27e87e2f486f394c96496ae61779b9.jpg', '56136', 'image/jpeg', '15cdac5be7e7eca83b5c5999d1e1a68b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('349', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/thumb200x200/', '7ef6eb2bbbb8d75cc0b9ec6e6e391225.jpg', '53466', 'image/jpeg', 'f98a6026f518b77f775d81032b84fb6e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('350', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/24/thumb200x200/', 'b2623daead138f7ebcc55dc2f9d8e589.jpg', '50466', 'image/jpeg', '03c900ae414362058357fdd37887605b', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('351', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/25/thumb200x200/', '59d881f2532a70a29ba0095a05f21b98.jpg', '58214', 'image/jpeg', '9ed1e78efc911d71994cf9f381b55249', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('352', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/26/thumb200x200/', '3d9a0aa7a36073d34490b24f404c2422.jpg', '64415', 'image/jpeg', '7d45d5613ad8922078f7d60533031130', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('353', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/27/thumb200x200/', '24e2c7a24d87042cb5deb79a991fc13a.jpg', '42344', 'image/jpeg', 'bcc0e12daab98fffc4baa804dd7fb0d6', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('354', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/28/selector100x100/', '4e85e6b21b5633f14cf56b24e905adb8.jpg', '48799', 'image/jpeg', '580e1badba4744d9fe84a9b6bb0448a8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('355', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/28/selector100x100/', 'b3bffd6cdc840d8ebe158825568ad1c1.jpg', '53933', 'image/jpeg', '1b5bfb06458c6a604858eb6831e2e579', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('356', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/28/thumb200x200/', '4e85e6b21b5633f14cf56b24e905adb8.jpg', '73380', 'image/jpeg', '7216731d45a6e4a9cd4381d495d0c463', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('357', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/28/thumb200x200/', 'b3bffd6cdc840d8ebe158825568ad1c1.jpg', '81713', 'image/jpeg', 'ea5ace823fab646b09088d3f646bab82', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('358', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/29/thumb200x200/', '89e60ad35a068c8c91c4cbda123b2310.jpg', '13648', 'image/jpeg', 'f38d0edc6f513ab4d70ec1dc54da05a5', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('359', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/31/thumb200x200/', 'f80e7f641505301309818a2a4ef5f9ba.jpg', '11632', 'image/jpeg', '8317db9b048dfe6dc18c9ce2d94ed3cd', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('360', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/32/thumb200x200/', 'da2a5efd9a156d124e30d79337959671.jpg', '10844', 'image/jpeg', 'b823bcb7e6326ac017d3ad692e4ccb25', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('361', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/33/thumb200x200/', '6e9d606ddbd48b1cdf662bb5f4bb7fe9.jpg', '12941', 'image/jpeg', '31433076a57087d49443ff15239d41ca', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('362', '1', '0', 'magictoolbox_cache/dd6b6cfc02e1715d9cb0915c3f4a72c2/33/thumb200x200/', 'df8cfeecd88dc11ee82865f9ed590c9d.jpg', '39198', 'image/jpeg', '8e3065fa630349fb82ee38d84569b8ce', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('363', '1', '0', 'Headers/', 'header.jpg', '62355', 'image/jpeg', '8dc4fac5a8e816c38f045f71fb90f79f', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('364', '1', '0', 'slides/', 'header_promo1.jpg', '73721', 'image/jpeg', '207ba335c89662f0ea42c41db978df78', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('365', '1', '0', 'slides/', 'header_promo2.jpg', '73748', 'image/jpeg', 'd0405f9ae2406959407284221cd5f359', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('366', '1', '0', 'slides/', 'header_promo3.jpg', '80304', 'image/jpeg', '5a272cce89de3bec94df73313b4ee3c8', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('367', '1', '0', 'slides/', 'header_promo4.jpg', '71333', 'image/jpeg', '71799fc8f6908a53b27a92a58f73dbfe', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('368', '1', '0', 'slides/', 'header_promo5.jpg', '68415', 'image/jpeg', '5ac0c40fa642fc16795e56f36470246e', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('369', '1', '0', 'slides/', 'header_promo6.jpg', '81188', 'image/jpeg', 'dbc5b39e439805c37a2a23f5157d7227', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('370', '1', '0', 'slides/', 'header_promo7.jpg', '69382', 'image/jpeg', '008f5d61819718f24aedcd3de6d4d469', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('371', '1', '0', 'slides/', 'header_promo8.jpg', '83499', 'image/jpeg', 'a4b7bd9b5a8556ec65bd9602a6caad07', ''); #EOQ
INSERT INTO `cc4_CubeCart_filemanager` VALUES('372', '1', '0', 'slides/', 'header_promo9.jpg', '72442', 'image/jpeg', 'ba187074cf031745a312434bdc7fe791', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_fusion`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_fusion`
--

CREATE TABLE `cc4_CubeCart_fusion` (
  `skin` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  UNIQUE KEY `skin` (`skin`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_fusion`
--

INSERT INTO `cc4_CubeCart_fusion` VALUES('vector', 'YTo3OTp7czoxMDoibGljZW5zZWtleSI7czoxNzoiVkVDVE9SLTI5OTE4ZmM0ZmQiO3M6MTE6ImJyZWFkY3J1bWJzIjthOjE6e2k6MDtzOjc6InByb2R1Y3QiO31zOjI1OiJsaWdodGJveF9hbmltYXRpb25fZWZmZWN0IjtzOjc6ImVsYXN0aWMiO3M6MjQ6ImxpZ2h0Ym94X2FuaW1hdGlvbl9zcGVlZCI7czo0OiJmYXN0IjtzOjI0OiJsaWdodGJveF9vdmVybGF5X29wYWNpdHkiO3M6NDoiMC44NSI7czoxOToiaW1hZ2VfbWFnbmlmaWNhdGlvbiI7czoyOiJvbiI7czoyOToiaW1hZ2Vfc2xpZGVyX2FuaW1hdGlvbl9lZmZlY3QiO3M6NToic2xpZGUiO3M6MzI6ImltYWdlX3NsaWRlcl9hbmltYXRpb25fZGlyZWN0aW9uIjtzOjEwOiJob3Jpem9udGFsIjtzOjI4OiJpbWFnZV9zbGlkZXJfYW5pbWF0aW9uX3NwZWVkIjtzOjY6Im5vcm1hbCI7czoyNzoiaW1hZ2Vfc2xpZGVyX2ZyYW1lX2R1cmF0aW9uIjtzOjQ6IjQwMDAiO3M6MjI6ImltYWdlX3NsaWRlcl9hdXRvc3RhcnQiO3M6Mjoib24iO3M6Mjc6ImltYWdlX3NsaWRlcl9wYXVzZV9vbl9ob3ZlciI7czoyOiJvbiI7czoyODoiaW1hZ2Vfc2xpZGVyX3BhdXNlX29uX2FjdGlvbiI7czoyOiJvbiI7czoyMjoiaW1hZ2Vfc2xpZGVyX3JhbmRvbWl6ZSI7czoyOiJvbiI7czoxNzoiaW1hZ2Vfc2xpZGVyX2xvb3AiO3M6Mjoib24iO3M6MTc6ImltYWdlX3NsaWRlcl9ob21lIjthOjI6e3M6Njoic2xpZGVzIjthOjY6e2k6MTthOjQ6e3M6NToiaW1hZ2UiO3M6Mzg6ImltYWdlcy9zb3VyY2Uvc2xpZGVzL2hlYWRlcl9wcm9tbzEuanBnIjtzOjE2OiJiYWNrZ3JvdW5kX2NvbG9yIjtzOjc6IiNGRkZGRkYiO3M6MTY6ImJhY2tncm91bmRfaW1hZ2UiO3M6MDoiIjtzOjM6InVybCI7czoxOiIjIjt9aToyO2E6NDp7czo1OiJpbWFnZSI7czozODoiaW1hZ2VzL3NvdXJjZS9zbGlkZXMvaGVhZGVyX3Byb21vMi5qcGciO3M6MTY6ImJhY2tncm91bmRfY29sb3IiO3M6NzoiI0ZGRkZGRiI7czoxNjoiYmFja2dyb3VuZF9pbWFnZSI7czowOiIiO3M6MzoidXJsIjtzOjE6IiMiO31pOjM7YTo0OntzOjU6ImltYWdlIjtzOjM4OiJpbWFnZXMvc291cmNlL3NsaWRlcy9oZWFkZXJfcHJvbW80LmpwZyI7czoxNjoiYmFja2dyb3VuZF9jb2xvciI7czo3OiIjRkZGRkZGIjtzOjE2OiJiYWNrZ3JvdW5kX2ltYWdlIjtzOjA6IiI7czozOiJ1cmwiO3M6MToiIyI7fWk6NDthOjQ6e3M6NToiaW1hZ2UiO3M6Mzg6ImltYWdlcy9zb3VyY2Uvc2xpZGVzL2hlYWRlcl9wcm9tbzYuanBnIjtzOjE2OiJiYWNrZ3JvdW5kX2NvbG9yIjtzOjc6IiNGRkZGRkYiO3M6MTY6ImJhY2tncm91bmRfaW1hZ2UiO3M6MDoiIjtzOjM6InVybCI7czoxOiIjIjt9aTo1O2E6NDp7czo1OiJpbWFnZSI7czozODoiaW1hZ2VzL3NvdXJjZS9zbGlkZXMvaGVhZGVyX3Byb21vNy5qcGciO3M6MTY6ImJhY2tncm91bmRfY29sb3IiO3M6NzoiI0ZGRkZGRiI7czoxNjoiYmFja2dyb3VuZF9pbWFnZSI7czowOiIiO3M6MzoidXJsIjtzOjE6IiMiO31pOjY7YTo0OntzOjU6ImltYWdlIjtzOjM4OiJpbWFnZXMvc291cmNlL3NsaWRlcy9oZWFkZXJfcHJvbW85LmpwZyI7czoxNjoiYmFja2dyb3VuZF9jb2xvciI7czo3OiIjRkZGRkZGIjtzOjE2OiJiYWNrZ3JvdW5kX2ltYWdlIjtzOjA6IiI7czozOiJ1cmwiO3M6MToiIyI7fX1zOjc6ImVuYWJsZWQiO3M6Mjoib24iO31zOjE5OiJpbWFnZV9zbGlkZXJfZ2xvYmFsIjthOjE6e3M6Njoic2xpZGVzIjthOjA6e319czozMToidGFnbGluZV9zbGlkZXJfYW5pbWF0aW9uX2VmZmVjdCI7czo0OiJmYWRlIjtzOjMwOiJ0YWdsaW5lX3NsaWRlcl9hbmltYXRpb25fc3BlZWQiO3M6Njoibm9ybWFsIjtzOjI5OiJ0YWdsaW5lX3NsaWRlcl9mcmFtZV9kdXJhdGlvbiI7czo0OiI0MDAwIjtzOjI5OiJ0YWdsaW5lX3NsaWRlcl9wYXVzZV9vbl9ob3ZlciI7czoyOiJvbiI7czoyMToidGFnbGluZV9zbGlkZXJfZ2xvYmFsIjthOjI6e3M6Njoic2xpZGVzIjthOjU6e2k6MTthOjE6e3M6MTI6ImNvbnRlbnRfaHRtbCI7czozODoiV2VsY29tZSB0byBQcmluY2VzcyAmIzM5O24mIzM5OyBQaWNrbGUiO31pOjI7YToxOntzOjEyOiJjb250ZW50X2h0bWwiO3M6NTA6Ik9mZmVyaW5nIGNoaWxkcmVuJiMzOTtzIGRhbmNlIHdlYXIgYXQgZ3JlYXQgcHJpY2VzIjt9aTozO2E6MTp7czoxMjoiY29udGVudF9odG1sIjtzOjQyOiJCZXNwb2tlIHdvcmsgdWRlcnRha2VuIGF0IGNvbXBldGl2ZSBwcmljZXMiO31pOjQ7YToxOntzOjEyOiJjb250ZW50X2h0bWwiO3M6MzY6IlNwYXJrbGVzIGFuZCBzdG9uZXM/IExvb2sgbm8gZnVydGhlciI7fWk6NTthOjE6e3M6MTI6ImNvbnRlbnRfaHRtbCI7czo0MjoiQnJhbmQgbmV3IHNob3Agb3BlbmluZyBpbiBQb3J0c21vdXRoIHNvb24hIjt9fXM6NzoiZW5hYmxlZCI7czoyOiJvbiI7fXM6MTk6InBhZ2VfbGF5b3V0X2RlZmF1bHQiO2E6Mzp7czo4OiJ0ZW1wbGF0ZSI7czoxMDoidHdvX2NvbHVtbiI7czoxMDoidHdvX2NvbHVtbiI7YTo0OntzOjEyOiJoZWFkZXJfdXBwZXIiO2E6MTp7aTowO3M6NjoidG9wbmF2Ijt9czoxMjoiaGVhZGVyX2xvd2VyIjthOjE6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjt9czoxMjoic2lkZWJhcl9sZWZ0IjthOjM6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjtpOjE7czo3OiJzZXNzaW9uIjtpOjI7czoxMzoic2hvcHBpbmdfY2FydCI7fXM6NjoiZm9vdGVyIjthOjM6e2k6MDtzOjk6Im1haWxfbGlzdCI7aToxO3M6ODoicmVnaW9uYWwiO2k6MjtzOjk6InNpdGVfZG9jcyI7fX1zOjEwOiJvbmVfY29sdW1uIjthOjM6e3M6MTI6ImhlYWRlcl91cHBlciI7YToxOntpOjA7czo2OiJ0b3BuYXYiO31zOjEyOiJoZWFkZXJfbG93ZXIiO2E6MTp7aTowO3M6MTA6ImNhdGVnb3JpZXMiO31zOjY6ImZvb3RlciI7YTozOntpOjA7czo5OiJtYWlsX2xpc3QiO2k6MTtzOjg6InJlZ2lvbmFsIjtpOjI7czo5OiJzaXRlX2RvY3MiO319fXM6MTY6InBhZ2VfbGF5b3V0X2hvbWUiO2E6MTp7czo4OiJ0ZW1wbGF0ZSI7czowOiIiO31zOjE5OiJwYWdlX2xheW91dF9wcm9kdWN0IjthOjE6e3M6ODoidGVtcGxhdGUiO3M6MDoiIjt9czoyMDoicGFnZV9sYXlvdXRfY2F0ZWdvcnkiO2E6Mjp7czo4OiJ0ZW1wbGF0ZSI7czoxMDoidHdvX2NvbHVtbiI7czoxMDoidHdvX2NvbHVtbiI7YTo0OntzOjEyOiJoZWFkZXJfdXBwZXIiO2E6MTp7aTowO3M6NjoidG9wbmF2Ijt9czoxMjoiaGVhZGVyX2xvd2VyIjthOjE6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjt9czoxMjoic2lkZWJhcl9sZWZ0IjthOjQ6e2k6MDtzOjc6InNlc3Npb24iO2k6MTtzOjEwOiJzYWxlX2l0ZW1zIjtpOjI7czoxNjoicG9wdWxhcl9wcm9kdWN0cyI7aTozO3M6MTM6InNob3BwaW5nX2NhcnQiO31zOjY6ImZvb3RlciI7YTozOntpOjA7czo5OiJtYWlsX2xpc3QiO2k6MTtzOjg6InJlZ2lvbmFsIjtpOjI7czo5OiJzaXRlX2RvY3MiO319fXM6MjA6InBhZ2VfbGF5b3V0X2RvY3VtZW50IjthOjE6e3M6ODoidGVtcGxhdGUiO3M6MDoiIjt9czoyMToicGFnZV9sYXlvdXRfc2FsZWl0ZW1zIjthOjI6e3M6ODoidGVtcGxhdGUiO3M6MTA6InR3b19jb2x1bW4iO3M6MTA6InR3b19jb2x1bW4iO2E6NDp7czoxMjoiaGVhZGVyX3VwcGVyIjthOjE6e2k6MDtzOjY6InRvcG5hdiI7fXM6MTI6ImhlYWRlcl9sb3dlciI7YToxOntpOjA7czoxMDoiY2F0ZWdvcmllcyI7fXM6MTI6InNpZGViYXJfbGVmdCI7YToyOntpOjA7czoxNjoicG9wdWxhcl9wcm9kdWN0cyI7aToxO3M6MTA6InNhbGVfaXRlbXMiO31zOjY6ImZvb3RlciI7YTozOntpOjA7czo5OiJtYWlsX2xpc3QiO2k6MTtzOjg6InJlZ2lvbmFsIjtpOjI7czo5OiJzaXRlX2RvY3MiO319fXM6MjA6InBhZ2VfbGF5b3V0X3JlZ2lzdGVyIjthOjE6e3M6ODoidGVtcGxhdGUiO3M6MDoiIjt9czoxNzoicGFnZV9sYXlvdXRfb3JkZXIiO2E6Mjp7czo4OiJ0ZW1wbGF0ZSI7czoxMDoidHdvX2NvbHVtbiI7czoxMDoidHdvX2NvbHVtbiI7YTo0OntzOjEyOiJoZWFkZXJfdXBwZXIiO2E6MTp7aTowO3M6NjoidG9wbmF2Ijt9czoxMjoiaGVhZGVyX2xvd2VyIjthOjE6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjt9czoxMjoic2lkZWJhcl9sZWZ0IjthOjE6e2k6MDtzOjc6ImFjY291bnQiO31zOjY6ImZvb3RlciI7YTozOntpOjA7czo5OiJtYWlsX2xpc3QiO2k6MTtzOjg6InJlZ2lvbmFsIjtpOjI7czo5OiJzaXRlX2RvY3MiO319fXM6MTk6InBhZ2VfbGF5b3V0X2FjY291bnQiO2E6Mjp7czo4OiJ0ZW1wbGF0ZSI7czoxMDoidHdvX2NvbHVtbiI7czoxMDoidHdvX2NvbHVtbiI7YTo0OntzOjEyOiJoZWFkZXJfdXBwZXIiO2E6MTp7aTowO3M6NjoidG9wbmF2Ijt9czoxMjoiaGVhZGVyX2xvd2VyIjthOjE6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjt9czoxMjoic2lkZWJhcl9sZWZ0IjthOjE6e2k6MDtzOjc6ImFjY291bnQiO31zOjY6ImZvb3RlciI7YTozOntpOjA7czo5OiJtYWlsX2xpc3QiO2k6MTtzOjg6InJlZ2lvbmFsIjtpOjI7czo5OiJzaXRlX2RvY3MiO319fXM6MjA6InBhZ2VfbGF5b3V0X2Rvd25sb2FkIjthOjI6e3M6ODoidGVtcGxhdGUiO3M6MTA6InR3b19jb2x1bW4iO3M6MTA6InR3b19jb2x1bW4iO2E6NDp7czoxMjoiaGVhZGVyX3VwcGVyIjthOjE6e2k6MDtzOjY6InRvcG5hdiI7fXM6MTI6ImhlYWRlcl9sb3dlciI7YToxOntpOjA7czoxMDoiY2F0ZWdvcmllcyI7fXM6MTI6InNpZGViYXJfbGVmdCI7YToxOntpOjA7czo3OiJhY2NvdW50Ijt9czo2OiJmb290ZXIiO2E6Mzp7aTowO3M6OToibWFpbF9saXN0IjtpOjE7czo4OiJyZWdpb25hbCI7aToyO3M6OToic2l0ZV9kb2NzIjt9fX1zOjI3OiJwYWdlX2xheW91dF9naWZ0Y2VydGlmaWNhdGUiO2E6Mjp7czo4OiJ0ZW1wbGF0ZSI7czoxMDoidHdvX2NvbHVtbiI7czoxMDoidHdvX2NvbHVtbiI7YTo0OntzOjEyOiJoZWFkZXJfdXBwZXIiO2E6MTp7aTowO3M6NjoidG9wbmF2Ijt9czoxMjoiaGVhZGVyX2xvd2VyIjthOjE6e2k6MDtzOjEwOiJjYXRlZ29yaWVzIjt9czoxMjoic2lkZWJhcl9sZWZ0IjthOjI6e2k6MDtzOjE2OiJwb3B1bGFyX3Byb2R1Y3RzIjtpOjE7czoxMDoic2FsZV9pdGVtcyI7fXM6NjoiZm9vdGVyIjthOjM6e2k6MDtzOjk6Im1haWxfbGlzdCI7aToxO3M6ODoicmVnaW9uYWwiO2k6MjtzOjk6InNpdGVfZG9jcyI7fX19czoyMDoicGFnZV9sYXlvdXRfY2hlY2tvdXQiO2E6MTp7czo4OiJ0ZW1wbGF0ZSI7czowOiIiO31zOjE5OiJwYWdlX2xheW91dF9nYXRld2F5IjthOjE6e3M6ODoidGVtcGxhdGUiO3M6MDoiIjt9czoyNToiY2F0ZWdvcnlfcHJvZHVjdHNfcGVyX3JvdyI7czoxOiIzIjtzOjIzOiJsYXRlc3RfcHJvZHVjdHNfcGVyX3JvdyI7czoxOiI0IjtzOjI0OiJyZWxhdGVkX3Byb2R1Y3RzX3Blcl9yb3ciO3M6MToiMyI7czoyMToiYWxpZ25fcHJvZHVjdF9hY3Rpb25zIjtzOjI6Im9uIjtzOjI5OiJmZWF0dXJlZF9wcm9kdWN0c19hZGRfdG9fY2FydCI7czoyOiJvbiI7czoyNToic2FsZV9wcm9kdWN0c19hZGRfdG9fY2FydCI7czoyOiJvbiI7czoxMzoiY3VzdG9tX2NvbG9ycyI7czoyOiJvbiI7czoxNzoibGVzc3Zhcl90ZXh0Q29sb3IiO3M6NzoiI0E5NEQ4NSI7czoxNzoibGVzc3Zhcl9saW5rQ29sb3IiO3M6NzoiI0RFNjhCMSI7czoyMjoibGVzc3Zhcl9saW5rQ29sb3JIb3ZlciI7czo3OiIjNjYxRTRCIjtzOjIyOiJsZXNzdmFyX2JvZHlCYWNrZ3JvdW5kIjtzOjc6IiNGMkYyRjIiO3M6Mjc6Imxlc3N2YXJfYm9keUJhY2tncm91bmRJbWFnZSI7czowOiIiO3M6Mjg6Imxlc3N2YXJfYm9keUJhY2tncm91bmRSZXBlYXQiO3M6NjoicmVwZWF0IjtzOjMwOiJsZXNzdmFyX2JvZHlCYWNrZ3JvdW5kUG9zaXRpb24iO3M6ODoibGVmdCB0b3AiO3M6MjU6Imxlc3N2YXJfcGFnZVNoYWRvd09wYWNpdHkiO3M6MzoiMC4zIjtzOjIyOiJsZXNzdmFyX3BhZ2VTaGFkb3dCbHVyIjtzOjQ6IjEycHgiO3M6Mjc6Imxlc3N2YXJfaGVhZGVydG9wQmFja2dyb3VuZCI7czo3OiIjQTk0RDg1IjtzOjI0OiJsZXNzdmFyX2hlYWRlcnRvcE9wYWNpdHkiO3M6MToiMSI7czoyMjoibGVzc3Zhcl9oZWFkZXJ0b3BDb2xvciI7czo3OiIjRkZGRkZGIjtzOjMwOiJsZXNzdmFyX2hlYWRlcmJvdHRvbUJhY2tncm91bmQiO3M6NzoiI0ZGRkZGRiI7czoyNToibGVzc3Zhcl9oZWFkZXJib3R0b21Db2xvciI7czo3OiIjNzk4Mjg5IjtzOjI3OiJsZXNzdmFyX2Zvb3RlcnRvcEJhY2tncm91bmQiO3M6NzoiI0YyRjJGMiI7czoyMjoibGVzc3Zhcl9mb290ZXJ0b3BDb2xvciI7czo3OiIjNjY2NjY2IjtzOjMwOiJsZXNzdmFyX2Zvb3RlcmJvdHRvbUJhY2tncm91bmQiO3M6NzoiI0ZGRkZGRiI7czoyNToibGVzc3Zhcl9mb290ZXJib3R0b21Db2xvciI7czo3OiIjNjY2NjY2IjtzOjMxOiJsZXNzdmFyX2NvbnRlbnRoZWFkZXJCYWNrZ3JvdW5kIjtzOjc6IiNGNUY1RjUiO3M6MjY6Imxlc3N2YXJfY29udGVudGhlYWRlckNvbG9yIjtzOjc6IiNBOTREODUiO3M6MjQ6Imxlc3N2YXJfc3ViY2F0QmFja2dyb3VuZCI7czo3OiIjRUZGNkZDIjtzOjE5OiJsZXNzdmFyX3N1YmNhdENvbG9yIjtzOjc6IiNBOTREODUiO3M6MjQ6Imxlc3N2YXJfc3ViY2F0Q29sb3JIb3ZlciI7czo3OiIjNjYxRTRCIjtzOjIxOiJsZXNzdmFyX2J0bkJhY2tncm91bmQiO3M6NzoiI0ZGRkZGRiI7czoyODoibGVzc3Zhcl9idG5QcmltYXJ5QmFja2dyb3VuZCI7czo3OiIjQTk0RDg1IjtzOjI1OiJsZXNzdmFyX2J0bkluZm9CYWNrZ3JvdW5kIjtzOjc6IiNGRkZGRkYiO3M6Mjg6Imxlc3N2YXJfYnRuU3VjY2Vzc0JhY2tncm91bmQiO3M6NzoiIzYyQzQ2MiI7czoyODoibGVzc3Zhcl9idG5XYXJuaW5nQmFja2dyb3VuZCI7czo3OiIjRkFBNzMyIjtzOjI3OiJsZXNzdmFyX2J0bkRhbmdlckJhY2tncm91bmQiO3M6NzoiI0VFNUY1QiI7czoyODoibGVzc3Zhcl9idG5JbnZlcnNlQmFja2dyb3VuZCI7czo3OiIjNTU1NTU1IjtzOjI3OiJsZXNzdmFyX3NhbGVCYWRnZUJhY2tncm91bmQiO3M6NzoiIzlEMjYxRCI7czoyMjoibGVzc3Zhcl9zYWxlQmFkZ2VDb2xvciI7czo3OiIjRkZGRkZGIjtzOjI4OiJsZXNzdmFyX2N1YmVjYXJ0Q3JlZGl0c0NvbG9yIjtzOjc6IiM5OTk5OTkiO3M6MTQ6InBhZ2VfbWF4X3dpZHRoIjtzOjY6IjEyMDBweCI7czoxNDoicGFnZV9taW5fd2lkdGgiO3M6NToiOTYwcHgiO3M6MTU6ImltcG9ydF9zZXR0aW5ncyI7YTo1OntzOjQ6Im5hbWUiO3M6MDoiIjtzOjQ6InR5cGUiO3M6MDoiIjtzOjg6InRtcF9uYW1lIjtzOjA6IiI7czo1OiJlcnJvciI7aTo0O3M6NDoic2l6ZSI7aTowO31zOjE1OiJleHBvcnRfc2V0dGluZ3MiO3M6MDoiIjt9'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_geo_country`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_geo_country`
--

CREATE TABLE `cc4_CubeCart_geo_country` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `iso` char(2) collate utf8_unicode_ci NOT NULL default '',
  `name` varchar(80) collate utf8_unicode_ci NOT NULL default '',
  `iso3` char(3) collate utf8_unicode_ci default NULL,
  `numcode` smallint(3) default NULL,
  PRIMARY KEY  (`iso`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=241 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_geo_country`
--

INSERT INTO `cc4_CubeCart_geo_country` VALUES('1', 'AF', 'Afghanistan', 'AFG', '4'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('2', 'AL', 'Albania', 'ALB', '8'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('3', 'DZ', 'Algeria', 'DZA', '12'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('4', 'AS', 'American Samoa', 'ASM', '16'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('5', 'AD', 'Andorra', 'AND', '20'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('6', 'AO', 'Angola', 'AGO', '24'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('7', 'AI', 'Anguilla', 'AIA', '660'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('8', 'AQ', 'Antarctica', 'AQA', '10'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('9', 'AG', 'Antigua and Barbuda', 'ATG', '28'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('10', 'AR', 'Argentina', 'ARG', '32'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('11', 'AM', 'Armenia', 'ARM', '51'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('12', 'AW', 'Aruba', 'ABW', '533'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('13', 'AU', 'Australia', 'AUS', '36'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('14', 'AT', 'Austria', 'AUT', '40'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('15', 'AZ', 'Azerbaijan', 'AZE', '31'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('16', 'BS', 'Bahamas', 'BHS', '44'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('17', 'BH', 'Bahrain', 'BHR', '48'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('18', 'BD', 'Bangladesh', 'BGD', '50'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('19', 'BB', 'Barbados', 'BRB', '52'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('20', 'BY', 'Belarus', 'BLR', '112'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('21', 'BE', 'Belgium', 'BEL', '56'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('22', 'BZ', 'Belize', 'BLZ', '84'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('23', 'BJ', 'Benin', 'BEN', '204'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('24', 'BM', 'Bermuda', 'BMU', '60'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('25', 'BT', 'Bhutan', 'BTN', '64'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('26', 'BO', 'Bolivia', 'BOL', '68'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('27', 'BA', 'Bosnia and Herzegovina', 'BIH', '70'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('28', 'BW', 'Botswana', 'BWA', '72'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('29', 'BV', 'Bouvet Island', 'BVT', '74'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('30', 'BR', 'Brazil', 'BRA', '76'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('31', 'IO', 'British Indian Ocean Territory', 'IOT', '86'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('32', 'BN', 'Brunei Darussalam', 'BRN', '96'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('33', 'BG', 'Bulgaria', 'BGR', '100'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('34', 'BF', 'Burkina Faso', 'BFA', '854'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('35', 'BI', 'Burundi', 'BDI', '108'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('36', 'KH', 'Cambodia', 'KHM', '116'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('37', 'CM', 'Cameroon', 'CMR', '120'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('38', 'CA', 'Canada', 'CAN', '124'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('39', 'CV', 'Cape Verde', 'CPV', '132'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('40', 'KY', 'Cayman Islands', 'CYM', '136'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('41', 'CF', 'Central African Republic', 'CAF', '140'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('42', 'TD', 'Chad', 'TCD', '148'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('43', 'CL', 'Chile', 'CHL', '152'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('44', 'CN', 'China', 'CHN', '156'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('45', 'CX', 'Christmas Island', 'CXR', '162'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('46', 'CC', 'Cocos (Keeling) Islands', 'CCK', '166'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('47', 'CO', 'Colombia', 'COL', '170'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('48', 'KM', 'Comoros', 'COM', '174'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('49', 'CG', 'Congo', 'COG', '178'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('50', 'CD', 'Congo, the Democratic Republic of the', 'COD', '180'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('51', 'CK', 'Cook Islands', 'COK', '184'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('52', 'CR', 'Costa Rica', 'CRI', '188'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('53', 'CI', 'Cote D\'Ivoire', 'CIV', '384'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('54', 'HR', 'Croatia', 'HRV', '191'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('55', 'CU', 'Cuba', 'CUB', '192'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('56', 'CY', 'Cyprus', 'CYP', '196'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('57', 'CZ', 'Czech Republic', 'CZE', '203'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('58', 'DK', 'Denmark', 'DNK', '208'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('59', 'DJ', 'Djibouti', 'DJI', '262'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('60', 'DM', 'Dominica', 'DMA', '212'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('61', 'DO', 'Dominican Republic', 'DOM', '214'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('62', 'EC', 'Ecuador', 'ECU', '218'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('63', 'EG', 'Egypt', 'EGY', '818'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('64', 'SV', 'El Salvador', 'SLV', '222'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('65', 'GQ', 'Equatorial Guinea', 'GNQ', '226'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('66', 'ER', 'Eritrea', 'ERI', '232'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('67', 'EE', 'Estonia', 'EST', '233'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('68', 'ET', 'Ethiopia', 'ETH', '231'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('69', 'FK', 'Falkland Islands (Malvinas)', 'FLK', '238'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('70', 'FO', 'Faroe Islands', 'FRO', '234'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('71', 'FJ', 'Fiji', 'FJI', '242'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('72', 'FI', 'Finland', 'FIN', '246'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('73', 'FR', 'France', 'FRA', '250'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('74', 'GF', 'French Guiana', 'GUF', '254'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('75', 'PF', 'French Polynesia', 'PYF', '258'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('76', 'TF', 'French Southern Territories', 'ATF', '260'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('77', 'GA', 'Gabon', 'GAB', '266'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('78', 'GM', 'Gambia', 'GMB', '270'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('79', 'GE', 'Georgia', 'GEO', '268'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('80', 'DE', 'Germany', 'DEU', '276'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('81', 'GH', 'Ghana', 'GHA', '288'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('82', 'GI', 'Gibraltar', 'GIB', '292'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('83', 'GR', 'Greece', 'GRC', '300'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('84', 'GL', 'Greenland', 'GRL', '304'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('85', 'GD', 'Grenada', 'GRD', '308'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('86', 'GP', 'Guadeloupe', 'GLP', '312'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('87', 'GU', 'Guam', 'GUM', '316'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('88', 'GT', 'Guatemala', 'GTM', '320'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('89', 'GN', 'Guinea', 'GIN', '324'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('90', 'GW', 'Guinea-Bissau', 'GNB', '624'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('91', 'GY', 'Guyana', 'GUY', '328'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('92', 'HT', 'Haiti', 'HTI', '332'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('93', 'HM', 'Heard Island and Mcdonald Islands', 'HMD', '334'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('94', 'VA', 'Holy See (Vatican City State)', 'VAT', '336'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('95', 'HN', 'Honduras', 'HND', '340'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('96', 'HK', 'Hong Kong', 'HKG', '344'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('97', 'HU', 'Hungary', 'HUN', '348'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('98', 'IS', 'Iceland', 'ISL', '352'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('99', 'IN', 'India', 'IND', '356'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('100', 'ID', 'Indonesia', 'IDN', '360'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('101', 'IR', 'Iran, Islamic Republic of', 'IRN', '364'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('102', 'IQ', 'Iraq', 'IRQ', '368'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('103', 'IE', 'Ireland', 'IRL', '372'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('104', 'IL', 'Israel', 'ISR', '376'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('105', 'IT', 'Italy', 'ITA', '380'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('106', 'JM', 'Jamaica', 'JAM', '388'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('107', 'JP', 'Japan', 'JPN', '392'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('108', 'JO', 'Jordan', 'JOR', '400'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('109', 'KZ', 'Kazakhstan', 'KAZ', '398'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('110', 'KE', 'Kenya', 'KEN', '404'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('111', 'KI', 'Kiribati', 'KIR', '296'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('112', 'KP', 'Korea, Democratic People\'s Republic of', 'PRK', '408'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('113', 'KR', 'Korea, Republic of', 'KOR', '410'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('114', 'KW', 'Kuwait', 'KWT', '414'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('115', 'KG', 'Kyrgyzstan', 'KGZ', '417'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('116', 'LA', 'Lao People\'s Democratic Republic', 'LAO', '418'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('117', 'LV', 'Latvia', 'LVA', '428'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('118', 'LB', 'Lebanon', 'LBN', '422'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('119', 'LS', 'Lesotho', 'LSO', '426'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('120', 'LR', 'Liberia', 'LBR', '430'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('121', 'LY', 'Libyan Arab Jamahiriya', 'LBY', '434'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('122', 'LI', 'Liechtenstein', 'LIE', '438'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('123', 'LT', 'Lithuania', 'LTU', '440'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('124', 'LU', 'Luxembourg', 'LUX', '442'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('125', 'MO', 'Macao', 'MAC', '446'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('126', 'MK', 'Macedonia, the Former Yugoslav Republic of', 'MKD', '807'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('127', 'MG', 'Madagascar', 'MDG', '450'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('128', 'MW', 'Malawi', 'MWI', '454'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('129', 'MY', 'Malaysia', 'MYS', '458'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('130', 'MV', 'Maldives', 'MDV', '462'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('131', 'ML', 'Mali', 'MLI', '466'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('132', 'MT', 'Malta', 'MLT', '470'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('133', 'MH', 'Marshall Islands', 'MHL', '584'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('134', 'MQ', 'Martinique', 'MTQ', '474'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('135', 'MR', 'Mauritania', 'MRT', '478'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('136', 'MU', 'Mauritius', 'MUS', '480'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('137', 'YT', 'Mayotte', 'MYT', '175'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('138', 'MX', 'Mexico', 'MEX', '484'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('139', 'FM', 'Micronesia, Federated States of', 'FSM', '583'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('140', 'MD', 'Moldova, Republic of', 'MDA', '498'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('141', 'MC', 'Monaco', 'MCO', '492'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('142', 'MN', 'Mongolia', 'MNG', '496'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('143', 'MS', 'Montserrat', 'MSR', '500'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('144', 'MA', 'Morocco', 'MAR', '504'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('145', 'MZ', 'Mozambique', 'MOZ', '508'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('146', 'MM', 'Myanmar', 'MMR', '104'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('147', 'NA', 'Namibia', 'NAM', '516'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('148', 'NR', 'Nauru', 'NRU', '520'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('149', 'NP', 'Nepal', 'NPL', '524'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('150', 'NL', 'Netherlands', 'NLD', '528'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('151', 'AN', 'Netherlands Antilles', 'ANT', '530'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('152', 'NC', 'New Caledonia', 'NCL', '540'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('153', 'NZ', 'New Zealand', 'NZL', '554'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('154', 'NI', 'Nicaragua', 'NIC', '558'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('155', 'NE', 'Niger', 'NER', '562'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('156', 'NG', 'Nigeria', 'NGA', '566'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('157', 'NU', 'Niue', 'NIU', '570'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('158', 'NF', 'Norfolk Island', 'NFK', '574'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('159', 'MP', 'Northern Mariana Islands', 'MNP', '580'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('160', 'NO', 'Norway', 'NOR', '578'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('161', 'OM', 'Oman', 'OMN', '512'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('162', 'PK', 'Pakistan', 'PAK', '586'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('163', 'PW', 'Palau', 'PLW', '585'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('164', 'PS', 'Palestinian Territory, Occupied', 'PSE', '275'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('165', 'PA', 'Panama', 'PAN', '591'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('166', 'PG', 'Papua New Guinea', 'PNG', '598'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('167', 'PY', 'Paraguay', 'PRY', '600'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('168', 'PE', 'Peru', 'PER', '604'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('169', 'PH', 'Philippines', 'PHL', '608'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('170', 'PN', 'Pitcairn', 'PCN', '612'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('171', 'PL', 'Poland', 'POL', '616'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('172', 'PT', 'Portugal', 'PRT', '620'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('173', 'PR', 'Puerto Rico', 'PRI', '630'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('174', 'QA', 'Qatar', 'QAT', '634'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('175', 'RE', 'Reunion', 'REU', '638'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('176', 'RO', 'Romania', 'ROM', '642'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('177', 'RU', 'Russian Federation', 'RUS', '643'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('178', 'RW', 'Rwanda', 'RWA', '646'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('179', 'SH', 'Saint Helena', 'SHN', '654'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('180', 'KN', 'Saint Kitts and Nevis', 'KNA', '659'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('181', 'LC', 'Saint Lucia', 'LCA', '662'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('182', 'PM', 'Saint Pierre and Miquelon', 'SPM', '666'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('183', 'VC', 'Saint Vincent and the Grenadines', 'VCT', '670'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('184', 'WS', 'Samoa', 'WSM', '882'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('185', 'SM', 'San Marino', 'SMR', '674'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('186', 'ST', 'Sao Tome and Principe', 'STP', '678'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('187', 'SA', 'Saudi Arabia', 'SAU', '682'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('188', 'SN', 'Senegal', 'SEN', '686'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('189', 'RS', 'Serbia', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('190', 'SC', 'Seychelles', 'SYC', '690'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('191', 'SL', 'Sierra Leone', 'SLE', '694'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('192', 'SG', 'Singapore', 'SGP', '702'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('193', 'SK', 'Slovakia', 'SVK', '703'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('194', 'SI', 'Slovenia', 'SVN', '705'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('195', 'SB', 'Solomon Islands', 'SLB', '90'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('196', 'SO', 'Somalia', 'SOM', '706'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('197', 'ZA', 'South Africa', 'ZAF', '710'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('198', 'GS', 'South Georgia and the South Sandwich Islands', 'SGS', '239'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('199', 'ES', 'Spain', 'ESP', '724'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('200', 'LK', 'Sri Lanka', 'LKA', '144'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('201', 'SD', 'Sudan', 'SDN', '736'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('202', 'SR', 'Suriname', 'SUR', '740'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('203', 'SJ', 'Svalbard and Jan Mayen', 'SJM', '744'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('204', 'SZ', 'Swaziland', 'SWZ', '748'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('205', 'SE', 'Sweden', 'SWE', '752'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('206', 'CH', 'Switzerland', 'CHE', '756'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('207', 'SY', 'Syrian Arab Republic', 'SYR', '760'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('208', 'TW', 'Taiwan', 'TWN', '158'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('209', 'TJ', 'Tajikistan', 'TJK', '762'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('210', 'TZ', 'Tanzania, United Republic of', 'TZA', '834'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('211', 'TH', 'Thailand', 'THA', '764'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('212', 'TL', 'Timor-Leste', 'TLS', '626'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('213', 'TG', 'Togo', 'TGO', '768'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('214', 'TK', 'Tokelau', 'TKL', '772'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('215', 'TO', 'Tonga', 'TON', '776'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('216', 'TT', 'Trinidad and Tobago', 'TTO', '780'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('217', 'TN', 'Tunisia', 'TUN', '788'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('218', 'TR', 'Turkey', 'TUR', '792'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('219', 'TM', 'Turkmenistan', 'TKM', '795'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('220', 'TC', 'Turks and Caicos Islands', 'TCA', '796'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('221', 'TV', 'Tuvalu', 'TUV', '798'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('222', 'UG', 'Uganda', 'UGA', '800'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('223', 'UA', 'Ukraine', 'UKR', '804'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('224', 'AE', 'United Arab Emirates', 'ARE', '784'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('225', 'GB', 'United Kingdom', 'GBR', '826'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('226', 'US', 'United States', 'USA', '840'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('227', 'UM', 'United States Minor Outlying Islands', 'UMI', '581'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('228', 'UY', 'Uruguay', 'URY', '858'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('229', 'UZ', 'Uzbekistan', 'UZB', '860'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('230', 'VU', 'Vanuatu', 'VUT', '548'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('231', 'VE', 'Venezuela', 'VEN', '862'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('232', 'VN', 'Viet Nam', 'VNM', '704'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('233', 'VG', 'Virgin Islands, British', 'VGB', '92'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('234', 'VI', 'Virgin Islands, U.s.', 'VIR', '850'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('235', 'WF', 'Wallis and Futuna', 'WLF', '876'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('236', 'EH', 'Western Sahara', 'ESH', '732'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('237', 'YE', 'Yemen', 'YEM', '887'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('238', 'ZM', 'Zambia', 'ZMB', '894'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('239', 'ZW', 'Zimbabwe', 'ZWE', '716'); #EOQ
INSERT INTO `cc4_CubeCart_geo_country` VALUES('240', 'ME', 'Montenegro', '', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_geo_zone`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_geo_zone`
--

CREATE TABLE `cc4_CubeCart_geo_zone` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `country_id` int(4) unsigned NOT NULL default '0',
  `abbrev` varchar(4) collate utf8_unicode_ci NOT NULL default '',
  `name` varchar(40) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `countryId` (`country_id`),
  KEY `country_id` (`country_id`)
) ENGINE=MyISAM AUTO_INCREMENT=572 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_geo_zone`
--

INSERT INTO `cc4_CubeCart_geo_zone` VALUES('130', '199', 'ACOR', 'A CoruÃ±a'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('104', '206', 'AG', 'Aargau'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('492', '225', 'ABD', 'Aberdeenshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('1', '226', 'AL', 'Alabama'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('2', '226', 'AK', 'Alaska'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('131', '199', 'ALAV', 'Alava'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('132', '199', 'ALBA', 'Albacete'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('66', '38', 'AB', 'Alberta'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('133', '199', 'ALIC', 'Alicante'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('134', '199', 'ALME', 'Almeria'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('3', '226', 'AS', 'American Samoa'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('525', '225', 'AGY', 'Anglesey'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('493', '225', 'ANS', 'Angus'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('543', '225', 'ANT', 'Antrim'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('106', '206', 'APP', 'Appenzell Ausserrhoden'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('105', '206', 'AI', 'Appenzell Innerrhoden'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('494', '225', 'ARL', 'Argyll'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('4', '226', 'AZ', 'Arizona'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('5', '226', 'AR', 'Arkansas'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('544', '225', 'ARM', 'Armagh'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('6', '226', 'AF', 'Armed Forces Africa'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('7', '226', 'AA', 'Armed Forces Americas'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('8', '226', 'AC', 'Armed Forces Canada'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('9', '226', 'AE', 'Armed Forces Europe'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('10', '226', 'AM', 'Armed Forces Middle East'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('11', '226', 'AP', 'Armed Forces Pacific'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('135', '199', 'ASTU', 'Asturias'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('563', '13', 'ACT', 'Australian Capital Territory'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('136', '199', 'AVIL', 'Avila'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('441', '225', 'AVN', 'Avon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('495', '225', 'AYR', 'Ayrshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('137', '199', 'BADA', 'Badajoz'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('80', '80', 'BAW', 'Baden-WÃ¼rttemberg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('138', '199', 'BALE', 'Baleares'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('496', '225', 'BAN', 'Banffshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('139', '199', 'BARC', 'Barcelona'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('108', '206', 'BLA', 'Basel-Landschaft'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('109', '206', 'BS', 'Basel-Stadt'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('81', '80', 'BAY', 'Bayern'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('442', '225', 'BDF', 'Bedfordshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('443', '225', 'BRK', 'Berkshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('82', '80', 'BER', 'Berlin'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('107', '206', 'BE', 'Bern'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('497', '225', 'BEW', 'Berwickshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('83', '80', 'BRG', 'Brandenburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('526', '225', 'BRN', 'Brecknockshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('84', '80', 'BRE', 'Bremen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('67', '38', 'BC', 'British Columbia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('444', '225', 'BKM', 'Buckinghamshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('102', '14', 'BL', 'Burgenland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('140', '199', 'BURG', 'Burgos'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('498', '225', 'BUT', 'Bute'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('141', '199', 'CACE', 'Caceres'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('142', '199', 'CADI', 'Cadiz'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('527', '225', 'CAE', 'Caernarfonshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('499', '225', 'CAI', 'Caithness'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('12', '226', 'CA', 'California'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('445', '225', 'CAM', 'Cambridgeshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('143', '199', 'CANT', 'Cantabria'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('528', '225', 'CAD', 'Cardiganshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('415', '103', 'CW', 'Carlow'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('529', '225', 'CRR', 'Carmarthenshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('144', '199', 'CAST', 'Castellon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('416', '103', 'CN', 'Cavan'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('145', '199', 'CEUT', 'Ceuta'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('550', '225', 'GGY', 'Channel Islands'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('446', '225', 'CHS', 'Cheshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('146', '199', 'CIUD', 'Ciudad Real'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('500', '225', 'CLK', 'Clackmannanshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('417', '103', 'CE', 'Clare'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('447', '225', 'CLV', 'Cleveland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('530', '225', 'CLW', 'Clwyd'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('13', '226', 'CO', 'Colorado'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('14', '226', 'CT', 'Connecticut'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('147', '199', 'CORD', 'Cordoba'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('418', '103', 'C', 'Cork'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('448', '225', 'CON', 'Cornwall'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('454', '225', 'DUR', 'County Durham'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('501', '225', 'CRO', 'Cromartyshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('148', '199', 'CUEN', 'Cuenca'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('449', '225', 'CUL', 'Cumberland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('450', '225', 'CMA', 'Cumbria'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('15', '226', 'DE', 'Delaware'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('531', '225', 'DEN', 'Denbighshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('451', '225', 'DBY', 'Derbyshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('452', '225', 'DEV', 'Devon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('16', '226', 'DC', 'District of Columbia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('419', '103', 'DL', 'Donegal'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('453', '225', 'DOR', 'Dorset'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('546', '225', 'DOW', 'Down'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('551', '150', 'DR', 'Drenthe'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('420', '103', 'D', 'Dublin'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('502', '225', 'DFS', 'Dumfriesshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('503', '225', 'DNB', 'Dunbartonshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('532', '225', 'DFD', 'Dyfed'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('504', '225', 'ELN', 'East Lothian'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('455', '225', 'ESX', 'East Sussex'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('456', '225', 'ESS', 'Essex'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('17', '226', 'FM', 'Federated States Of Micronesia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('547', '225', 'FER', 'Fermanagh'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('505', '225', 'FIF', 'Fife'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('552', '150', 'FL', 'Flevoland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('533', '225', 'FLN', 'Flintshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('18', '226', 'FL', 'Florida'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('110', '206', 'FR', 'Freiburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('553', '150', 'FR', 'Friesland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('421', '103', 'G', 'Galway'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('554', '150', 'GLD', 'Gelderland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('111', '206', 'GE', 'Genf'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('19', '226', 'GA', 'Georgia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('149', '199', 'GIRO', 'Girona'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('534', '225', 'GLA', 'Glamorgan'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('112', '206', 'GL', 'Glarus'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('457', '225', 'GLS', 'Gloucestershire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('150', '199', 'GRAN', 'Granada'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('113', '206', 'JUB', 'GraubÃ¼nden'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('470', '225', 'GTL', 'Greater London'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('469', '225', 'GTM', 'Greater Manchester'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('555', '150', 'GR', 'Groningen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('151', '199', 'GUAD', 'Guadalajara'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('20', '226', 'GU', 'Guam'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('549', '225', 'JEY', 'Guernsey'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('152', '199', 'GUIP', 'Guipuzcoa'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('535', '225', 'GNT', 'Gwent'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('536', '225', 'GWN', 'Gwynedd'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('85', '80', 'HAM', 'Hamburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('458', '225', 'HAM', 'Hampshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('21', '226', 'HI', 'Hawaii'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('459', '225', 'HWR', 'Hereford and Worcester'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('460', '225', 'HEF', 'Herefordshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('461', '225', 'HRT', 'Hertfordshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('86', '80', 'HES', 'Hessen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('153', '199', 'HUEL', 'Huelva'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('154', '199', 'HUES', 'Huesca'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('462', '225', 'HUM', 'Humberside'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('463', '225', 'HUN', 'Huntingdonshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('22', '226', 'ID', 'Idaho'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('23', '226', 'IL', 'Illinois'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('24', '226', 'IN', 'Indiana'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('506', '225', 'INV', 'Inverness-shire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('25', '226', 'IA', 'Iowa'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('464', '225', 'IOW', 'Isle of Wight'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('155', '199', 'JAEN', 'Jaen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('114', '206', 'JU', 'Jura'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('99', '14', 'KN', 'KÃ¤rnten'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('26', '226', 'KS', 'Kansas'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('465', '225', 'KEN', 'Kent'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('27', '226', 'KY', 'Kentucky'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('422', '103', 'KY', 'Kerry'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('423', '103', 'KE', 'Kildare'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('424', '103', 'KK', 'Kilkenny'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('507', '225', 'KRS', 'Kinross-shire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('508', '225', 'KKD', 'Kirkcudbrightshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('156', '199', 'LAR', 'La Rioja'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('509', '225', 'LAN', 'Lanarkshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('466', '225', 'LAN', 'Lancashire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('425', '103', 'LS', 'Laoighis'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('157', '199', 'LAS', 'Las Palmas'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('467', '225', 'LEI', 'Leicestershire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('426', '103', 'LM', 'Leitrim'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('158', '199', 'LEON', 'Leon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('556', '150', 'LI', 'Limburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('427', '103', 'LK', 'Limerick'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('468', '225', 'LIN', 'Lincolnshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('159', '199', 'LLEI', 'Lleida'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('545', '225', 'LDY', 'Londonderry'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('428', '103', 'LD', 'Longford'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('28', '226', 'LA', 'Louisiana'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('429', '103', 'LH', 'Louth'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('160', '199', 'LUGO', 'Lugo'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('115', '206', 'LU', 'Luzern'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('161', '199', 'MADR', 'Madrid'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('29', '226', 'ME', 'Maine'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('162', '199', 'MALA', 'Malaga'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('68', '38', 'MB', 'Manitoba'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('30', '226', 'MH', 'Marshall Islands'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('31', '226', 'MD', 'Maryland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('32', '226', 'MA', 'Massachusetts'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('430', '103', 'MO', 'Mayo'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('431', '103', 'MH', 'Meath'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('87', '80', 'MEC', 'Mecklenburg-Vorpommern'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('163', '199', 'MELI', 'Melilla'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('537', '225', 'MER', 'Merionethshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('471', '225', 'MSY', 'Merseyside'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('33', '226', 'MI', 'Michigan'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('472', '225', 'MDX', 'Middlesex'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('510', '225', 'MLN', 'Midlothian'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('34', '226', 'MN', 'Minnesota'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('35', '226', 'MS', 'Mississippi'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('36', '226', 'MO', 'Missouri'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('432', '103', 'MN', 'Monaghan'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('538', '225', 'MON', 'Monmouthshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('37', '226', 'MT', 'Montana'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('539', '225', 'MGY', 'Montgomeryshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('511', '225', 'MOR', 'Moray'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('164', '199', 'MURC', 'Murcia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('512', '225', 'NAI', 'Nairnshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('165', '199', 'NAVA', 'Navarra'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('38', '226', 'NE', 'Nebraska'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('116', '206', 'NEU', 'Neuenburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('39', '226', 'NV', 'Nevada'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('70', '38', 'NB', 'New Brunswick'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('40', '226', 'NH', 'New Hampshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('41', '226', 'NJ', 'New Jersey'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('42', '226', 'NM', 'New Mexico'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('564', '13', 'NSW', 'New South Wales'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('43', '226', 'NY', 'New York'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('69', '38', 'NL', 'Newfoundland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('117', '206', 'NW', 'Nidwalden'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('96', '14', 'NO', 'NiederÃ–sterreich'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('79', '80', 'NDS', 'Niedersachsen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('557', '150', 'NB', 'Noord-Brabant'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('558', '150', 'NH', 'Noord-Holland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('88', '80', 'NRW', 'Nordrhein-Westfalen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('473', '225', 'NFK', 'Norfolk'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('44', '226', 'NC', 'North Carolina'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('45', '226', 'ND', 'North Dakota'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('474', '225', 'NTH', 'Northamptonshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('46', '226', 'MP', 'Northern Mariana Islands'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('565', '13', 'NT', 'Northern Territory'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('475', '225', 'NBL', 'Northumberland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('72', '38', 'NT', 'Northwest Territories'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('476', '225', 'NTT', 'Nottinghamshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('71', '38', 'NS', 'Nova Scotia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('73', '38', 'NU', 'Nunavut'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('97', '14', 'OO', 'OberÃ–sterreich'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('118', '206', 'OW', 'Obwalden'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('433', '103', 'OY', 'Offaly'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('47', '226', 'OH', 'Ohio'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('48', '226', 'OK', 'Oklahoma'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('74', '38', 'ON', 'Ontario'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('49', '226', 'OR', 'Oregon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('513', '225', 'OKI', 'Orkney'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('166', '199', 'OURE', 'Ourense'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('559', '150', 'OV', 'Overijssel'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('477', '225', 'OXF', 'Oxfordshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('50', '226', 'PW', 'Palau'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('167', '199', 'PALE', 'Palencia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('514', '225', 'PEE', 'Peeblesshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('540', '225', 'PEM', 'Pembrokeshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('51', '226', 'PA', 'Pennsylvania'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('515', '225', 'PER', 'Perthshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('168', '199', 'PONT', 'Pontevedra'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('541', '225', 'POW', 'Powys'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('75', '38', 'PE', 'Prince Edward Island'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('52', '226', 'PR', 'Puerto Rico'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('76', '38', 'QC', 'Quebec'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('566', '13', 'QLD', 'Queensland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('542', '225', 'RAD', 'Radnorshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('516', '225', 'RFW', 'Renfrewshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('89', '80', 'RHE', 'Rheinland-Pfalz'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('53', '226', 'RI', 'Rhode Island'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('434', '103', 'RN', 'Roscommon'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('517', '225', 'ROC', 'Ross'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('518', '225', 'ROX', 'Roxburghshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('478', '225', 'RUT', 'Rutland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('90', '80', 'SAR', 'Saarland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('91', '80', 'SAS', 'Sachsen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('92', '80', 'SAC', 'Sachsen-Anhalt'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('169', '199', 'SALA', 'Salamanca'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('98', '14', 'SB', 'Salzburg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('170', '199', 'SANT', 'Santa Cruz de Tenerife'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('77', '38', 'SK', 'Saskatchewan'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('120', '206', 'SH', 'Schaffhausen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('93', '80', 'SCN', 'Schleswig-Holstein'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('122', '206', 'SZ', 'Schwyz'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('171', '199', 'SEGO', 'Segovia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('519', '225', 'SEL', 'Selkirkshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('172', '199', 'SEVI', 'Sevilla'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('520', '225', 'SHI', 'Shetland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('479', '225', 'SAL', 'Shropshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('435', '103', 'SO', 'Sligo'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('121', '206', 'SO', 'Solothurn'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('480', '225', 'SOM', 'Somerset'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('173', '199', 'SORI', 'Soria'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('567', '13', 'SA', 'South Australia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('54', '226', 'SC', 'South Carolina'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('55', '226', 'SD', 'South Dakota'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('119', '206', 'SG', 'St. Gallen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('481', '225', 'STS', 'Staffordshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('100', '14', 'ST', 'Steiermark'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('521', '225', 'STI', 'Stirlingshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('482', '225', 'SFK', 'Suffolk'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('483', '225', 'SRY', 'Surrey'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('484', '225', 'SSX', 'Sussex'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('522', '225', 'SUT', 'Sutherland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('174', '199', 'TARR', 'Tarragona'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('568', '13', 'TAS', 'Tasmania'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('56', '226', 'TN', 'Tennessee'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('175', '199', 'TERU', 'Teruel'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('124', '206', 'TE', 'Tessin'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('57', '226', 'TX', 'Texas'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('94', '80', 'THE', 'ThÃ¼ringen'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('123', '206', 'TG', 'Thurgau'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('436', '103', 'TA', 'Tipperary'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('101', '14', 'TI', 'Tirol'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('176', '199', 'TOLE', 'Toledo'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('485', '225', 'TWR', 'Tyne and Wear'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('548', '225', 'TYR', 'Tyrone'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('125', '206', 'UR', 'Uri'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('58', '226', 'UT', 'Utah'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('560', '150', 'UT', 'Utrecht'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('177', '199', 'VALE', 'Valencia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('178', '199', 'VALL', 'Valladolid'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('59', '226', 'VT', 'Vermont'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('569', '13', 'VIC', 'Victoria'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('60', '226', 'VI', 'Virgin Islands'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('61', '226', 'VA', 'Virginia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('179', '199', 'VIZC', 'Vizcaya'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('103', '14', 'VB', 'Voralberg'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('126', '206', 'VD', 'Waadt'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('127', '206', 'VS', 'Wallis'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('486', '225', 'WAR', 'Warwickshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('62', '226', 'WA', 'Washington'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('437', '103', 'WD', 'Waterford'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('523', '225', 'WLN', 'West Lothian'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('487', '225', 'WMD', 'West Midlands'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('63', '226', 'WV', 'West Virginia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('570', '13', 'WA', 'Western Australia'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('438', '103', 'WH', 'Westmeath'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('488', '225', 'WES', 'Westmorland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('439', '103', 'WX', 'Wexford'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('440', '103', 'WW', 'Wicklow'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('95', '14', 'WIE', 'Wien'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('524', '225', 'WIG', 'Wigtownshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('489', '225', 'WIL', 'Wiltshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('64', '226', 'WI', 'Wisconsin'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('490', '225', 'WOR', 'Worcestershire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('65', '226', 'WY', 'Wyoming'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('491', '225', 'YOK', 'Yorkshire'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('78', '38', 'YT', 'Yukon Territory'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('129', '206', 'ZH', 'ZÃ¼rich'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('180', '199', 'ZAMO', 'Zamora'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('181', '199', 'ZARA', 'Zaragoza'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('561', '150', 'ZL', 'Zeeland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('128', '206', 'ZG', 'Zug'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('562', '150', 'ZH', 'Zuid-Holland'); #EOQ
INSERT INTO `cc4_CubeCart_geo_zone` VALUES('571', '225', '--', '-- Please Select --'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_history`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_history`
--

CREATE TABLE `cc4_CubeCart_history` (
  `id` int(11) NOT NULL auto_increment,
  `version` varchar(50) collate utf8_unicode_ci NOT NULL,
  `time` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_history`
--

INSERT INTO `cc4_CubeCart_history` VALUES('3', '4.0.0', '1352289855'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('4', '4.0.3', '1352289862'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('5', '4.1.0', '1352289869'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('6', '4.1.1', '1352289875'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('7', '4.2.0', '1352289881'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('8', '4.2.3', '1352289887'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('9', '4.3.0', '1352289894'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('10', '4.3.1', '1352289900'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('11', '4.3.6', '1352289906'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('12', '4.3.7', '1352289912'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('13', '4.3.9', '1352289919'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('14', '4.4.5', '1352289925'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('15', '5.0.0b1', '1352289944'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('16', '5.0.0b2', '1352289950'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('17', '5.0.0b4', '1352289956'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('18', '5.0.0b5', '1352289962'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('19', '5.0.0b6', '1352289969'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('20', '5.0.0b7', '1352289975'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('21', '5.0.1', '1352289981'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('22', '5.0.2', '1352289987'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('23', '5.0.3', '1352289993'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('24', '5.0.4', '1352289999'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('25', '5.0.5', '1352290005'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('26', '5.0.6', '1352290011'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('27', '5.0.7', '1352290018'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('28', '5.0.8', '1352290024'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('29', '5.0.9', '1352290030'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('30', '5.1.0', '1352290036'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('31', '5.1.1', '1352290043'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('32', '5.1.2', '1352290049'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('33', '5.1.3', '1352290055'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('34', '5.1.4', '1352290061'); #EOQ
INSERT INTO `cc4_CubeCart_history` VALUES('35', '5.1.5', '1352290067'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_hooks`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_hooks`
--

CREATE TABLE `cc4_CubeCart_hooks` (
  `hook_id` int(10) unsigned NOT NULL auto_increment,
  `plugin` varchar(100) collate utf8_unicode_ci NOT NULL,
  `hook_name` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'A descriptive name for the hook',
  `enabled` tinyint(1) unsigned NOT NULL default '0' COMMENT 'All hooks should be disabled by default',
  `trigger` varchar(255) collate utf8_unicode_ci NOT NULL COMMENT 'The trigger used to call the hook',
  `filepath` text collate utf8_unicode_ci NOT NULL,
  `priority` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`hook_id`),
  KEY `trigger` (`trigger`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_hooks`
--

INSERT INTO `cc4_CubeCart_hooks` VALUES('35', 'Fusion', 'Standardise Latest Products', '1', 'class.cubecart.display_homepage', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('34', 'Fusion', 'Standardise Featured Product', '1', 'class.gui.display_random_product', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('33', 'Fusion', 'Standardise Sale Items', '1', 'class.gui.display_sale_items', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('32', 'Fusion', 'Standardise Popular Products', '1', 'class.gui.display_popular_products', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('31', 'Fusion', 'Fusion Configuration Panel Link', '1', 'admin.navigation', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('30', 'Fusion', 'Fusion Enhancements', '1', 'controller.index', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('29', 'Fusion', 'Expose Fusion to Skin', '1', 'class.gui.css', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('28', 'Fusion', 'Fusion Configuration Panel', '1', 'admin.fusion', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('10', 'Google_Checkout', 'ACP - Order details tab', '1', 'admin.order.index.display', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('11', 'Google_Checkout', 'Admin - Post-processing plugin', '1', 'admin.order.index.post_process', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('12', 'Google_Checkout', 'ACP - Order Transactions log plugin', '1', 'admin.order.index.transaction', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('13', 'Google_Checkout', 'Checkout Button', '1', 'class.cubecart.display_basket.alternate', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('14', 'Google_Checkout', 'Gateway Processor', '1', 'class.cubecart.display_gateways', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('15', 'Google_Checkout', 'Place Order plugin', '1', 'class.order.place_order', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('16', 'Google_Checkout', 'Order Status plugin', '1', 'class.order.order_status', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('17', 'Google_Checkout', 'Callback Handler', '1', 'class.cubecart.construct.callback.gateway', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('18', 'PayPal_Pro', 'Admin Processing', '1', 'admin.order.index.post_process', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('19', 'PayPal_Pro', 'Admin Pre-display', '1', 'admin.order.index.pre_display', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('20', 'PayPal_Pro', 'Transaction display', '1', 'admin.order.index.transaction', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('21', 'PayPal_Pro', 'Empty Basket', '1', 'class.cart.clear', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('22', 'PayPal_Pro', 'Callback Handler', '1', 'class.cubecart.construct.callback.gateway', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('23', 'PayPal_Pro', 'Cancel Process Handler', '1', 'class.cubecart.construct.cancel', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('24', 'PayPal_Pro', 'Checkout Confirmation', '1', 'class.cubecart.construct.confirm', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('25', 'PayPal_Pro', 'Payment Handler', '1', 'class.cubecart.construct.gateway', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('26', 'PayPal_Pro', 'Checkout Button', '1', 'class.cubecart.display_basket.alternate', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('27', 'PayPal_Pro', 'Gateways for Payments Pro', '1', 'class.cubecart.display_gateways', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_hooks` VALUES('36', 'Fusion', 'Standardise Related Products', '1', 'class.cubecart.display_basket', '', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_image_index`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_image_index`
--

CREATE TABLE `cc4_CubeCart_image_index` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL,
  `img` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `file_id` int(10) unsigned NOT NULL,
  `main_img` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `productId` (`product_id`),
  KEY `file_id` (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_image_index`
--

INSERT INTO `cc4_CubeCart_image_index` VALUES('1', '17', '_images/ProductImages/Lycra/DanceWear/pnpLycra-2.jpg', '229', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('2', '17', '_images/ProductImages/Lycra/DanceWear/pnpLycra-3.jpg', '230', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('3', '18', '_images/ProductImages/Lycra/DanceWear/pnpLycra-6.jpg', '233', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('4', '18', '_images/ProductImages/Lycra/DanceWear/pnpLycra-5.jpg', '232', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('5', '19', '_images/ProductImages/Lycra/DanceWear/pnpLycra-12.jpg', '239', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('6', '21', '_images/ProductImages/Lycra/DanceWear/pnpLycra-10.jpg', '237', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('7', '22', '_images/ProductImages/Lycra/DanceWear/pnpLycra-17.jpg', '242', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('8', '24', '_images/ProductImages/Lycra/DanceWear/Dancewear-21.jpg', '216', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('9', '24', '_images/ProductImages/Lycra/DanceWear/Dancewear-22.jpg', '217', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('10', '28', '_images/ProductImages/Lycra/DanceWear/Dancewear-27.jpg', '222', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('11', '33', '_images/ProductImages/Lycra/DanceWear/ComingSoon-4.jpg', '204', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('15', '47', '_images/SecondHand/BlueSwirl-2.jpg', '294', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('16', '48', '_images/SecondHand/BlueSilver-2.jpg', '292', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('13', '46', '_images/SecondHand/PinkSlow_2.jpg', '297', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('14', '46', '_images/SecondHand/PinkSlow_3.jpg', '298', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('17', '50', '_images/ProductImages/Lycra/DanceWear/Dancewear-16.jpg', '211', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('18', '50', '_images/ProductImages/Lycra/DanceWear/Dancewear-17.jpg', '212', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('19', '50', '_images/ProductImages/Lycra/DanceWear/Dancewear-18.jpg', '213', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('20', '50', '_images/ProductImages/Lycra/DanceWear/DanceWear-31.jpg', '226', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('21', '50', '_images/ProductImages/Lycra/DanceWear/pnpLycra-10.jpg', '237', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('22', '50', '_images/ProductImages/Lycra/DanceWear/pnpLycra-16.jpg', '241', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('23', '51', '_images/ProductImages/Lycra/DanceWear/pnpLycra-19.jpg', '244', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('24', '51', '_images/ProductImages/Lycra/DanceWear/pnpLycra-20.jpg', '245', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('25', '51', '_images/ProductImages/Lycra/DanceWear/pnpLycra-21.jpg', '246', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('26', '52', '_images/ProductImages/Lycra/DanceWear/pnpLycra-21.jpg', '246', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('27', '52', '_images/ProductImages/Lycra/DanceWear/pnpLycra-26.jpg', '251', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('28', '53', '_images/ProductImages/Lycra/DanceWear/pnpLycra-32.jpg', '257', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('29', '53', '_images/ProductImages/Lycra/DanceWear/pnpLycra-33.jpg', '258', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('30', '54', '_images/ProductImages/Lycra/DanceWear/Dancewear-11.jpg', '206', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('31', '54', '_images/ProductImages/Lycra/DanceWear/Dancewear-12.jpg', '207', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('32', '54', '_images/ProductImages/Lycra/DanceWear/Dancewear-13.jpg', '208', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('33', '54', '_images/ProductImages/Lycra/DanceWear/Dancewear-14.jpg', '209', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('34', '54', '_images/ProductImages/Lycra/DanceWear/DanceWear-31.jpg', '226', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('35', '54', '_images/ProductImages/Lycra/DanceWear/pnpLycra-36.jpg', '261', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('36', '54', '_images/ProductImages/Lycra/DanceWear/pnpLycra-35.jpg', '260', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('37', '54', '_images/ProductImages/Lycra/DanceWear/pnpLycra-37.jpg', '262', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('38', '55', '_images/SecondHand/pnpSecondhand-2.jpg', '300', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('39', '55', '_images/SecondHand/pnpSecondhand-4.jpg', '302', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('40', '55', '_images/SecondHand/pnpSecondhand-5.jpg', '303', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('41', '55', '_images/SecondHand/pnpSecondhand-6.jpg', '304', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('42', '55', '_images/SecondHand/pnpSecondhand-7.jpg', '305', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('43', '58', '_images/ProductImages/2nd Hand/green_frills_back.jpeg', '173', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('44', '61', '_images/ProductImages/Brand New PnP/PnP Dance-2.jpg', '190', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('45', '61', '_images/ProductImages/Brand New PnP/PnP Dance-3.jpg', '191', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('46', '62', '_images/ProductImages/Tracksuits/PnP Dance Tracksuits (10 of 12).jpg', '286', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('47', '62', '_images/ProductImages/Tracksuits/PnP Dance Tracksuits (11 of 12).jpg', '287', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('48', '62', '_images/ProductImages/Tracksuits/PnP Dance Tracksuits (12 of 12).jpg', '288', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('49', '62', '_images/ProductImages/Tracksuits/PnP Dance Tracksuits (8 of 12).jpg', '284', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('50', '62', '_images/ProductImages/Tracksuits/PnP Dance Tracksuits (9 of 12).jpg', '285', '0'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('51', '2', '', '177', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('52', '3', '', '178', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('53', '4', '', '175', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('54', '5', '', '182', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('55', '6', '', '183', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('56', '7', '', '186', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('57', '8', '', '180', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('58', '9', '', '179', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('59', '10', '', '181', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('60', '11', '', '188', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('61', '12', '', '187', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('62', '15', '', '185', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('63', '16', '', '184', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('64', '17', '', '228', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('65', '18', '', '231', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('66', '22', '', '241', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('67', '19', '', '234', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('68', '20', '', '238', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('69', '21', '', '236', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('70', '23', '', '225', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('71', '25', '', '206', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('72', '24', '', '214', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('73', '26', '', '226', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('74', '28', '', '221', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('75', '29', '', '201', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('76', '31', '', '202', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('77', '59', '', '174', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('78', '34', '', '161', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('79', '36', '', '160', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('80', '37', '', '159', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('81', '38', '', '158', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('82', '39', '', '158', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('83', '40', '', '165', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('84', '41', '', '166', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('85', '42', '', '168', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('86', '43', '', '164', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('87', '45', '', '163', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('88', '61', '', '189', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('89', '56', '', '178', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('90', '49', '', '306', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('91', '50', '', '210', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('92', '51', '', '247', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('93', '52', '', '250', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('94', '53', '', '256', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('95', '54', '', '259', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('96', '55', '', '301', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('97', '58', '', '172', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('98', '60', '', '255', '1'); #EOQ
INSERT INTO `cc4_CubeCart_image_index` VALUES('99', '57', '', '195', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_inventory`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_inventory`
--

CREATE TABLE `cc4_CubeCart_inventory` (
  `product_id` int(10) unsigned NOT NULL auto_increment,
  `product_code` varchar(60) collate utf8_unicode_ci default NULL,
  `quantity` int(16) NOT NULL default '1',
  `description` text collate utf8_unicode_ci,
  `price` decimal(16,2) NOT NULL default '0.00',
  `name` varchar(250) collate utf8_unicode_ci default NULL,
  `cat_id` int(16) NOT NULL default '0',
  `popularity` bigint(64) unsigned NOT NULL default '0',
  `sale_price` decimal(16,2) NOT NULL default '0.00',
  `cost_price` decimal(16,2) NOT NULL default '0.00',
  `stock_level` int(11) NOT NULL default '0',
  `stock_warning` int(10) unsigned NOT NULL default '0',
  `use_stock_level` tinyint(1) unsigned NOT NULL default '1',
  `digital` int(4) unsigned NOT NULL default '0',
  `digital_path` varchar(255) collate utf8_unicode_ci default NULL,
  `product_weight` decimal(10,3) default NULL,
  `tax_type` int(10) unsigned NOT NULL default '0',
  `tax_inclusive` tinyint(1) NOT NULL default '0',
  `featured` tinyint(1) unsigned NOT NULL default '1',
  `seo_meta_title` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_keywords` text collate utf8_unicode_ci NOT NULL,
  `upc` varchar(20) collate utf8_unicode_ci default NULL,
  `date_added` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ems_pricing_set` int(11) NOT NULL default '0',
  `ems_quantity_prices` text collate utf8_unicode_ci NOT NULL,
  `ean` varchar(20) collate utf8_unicode_ci default NULL,
  `jan` varchar(20) collate utf8_unicode_ci default NULL,
  `isbn` varchar(20) collate utf8_unicode_ci default NULL,
  `status` tinyint(1) unsigned NOT NULL default '1',
  `manufacturer` int(10) unsigned default NULL,
  `condition` varchar(25) collate utf8_unicode_ci default NULL,
  `updated` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`product_id`),
  KEY `cat_id_2` (`cat_id`),
  FULLTEXT KEY `fulltext` (`product_code`,`name`,`description`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_inventory`
--

INSERT INTO `cc4_CubeCart_inventory` VALUES('2', '4MMASOII8', '1', '<p><b>4mm flat back acrylic rhinestone, &nbsp;Clear silver backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or anything you like!<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p><strong>Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.50', '144 4mm Clear Silverback Rhinestones/Crystals', '8', '277', '1.00', '0.00', '100', '0', '1', '0', '', '0.010', '0', '1', '1', '4mm Clear Silverback Rhinestones/Crystals', 'High Quality 4mm Clear Silverback Rhinestones/Crystals', 'clear, silverback,AB, 4mm, silverback', '0', '2011-04-05 09:05:08', '0', '5:0.90, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('3', '4MMJSGF79', '1', '<div class=\"SPText\">\r\n<p><span style=\"font-size: large; \"><strong>**** Back in Stock! ****</strong></span></p>\r\n<p>&nbsp;</p>\r\n<p><b>4mm Clear AB flat back acrylic rhinestone, silver  backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or  anything you like!&nbsp; <br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n</div>\r\n<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Clear AB Silverback Rhinestones/Crystals', '9', '343', '1.25', '0.00', '10', '0', '1', '0', '', '0.010', '0', '1', '1', '4mm Clear AB Silverback Rhinestones/Crystals', '4mm Clear AB Silverback rhinestones/Crystals', 'clear, AB, Clear AB, Silverback', '0', '2011-04-05 09:18:59', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('4', '4MMZD5579', '1', '<div class=\"SPText\">\r\n<p><b>4mm Orange AB flat back acrylic rhinestone, silver  backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or  anything you like!&nbsp; <br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Orange AB Silverback Rhinestones', '9', '268', '1.25', '0.00', '7', '0', '1', '0', '', '0.000', '0', '0', '1', 'Silverback Rhinestones in Orange', 'Silverback Rhinestones in Orange, crystals and jazzing up outfits', '', '0', '2011-04-05 09:31:56', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('5', '4MMMAZXF9', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Lemon AB flat back acrylic rhinestone, silver  backed.&nbsp; These  rhinestones are ideal for jazzing up any dance outfit or  anything you  like!&nbsp; <br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Lemon AB Silverback Rhinestones/Crystals', '9', '263', '1.25', '0.00', '140', '0', '1', '0', '', '0.010', '0', '1', '1', '4mm Lemon AB Silverback Rhinestones/Crystals', 'Silverback Rhinestones in Lemon for jazzing up any costume', '', '0', '2011-04-05 10:04:18', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('6', '4MMQXX7R9', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Mint AB flat back acrylic rhinestone, silver  backed.&nbsp; These  rhinestones are ideal for jazzing up any dance outfit or  anything you  like!&nbsp; <br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Mint AB Silverback Rhinestones/Crystals', '9', '252', '1.25', '0.00', '72', '0', '1', '0', '', '0.010', '0', '1', '1', 'Mint green silverback rhinestones', 'Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required', '', '0', '2011-04-05 10:05:19', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('7', '4MMROKAG9', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Purple AB flat back acrylic rhinestone, silver  backed.&nbsp; These  rhinestones are ideal for jazzing up any dance outfit or  anything you  like!&nbsp; <br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Purple AB Silverback Rhinestones/Crystals', '9', '273', '1.25', '0.00', '57', '0', '1', '0', '', '0.010', '0', '1', '1', 'Purple Silverback Rhinestones', 'Purple silverback Rhinestones for customising or jazzing any outfit!', '', '0', '2011-04-05 10:10:12', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('8', '4MMN5M8E6', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Clear flat back acrylic hotfix rhinestone.&nbsp; These  rhinestones are ideal for jazzing up any dance outfit or  anything you  like, they can be glued or ironed onto fabric.<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Clear Hotfix Rhinestones', '6', '278', '1.25', '0.00', '0', '0', '1', '0', '', '0.010', '0', '1', '1', 'Crystal Hotfix 4mm SS16', 'Crystal Hotfix 4mm SS16', '', '0', '2011-04-05 10:21:51', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('9', '144B6JUF7', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Clear AB flat back acrylic hotfix rhinestone.&nbsp; These  rhinestones  are ideal for jazzing up any dance outfit or  anything you  like, they  can be glued or ironed onto fabric.<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 4mm Clear AB Hotfix Rhinestones', '7', '373', '1.50', '0.00', '84', '0', '1', '0', '', '0.010', '0', '1', '1', 'Crystal AB Hotfix 4mm SS16', 'Crystal AB Hotfix 4mm SS16', '', '0', '2011-04-05 10:35:19', '0', '5:1.25, 10:1.00', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('10', '144LNOR07', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Emerald&nbsp; flat back acrylic hotfix rhinestone.&nbsp; These  rhinestones  are ideal for jazzing up any dance outfit or  anything you  like, they  can be glued or ironed onto fabric.<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 4mm Emerald AB Hotfix Rhinestones', '6', '290', '1.50', '0.00', '20', '0', '1', '0', '', '0.010', '0', '1', '1', 'Emerald Hotfix 4mm SS16', 'Emerald Hotfix 4mm SS16', '', '0', '2011-04-05 10:36:44', '0', '5:1.25, 10:1.00', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('11', '144KJU8H6', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Siam Ruby&nbsp; flat back acrylic hotfix rhinestone.&nbsp; These  rhinestones  are ideal for jazzing up any dance outfit or  anything you  like, they  can be glued or ironed onto fabric.<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Siam Ruby Hotfix Rhinestones', '6', '257', '1.25', '0.00', '13', '0', '1', '0', '', '0.010', '0', '1', '1', 'Siam Ruby Hotfix 4mm SS16', 'Siam Ruby Hotfix 4mm SS16 Rhinestones crystals', '', '0', '2011-04-05 10:37:36', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('12', '144UP7YH6', '1', '<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<div class=\"SPText\">\r\n<p><b>4mm Sapphire flat back acrylic hotfix rhinestone.&nbsp; These  rhinestones  are ideal for jazzing up any dance outfit or  anything you  like, they  can be glued or ironed onto fabric.<br />\r\n</b></p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n</div>\r\n</div>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Sapphire Hotfix Rhinestones', '6', '317', '1.25', '0.00', '28', '0', '1', '0', '', '0.010', '0', '1', '1', 'Sapphire Hotfix 4mm SS16', 'Sapphire Hotfix 4mm SS16 Rhinestones crystals', '', '0', '2011-04-05 10:39:52', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('14', 'TESA31', '1', 'This is the main copy for the product.<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '10.00', 'Test Product', '1', '0', '6.99', '0.00', '0', '0', '0', '0', '', '4.000', '1', '0', '1', '', '', '', '', '2011-05-17 08:29:32', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('15', '1007RLI32', '1', '<p>&nbsp;\r\n<meta charset=\"utf-8\"><b>4mm Pink AB flat back acrylic rhinestone, silver backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or anything you like! &nbsp;</b>         </meta>\r\n</p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinestones when ordering</b>.</p>\r\n<p>&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.75', '144 4mm Pink AB Silverback Rhinestones/Crystals', '9', '326', '1.25', '0.00', '47', '0', '1', '0', '', '0.010', '0', '1', '1', 'Light Pink Silverback 4mm SS16', 'Light Pink Silverback 4mm SS16 Rhinestones', '', '0', '2011-05-23 07:28:08', '0', '5:1.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('16', '100WNLLQ8', '1', '<p>&nbsp;\r\n<meta charset=\"utf-8\"><b>4mm Pink flat back acrylic rhinestone, silver backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or anything you like! &nbsp;</b>        </meta>\r\n</p>\r\n<p><b>Sold in bags of 1 gross (144), please state how many bags, not rhinestones when ordering</b>.</p>\r\n<p>&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.50', '144 4mm Pink Silverback Rhinestones/Crystals', '8', '279', '1.00', '0.00', '46', '0', '1', '0', '', '0.010', '3', '1', '1', '', '', '', '0', '2011-05-23 07:32:49', '0', '5:90.00, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('17', 'PNPQ33OT2', '1', '<p>Princess n Pickle Lycra cat suit with short arms and puffed sleeves made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie</p>\r\n<p>Available in various colours and sizes</p>\r\n<p><a onclick=\"window.open(this.href,&#39;DanceWearSizeGuide&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for acurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'PnP Lycra Catsuit with Puffed Sleeves', '15', '2047', '0.00', '0.00', '693', '0', '1', '0', '', '0.000', '0', '0', '1', 'Princess and Pickle :: Childrens PnP Lycra Catsuit', 'PnP Lycra Catsuit with Puffed Sleeves', 'dance, lycra, catsuit, puffed, sleeves, colours, sizes', '0', '2011-10-24 10:05:18', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('18', 'PNPE1NB815', '1', '<p>&nbsp;Princess n Pickle Lycra cat suit with long arms, keyhole back and halter neck made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">Available in various colours and sizes</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for acurate sizing</a></p>\r\n<div>&nbsp;</div>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'PnP Lycra Catsuit with Long Sleeves', '15', '1654', '0.00', '0.00', '539', '0', '1', '0', '', '0.000', '0', '0', '0', '', '', '', '0', '2011-11-11 10:01:37', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('22', 'PNPLJUSL15', '1', '<p>&nbsp;Princess n Pickle Lycra halter neck tie top made from high quality Funki Fabirc lycra</p>\r\n<p>Available in various colours and sizes</p>\r\n<p><a href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for accurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '10.99', 'PnP Lycra Halter Neck Tie Top', '15', '687', '0.00', '0.00', '346', '0', '1', '0', '', '0.000', '0', '0', '0', '', '', '', '0', '2011-11-11 13:01:08', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('19', 'PNPCZC3O2', '1', '<p>&nbsp;Princess n Pickle Lycra crop top with short arms and puffed sleeves made from high quality Funki Fabirc lycra</p>\r\n<p>Available in various colours and sizes</p>\r\n<p><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for accurate sizing</a></p>\r\n<div>&nbsp;</div>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '10.99', 'PnP Lycra Crop Top With Puff Sleeves', '15', '1704', '0.00', '0.00', '345', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2011-11-11 10:18:21', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('20', 'PNP8IHMB15', '1', '<p>&nbsp;Princess n Pickle Lycra shorts made from high quality Funki Fabirc lycra</p>\r\n<p>Available in various colours and sizes</p>\r\n<p><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for accurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '7.99', 'PnP Lycra Shorts', '15', '1233', '0.00', '0.00', '347', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2011-11-11 10:38:41', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('21', 'PNPCY14315', '1', '<p>&nbsp;Princess n Pickle Lycra leggings made from high quality Funki Fabirc lycra</p>\r\n<p>Available in various colours and sizes</p>\r\n<p><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.com\">Please see the size chart for accurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '9.99', 'PnP Lycra Leggings', '15', '1171', '0.00', '0.00', '345', '0', '1', '0', '', '0.000', '0', '0', '0', '', '', '', '0', '2011-11-11 10:52:34', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('23', 'ROC6WOSS15', '1', '<p>&nbsp;&nbsp;Pink rock and roll dance skirt in various colours, with a choice of different coloured netting</p>\r\n<div style=\"padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; \">\r\n<p>This skirt can be bought with a puffed sleve top and also accessories to make a complete dance outfit in different colours. &nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>***** These items are made to order please specify colour and netting colour as well as size *****</p>\r\n<p>&nbsp;</p>\r\n<p><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please check the size guide for accurate sizing</a></p>\r\n</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '19.99', 'Rock &#39;n&#39; Roll Skirt', '17', '695', '0.00', '0.00', '1049', '0', '1', '0', '', '0.000', '0', '1', '1', '', '', '', '0', '2011-11-18 06:19:55', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('25', 'ROCD0V6W15', '1', '<p>&nbsp;Rock &#39;n&#39; Roll Costume complete with stoned accessories. &nbsp;Available in a range of colours of Lycra and netting.</p>\r\n<p>&nbsp;</p>\r\n<p>***** These items are made to order please specify colour and netting colour as well as size *****</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '54.99', 'Rock &#39;n&#39; Roll Outfit', '17', '1116', '0.00', '0.00', '1050', '0', '1', '0', '', '0.000', '0', '1', '1', 'Rock &#39;n&#39; Roll Outfit', 'Dance wear Childrens dance wear with stoned accessories', '', '0', '2011-12-01 16:41:01', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('24', 'PUF1BUOU15', '1', '<p class=\"p1\">Princess n Pickle Lycra unitard with short arms and puffed sleeves made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie</p>\r\n<p class=\"p1\">Available in various colours and sizes</p>\r\n<p class=\"p1\"><a onclick=\"window.open(this.href,&#39;&#39;,&#39;resizable=yes,location=no,menubar=no,scrollbars=yes,status=no,toolbar=no,fullscreen=no,dependent=no,width=400,height=400,status&#39;); return false\" href=\"http://www.pnpdance.com/sizes.html\">Please see the size chart for acurate sizing</a></p>\r\n<p class=\"p2\">&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'Puffed sleeved unitard', '15', '525', '0.00', '0.00', '446', '0', '1', '0', '', '0.000', '0', '1', '0', 'Puffed sleeved unitard', 'Princess n Pickle Lycra unitard with short arms and puffed sleeves made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag, scrunchie and headband\r\n', '', '0', '2011-11-18 09:26:14', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('26', 'DISU2GEX15', '1', '<p>&nbsp;Tassled Belt Wrist bands Ankle bands Double Headband and Chocker please select colour and age when ordering from selections below</p>\r\n<p>These fabulous extras will enhance any dance costume, available with or without stones, please choose from the list whether you require crystal AB, crystal Clear or no stones. &nbsp;</p>\r\n<p>If you have any special measurement requirements please state the measurements in the comments box at check out thanks</p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-size: larger; \"><strong>For a particular colour of stones please email us or call. &nbsp;All contact details are on the </strong></span><strong><a target=\"_blank\" href=\"http://www.pnpdance.com/contact-us/info_2.html\"><span style=\"font-size: larger; \">Contact Us Page</span></a></strong><span style=\"font-size: larger; \"><strong> above.</strong></span></p>\r\n<div>&nbsp;</div>\r\n<p>&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '25.00', 'Disco Freestyle Dance Costume Accessories', '15', '1648', '0.00', '0.00', '718', '0', '1', '0', '', '0.000', '0', '1', '1', '', 'Tassled Belt Wrist bands Ankle bands Double Headband and Chocker Available in many colours, please specify on purchase.\r\n', '', '0', '2012-01-10 05:25:20', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('28', 'PNPU9D3J15', '1', '<p>&nbsp;Princess n Pickle Lycra unitard with long arms and high collar with large keyhole back, made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie</p>\r\n<p>(Product Shown is &pound;25 as the Lycra is special print)</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'PnP Lycra Unitard', '15', '449', '0.00', '0.00', '10', '0', '1', '0', '', '0.000', '0', '0', '1', '', 'Princess n Pickle Lycra unitard with long arms and high collar with large keyhole back, made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie', '', '0', '2012-01-10 06:01:48', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('29', 'SOLFXFW820', '1', '<p>&nbsp;</p>\r\n<p>&nbsp;A beautifully green Swarovski stoned freestyle disco solo costume, made to measure, looks stunning on the dance floor. &nbsp;</p>\r\n<p><strong>Only the green costume is for sale&nbsp;</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '60.00', 'Green Butterfly Costume', '20', '395', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2012-01-10 06:25:07', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('31', 'SOL3PQIZ15', '1', '<p>&nbsp;A beautiful peach and white slow costum, this has been stoned with Pink AB rhinestones. &nbsp;Looks stunning on the dance floor and has a great &quot;cute&quot; factor</p>\r\n<p>Age 3 immaculate condition - ONLY WORN ONCE!</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '30.00', 'Second hand Peach and White Slow Costume', '18', '390', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2012-01-10 06:31:58', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('59', 'ROCOAQTK18', '1', '<p>&nbsp;Under 6 Rock &#39;n&#39; roll costumes with tie back crop top and a full netted skirt, bright multi-coloured hearts all over. &nbsp;This costume is really cute and stand out on the dance floor.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>These are sold as the pair only</strong></p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P!</p>', '60.00', 'Rock n Roll Bright Pairs Costumes', '18', '235', '0.00', '0.00', '0', '0', '1', '0', '', '0.000', '0', '0', '1', 'Rock n Roll Bright Pairs Costumes', 'Under 6 Rock &#39;n&#39; roll costumes with tie back crop top and a full netted skirt, bright multi-coloured hearts all over.  This costume is really cute and stand out on the dance floor.', 'Under 6 Rock &#39;n&#39; roll costumes with tie back crop top and a full netted skirt, bright multi-coloured hearts all over.  This costume is really cute and stand out on the dance floor.', '0', '2012-09-04 08:12:19', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('34', '1004CGJD15', '1', '<p><strong>100 5mm (SS20) Topaz silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross (144) please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 5mm Topaz Silverback Rhinestones', '12', '143', '1.75', '0.00', '20', '0', '1', '0', '', '0.000', '0', '0', '1', '100 5mm Topaz Silverback Rhinestones', '100 5mm Topaz Silverback Rhinestones', '', '0', '2012-02-16 12:52:39', '0', '5:1.50, 10:1.25', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('35', '1004ZDAR12', '1', '<p>&nbsp;<strong>100 5mm (SS20) Purple silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross (144) please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 5mm Purple Silverback Rhinestones', '12', '141', '1.75', '0.00', '30', '0', '1', '0', '', '0.000', '0', '0', '1', '5mm (SS20) Purple Silverback Rhinestones', '100 5mm (SS20) Topaz silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.', '', '0', '2012-02-17 10:39:32', '0', '5:1.50, 10:1.25', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('36', '1001S4VU15', '1', '<p>&nbsp;<strong>100 5mm (SS20) Mint Green silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 5mm Mint Green Silverback Rhinestones', '12', '192', '1.75', '0.00', '30', '0', '1', '0', '', '0.000', '0', '0', '1', '5mm (SS20) Green Silverback Rhinestones', '100 5mm (SS20) Mint Green silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.\r\n', '', '0', '2012-02-17 10:40:19', '0', '5:1.50, 10:1.25', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('37', '100ROPLP12', '1', '<p>&nbsp;<strong>100 5mm (SS20) Hot Pink silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross (144) please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 5mm Hot Pink Silverback Rhinestones', '12', '190', '1.75', '0.00', '28', '0', '1', '0', '', '0.000', '0', '0', '1', '5mm (SS20) Hot Pink Silverback Rhinestones', '100 5mm (SS20) Hot Pink silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.\r\n', '', '0', '2012-02-17 10:42:44', '0', '5:1.50, 10:1.25', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('38', '100MSO1112', '1', '<p>&nbsp;<strong>100 5mm (SS20) Aqua Blue silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.25', '144 5mm Aqua Blue Silverback Rhinestones', '12', '175', '1.75', '0.00', '25', '0', '1', '0', '', '0.000', '0', '0', '1', '5mm (SS20) Aqua Blue Silverback Rhinestones', '100 5mm (SS20) Aqua Blue silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.\r\n', '', '0', '2012-02-17 10:46:05', '0', '5:1.50, 10:1.25', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('39', '1008QUBQ8', '1', '<p>&nbsp;<strong>100 4mm (SS16) aqua blue silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.</strong></p>\r\n<p><strong><br />\r\n</strong></p>\r\n<p><strong>Sold in quantities of 1 gross (144) please state how many bags of 144 you require</strong></p>\r\n<p>&nbsp;</p>\r\n<p><strong>note these are not Hotfix</strong></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '1.50', '144 4mm Aqua Blue Silverback Rhinestones/Crystals', '8', '156', '1.00', '0.00', '45', '0', '1', '0', '', '0.000', '0', '0', '1', '4mm aqua blue Silverback Rhinestones/Crystals', '100 4mm (SS16) aqua blue silverback Crystals / rhinestones ideal for jazzing up any costume or outfit.\r\n', '', '0', '2012-02-17 10:49:32', '0', '5:0.90, 10:0.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('40', '144RJFR723', '1', '<p>&nbsp;144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones</p>\r\n<p>Finest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!</p>\r\n<p>&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '3.50', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '23', '278', '0.00', '0.00', '73', '0', '1', '0', '', '0.000', '0', '0', '1', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '', '0', '2012-02-20 08:29:39', '0', '5:3.15, 10:2.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('41', '144IQ4WU23', '1', '<p>144 5mm (SS20) Crystal DMC Hotfix Rhinestones</p>\r\n<p>Finest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!</p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P on ALL orders!</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '3.50', '144 5mm (SS20) Crystal DMC Hotfix Rhinestones', '23', '267', '0.00', '0.00', '95', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2012-02-21 11:32:32', '0', '5:3.15, 10:2.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('42', '144OVGCZ23', '1', '<p>144 5mm (SS20) Siam Ruby DMC Hotfix Rhinestones</p>\r\n<p>Finest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!</p>\r\n<p>Free P&amp;P on All Orders</p>\r\n<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '3.50', '144 5mm (SS20) Siam Ruby DMC Hotfix Rhinestones', '23', '185', '0.00', '0.00', '80', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2012-02-21 11:34:14', '0', '5:3.15, 10:2.80', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('43', '144L7R8B15', '1', '<p>144 2mm (SS6) Fushia Pink DMC Hotfix Rhinestones</p>\r\n<p>Finest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!</p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P on all orders</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.50', '144 2mm (SS6) Fushia Pink AB DMC Hotfix Rhinestones', '23', '228', '0.00', '0.00', '46', '0', '1', '0', '', '0.000', '0', '0', '1', 'SS6 (2mm) DMC Cut HotfixRhinestones', '144 2mm (SS6) Fushia Pink DMC Hotfix Rhinestones\r\nFinest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!\r\n\r\n\r\n\r\nFree P&P on all orders', '', '0', '2012-02-21 11:34:52', '0', '5:2.25, 10:2.00', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('45', '1446YHP023', '1', '<p>&nbsp;144 2mm (SS6) Black DMC Hotfix Rhinestones</p>\r\n<p>Finest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!</p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P on all orders</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.50', '144 2mm (SS6) Black AB DMC Hotfix Rhinestones', '23', '191', '0.00', '0.00', '0', '0', '1', '0', '', '0.000', '0', '0', '1', 'SS6 (2mm) DMC Cut HotfixRhinestones', '144 2mm (SS6)Black DMC Hotfix Rhinestones\r\nFinest quality DMC cut sold by the gross (144), these rhinestones are absoultely stunning will add a lot of sparkle and shine to any costume!\r\n\r\n\r\n\r\nFree P&P on all orders', '', '0', '2012-02-21 11:39:38', '0', '5:2.25, 10:2.00', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('61', 'WOWRYL9S20', '1', '<p>&nbsp;WOW!! Brand new heavily blinged solo costume for sale age 8-10</p>\r\n<p>This is an original PnP Dance Creation heavily stoned and very colourful, will really stand out on the floor!</p>', '175.00', 'WOW! Brand new Solo Costume', '20', '303', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', 'WOW! Brand new Solo Costume', 'WOW!! Brand new heavily blinged solo costume for sale age 8-10\r\n\r\nThis is an original PnP Dance Creation heavily stoned and very colourful, will really stand out on the floor!', 'WOW!! Brand new heavily blinged solo costume for sale age 8-10\r\n\r\nThis is an original PnP Dance Creation heavily stoned and very colourful, will really stand out on the floor!', '0', '2012-09-06 05:53:03', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('56', '14401ZXZ14', '1', '<p>SS20 5<b style=\"color: rgb(102, 51, 102); font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; line-height: 14px; text-align: left; \">mm Clear AB flat back acrylic rhinestone, silver backed.&nbsp; These rhinestones are ideal for jazzing up any dance outfit or anything you like! &nbsp;</b></p>\r\n<p style=\"padding: 0px; border: 0px; outline: 0px; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; margin: 5px; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><b>Sold in bags of 1 gross (144), please state how many bags, not rhinstones when ordering</b>.</p>\r\n<p style=\"padding: 0px; border: 0px; outline: 0px; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; margin: 5px; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">&nbsp;</p>\r\n<p style=\"padding: 0px; border: 0px; outline: 0px; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; margin: 5px; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><strong style=\"padding: 0px; border: 0px; outline: 0px; font-style: inherit; font-family: inherit; vertical-align: baseline; \">Please note Silverbacks are NOT self adhesive and require glue to stick them, they are not HOTFIX, we sell Hotfix Rhinestones if required</strong></p>\r\n<p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '2.00', '144 SS20 5mm Clear AB Silverback Rhinestones/Crystals', '14', '372', '0.00', '0.00', '0', '0', '1', '0', '', '0.000', '0', '0', '1', '144 ss20 4mm Clear AB Silverback Rhinestones/Crystals', '144 ss20 5mm Clear AB Silverback Rhinestones/Crystals', '', '0', '2012-05-23 02:41:15', '0', '5:1.75, 10:1.50', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('49', 'SECEP3FL15', '1', '<div>Aqua blue and pink poodle rock and roll outfit, this outfit is so cute on the dance floor and stands out in the crowd, this was also a winning costume for the kids in the pic.&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>size will fit between a 4 - 6 year old.</div><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '40.00', 'Second Hand Aqua blue and pink poodle rock and roll outfit', '18', '324', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', 'Second Hand Aqua blue and pink poodle rock and roll outfit', 'Aqua blue and pink poodle rock and roll outfit, this outfit is so cute on the dance floor and stands out in the crowd, this was also a winning costume for the kids in the pic.', '', '0', '2012-04-23 07:34:42', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('50', 'COM6QECE15', '1', '<p>&nbsp;PnP Dance complete disco outfit which comprises of a halter neck tie top, leggings and stoned accesories</p>\r\n<p>The accessories set is made up of the following:</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>Tassled Belt Wrist bands Ankle bands Double Headband and Chocker please select colour and age when ordering from selections below,&nbsp;please choose from the list whether you require crystal AB, crystal Clear or no stones. &nbsp;</p>\r\n<p>If you have any special measurement requirements please state the measurements in the comments box at check out thanks</p>\r\n<p>&nbsp;</p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '49.99', 'Complete Disco Outfit', '15', '304', '0.00', '0.00', '699', '0', '1', '0', '', '0.000', '0', '0', '1', 'Complete Disco Outfit', 'PnP Dance complete disco outfit which comprises of a halter neck tie top, leggings and stoned accesories\r\n', '', '0', '2012-04-26 03:32:23', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('51', 'PNPU8J2P15', '1', '<p>&nbsp;<span style=\"color: rgb(102, 51, 102); font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; line-height: 14px; text-align: left; \">Princess n Pickle Lycra leotard with short arms and puffed sleeves made from high quality Funki Fabirc lycra</span></p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">Available in various colours and sizes</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><a href=\"http://www.pnpdance.com/sizes.html\" style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-style: inherit; font-family: inherit; vertical-align: baseline; color: rgb(216, 169, 219); text-decoration: none; \">Please see the size chart for accurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '15.00', 'PnP Lycra Leotard', '15', '276', '0.00', '0.00', '699', '0', '1', '0', '', '0.000', '0', '0', '1', 'PnP Lycra Leotard', 'Princess n Pickle Lycra leotard with short arms and puffed sleeves made from high quality Funki Fabirc lycra', '', '0', '2012-04-26 08:10:28', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('52', 'PNPZFZYC15', '1', '<p>&nbsp;<span style=\"color: rgb(102, 51, 102); font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; line-height: 14px; text-align: left; \">Princess n Pickle three quarter length lycra cat suit with short arms and puffed sleeves made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie</span></p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">Available in various colours and sizes</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><a href=\"http://www.pnpdance.com/dance-wear-size-guide/info_10.html\" style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-style: inherit; font-family: inherit; vertical-align: baseline; color: rgb(216, 169, 219); text-decoration: none; \" target=\"_blank\">Please see the size chart for acurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'PnP 3/4 Length Lycra Catsuit with Puffed Sleeves', '15', '353', '0.00', '0.00', '700', '0', '1', '0', '', '0.000', '0', '0', '1', 'PnP 3/4 Length Lycra Catsuit with Puffed Sleeves', 'Princess n Pickle three quarter length lycra cat suit with short arms and puffed sleeves made from high quality Funki Fabirc lycra, comes complete with matching drawstring accessory bag and scrunchie\r\n', '', '0', '2012-04-27 08:43:42', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('53', 'PNP4F8RP15', '1', '<p>&nbsp;<span style=\"color: rgb(102, 51, 102); font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; line-height: 14px; text-align: left; \">&nbsp;</span><span style=\"color: rgb(102, 51, 102); font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; line-height: 14px; text-align: left; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-style: inherit; vertical-align: baseline; \">Princess n Pickle Lycra leotard with long sleeves made from high quality Funki Fabirc lycra</span></p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">Available in various colours and sizes</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: &#39;Lucida Sans&#39;, &#39;Lucida Sans Unicode&#39;, &#39;Lucida Grande&#39;; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \"><a href=\"http://www.pnpdance.com/sizes.html\" style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-style: inherit; font-family: inherit; vertical-align: baseline; color: rgb(216, 169, 219); text-decoration: none; \">Please see the size chart for accurate sizing</a></p><p><strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>', '17.49', 'PnP Lycra Leotard with Long Sleeves', '15', '494', '0.00', '0.00', '700', '0', '1', '0', '', '0.000', '0', '0', '1', 'PnP Lycra Leotard with Long Sleeves', 'Princess n Pickle Lycra leotard with long sleeves made from high quality Funki Fabirc lycra\r\n', '', '0', '2012-04-30 08:09:35', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('54', 'ROBQUMQ17', '1', '<p>\r\n	&nbsp;&nbsp;<span style=\"color: rgb(102, 51, 102); font-family: \'Lucida Sans\', \'Lucida Sans Unicode\', \'Lucida Grande\'; line-height: 14px; text-align: left; \">Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories, also available without accessories or without stones..</span></p>\r\n<p>\r\n	This is for 2 outfits with all accessories. &nbsp;The price will reduce if stones or no acceories are selected.</p>\r\n<p>\r\n	<span style=\"color: rgb(102, 51, 102); font-family: \'Lucida Sans\', \'Lucida Sans Unicode\', \'Lucida Grande\'; line-height: 14px; text-align: left; \">Available in a range of colours of Lycra and netting.</span></p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: \'Lucida Sans\', \'Lucida Sans Unicode\', \'Lucida Grande\'; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">\r\n	&nbsp;</p>\r\n<p style=\"margin-top: 5px; margin-right: 5px; margin-bottom: 5px; margin-left: 5px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; border-top-width: 0px; border-right-width: 0px; border-bottom-width: 0px; border-left-width: 0px; border-style: initial; border-color: initial; border-image: initial; outline-width: 0px; outline-style: initial; outline-color: initial; font-family: \'Lucida Sans\', \'Lucida Sans Unicode\', \'Lucida Grande\'; vertical-align: baseline; color: rgb(102, 51, 102); line-height: 14px; text-align: left; \">\r\n	***** These items are made to order please specify colour and netting colour as well as size *****</p>\r\n<p>\r\n	<strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>\r\n', '99.99', 'Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories', '17', '561', '0.00', '0.00', '100', '0', '1', '0', '', '0.000', '0', '0', '1', 'Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories', 'Rock &#39;n&#39; Roll Pairs Costume complete with stoned accessories, also available without accessories or without stones..\r\nAvailable in a range of colours of Lycra and netting.', '', '0', '2012-05-02 11:00:59', '0', '', '', '', '', '1', '0', 'new', '2012-11-08 10:27:37'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('55', 'PRE3E3F618', '1', '<p>\r\n	Previously Owned Freestyle Disco Solo Costume for sale with matching head accessories &nbsp;</p>\r\n<p>\r\n	<strong>All Items take 3-5 working days to arrive, sometimes it is quicker</strong></p>\r\n', '60.00', 'Previously Owned Freestyle Disco Solo Costume', '18', '899', '0.00', '0.00', '0', '0', '1', '0', '', '0.000', '0', '0', '1', 'Previously Owned Freestyle Disco Solo Costume', 'Previously Owned Freestyle Disco Solo Costume', '', '0', '2012-05-04 11:09:50', '0', '', '', '', '', '1', '0', 'new', '2012-11-08 16:38:16'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('58', 'PREQ54SE18', '1', '<p>&nbsp;Previously loved and revamped green disco solo / freestyle costume. &nbsp;Aged between 12-14, covered in high quality crystals, black lace and netting complete with writs, ankle and headband this costume is devine and stands out from the crowd.</p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P!!</p>', '175.00', 'Previously loved Green Disco Costume', '18', '271', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', 'Previously loved Green Disco Costume', 'Previously loved and revamped green disco solo / freestyle costume.  Aged between 12-14, covered in high quality crystals, black lace and netting complete with writs, ankle and headband this costume is devine and stands out from the crowd.', 'Previously loved and revamped green disco solo / freestyle costume.  Aged between 12-14, covered in high quality crystals, black lace and netting complete with writs, ankle and headband this costume is devine and stands out from the crowd.', '0', '2012-09-04 05:14:06', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('60', 'PAI6HZQW15', '1', '<p>&nbsp;Age 4 a one off pair of really cute disco / slow pairs costume pale blue with white clouds. &nbsp;Covered in high quality crystal AB stones and matching accessories. &nbsp;</p>\r\n<p>Sold only as a pair</p>\r\n<p>&nbsp;</p>\r\n<p>Free P&amp;P</p>\r\n<p>&nbsp;</p>', '60.00', 'Pair of Disco Blinged Costumes', '18', '234', '0.00', '0.00', '1', '0', '1', '0', '', '0.000', '0', '0', '1', 'Pair of Disco Blinged Costumes', 'Age 4 a one off pair of really cute disco / slow pairs costume pale blue with white clouds.  Covered in high quality crystal AB stones and matching accessories.', 'Age 4 a one off pair of really cute disco / slow pairs costume pale blue with white clouds.  Covered in high quality crystal AB stones and matching accessories.', '0', '2012-09-04 08:25:42', '0', '', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('57', 'BLITSI0615', '1', '<p>&nbsp;Brand new to PnP Dance Stoned blinged competetion pins, wear your number with style on the dance floor, give yourself the edge and stand out from the crowd!!</p>\r\n<p>Available in various colours please choose from the list when ordering</p>\r\n<p>Buy 2 for free P&amp;P!!</p>', '2.50', 'Blinged Competition pins', '24', '254', '0.00', '0.00', '98', '0', '1', '0', '', '0.000', '0', '1', '1', 'Blinged Competition pins', 'Brand new to PnP Dance Stoned blinged competetion pins, wear your number with style on the dance floor, give yourself the edge and stand out from the crowd!!\r\n\r\nAvailable in various colours please choose from the list when ordering', '', '0', '2012-09-04 03:30:28', '0', '5:2.25, 10:2.00', '', '', '', '1', '', '', '0000-00-00 00:00:00'); #EOQ
INSERT INTO `cc4_CubeCart_inventory` VALUES('62', 'PNPVUZQN24', '1', '<p>&nbsp;Princess &#39;n&#39; Pickle tracksuits in Pink with stoned back and legs. &nbsp;Hoodie top and drawstring bottom. &nbsp;These tracksuits stand out and can either have Princess or Pickle printed on the leg. &nbsp;On the reverse is Princess &#39;n&#39; Pickle in hologram wirting with small pink bows and stoned with high quality crystals.</p>\r\n<p>&nbsp;</p>\r\n<p>Various sizes available</p>', '30.00', 'PnP Dance Tracksuits', '24', '0', '0.00', '0.00', '100', '0', '1', '0', '', '0.000', '0', '0', '1', '', '', '', '0', '2012-11-05 05:22:36', '0', '', '', '', '', '0', '', '', '0000-00-00 00:00:00'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_inventory_language`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_inventory_language`
--

CREATE TABLE `cc4_CubeCart_inventory_language` (
  `translation_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `language` varchar(5) collate utf8_unicode_ci default NULL,
  `product_id` int(10) unsigned NOT NULL default '0',
  `description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_title` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_description` text collate utf8_unicode_ci NOT NULL,
  `seo_meta_keywords` text collate utf8_unicode_ci NOT NULL,
  KEY `translation_id` (`translation_id`),
  FULLTEXT KEY `fulltext` (`name`,`description`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_inventory_language` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_lang_strings`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_lang_strings`
--

CREATE TABLE `cc4_CubeCart_lang_strings` (
  `string_id` int(10) unsigned NOT NULL auto_increment,
  `language` varchar(5) collate utf8_unicode_ci NOT NULL,
  `type` varchar(50) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `value` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`string_id`),
  KEY `language` (`language`),
  KEY `type` (`type`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_lang_strings` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_logo`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_logo`
--

CREATE TABLE `cc4_CubeCart_logo` (
  `logo_id` int(10) unsigned NOT NULL auto_increment,
  `status` tinyint(1) unsigned NOT NULL,
  `filename` varchar(150) collate utf8_unicode_ci NOT NULL,
  `mimetype` varchar(100) collate utf8_unicode_ci NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `skin` varchar(100) collate utf8_unicode_ci NOT NULL,
  `style` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`logo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_logo`
--

INSERT INTO `cc4_CubeCart_logo` VALUES('1', '0', 'Transparrent_PnP_Design.gif', 'image/gif', '872', '680', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_logo` VALUES('5', '0', 'vector_logo.jpg', 'image/jpeg', '287', '85', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_logo` VALUES('3', '0', 'ballet1Plate_trans.gif', 'image/gif', '300', '255', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_logo` VALUES('6', '0', 'vector_logo2.jpg', 'image/jpeg', '615', '100', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_logo` VALUES('7', '1', 'vector_logo3.jpg', 'image/jpeg', '700', '100', 'vector', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_manufacturers`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_manufacturers`
--

CREATE TABLE `cc4_CubeCart_manufacturers` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `URL` varchar(250) collate utf8_unicode_ci default NULL,
  `image` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_manufacturers` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_modules`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_modules`
--

CREATE TABLE `cc4_CubeCart_modules` (
  `module_id` int(10) unsigned NOT NULL auto_increment,
  `module` varchar(25) collate utf8_unicode_ci NOT NULL,
  `folder` varchar(30) collate utf8_unicode_ci NOT NULL default '',
  `status` smallint(1) NOT NULL default '0',
  `default` tinyint(1) unsigned default '0',
  `countries` tinytext collate utf8_unicode_ci,
  UNIQUE KEY `folder_2` (`folder`),
  KEY `moduleId` (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_modules`
--

INSERT INTO `cc4_CubeCart_modules` VALUES('1', 'shipping', 'Free_Shipping', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('2', 'gateway', 'Print_Order_Form', '0', '1', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('3', 'gateway', 'PayPal', '1', '1', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('4', 'gateway', 'Nochex_APC', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('5', '3rdparty', 'Extended_Product_Options', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('6', 'shipping', 'By_Price', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('7', 'shipping', 'UK_Flat_Shipping_Rates', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('8', '3rdparty', 'Stock_Levels_for_Product_Opts', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('9', 'gateway', 'OBT', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('12', 'cubehelper', 'Customer_registration', '1', '1', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('13', 'cubehelper', 'Custom_registration', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('14', '3rdparty', 'Product_Quantity_Discounts', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('18', 'altCheckout', 'Google_Checkout', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('15', '3rdparty', 'Google_Analytics', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('16', '3rdparty', 'Quick_Checkout', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('17', 'shipping', 'Pick_Up', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('19', 'altCheckout', 'PayPal_Pro', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('20', 'plugins', 'Fusion', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('21', 'social', 'Facebook', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('22', 'livehelp', 'olark', '1', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('23', 'plugins', 'Janrain', '0', '0', ''); #EOQ
INSERT INTO `cc4_CubeCart_modules` VALUES('24', 'plugins', 'ShareYourCart', '0', '0', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_newsletter`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_newsletter`
--

CREATE TABLE `cc4_CubeCart_newsletter` (
  `newsletter_id` int(10) unsigned NOT NULL auto_increment,
  `status` tinyint(1) unsigned NOT NULL default '0',
  `template_id` int(10) unsigned NOT NULL,
  `date_saved` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `date_sent` timestamp NULL default NULL,
  `subject` varchar(250) collate utf8_unicode_ci NOT NULL,
  `sender_email` varchar(254) collate utf8_unicode_ci NOT NULL,
  `sender_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `content_html` text collate utf8_unicode_ci NOT NULL,
  `content_text` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`newsletter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_newsletter` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_newsletter_subscriber`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_newsletter_subscriber`
--

CREATE TABLE `cc4_CubeCart_newsletter_subscriber` (
  `subscriber_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned default NULL,
  `status` tinyint(1) NOT NULL default '0',
  `email` varchar(254) collate utf8_unicode_ci NOT NULL,
  `validation` varchar(50) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`subscriber_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_newsletter_subscriber`
--

INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('1', '', '1', 'purplemamma@ntlworld.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('2', '', '1', 'mariskagarcia@yahoo.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('3', '', '1', 'angiechris2011@live.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('4', '', '1', 'fishgirlcrawley@sky.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('5', '', '1', 'sammyjosharpe@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('6', '', '1', 'lewisgsc22@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('7', '', '1', 'mark@fabian-lovely.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('8', '', '1', 'jason@bonner81.fsnet.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('9', '', '1', 'jaczandrobbie@live.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('10', '', '1', 'lorrainesankey@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('11', '', '1', 'laulau_laulau@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('12', '', '1', 'kelly-rus@hotmail.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('13', '', '1', 'leahselwood@live.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('14', '', '1', 'shannonroberts.roberts24@googlemail.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('15', '', '1', 'mrsbunchies@yahoo.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('16', '', '1', 'candt20112011@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('17', '', '1', 'jay.handley@sky.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('18', '', '1', 'andertonmx@aol.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('19', '', '1', 'boys_r_gr8@hotmail.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('20', '', '1', 'Colinandmarianne@btinternet.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('21', '', '1', 'fmorgan123@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('22', '', '1', 'POMPEYKIDS2@HOTMAIL.COM', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('23', '', '1', 'jackie-1958@hotmail.co.uk', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('24', '', '1', 'Rbrtsn@fsmail.net', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('25', '', '1', 'l.grant8se@btinternet.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('26', '', '1', 'trudyscrumptious@sky.com', ''); #EOQ
INSERT INTO `cc4_CubeCart_newsletter_subscriber` VALUES('27', '', '1', 'name@example.com', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_openid`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_openid`
--

CREATE TABLE `cc4_CubeCart_openid` (
  `identity_id` int(10) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL,
  `identity_url` tinytext collate utf8_unicode_ci NOT NULL,
  `identity_type` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`identity_id`),
  UNIQUE KEY `identity_url` (`identity_url`(250)),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_openid` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_option_assign`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_option_assign`
--

CREATE TABLE `cc4_CubeCart_option_assign` (
  `assign_id` int(10) unsigned NOT NULL auto_increment,
  `product` int(10) unsigned NOT NULL default '0',
  `option_id` int(10) unsigned NOT NULL,
  `value_id` int(10) unsigned NOT NULL,
  `option_price` decimal(16,2) NOT NULL default '0.00',
  `image_filename` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `set_member_id` int(10) unsigned NOT NULL default '0',
  `set_enabled` tinyint(1) unsigned NOT NULL default '1',
  `option_weight` decimal(10,2) unsigned NOT NULL default '0.00',
  `option_use_stock` tinyint(1) unsigned NOT NULL default '0',
  `option_stock` int(11) default '0',
  `option_negative` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`assign_id`),
  KEY `product_2` (`product`),
  KEY `set_member_id` (`set_member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=296 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_option_assign`
--

INSERT INTO `cc4_CubeCart_option_assign` VALUES('1', '17', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('2', '17', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('3', '17', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('4', '17', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('5', '17', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('6', '17', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('7', '17', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('8', '17', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('9', '17', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('10', '17', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('11', '18', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('12', '18', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('13', '18', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('14', '18', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('15', '18', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('16', '18', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('186', '50', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('18', '18', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('19', '18', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('20', '18', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('21', '19', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('22', '19', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('23', '19', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('24', '19', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('25', '19', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('26', '19', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('27', '19', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('28', '19', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('29', '19', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('30', '19', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('31', '21', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('32', '21', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('33', '21', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('34', '21', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('35', '21', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('36', '21', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('37', '21', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('38', '21', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('39', '21', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('40', '21', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('41', '20', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('42', '20', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('43', '20', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('44', '20', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('45', '20', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('46', '20', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('47', '20', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('48', '20', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('49', '20', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('50', '20', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('51', '18', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('52', '22', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('53', '22', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('54', '22', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('55', '22', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('56', '22', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('57', '22', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('58', '22', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('59', '22', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('60', '22', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('61', '22', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('62', '22', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('63', '17', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('64', '19', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('72', '22', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('66', '21', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('67', '20', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('68', '18', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('69', '17', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('71', '19', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('73', '21', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('74', '20', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('75', '23', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('76', '23', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('77', '23', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('78', '23', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('79', '23', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('80', '23', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('81', '23', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('82', '23', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('83', '23', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('84', '23', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('85', '23', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('86', '23', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('87', '23', '9', '16', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('88', '23', '9', '18', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('89', '23', '9', '17', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('90', '24', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('91', '24', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('92', '24', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('93', '24', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('94', '24', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('95', '24', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('96', '24', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('97', '24', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('98', '24', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('99', '24', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('100', '24', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('101', '24', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('102', '25', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('103', '25', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('104', '25', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('105', '25', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('106', '25', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('107', '25', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('108', '25', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('109', '25', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('110', '25', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('111', '25', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('112', '25', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('113', '25', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('114', '25', '9', '16', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('115', '25', '9', '18', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('116', '25', '9', '17', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('117', '24', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('118', '24', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('119', '26', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('120', '26', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('121', '26', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('122', '26', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('123', '26', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('124', '26', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('125', '26', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('126', '26', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('127', '26', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('128', '26', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('129', '26', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('130', '26', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('191', '50', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('190', '50', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('189', '50', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('188', '50', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('187', '50', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('185', '18', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('184', '18', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('183', '18', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('182', '17', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('180', '26', '10', '25', '-10.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('181', '17', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('177', '26', '10', '26', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('143', '28', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('144', '28', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('145', '28', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('146', '28', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('147', '28', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('148', '28', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('149', '28', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('150', '28', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('151', '28', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('152', '28', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('153', '28', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('154', '28', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('158', '28', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('159', '17', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('157', '28', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('160', '17', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('161', '17', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('162', '17', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('163', '17', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('164', '18', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('165', '18', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('166', '18', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('167', '18', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('168', '18', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('169', '26', '6', '24', '3.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('170', '26', '5', '20', '5.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('171', '26', '5', '21', '5.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('172', '26', '5', '19', '5.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('173', '26', '5', '22', '5.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('174', '26', '5', '23', '5.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('179', '26', '10', '27', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('192', '50', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('193', '50', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('194', '50', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('195', '50', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('196', '50', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('197', '50', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('198', '50', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('199', '50', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('200', '50', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('201', '50', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('202', '50', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('203', '50', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('204', '50', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('205', '50', '10', '27', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('206', '50', '10', '26', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('207', '50', '10', '25', '-15.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('208', '51', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('209', '51', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('210', '51', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('211', '51', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('212', '51', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('213', '51', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('214', '51', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('215', '51', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('216', '51', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('217', '51', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('218', '51', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('219', '51', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('220', '51', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('221', '51', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('222', '51', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('223', '51', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('224', '51', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('225', '51', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('226', '51', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('227', '52', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('228', '52', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('229', '52', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('230', '52', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('231', '52', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('232', '52', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('233', '52', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('234', '52', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('235', '52', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('236', '52', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('237', '52', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('238', '52', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('239', '52', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('240', '52', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('241', '52', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('242', '52', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('243', '52', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('244', '52', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('245', '52', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('246', '53', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('247', '53', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('248', '53', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('249', '53', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('250', '53', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('251', '53', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('252', '53', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('253', '53', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('254', '53', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('255', '53', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('256', '53', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('257', '53', '5', '19', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('258', '53', '5', '20', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('259', '53', '5', '21', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('260', '53', '5', '22', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('261', '53', '5', '23', '7.51', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('262', '53', '5', '28', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('263', '53', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('264', '53', '5', '29', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('265', '54', '5', '6', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('266', '54', '5', '11', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('267', '54', '5', '7', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('268', '54', '5', '10', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('269', '54', '5', '2', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('270', '54', '5', '9', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('271', '54', '5', '12', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('272', '54', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('273', '54', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('274', '54', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('275', '54', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('276', '54', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('277', '54', '9', '16', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('278', '54', '9', '18', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('279', '54', '9', '17', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('280', '54', '10', '27', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('281', '54', '10', '26', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('282', '54', '10', '25', '-17.50', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('283', '57', '11', '37', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('284', '57', '11', '30', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('285', '57', '11', '31', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('286', '57', '11', '33', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('287', '57', '11', '34', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('288', '57', '11', '32', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('289', '57', '11', '36', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('290', '57', '11', '35', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('291', '62', '6', '15', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('292', '62', '6', '3', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('293', '62', '6', '4', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('294', '62', '6', '5', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_assign` VALUES('295', '62', '6', '14', '0.00', '', '0', '1', '0.00', '0', '0', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_option_group`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_option_group`
--

CREATE TABLE `cc4_CubeCart_option_group` (
  `option_id` int(10) unsigned NOT NULL auto_increment,
  `option_name` varchar(50) collate utf8_unicode_ci NOT NULL default '',
  `option_type` tinyint(1) unsigned NOT NULL default '0',
  `option_description` text collate utf8_unicode_ci,
  `option_required` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`option_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_option_group`
--

INSERT INTO `cc4_CubeCart_option_group` VALUES('5', 'Colour', '0', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_group` VALUES('6', 'Size', '0', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_group` VALUES('9', 'Netting', '0', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_group` VALUES('10', 'Stones', '0', '', '0'); #EOQ
INSERT INTO `cc4_CubeCart_option_group` VALUES('11', 'Pin Colour', '12', '', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_option_value`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_option_value`
--

CREATE TABLE `cc4_CubeCart_option_value` (
  `value_id` int(10) unsigned NOT NULL auto_increment,
  `value_name` varbinary(50) NOT NULL default '',
  `option_id` int(10) unsigned NOT NULL default '0',
  `default_image` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`value_id`),
  KEY `option_id` (`option_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_option_value`
--

INSERT INTO `cc4_CubeCart_option_value` VALUES('2', 'Neon Red Matt', '5', '_images/ProductImages/Lycra/Swatches/RedMF5036.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('3', '4 Years', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('4', '5 Years', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('5', '6 Years', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('6', 'Acid Green Matt', '5', '_images/ProductImages/Lycra/Swatches/GreenMF5020.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('7', 'Electric Pink Matt', '5', '_images/ProductImages/Lycra/Swatches/PinkMF5032.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('9', 'Turquoise Matt', '5', '_images/ProductImages/Lycra/Swatches/AquaBlueMF5014.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('10', 'FL Yellow Matt', '5', '_images/ProductImages/Lycra/Swatches/YellowMF5022.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('11', 'Black Matt', '5', '_images/ProductImages/Lycra/Swatches/BlackMF5001.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('12', 'White Matt', '5', '_images/ProductImages/Lycra/Swatches/WhiteMF5002.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('14', '7 Years', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('15', '3 Years', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('16', 'Aqua Blue', '9', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('17', 'White', '9', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('18', 'Black', '9', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('19', 'Blue Water Bubbles', '5', '_images/ProductImages/Lycra/Swatches/blue bubbles.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('20', 'Black White and Grey Animal', '5', '_images/ProductImages/Lycra/Swatches/Black white grey animal.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('21', 'Blue Pin Stripes', '5', '_images/ProductImages/Lycra/Swatches/BlueStripes.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('22', 'Caramel Leopard Print', '5', '_images/ProductImages/Lycra/Swatches/Leopard.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('23', 'Purple and Turquoise Leopard Print', '5', '_images/ProductImages/Lycra/Swatches/PurpleLeopard.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('24', 'Over 8 (Please specify waist, ankle and wrist size', '6', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('25', 'Without', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('26', 'Crystal Clear', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('27', 'Crystal AB', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('28', 'Red Matt', '5', '_images/ProductImages/Lycra/Swatches/Red Matt - MF5035.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('29', 'Aqua Blue Matt', '5', '_images/ProductImages/Lycra/Swatches/Aqua Matt - MF5016.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('30', 'Crystal', '11', '_images/ProductImages/Comp Pins/crystal.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('31', 'Crystal AB', '11', '_images/ProductImages/Comp Pins/Crystal_AB.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('32', 'Mint Green', '11', '_images/ProductImages/Comp Pins/mint_green.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('33', 'Hot Pink', '11', '_images/ProductImages/Comp Pins/hot_pink.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('34', 'Light Pink', '11', '_images/ProductImages/Comp Pins/pink.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('35', 'Siam Ruby', '11', '_images/ProductImages/Comp Pins/ruby.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('36', 'Orange', '11', '_images/ProductImages/Comp Pins/orange.jpg'); #EOQ
INSERT INTO `cc4_CubeCart_option_value` VALUES('37', 'Aqua Blue', '11', '_images/ProductImages/Comp Pins/aqua_blue.jpg'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_set`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_set`
--

CREATE TABLE `cc4_CubeCart_options_set` (
  `set_id` int(10) unsigned NOT NULL auto_increment,
  `set_name` text collate utf8_unicode_ci NOT NULL,
  `set_description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`set_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_options_set` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_set_member`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_set_member`
--

CREATE TABLE `cc4_CubeCart_options_set_member` (
  `set_member_id` int(10) unsigned NOT NULL auto_increment,
  `set_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `value_id` int(10) unsigned NOT NULL,
  `priority` int(11) NOT NULL,
  `price` decimal(16,2) NOT NULL default '0.00',
  `weight` decimal(16,2) NOT NULL default '0.00',
  PRIMARY KEY  (`set_member_id`),
  KEY `set_id` (`set_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_options_set_member` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_set_product`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_set_product`
--

CREATE TABLE `cc4_CubeCart_options_set_product` (
  `set_product_id` int(10) unsigned NOT NULL auto_increment,
  `set_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`set_product_id`),
  KEY `set_id` (`set_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_options_set_product` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_stock_levels`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_stock_levels`
--

CREATE TABLE `cc4_CubeCart_options_stock_levels` (
  `assign_key` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `product_id` int(11) NOT NULL default '0',
  `stock_level` int(11) NOT NULL default '0',
  `product_code` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  PRIMARY KEY  (`assign_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_options_stock_levels`
--

INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('2,3', '17', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('1,3', '17', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('6,3', '17', '8', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('7,3', '17', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('10,3', '17', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('8,3', '17', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('9,3', '17', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('2,4', '17', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('1,4', '17', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('6,4', '17', '9', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('7,4', '17', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('10,4', '17', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('8,4', '17', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('9,4', '17', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('2,5', '17', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('1,5', '17', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('6,5', '17', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('7,5', '17', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('10,5', '17', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('8,5', '17', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('9,5', '17', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('2,63', '17', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('1,63', '17', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('6,63', '17', '9', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('7,63', '17', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('10,63', '17', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('8,63', '17', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('9,63', '17', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('2,69', '17', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('1,69', '17', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('6,69', '17', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('7,69', '17', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('10,69', '17', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('8,69', '17', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('9,69', '17', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('12,13', '18', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('11,13', '18', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('16,13', '18', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('17,13', '18', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('20,13', '18', '9', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('18,13', '18', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('19,13', '18', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('12,14', '18', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('11,14', '18', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('16,14', '18', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('17,14', '18', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('20,14', '18', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('18,14', '18', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('19,14', '18', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('12,15', '18', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('11,15', '18', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('16,15', '18', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('17,15', '18', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('20,15', '18', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('18,15', '18', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('19,15', '18', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('12,51', '18', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('11,51', '18', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('16,51', '18', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('17,51', '18', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('20,51', '18', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('18,51', '18', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('19,51', '18', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('12,68', '18', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('11,68', '18', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('16,68', '18', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('17,68', '18', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('20,68', '18', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('18,68', '18', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('19,68', '18', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('22,23', '19', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('21,23', '19', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('26,23', '19', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('27,23', '19', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('30,23', '19', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('28,23', '19', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('29,23', '19', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('22,24', '19', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('21,24', '19', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('26,24', '19', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('27,24', '19', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('30,24', '19', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('28,24', '19', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('29,24', '19', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('22,25', '19', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('21,25', '19', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('26,25', '19', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('27,25', '19', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('30,25', '19', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('28,25', '19', '7', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('29,25', '19', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('22,64', '19', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('21,64', '19', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('26,64', '19', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('27,64', '19', '9', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('30,64', '19', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('28,64', '19', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('29,64', '19', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('22,71', '19', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('21,71', '19', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('26,71', '19', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('27,71', '19', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('30,71', '19', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('28,71', '19', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('29,71', '19', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('42,43', '20', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('41,43', '20', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('46,43', '20', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('47,43', '20', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('50,43', '20', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('48,43', '20', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('49,43', '20', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('42,44', '20', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('41,44', '20', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('46,44', '20', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('47,44', '20', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('50,44', '20', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('48,44', '20', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('49,44', '20', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('42,45', '20', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('41,45', '20', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('46,45', '20', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('47,45', '20', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('50,45', '20', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('48,45', '20', '9', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('49,45', '20', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('42,67', '20', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('41,67', '20', '9', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('46,67', '20', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('47,67', '20', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('50,67', '20', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('48,67', '20', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('49,67', '20', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('42,74', '20', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('41,74', '20', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('46,74', '20', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('47,74', '20', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('50,74', '20', '9', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('48,74', '20', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('49,74', '20', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('32,33', '21', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('31,33', '21', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('36,33', '21', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('37,33', '21', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('40,33', '21', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('38,33', '21', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('39,33', '21', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('32,34', '21', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('31,34', '21', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('36,34', '21', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('37,34', '21', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('40,34', '21', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('38,34', '21', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('39,34', '21', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('32,35', '21', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('31,35', '21', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('36,35', '21', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('37,35', '21', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('40,35', '21', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('38,35', '21', '9', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('39,35', '21', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('32,66', '21', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('31,66', '21', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('36,66', '21', '9', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('37,66', '21', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('40,66', '21', '9', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('38,66', '21', '9', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('39,66', '21', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('32,73', '21', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('31,73', '21', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('36,73', '21', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('37,73', '21', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('40,73', '21', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('38,73', '21', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('39,73', '21', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('53,54', '22', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('52,54', '22', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('57,54', '22', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('58,54', '22', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('61,54', '22', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('59,54', '22', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('60,54', '22', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('53,55', '22', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('52,55', '22', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('57,55', '22', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('58,55', '22', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('61,55', '22', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('59,55', '22', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('60,55', '22', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('53,56', '22', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('52,56', '22', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('57,56', '22', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('58,56', '22', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('61,56', '22', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('59,56', '22', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('60,56', '22', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('53,62', '22', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('52,62', '22', '9', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('57,62', '22', '9', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('58,62', '22', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('61,62', '22', '9', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('59,62', '22', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('60,62', '22', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('53,72', '22', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('52,72', '22', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('57,72', '22', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('58,72', '22', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('61,72', '22', '9', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('59,72', '22', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('60,72', '22', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,83,87', '23', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,83,87', '23', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,83,87', '23', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,83,87', '23', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,83,87', '23', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,83,87', '23', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,83,87', '23', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,84,87', '23', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,84,87', '23', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,84,87', '23', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,84,87', '23', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,84,87', '23', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,84,87', '23', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,84,87', '23', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,85,87', '23', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,85,87', '23', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,85,87', '23', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,85,87', '23', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,85,87', '23', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,85,87', '23', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,85,87', '23', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,86,87', '23', '10', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,86,87', '23', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,86,87', '23', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,86,87', '23', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,86,87', '23', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,86,87', '23', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,86,87', '23', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,82,87', '23', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,82,87', '23', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,82,87', '23', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,82,87', '23', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,82,87', '23', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,82,87', '23', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,82,87', '23', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,83,89', '23', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,83,89', '23', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,83,89', '23', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,83,89', '23', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,83,89', '23', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,83,89', '23', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,83,89', '23', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,84,89', '23', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,84,89', '23', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,84,89', '23', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,84,89', '23', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,84,89', '23', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,84,89', '23', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,84,89', '23', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,85,89', '23', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,85,89', '23', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,85,89', '23', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,85,89', '23', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,85,89', '23', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,85,89', '23', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,85,89', '23', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,86,89', '23', '10', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,86,89', '23', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,86,89', '23', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,86,89', '23', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,86,89', '23', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,86,89', '23', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,86,89', '23', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,82,89', '23', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,82,89', '23', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,82,89', '23', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,82,89', '23', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,82,89', '23', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,82,89', '23', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,82,89', '23', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,83,88', '23', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,83,88', '23', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,83,88', '23', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,83,88', '23', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,83,88', '23', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,83,88', '23', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,83,88', '23', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,84,88', '23', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,84,88', '23', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,84,88', '23', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,84,88', '23', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,84,88', '23', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,84,88', '23', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,84,88', '23', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,85,88', '23', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,85,88', '23', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,85,88', '23', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,85,88', '23', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,85,88', '23', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,85,88', '23', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,85,88', '23', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,86,88', '23', '9', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,86,88', '23', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,86,88', '23', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,86,88', '23', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,86,88', '23', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,86,88', '23', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,86,88', '23', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('79,82,88', '23', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('75,82,88', '23', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('77,82,88', '23', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('80,82,88', '23', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('78,82,88', '23', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('76,82,88', '23', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('81,82,88', '23', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('91,92', '24', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('90,92', '24', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('95,92', '24', '8', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('96,92', '24', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('99,92', '24', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('97,92', '24', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('98,92', '24', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('91,93', '24', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('90,93', '24', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('95,93', '24', '9', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('96,93', '24', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('99,93', '24', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('97,93', '24', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('98,93', '24', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('91,94', '24', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('90,94', '24', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('95,94', '24', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('96,94', '24', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('99,94', '24', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('97,94', '24', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('98,94', '24', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('91,100', '24', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('90,100', '24', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('95,100', '24', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('96,100', '24', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('99,100', '24', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('97,100', '24', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('98,100', '24', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('91,101', '24', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('90,101', '24', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('95,101', '24', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('96,101', '24', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('99,101', '24', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('97,101', '24', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('98,101', '24', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('118,92', '24', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('117,92', '24', '10', 'BWG4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('118,93', '24', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('117,93', '24', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('118,94', '24', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('117,94', '24', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('118,100', '24', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('117,100', '24', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('184,13', '18', '10', 'TQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('118,101', '24', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('117,101', '24', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('184,14', '18', '10', 'TQM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('185,13', '18', '10', 'ABM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('183,13', '18', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,110,114', '25', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,110,114', '25', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,110,114', '25', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,110,114', '25', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,110,114', '25', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,110,114', '25', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,110,114', '25', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,111,114', '25', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,111,114', '25', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,111,114', '25', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,111,114', '25', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,111,114', '25', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,111,114', '25', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,111,114', '25', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,112,114', '25', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,112,114', '25', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,112,114', '25', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,112,114', '25', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,112,114', '25', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,112,114', '25', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,112,114', '25', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,113,114', '25', '10', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,113,114', '25', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,113,114', '25', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,113,114', '25', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,113,114', '25', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,113,114', '25', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,113,114', '25', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,109,114', '25', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,109,114', '25', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,109,114', '25', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,109,114', '25', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,109,114', '25', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,109,114', '25', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,109,114', '25', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,110,116', '25', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,110,116', '25', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,110,116', '25', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,110,116', '25', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,110,116', '25', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,110,116', '25', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,110,116', '25', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,111,116', '25', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,111,116', '25', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,111,116', '25', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,111,116', '25', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,111,116', '25', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,111,116', '25', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,111,116', '25', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,112,116', '25', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,112,116', '25', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,112,116', '25', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,112,116', '25', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,112,116', '25', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,112,116', '25', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,112,116', '25', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,113,116', '25', '10', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,113,116', '25', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,113,116', '25', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,113,116', '25', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,113,116', '25', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,113,116', '25', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,113,116', '25', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,109,116', '25', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,109,116', '25', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,109,116', '25', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,109,116', '25', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,109,116', '25', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,109,116', '25', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,109,116', '25', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,110,115', '25', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,110,115', '25', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,110,115', '25', '10', 'PINKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,110,115', '25', '10', 'TURQUOISENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,110,115', '25', '10', 'FLYELLOWNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,110,115', '25', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,110,115', '25', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,111,115', '25', '10', 'REDNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,111,115', '25', '10', 'GREENNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,111,115', '25', '10', 'PINKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,111,115', '25', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,111,115', '25', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,111,115', '25', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,111,115', '25', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,112,115', '25', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,112,115', '25', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,112,115', '25', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,112,115', '25', '10', 'TURQUOISENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,112,115', '25', '10', 'FLYELLOWNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,112,115', '25', '10', 'BLACKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,112,115', '25', '10', 'WHITENET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,113,115', '25', '10', 'REDNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,113,115', '25', '10', 'GREENNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,113,115', '25', '10', 'PINKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,113,115', '25', '10', 'TURQUOISENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,113,115', '25', '10', 'FLYELLOWNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,113,115', '25', '10', 'BLACKNET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,113,115', '25', '10', 'WHITENET7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('106,109,115', '25', '10', 'REDNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('102,109,115', '25', '10', 'GREENNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('104,109,115', '25', '10', 'PINKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('107,109,115', '25', '10', 'TURQUOISENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('105,109,115', '25', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('103,109,115', '25', '10', 'BLACKNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('108,109,115', '25', '10', 'WHITENET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,121', '26', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,121', '26', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,121', '26', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,121', '26', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,121', '26', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,121', '26', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,121', '26', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,122', '26', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,122', '26', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,122', '26', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,122', '26', '10', 'TURQUOISENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,122', '26', '10', 'FLYELLOWNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,122', '26', '10', 'BLACKNET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,122', '26', '10', 'WHITENET5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,123', '26', '10', 'REDNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,123', '26', '10', 'GREENNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,123', '26', '10', 'PINKNET6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,123', '26', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,123', '26', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,123', '26', '9', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,123', '26', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,129', '26', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,129', '26', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,129', '26', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,129', '26', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,129', '26', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,129', '26', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,129', '26', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,130', '26', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,130', '26', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,130', '26', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,130', '26', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,130', '26', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,130', '26', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,130', '26', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('132,133', '27', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('131,133', '27', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('136,133', '27', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('137,133', '27', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('140,133', '27', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('138,133', '27', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('139,133', '27', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('132,134', '27', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('131,134', '27', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('136,134', '27', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('137,134', '27', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('140,134', '27', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('138,134', '27', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('139,134', '27', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('132,135', '27', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('131,135', '27', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('136,135', '27', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('137,135', '27', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('140,135', '27', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('138,135', '27', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('139,135', '27', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('132,141', '27', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('131,141', '27', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('136,141', '27', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('137,141', '27', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('140,141', '27', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('138,141', '27', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('139,141', '27', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('132,142', '27', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('131,142', '27', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('136,142', '27', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('137,142', '27', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('140,142', '27', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('138,142', '27', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('139,142', '27', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('144,145', '28', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('143,145', '28', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('148,145', '28', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('149,145', '28', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('152,145', '28', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('150,145', '28', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('151,145', '28', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('157,145', '28', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('155,145', '28', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('156,145', '28', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('144,146', '28', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('143,146', '28', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('148,146', '28', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('149,146', '28', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('152,146', '28', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('150,146', '28', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('151,146', '28', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('157,146', '28', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('155,146', '28', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('156,146', '28', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('144,147', '28', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('143,147', '28', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('148,147', '28', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('149,147', '28', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('152,147', '28', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('150,147', '28', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('151,147', '28', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('157,147', '28', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('155,147', '28', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('156,147', '28', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('144,153', '28', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('143,153', '28', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('148,153', '28', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('149,153', '28', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('152,153', '28', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('150,153', '28', '10', 'REDNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('151,153', '28', '10', 'GREENNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('157,153', '28', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('155,153', '28', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('156,153', '28', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('144,154', '28', '10', 'BLACKNET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('143,154', '28', '10', 'WHITENET4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('148,154', '28', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('149,154', '28', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('152,154', '28', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('150,154', '28', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('151,154', '28', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('157,154', '28', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('155,154', '28', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('161,3', '17', '10', 'BB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('159,3', '17', '10', 'BWGA4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('160,3', '17', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('162,3', '17', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('163,3', '17', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('161,4', '17', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('159,4', '17', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('160,4', '17', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('162,4', '17', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('163,4', '17', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('161,5', '17', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('159,5', '17', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('160,5', '17', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('162,5', '17', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('163,5', '17', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('161,63', '17', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('159,63', '17', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('160,63', '17', '10', 'BPS7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('162,63', '17', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('163,63', '17', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('161,69', '17', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('159,69', '17', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('160,69', '17', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('162,69', '17', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('163,69', '17', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('164,13', '18', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('165,13', '18', '10', 'BWG4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('166,13', '18', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('167,13', '18', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('168,13', '18', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('164,14', '18', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('165,14', '18', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('166,14', '18', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('167,14', '18', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('168,14', '18', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('164,15', '18', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('165,15', '18', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('166,15', '18', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('167,15', '18', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('168,15', '18', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('164,51', '18', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('165,51', '18', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('166,51', '18', '10', 'BPS7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('167,51', '18', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('168,51', '18', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('164,68', '18', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('165,68', '18', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('166,68', '18', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('167,68', '18', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('168,68', '18', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('120,169', '26', '10', '08R'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('119,169', '26', '10', 'O8G'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('124,169', '26', '10', 'O8P'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('125,169', '26', '9', 'O8T'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('128,169', '26', '10', 'O8Y'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('126,169', '26', '10', 'O8B'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('127,169', '26', '10', 'O8W'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,121', '26', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,121', '26', '10', 'BWG4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,121', '26', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,121', '26', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,121', '26', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,122', '26', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,122', '26', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,122', '26', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,122', '26', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,122', '26', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,123', '26', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,123', '26', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,123', '26', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,123', '26', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,123', '26', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,129', '26', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,129', '26', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,129', '26', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,129', '26', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,129', '26', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,130', '26', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,130', '26', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,130', '26', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,130', '26', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,130', '26', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('172,169', '26', '10', 'BWB8'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('170,169', '26', '10', 'BWG8'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('171,169', '26', '10', 'BPS8'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('173,169', '26', '10', 'CLP8'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('174,169', '26', '10', 'PTL8'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('182,3', '17', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('181,3', '17', '10', 'AQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('182,4', '17', '10', 'RM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('181,4', '17', '10', 'AQBM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('182,5', '17', '10', 'RM6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('181,5', '17', '10', 'AQB'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('182,63', '17', '10', 'RM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('181,63', '17', '10', 'QBM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('182,69', '17', '10', 'ARM3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('181,69', '17', '10', 'AQB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('187,188', '50', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('186,188', '50', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('191,188', '50', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('203,188', '50', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('194,188', '50', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('192,188', '50', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('193,188', '50', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('197,188', '50', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('198,188', '50', '10', 'BWGA4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('199,188', '50', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('200,188', '50', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('201,188', '50', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('202,188', '50', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('204,188', '50', '10', 'AQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('187,189', '50', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('186,189', '50', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('191,189', '50', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('203,189', '50', '10', 'TQM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('194,189', '50', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('192,189', '50', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('193,189', '50', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('197,189', '50', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('198,189', '50', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('199,189', '50', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('200,189', '50', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('201,189', '50', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('202,189', '50', '10', 'RM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('204,189', '50', '10', 'AQBM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('187,190', '50', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('186,190', '50', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('191,190', '50', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('203,190', '50', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('194,190', '50', '10', 'FLYELLOWNET3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('192,190', '50', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('193,190', '50', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('197,190', '50', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('198,190', '50', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('199,190', '50', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('200,190', '50', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('201,190', '50', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('202,190', '50', '10', 'RM6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('204,190', '50', '10', 'AQB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('187,195', '50', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('186,195', '50', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('191,195', '50', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('203,195', '50', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('194,195', '50', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('192,195', '50', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('193,195', '50', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('197,195', '50', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('198,195', '50', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('199,195', '50', '10', 'BPS7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('200,195', '50', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('201,195', '50', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('202,195', '50', '10', 'RM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('204,195', '50', '10', 'QBM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('187,196', '50', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('186,196', '50', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('191,196', '50', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('203,196', '50', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('194,196', '50', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('192,196', '50', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('193,196', '50', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('197,196', '50', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('198,196', '50', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('199,196', '50', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('200,196', '50', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('201,196', '50', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('202,196', '50', '10', 'RM3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('204,196', '50', '10', 'AQB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('209,210', '51', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('208,210', '51', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('213,210', '51', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('225,210', '51', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('216,210', '51', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('214,210', '51', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('215,210', '51', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('219,210', '51', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('220,210', '51', '10', 'BWGA4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('221,210', '51', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('222,210', '51', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('223,210', '51', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('224,210', '51', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('226,210', '51', '10', 'AQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('209,211', '51', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('208,211', '51', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('213,211', '51', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('225,211', '51', '10', 'TQM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('216,211', '51', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('214,211', '51', '9', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('215,211', '51', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('219,211', '51', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('220,211', '51', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('221,211', '51', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('222,211', '51', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('223,211', '51', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('224,211', '51', '10', 'RM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('226,211', '51', '10', 'AQBM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('209,212', '51', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('208,212', '51', '10', 'GREEN6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('213,212', '51', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('225,212', '51', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('216,212', '51', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('214,212', '51', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('215,212', '51', '10', 'WH6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('219,212', '51', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('220,212', '51', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('221,212', '51', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('222,212', '51', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('223,212', '51', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('224,212', '51', '10', 'RM6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('226,212', '51', '10', 'AQB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('209,217', '51', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('208,217', '51', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('213,217', '51', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('225,217', '51', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('216,217', '51', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('214,217', '51', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('215,217', '51', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('219,217', '51', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('220,217', '51', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('221,217', '51', '10', 'BPS7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('222,217', '51', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('223,217', '51', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('224,217', '51', '10', 'RM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('226,217', '51', '10', 'QBM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('209,218', '51', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('208,218', '51', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('213,218', '51', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('225,218', '51', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('216,218', '51', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('214,218', '51', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('215,218', '51', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('219,218', '51', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('220,218', '51', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('221,218', '51', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('222,218', '51', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('223,218', '51', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('224,218', '51', '10', 'RM3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('226,218', '51', '10', 'AQB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('228,229', '52', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('227,229', '52', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('232,229', '52', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('244,229', '52', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('235,229', '52', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('233,229', '52', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('234,229', '52', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('238,229', '52', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('239,229', '52', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('240,229', '52', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('241,229', '52', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('242,229', '52', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('243,229', '52', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('245,229', '52', '10', 'AQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('228,230', '52', '10', 'RED5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('227,230', '52', '10', 'GREEN5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('232,230', '52', '10', 'PINK5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('244,230', '52', '10', 'TQM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('235,230', '52', '10', 'YELL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('233,230', '52', '10', 'BL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('234,230', '52', '10', 'WH5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('238,230', '52', '10', 'BWB5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('239,230', '52', '10', 'BWG5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('240,230', '52', '10', 'BPS5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('241,230', '52', '10', 'CLP5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('242,230', '52', '10', 'PTL5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('243,230', '52', '10', 'RM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('245,230', '52', '10', 'AQBM5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('228,231', '52', '10', 'RED6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('227,231', '52', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('232,231', '52', '10', 'PINK6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('244,231', '52', '10', 'TURQ6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('235,231', '52', '10', 'YELL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('233,231', '52', '10', 'BL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('234,231', '52', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('238,231', '52', '10', 'BWB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('239,231', '52', '10', 'BWG6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('240,231', '52', '10', 'BPS6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('241,231', '52', '10', 'CLP6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('242,231', '52', '10', 'PTL6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('243,231', '52', '10', 'RM6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('245,231', '52', '10', 'AQB6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('228,236', '52', '10', 'RED7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('227,236', '52', '10', 'GREEN7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('232,236', '52', '10', 'PINK7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('244,236', '52', '10', 'TURQ7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('235,236', '52', '10', 'YELL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('233,236', '52', '10', 'BL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('234,236', '52', '10', 'WH7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('238,236', '52', '10', 'BWB7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('239,236', '52', '10', 'BWG7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('240,236', '52', '10', 'BPS7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('241,236', '52', '10', 'CLP7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('242,236', '52', '10', 'PTL7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('243,236', '52', '10', 'RM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('245,236', '52', '10', 'QBM7'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('228,237', '52', '10', 'RED3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('227,237', '52', '10', 'GREEN3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('232,237', '52', '10', 'PINK3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('244,237', '52', '10', 'TURQ3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('235,237', '52', '10', 'YELL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('233,237', '52', '10', 'BL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('234,237', '52', '10', 'WH3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('238,237', '52', '10', 'BWB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('239,237', '52', '10', 'BWG3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('240,237', '52', '10', 'BPS3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('241,237', '52', '10', 'CLP3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('242,237', '52', '10', 'PTL3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('243,237', '52', '10', 'RM3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('245,237', '52', '10', 'AQB3'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('247,248', '53', '10', 'RED4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('246,248', '53', '10', 'GREEN4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('251,248', '53', '10', 'PINK4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('263,248', '53', '10', 'TURQ4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('254,248', '53', '10', 'YELL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('252,248', '53', '10', 'BL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('253,248', '53', '10', 'WHITE4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('257,248', '53', '10', 'BWB4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('258,248', '53', '10', 'BWGA4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('259,248', '53', '10', 'BPS4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('260,248', '53', '10', 'CLP4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('261,248', '53', '10', 'PTL4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('262,248', '53', '10', 'RM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('264,248', '53', '10', 'AQM4'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('247,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('246,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('251,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('263,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('254,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('252,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('253,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('257,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('258,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('259,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('260,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('261,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('262,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('264,249', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('247,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('246,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('251,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('263,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('254,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('252,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('253,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('257,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('258,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('259,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('260,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('261,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('262,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('264,250', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('247,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('246,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('251,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('263,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('254,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('252,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('253,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('257,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('258,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('259,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('260,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('261,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('262,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('264,255', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('247,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('246,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('251,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('263,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('254,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('252,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('253,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('257,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('258,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('259,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('260,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('261,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('262,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('264,256', '53', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,273,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,274,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,275,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,276,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,272,277', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,273,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,274,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,275,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,276,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,272,279', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,273,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,274,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,275,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,276,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('269,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('265,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('267,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('270,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('268,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('266,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('271,272,278', '54', '10', ''); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('284', '57', '10', 'CPCRYSTAL'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('285', '57', '10', 'CPAB'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('288', '57', '10', 'CPMG'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('286', '57', '10', 'CPHP'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('287', '57', '10', 'CPLP'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('290', '57', '10', 'CPSR'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('289', '57', '10', 'CPOR'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_levels` VALUES('283', '57', '8', 'CPAB'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_stock_opts`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_stock_opts`
--

CREATE TABLE `cc4_CubeCart_options_stock_opts` (
  `product_id` int(11) NOT NULL default '0',
  `option_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`product_id`,`option_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_options_stock_opts`
--

INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('17', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('17', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('18', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('18', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('19', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('19', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('20', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('20', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('21', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('21', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('22', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('22', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('23', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('23', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('23', '9'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('24', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('24', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('25', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('25', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('25', '9'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('26', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('26', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('27', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('27', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('28', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('28', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('50', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('50', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('51', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('51', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('52', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('52', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('53', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('53', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('54', '5'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('54', '6'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('54', '9'); #EOQ
INSERT INTO `cc4_CubeCart_options_stock_opts` VALUES('57', '11'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_options_types`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_options_types`
--

CREATE TABLE `cc4_CubeCart_options_types` (
  `id` int(255) NOT NULL auto_increment,
  `type_tag` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `type_name` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `is_visual` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_options_types`
--

INSERT INTO `cc4_CubeCart_options_types` VALUES('10', 'radio_vertical', 'Radio Options', '0'); #EOQ
INSERT INTO `cc4_CubeCart_options_types` VALUES('11', 'checkbox_vertical', 'Checkboxes (refer to notes)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_options_types` VALUES('12', 'visual_with_names', 'Visual Options (with names)', '1'); #EOQ
INSERT INTO `cc4_CubeCart_options_types` VALUES('13', 'visual_image_swap', 'Visual Options (swap main image)', '1'); #EOQ
INSERT INTO `cc4_CubeCart_options_types` VALUES('14', 'visual_horizontal', 'Visual Options (horizontal)', '1'); #EOQ
INSERT INTO `cc4_CubeCart_options_types` VALUES('15', 'visual_vertical', 'Visual Options (vertical)', '1'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_order_history`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_order_history`
--

CREATE TABLE `cc4_CubeCart_order_history` (
  `history_id` int(10) unsigned NOT NULL auto_increment,
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL,
  `status` tinyint(2) unsigned NOT NULL default '0',
  `updated` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`history_id`),
  KEY `cart_order_id` (`cart_order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_order_history` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_order_inventory`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_order_inventory`
--

CREATE TABLE `cc4_CubeCart_order_inventory` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL default '0',
  `product_code` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `name` varchar(225) collate utf8_unicode_ci NOT NULL default '',
  `quantity` int(6) unsigned NOT NULL default '0',
  `price` decimal(16,2) NOT NULL default '0.00',
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL default '',
  `product_options` blob,
  `digital` int(10) unsigned NOT NULL default '0',
  `stock_updated` tinyint(1) unsigned NOT NULL default '0',
  `custom` blob,
  `coupon_id` int(10) unsigned NOT NULL default '0',
  `assign_key` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `hash` varchar(32) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `productId` (`product_id`),
  KEY `cart_order_id` (`cart_order_id`),
  KEY `productId_2` (`product_id`),
  KEY `cart_order_id_2` (`cart_order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_order_inventory`
--

INSERT INTO `cc4_CubeCart_order_inventory` VALUES('51', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '6', '21.00', '120223-232213-8789', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('49', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '2', '7.00', '120221-215341-8137', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('50', '9', '144B6JUF7', '100 4mm Clear AB Hotfix Rhinestones', '1', '2.00', '120222-165455-3051', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('33', '19', 'PNPCZC3O2/TURQ7', 'PnP Lycra Crop Top With Short Puff Sleeves', '1', '10.99', '120104-162811-2214', 'Colour - Turquoise Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '27,64', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('32', '17', 'PNPQ33OT2/PINK7', 'PnP Lycra Catsuit with Short Puffed Sleeves', '1', '17.49', '120104-162811-2214', 'Colour - Electric Pink Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '6,63', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('29', '20', 'PNP8IHMB15/YELL3', 'PnP Lycra Shorts', '1', '7.99', '111215-104103-7193', 'Colour - FL Yellow Matt\r\nSize - 3 Years\r\n', '0', '1', '', '0', '50,74', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('30', '22', 'PNPLJUSL15/YELL3', 'PnP Lycra Halter Neck Tie Top', '1', '10.99', '111215-104103-7193', 'Colour - FL Yellow Matt\r\nSize - 3 Years\r\n', '0', '1', '', '0', '61,72', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('31', '9', '144B6JUF7', '100 4mm Clear AB Hotfix Rhinestones', '20', '40.00', '111226-064806-2952', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('34', '21', 'PNPCY14315/BL7', 'PnP Lycra Leggings', '1', '9.99', '120104-162811-2214', 'Colour - Black Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '38,66', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('36', '17', 'PNPQ33OT2/PINK4', 'PnP Lycra Catsuit with Short Puffed Sleeves', '1', '17.49', '120117-105841-8249', 'Colour - Electric Pink Matt\r\nSize - 4 Years\r\n', '0', '1', '', '0', '6,3', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('37', '24', 'PUF1BUOU15/TURQ4', 'Puffed sleeved unitard', '1', '17.49', '120126-221919-4485', 'Colour - Turquoise Matt\r\nSize - 4 Years\r\n', '0', '0', '', '0', '96,92', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('43', '24', 'PUF1BUOU15/RED3', 'Puffed sleeved unitard', '1', '17.49', '120217-112609-5973', 'Colour - Neon Red Matt\r\nSize - 3 Years\r\n', '0', '1', '', '0', '91,101', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('41', '3', '4MMJSGF79', '100 4mm Clear AB Silverback Rhinestones/Crystals', '2', '3.00', '120215-211311-7245', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('44', '24', 'PUF1BUOU15/PINK4', 'Puffed sleeved unitard', '2', '34.98', '120217-112609-5973', 'Colour - Electric Pink Matt\r\nSize - 4 Years\r\n', '0', '1', '', '0', '95,92', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('45', '17', 'PNPQ33OT2/RED5', 'PnP Lycra Catsuit with Puffed Sleeves', '1', '17.49', '120218-150148-2359', 'Colour - Neon Red Matt\r\nSize - 5 Years\r\n', '0', '1', '', '0', '2,4', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('46', '19', 'PNPCZC3O2/RED5', 'PnP Lycra Crop Top With Puff Sleeves', '1', '10.99', '120220-101443-2085', 'Colour - Neon Red Matt\r\nSize - 5 Years\r\n', '0', '1', '', '0', '22,24', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('47', '21', 'PNPCY14315/RED4', 'PnP Lycra Leggings', '1', '9.99', '120220-101443-2085', 'Colour - Neon Red Matt\r\nSize - 4 Years\r\n', '0', '1', '', '0', '32,33', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('48', '4', '4MMZD5579', '100 4mm Orange AB Silverback Rhinestones', '2', '3.00', '120221-215341-8137', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('52', '43', '144L7R8B15', '144 2mm (SS6) Fushia Pink AB DMC Hotfix Rhinestones', '3', '7.50', '120223-232213-8789', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('53', '22', 'PNPLJUSL15/GREEN7', 'PnP Lycra Halter Neck Tie Top', '1', '10.99', '120225-162703-4186', 'Colour - Acid Green Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '52,62', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('54', '20', 'PNP8IHMB15/GREEN7', 'PnP Lycra Shorts', '1', '7.99', '120225-162703-4186', 'Colour - Acid Green Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '41,67', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('55', '23', 'ROC6WOSS15/WHITENET3', 'Rock &#39;n&#39; Roll Skirt', '1', '19.99', '120229-135213-7825', 'Colour - White Matt\r\nNetting - White\r\nSize - 3 Years\r\n', '0', '0', '', '0', '81,82,89', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('57', '26', 'DISU2GEX15/O8T', 'Disco Freestyle Dance Costume Accessories', '1', '28.00', '120314-165023-6883', 'Colour - Turquoise Matt\r\nSize - Over 8 (Please specify waist s\r\nStones - Crystal AB\r\n', '0', '1', '', '0', '125,169', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('58', '21', 'PNPCY14315/PINK7', 'PnP Lycra Leggings', '1', '9.99', '120315-214032-8714', 'Colour - Electric Pink Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '36,66', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('59', '22', 'PNPLJUSL15/PINK7', 'PnP Lycra Halter Neck Tie Top', '1', '10.99', '120315-214032-8714', 'Colour - Electric Pink Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '57,62', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('60', '19', 'PNPCZC3O2/BL6', 'PnP Lycra Crop Top With Puff Sleeves', '2', '21.98', '120321-231958-3737', 'Colour - Black Matt\r\nSize - 6 Years\r\n', '0', '1', '', '0', '28,25', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('61', '21', 'PNPCY14315/YELL7', 'PnP Lycra Leggings', '1', '9.99', '120328-141406-5418', 'Colour - FL Yellow Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '40,66', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('62', '22', 'PNPLJUSL15/YELL7', 'PnP Lycra Halter Neck Tie Top', '1', '10.99', '120328-141406-5418', 'Colour - FL Yellow Matt\r\nSize - 7 Years\r\n', '0', '1', '', '0', '61,62', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('63', '24', 'PUF1BUOU15/PINK5', 'Puffed sleeved unitard', '1', '17.49', '120328-231238-6726', 'Colour - Electric Pink Matt\r\nSize - 5 Years\r\n', '0', '1', '', '0', '95,93', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('64', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '10', '28.00', '120329-145407-8782', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('65', '15', '1007RLI32', '144 4mm Pink AB Silverback Rhinestones/Crystals', '2', '2.50', '120416-131911-6313', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('66', '26', 'DISU2GEX15/BL6', 'Disco Freestyle Dance Costume Accessories', '1', '15.00', '120417-213448-1802', 'Colour - Black Matt\r\nSize - 6 Years\r\nStones - Without\r\n', '0', '1', '', '0', '126,123', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('67', '20', 'PNP8IHMB15/BL6', 'PnP Lycra Shorts', '1', '7.99', '120417-213448-1802', 'Colour - Black Matt\r\nSize - 6 Years\r\n', '0', '1', '', '0', '48,45', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('68', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '5', '5.00', '120422-194357-9544', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('69', '7', '4MMROKAG9', '144 4mm Purple AB Silverback Rhinestones/Crystals', '1', '1.25', '120422-194357-9544', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('70', '16', '100WNLLQ8', '144 4mm Pink Silverback Rhinestones/Crystals', '1', '1.00', '120422-194357-9544', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('71', '9', '144B6JUF7', '144 4mm Clear AB Hotfix Rhinestones', '2', '3.00', '120426-130204-2116', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('72', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '10', '8.00', '120426-130204-2116', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('73', '4', '4MMZD5579', '144 4mm Orange AB Silverback Rhinestones', '1', '1.25', '120426-130204-2116', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('74', '5', '4MMMAZXF9', '144 4mm Lemon AB Silverback Rhinestones/Crystals', '1', '1.25', '120426-130204-2116', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('75', '6', '4MMQXX7R9', '144 4mm Mint AB Silverback Rhinestones/Crystals', '1', '1.25', '120426-130204-2116', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('76', '15', '1007RLI32', '144 4mm Pink AB Silverback Rhinestones/Crystals', '1', '1.25', '120426-130738-3939', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('77', '17', 'PNPQ33OT2/PINK4', 'PnP Lycra Catsuit with Puffed Sleeves', '1', '17.49', '120430-091931-5451', 'Colour - Electric Pink Matt\r\nSize - 4 Years\r\n', '0', '1', '', '0', '6,3', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('78', '9', '144B6JUF7', '144 4mm Clear AB Hotfix Rhinestones', '1', '1.50', '120430-132914-2081', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('79', '47', 'SECEV05S18', 'Second Hand Crop Top and Shorts', '1', '7.50', '120503-191800-2073', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('80', '5', '4MMMAZXF9', '144 4mm Lemon AB Silverback Rhinestones/Crystals', '1', '1.25', '120503-215101-7821', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('88', '51', 'PNPU8J2P15/BL5', 'PnP Lycra Leotard', '1', '15.00', '120510-074603-6772', 'Colour - Black Matt\r\nSize - 5 Years\r\n', '0', '0', '', '0', '214,211', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('82', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '20', '16.00', '120506-123849-8852', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('87', '47', 'SECEV05S18', 'Second Hand Crop Top and Shorts', '1', '7.50', '120510-074603-6772', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('86', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '2', '2.50', '120510-074603-6772', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('85', '9', '144B6JUF7', '144 4mm Clear AB Hotfix Rhinestones', '10', '10.00', '120506-202916-1835', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('89', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '2', '2.50', '120510-075837-9420', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('90', '47', 'SECEV05S18', 'Second Hand Crop Top and Shorts', '1', '7.50', '120510-075837-9420', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('91', '51', 'PNPU8J2P15/BL5', 'PnP Lycra Leotard', '1', '15.00', '120510-075837-9420', 'Colour - Black Matt\r\nSize - 5 Years\r\n', '0', '1', '', '0', '214,211', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('93', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '10', '8.00', '120519-141737-2262', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('94', '6', '4MMQXX7R9', '144 4mm Mint AB Silverback Rhinestones/Crystals', '5', '5.00', '120519-141737-2262', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('95', '23', 'ROC6WOSS15/REDNET7', 'Rock &#39;n&#39; Roll Skirt', '1', '19.99', '120520-135655-3821', 'Colour - Neon Red Matt\r\nNetting - Black\r\nSize - 7 Years\r\n', '0', '1', '', '0', '79,86,88', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('96', '16', '100WNLLQ8', '144 4mm Pink Silverback Rhinestones/Crystals', '1', '1.00', '120521-130007-3632', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('97', '9', '144B6JUF7', '144 4mm Clear AB Hotfix Rhinestones', '1', '1.50', '120521-130007-3632', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('100', '9', '144B6JUF7', '144 4mm Clear AB Hotfix Rhinestones', '2', '3.00', '120621-143058-8499', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('101', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '1', '3.50', '120621-143058-8499', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('99', '18', 'PNPE1NB815/YELL4', 'PnP Lycra Catsuit with Long Sleeves', '1', '17.49', '120604-214126-4579', 'Colour - FL Yellow Matt\r\nSize - 4 Years\r\n', '0', '1', '', '0', '20,13', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('102', '20', 'PNP8IHMB15/PINK7', 'PnP Lycra Shorts', '1', '7.99', '120710-204805-8547', 'Colour - Electric Pink Matt\r\nSize - 7 Years\r\n', '0', '0', '', '0', '46,67', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('103', '22', 'PNPLJUSL15/PINK7', 'PnP Lycra Halter Neck Tie Top', '1', '10.99', '120710-204805-8547', 'Colour - Electric Pink Matt\r\nSize - 7 Years\r\n', '0', '0', '', '0', '57,62', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('104', '56', '14401ZXZ14', '144 SS20 5mm Clear AB Silverback Rhinestones/Crystals', '1', '2.00', '120711-230224-2457', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('105', '56', '14401ZXZ14', '144 SS20 5mm Clear AB Silverback Rhinestones/Crystals', '1', '2.00', '120711-231120-7119', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('106', '17', 'PNPQ33OT2/PINK5', 'PnP Lycra Catsuit with Puffed Sleeves', '1', '17.49', '120801-204648-4367', 'Colour - Electric Pink Matt\r\nSize - 5 Years\r\n', '0', '1', '', '0', '6,4', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('107', '56', '14401ZXZ14', '144 SS20 5mm Clear AB Silverback Rhinestones/Crystals', '54', '81.00', '120808-230150-3399', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('108', '3', '4MMJSGF79', '144 4mm Clear AB Silverback Rhinestones/Crystals', '26', '20.80', '120808-230150-3399', '', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('109', '19', 'PNPCZC3O2/BL6', 'PnP Lycra Crop Top With Puff Sleeves', '1', '10.99', '120827-124418-6821', 'Colour - Black Matt\r\nSize - 6 Years\r\n', '0', '1', '', '0', '28,25', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('110', '21', 'PNPCY14315/BL6', 'PnP Lycra Leggings', '1', '9.99', '120827-124418-6821', 'Colour - Black Matt\r\nSize - 6 Years\r\n', '0', '1', '', '0', '38,35', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('111', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '3', '10.50', '120901-123501-2198', '', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('112', '57', 'BLITSI0615/CPAB', 'Blinged Competition pins', '2', '5.00', '120926-204400-4073', 'Pin Colour - Aqua Blue\r\n', '0', '1', '', '0', '283', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('113', '18', 'PNPE1NB815', 'PnP Lycra Catsuit with Long Sleeves', '1', '17.49', '121015-112737-6478', 'Size - 7 Years\r\nColour - Electric Pink Matt\r\n', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('114', '26', 'DISU2GEX15', 'Disco Freestyle Dance Costume Accessories', '1', '15.00', '121015-114708-4244', 'Stones - Without\r\nSize - 3 Years\r\nColour - Electric Pink Matt\r\n', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('115', '17', 'PNPQ33OT2', 'PnP Lycra Catsuit with Puffed Sleeves', '1', '17.49', '121015-203658-9485', 'Size - 4 Years\r\nColour - Neon Red Matt\r\n', '0', '0', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('116', '57', 'BLITSI0615', 'Blinged Competition pins', '2', '5.00', '121015-211741-2192', 'Pin Colour - Light Pink\r\n', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('117', '17', 'PNPQ33OT2', 'PnP Lycra Catsuit with Puffed Sleeves', '1', '17.49', '121016-120035-7927', 'Size - 4 Years\r\nColour - Neon Red Matt\r\n', '0', '1', '', '0', '', ''); #EOQ
INSERT INTO `cc4_CubeCart_order_inventory` VALUES('118', '40', '144RJFR723', '144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones', '1', '3.50', '121024-170942-3703', '', '0', '1', '', '0', '', ''); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_order_notes`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_order_notes`
--

CREATE TABLE `cc4_CubeCart_order_notes` (
  `note_id` int(10) unsigned NOT NULL auto_increment,
  `admin_id` int(10) unsigned NOT NULL,
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `content` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`note_id`),
  KEY `admin_id` (`admin_id`),
  KEY `cart_order_id` (`cart_order_id`),
  KEY `time` (`time`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_order_notes` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_order_summary`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_order_summary`
--

CREATE TABLE `cc4_CubeCart_order_summary` (
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `line1` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `line2` varchar(150) collate utf8_unicode_ci default NULL,
  `town` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `state` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `postcode` varchar(50) collate utf8_unicode_ci NOT NULL default '',
  `country` varchar(200) collate utf8_unicode_ci default NULL,
  `name_d` varchar(255) collate utf8_unicode_ci default NULL,
  `line1_d` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `line2_d` varchar(150) collate utf8_unicode_ci default NULL,
  `town_d` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `state_d` varchar(150) collate utf8_unicode_ci NOT NULL default '',
  `postcode_d` varchar(50) collate utf8_unicode_ci NOT NULL default '',
  `country_d` varchar(200) collate utf8_unicode_ci default NULL,
  `phone` varchar(50) collate utf8_unicode_ci default NULL,
  `mobile` varchar(50) collate utf8_unicode_ci default NULL,
  `subtotal` decimal(16,2) unsigned NOT NULL default '0.00',
  `discount` decimal(16,2) unsigned NOT NULL default '0.00',
  `total` decimal(16,2) unsigned NOT NULL default '0.00',
  `total_tax` decimal(16,2) unsigned NOT NULL default '0.00',
  `shipping` decimal(16,2) unsigned NOT NULL default '0.00',
  `status` tinyint(1) unsigned NOT NULL default '1',
  `sec_order_id` varchar(30) collate utf8_unicode_ci default NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL default '',
  `order_date` int(10) unsigned NOT NULL default '0',
  `email` varchar(254) collate utf8_unicode_ci default NULL,
  `comments` text collate utf8_unicode_ci,
  `ship_date` date default NULL,
  `ship_method` varchar(100) collate utf8_unicode_ci default NULL,
  `gateway` varchar(100) collate utf8_unicode_ci NOT NULL default '',
  `currency` varchar(5) collate utf8_unicode_ci NOT NULL,
  `customer_comments` text collate utf8_unicode_ci,
  `extra_notes` text collate utf8_unicode_ci NOT NULL,
  `tax1_disp` varchar(128) collate utf8_unicode_ci default NULL,
  `tax1_amt` decimal(30,2) NOT NULL default '0.00',
  `tax2_disp` varchar(128) collate utf8_unicode_ci default NULL,
  `tax2_amt` decimal(30,2) NOT NULL default '0.00',
  `tax3_disp` varchar(128) collate utf8_unicode_ci default NULL,
  `tax3_amt` decimal(30,2) NOT NULL default '0.00',
  `offline_capture` blob,
  `ship_tracking` varchar(100) collate utf8_unicode_ci default NULL,
  `company_name` varchar(200) collate utf8_unicode_ci default NULL,
  `company_name_d` varchar(200) collate utf8_unicode_ci default NULL,
  `basket` text collate utf8_unicode_ci,
  `lang` varchar(5) collate utf8_unicode_ci default NULL,
  `dashboard` tinyint(1) unsigned NOT NULL default '0',
  `title` varchar(100) collate utf8_unicode_ci default NULL,
  `first_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `title_d` varchar(100) collate utf8_unicode_ci NOT NULL,
  `first_name_d` varchar(100) collate utf8_unicode_ci NOT NULL,
  `last_name_d` varchar(100) collate utf8_unicode_ci NOT NULL,
  `discount_type` char(1) collate utf8_unicode_ci NOT NULL default 'f',
  PRIMARY KEY  (`cart_order_id`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`),
  KEY `email` (`email`),
  KEY `order_date` (`order_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_order_summary`
--

INSERT INTO `cc4_CubeCart_order_summary` VALUES('120225-162703-4186', '26', 'miss leah selwood', '11 annesley road', '', 'Newport', 'Gwent', 'np197ey', '826', 'miss leah selwood', '11 annesley road', '', 'Newport', 'Gwent', 'np197ey', '826', '07717686739', '07717686739', '18.98', '0.00', '18.98', '0.00', '0.00', '3', '', '212.183.128.142', '1330187223', 'leahselwood@live.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:20:\"22{:}5{@}52{|}6{@}62\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1330186572;}s:20:\"20{:}5{@}41{|}6{@}67\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1330186705;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"22\";s:4:\"name\";s:29:\"PnP Lycra Halter Neck Tie Top\";s:11:\"productCode\";s:17:\"PNPLJUSL15/GREEN7\";s:11:\"prodOptions\";s:42:\"Colour - Acid Green Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"52,62\";}i:2;a:8:{s:9:\"productId\";s:2:\"20\";s:4:\"name\";s:16:\"PnP Lycra Shorts\";s:11:\"productCode\";s:17:\"PNP8IHMB15/GREEN7\";s:11:\"prodOptions\";s:42:\"Colour - Acid Green Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:4:\"7.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"41,67\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:4:\"leah\";s:8:\"lastName\";s:7:\"selwood\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"11 annesley road\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:7:\"Newport\";s:6:\"county\";s:5:\"Gwent\";s:8:\"postcode\";s:7:\"np197ey\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"18.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"18.98\";}', 'en', '0', 'miss', 'leah', 'selwood', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('111215-104103-7193', '6', 'miss emma crawley', '90', 'brynglas drive', 'newport', 'Gwent', 'np20 5qs', '826', 'miss emma crawley', '90', 'brynglas drive', 'newport', 'Gwent', 'np20 5qs', '826', '07521273518', '', '18.98', '0.00', '18.98', '0.00', '0.00', '3', '', '86.140.115.191', '1323963663', 'fishgirlcrawley@sky.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:20:\"20{:}5{@}50{|}6{@}74\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1323963611;}s:20:\"22{:}5{@}61{|}6{@}72\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1323963646;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:4:\"emma\";s:8:\"lastName\";s:7:\"crawley\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:2:\"90\";s:5:\"add_2\";s:14:\"brynglas drive\";s:4:\"town\";s:7:\"newport\";s:6:\"county\";s:5:\"Gwent\";s:8:\"postcode\";s:8:\"np20 5qs\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"20\";s:4:\"name\";s:16:\"PnP Lycra Shorts\";s:11:\"productCode\";s:16:\"PNP8IHMB15/YELL3\";s:11:\"prodOptions\";s:41:\"Colour - FL Yellow Matt\r\nSize - 3 Years\r\n\";s:5:\"price\";s:4:\"7.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"50,74\";}i:2;a:8:{s:9:\"productId\";s:2:\"22\";s:4:\"name\";s:29:\"PnP Lycra Halter Neck Tie Top\";s:11:\"productCode\";s:16:\"PNPLJUSL15/YELL3\";s:11:\"prodOptions\";s:41:\"Colour - FL Yellow Matt\r\nSize - 3 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"61,72\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"18.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"18.98\";}', 'en', '0', 'miss', 'emma', 'crawley', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120223-232213-8789', '24', 'mrs helen carvell', '190 Allerton Road', 'Allerton', 'Liverpool', 'Merseyside', 'L18 5HU', '826', 'mrs helen carvell', '190 Allerton Road', 'Allerton', 'Liverpool', 'Merseyside', 'L18 5HU', '826', '01514878704', '', '28.50', '0.00', '28.50', '0.00', '0.00', '3', '', '90.219.183.73', '1330039333', 'helen.carvell@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'chandlers', 'chandlers', 'a:10:{s:5:\"conts\";a:2:{s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:6;s:9:\"timestamp\";i:1330038406;}s:5:\"43{:}\";a:2:{s:8:\"quantity\";d:3;s:9:\"timestamp\";i:1330038513;}}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"21.00\";s:8:\"quantity\";d:6;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:2:\"43\";s:4:\"name\";s:51:\"144 2mm (SS6) Fushia Pink AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144L7R8B15\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"7.50\";s:8:\"quantity\";d:3;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"helen\";s:8:\"lastName\";s:7:\"carvell\";s:11:\"companyName\";s:9:\"chandlers\";s:5:\"add_1\";s:17:\"190 Allerton Road\";s:5:\"add_2\";s:8:\"Allerton\";s:4:\"town\";s:9:\"Liverpool\";s:6:\"county\";s:10:\"Merseyside\";s:8:\"postcode\";s:7:\"L18 5HU\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"28.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"28.50\";}', 'en', '0', 'mrs', 'helen', 'carvell', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('111226-064806-2952', '8', 'Miss Mariska Garcia', '70 hamstead hill', 'Handsworth wood', 'Birmingham', 'West Midlands', 'B201da', '826', 'Miss Mariska Garcia', '70 hamstead hill', 'Handsworth wood', 'Birmingham', 'West Midlands', 'B201da', '826', '07811546487', '', '40.00', '0.00', '40.00', '0.00', '0.00', '3', '', '2.96.86.51', '1324900086', 'mariskagarcia@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'Mariska Garcia', 'Mariska Garcia', 'a:10:{s:5:\"conts\";a:1:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:20;s:9:\"timestamp\";i:1324900044;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:7:\"Mariska\";s:8:\"lastName\";s:6:\"Garcia\";s:11:\"companyName\";s:14:\"Mariska Garcia\";s:5:\"add_1\";s:16:\"70 hamstead hill\";s:5:\"add_2\";s:15:\"Handsworth wood\";s:4:\"town\";s:10:\"Birmingham\";s:6:\"county\";s:13:\"West Midlands\";s:8:\"postcode\";s:6:\"B201da\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"100 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"40.00\";s:8:\"quantity\";s:2:\"20\";s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"40.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"40.00\";}', 'en', '0', 'Miss', 'Mariska', 'Garcia', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120104-162811-2214', '11', 'mr lewis stephen', '3 mcgregor cres', '', 'peterhead', 'Aberdeenshire', 'ab421ge', '826', 'mr lewis stephen', '3 mcgregor cres', '', 'peterhead', 'Aberdeenshire', 'ab421ge', '826', '01779481157', '', '38.47', '0.00', '38.47', '0.00', '0.00', '3', '', '95.146.87.121', '1325712491', 'lewisgsc22@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:3:{s:19:\"17{:}5{@}6{|}6{@}63\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1325712229;}s:20:\"19{:}5{@}27{|}6{@}64\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1325712262;}s:20:\"21{:}5{@}38{|}6{@}66\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1325712338;}}s:8:\"invArray\";a:3:{i:1;a:8:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:43:\"PnP Lycra Catsuit with Short Puffed Sleeves\";s:11:\"productCode\";s:15:\"PNPQ33OT2/PINK7\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:4:\"6,63\";}i:2;a:8:{s:9:\"productId\";s:2:\"19\";s:4:\"name\";s:42:\"PnP Lycra Crop Top With Short Puff Sleeves\";s:11:\"productCode\";s:15:\"PNPCZC3O2/TURQ7\";s:11:\"prodOptions\";s:41:\"Colour - Turquoise Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"27,64\";}i:3;a:8:{s:9:\"productId\";s:2:\"21\";s:4:\"name\";s:18:\"PnP Lycra Leggings\";s:11:\"productCode\";s:14:\"PNPCY14315/BL7\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:4:\"9.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"38,66\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:2:\"mr\";s:9:\"firstName\";s:5:\"lewis\";s:8:\"lastName\";s:7:\"stephen\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:15:\"3 mcgregor cres\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"peterhead\";s:6:\"county\";s:13:\"Aberdeenshire\";s:8:\"postcode\";s:7:\"ab421ge\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"38.47\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"38.47\";}', 'en', '0', 'mr', 'lewis', 'stephen', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120117-105841-8249', '14', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', '01779472103', '', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '88.104.220.107', '1326815921', 'sarahlvsdrew2@tiscali.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:18:\"17{:}5{@}6{|}6{@}3\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1326815419;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:43:\"PnP Lycra Catsuit with Short Puffed Sleeves\";s:11:\"productCode\";s:15:\"PNPQ33OT2/PINK4\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:3:\"6,3\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"sarah\";s:8:\"lastName\";s:6:\"norris\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"27 prunier drive\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"peterhead\";s:6:\"county\";s:13:\"Aberdeenshire\";s:8:\"postcode\";s:7:\"ab421zf\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";}', 'en', '0', 'mrs', 'sarah', 'norris', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120126-221919-4485', '18', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', '01257 368248', '', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '81.158.96.111', '1327616359', 'lorrainesankey@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'dancestyles', 'dancestyles', 'a:10:{s:5:\"conts\";a:1:{s:20:\"24{:}5{@}96{|}6{@}92\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1327616335;}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"Lorraine\";s:8:\"lastName\";s:6:\"Sankey\";s:11:\"companyName\";s:11:\"dancestyles\";s:5:\"add_1\";s:13:\"3 North Drive\";s:5:\"add_2\";s:13:\"Appley Bridge\";s:4:\"town\";s:5:\"Wigan\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:7:\"wn6 9dz\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"24\";s:4:\"name\";s:22:\"Puffed sleeved unitard\";s:11:\"productCode\";s:16:\"PUF1BUOU15/TURQ4\";s:11:\"prodOptions\";s:41:\"Colour - Turquoise Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"96,92\";}}s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";}', 'en', '0', 'miss', 'Lorraine', 'Sankey', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120222-165455-3051', '25', 'lisa watts', '3 glyngaer road', 'glyngaer', 'Hengoed', 'Gwent', 'CF828FJ', '826', 'lisa watts', '3 glyngaer road', 'glyngaer', 'Hengoed', 'Gwent', 'CF828FJ', '826', '441443836055', '441443836055', '2.00', '0.00', '2.00', '0.00', '0.00', '3', '', '90.214.31.57', '1329929695', 'shannonroberts.roberts24@googlemail.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1329928831;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"100 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"lisa\";s:8:\"lastName\";s:5:\"watts\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:15:\"3 glyngaer road\";s:5:\"add_2\";s:8:\"glyngaer\";s:4:\"town\";s:7:\"Hengoed\";s:6:\"county\";s:5:\"Gwent\";s:8:\"postcode\";s:7:\"CF828FJ\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"2.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"2.00\";}', 'en', '0', '', 'lisa', 'watts', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120215-211311-7245', '22', 'MRS CAROL OBRIEN', '3 Hesketh Court', '', 'GREAT HARWOOD', 'Lancashire', 'BB6 7TY', '826', 'MRS CAROL OBRIEN', '3 Hesketh Court', '', 'GREAT HARWOOD', 'Lancashire', 'BB6 7TY', '826', '01254882037', '', '3.00', '0.00', '3.00', '0.00', '0.00', '3', '', '2.100.212.108', '1329340391', 'carolruthobrien@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', 'please leave around back if not in', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1329340126;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"100 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"MRS\";s:9:\"firstName\";s:5:\"CAROL\";s:8:\"lastName\";s:6:\"OBRIEN\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:15:\"3 Hesketh Court\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:13:\"GREAT HARWOOD\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:7:\"BB6 7TY\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"3.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"3.00\";}', 'en', '0', 'MRS', 'CAROL', 'OBRIEN', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120217-112609-5973', '18', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', '01257 368248', '', '52.47', '0.00', '52.47', '0.00', '0.00', '3', '', '81.148.225.169', '1329477969', 'lorrainesankey@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'dancestyles', 'dancestyles', 'a:10:{s:5:\"conts\";a:2:{s:21:\"24{:}5{@}91{|}6{@}101\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1329477799;}s:20:\"24{:}5{@}95{|}6{@}92\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1329477917;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"Lorraine\";s:8:\"lastName\";s:6:\"Sankey\";s:11:\"companyName\";s:11:\"dancestyles\";s:5:\"add_1\";s:13:\"3 North Drive\";s:5:\"add_2\";s:13:\"Appley Bridge\";s:4:\"town\";s:5:\"Wigan\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:7:\"wn6 9dz\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"24\";s:4:\"name\";s:22:\"Puffed sleeved unitard\";s:11:\"productCode\";s:15:\"PUF1BUOU15/RED3\";s:11:\"prodOptions\";s:40:\"Colour - Neon Red Matt\r\nSize - 3 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:6:\"91,101\";}i:2;a:8:{s:9:\"productId\";s:2:\"24\";s:4:\"name\";s:22:\"Puffed sleeved unitard\";s:11:\"productCode\";s:16:\"PUF1BUOU15/PINK4\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:5:\"34.98\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"95,92\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"52.47\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"52.47\";}', 'en', '0', 'miss', 'Lorraine', 'Sankey', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120218-150148-2359', '23', 'miss kelly jones', '14 cremlyn', 'bethel', 'caernarfon', 'Gwynedd', 'll551aj', '826', 'miss kelly jones', '14 cremlyn', 'bethel', 'caernarfon', 'Gwynedd', 'll551aj', '826', '01248679192', '07748767558', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '86.141.97.204', '1329577308', 'kelly-rus@hotmail.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:18:\"17{:}5{@}2{|}6{@}4\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1329576713;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:37:\"PnP Lycra Catsuit with Puffed Sleeves\";s:11:\"productCode\";s:14:\"PNPQ33OT2/RED5\";s:11:\"prodOptions\";s:40:\"Colour - Neon Red Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:3:\"2,4\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:5:\"kelly\";s:8:\"lastName\";s:5:\"jones\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:10:\"14 cremlyn\";s:5:\"add_2\";s:6:\"bethel\";s:4:\"town\";s:10:\"caernarfon\";s:6:\"county\";s:7:\"Gwynedd\";s:8:\"postcode\";s:7:\"ll551aj\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";}', 'en', '0', 'miss', 'kelly', 'jones', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120220-101443-2085', '14', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', '01779472103', '', '20.98', '0.00', '20.98', '0.00', '0.00', '3', '', '88.104.211.243', '1329732883', 'sarahlvsdrew2@tiscali.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', 'Hi this is my discount code DISCOUNT15SN I&#39;m not sure if it worked or not! Thanks x', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:20:\"19{:}5{@}22{|}6{@}24\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1329732599;}s:20:\"21{:}5{@}32{|}6{@}33\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1329732656;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"19\";s:4:\"name\";s:36:\"PnP Lycra Crop Top With Puff Sleeves\";s:11:\"productCode\";s:14:\"PNPCZC3O2/RED5\";s:11:\"prodOptions\";s:40:\"Colour - Neon Red Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"22,24\";}i:2;a:8:{s:9:\"productId\";s:2:\"21\";s:4:\"name\";s:18:\"PnP Lycra Leggings\";s:11:\"productCode\";s:15:\"PNPCY14315/RED4\";s:11:\"prodOptions\";s:40:\"Colour - Neon Red Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:4:\"9.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"32,33\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"sarah\";s:8:\"lastName\";s:6:\"norris\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"27 prunier drive\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"peterhead\";s:6:\"county\";s:13:\"Aberdeenshire\";s:8:\"postcode\";s:7:\"ab421zf\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"20.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"20.98\";}', 'en', '0', 'mrs', 'sarah', 'norris', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120221-215341-8137', '24', 'mrs helen carvell', '190-194 Allerton Road', 'Allerton', 'Liverpool', 'Merseyside', 'L18 5HU', '826', 'mrs helen carvell', '190-194 Allerton Road', 'Allerton', 'Liverpool', 'Merseyside', 'L18 5HU', '826', '01514878704', '', '10.00', '0.00', '10.00', '0.00', '0.00', '3', '', '90.219.183.73', '1329861221', 'helen.carvell@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'Chandlers', 'Chandlers', 'a:10:{s:5:\"conts\";a:2:{s:4:\"4{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1329860246;}s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1329857567;}}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:1:\"4\";s:4:\"name\";s:40:\"100 4mm Orange AB Silverback Rhinestones\";s:11:\"productCode\";s:9:\"4MMZD5579\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"7.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"helen\";s:8:\"lastName\";s:7:\"carvell\";s:11:\"companyName\";s:9:\"Chandlers\";s:5:\"add_1\";s:21:\"190-194 Allerton Road\";s:5:\"add_2\";s:8:\"Allerton\";s:4:\"town\";s:9:\"Liverpool\";s:6:\"county\";s:10:\"Merseyside\";s:8:\"postcode\";s:7:\"L18 5HU\";s:7:\"country\";s:3:\"225\";}s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"10.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"10.00\";}', 'en', '0', 'mrs', 'helen', 'carvell', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120229-135213-7825', '27', 'mr aaaaaaa aaaaaaaa', 'aaaaaa', '', 'aaaaaaaaaaa', 'Cumberland', 'aa11aa', '826', 'mr aaaaaaa aaaaaaaa', 'aaaaaa', '', 'aaaaaaaaaaa', 'Cumberland', 'aa11aa', '826', '0000000', '', '19.99', '0.00', '19.99', '0.00', '0.00', '4', '', '176.35.203.86', '1330523533', 'aaa@aaa.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Undefined', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:29:\"23{:}5{@}81{|}9{@}89{|}6{@}82\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1330523453;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"23\";s:4:\"name\";s:27:\"Rock &#39;n&#39; Roll Skirt\";s:11:\"productCode\";s:20:\"ROC6WOSS15/WHITENET3\";s:11:\"prodOptions\";s:54:\"Colour - White Matt\r\nNetting - White\r\nSize - 3 Years\r\n\";s:5:\"price\";s:5:\"19.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:8:\"81,82,89\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:2:\"mr\";s:9:\"firstName\";s:7:\"aaaaaaa\";s:8:\"lastName\";s:8:\"aaaaaaaa\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:6:\"aaaaaa\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:11:\"aaaaaaaaaaa\";s:6:\"county\";s:10:\"Cumberland\";s:8:\"postcode\";s:6:\"aa11aa\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"19.99\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"19.99\";}', 'en', '0', 'mr', 'aaaaaaa', 'aaaaaaaa', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120314-165023-6883', '28', 'Mrs Dionne Dunn', '3 CLEADON HILL ROAD', '', 'SOUTH SHIELDS', 'Tyne and Wear', 'NE34 8DR', '826', 'Mrs Dionne Dunn', '3 CLEADON HILL ROAD', '', 'SOUTH SHIELDS', 'Tyne and Wear', 'NE34 8DR', '826', '07747136693', '', '28.00', '0.00', '28.00', '0.00', '0.00', '3', '', '77.103.53.244', '1331740223', 'dionnedunn68@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:33:\"26{:}5{@}125{|}6{@}169{|}10{@}179\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1331740035;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"26\";s:4:\"name\";s:41:\"Disco Freestyle Dance Costume Accessories\";s:11:\"productCode\";s:14:\"DISU2GEX15/O8T\";s:11:\"prodOptions\";s:85:\"Colour - Turquoise Matt\r\nSize - Over 8 (Please specify waist s\r\nStones - Crystal AB\r\n\";s:5:\"price\";s:5:\"28.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:7:\"125,169\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:6:\"Dionne\";s:8:\"lastName\";s:4:\"Dunn\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:19:\"3 CLEADON HILL ROAD\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:13:\"SOUTH SHIELDS\";s:6:\"county\";s:13:\"Tyne and Wear\";s:8:\"postcode\";s:8:\"NE34 8DR\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"28.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"28.00\";}', 'en', '0', 'Mrs', 'Dionne', 'Dunn', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120315-214032-8714', '29', 'Mr David Williams', '254 Miller way', 'Thornbury', 'Plymouth', 'Devon', 'PL6 8UQ', '826', 'Mr David Williams', '254 Miller way', 'Thornbury', 'Plymouth', 'Devon', 'PL6 8UQ', '826', '01752291304', '', '20.98', '0.00', '20.98', '0.00', '0.00', '3', '', '94.169.237.53', '1331844032', 'debzwills@blueyonder.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:20:\"21{:}5{@}36{|}6{@}66\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1331843528;}s:20:\"22{:}5{@}57{|}6{@}62\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1331843700;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"21\";s:4:\"name\";s:18:\"PnP Lycra Leggings\";s:11:\"productCode\";s:16:\"PNPCY14315/PINK7\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:4:\"9.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"36,66\";}i:2;a:8:{s:9:\"productId\";s:2:\"22\";s:4:\"name\";s:29:\"PnP Lycra Halter Neck Tie Top\";s:11:\"productCode\";s:16:\"PNPLJUSL15/PINK7\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"57,62\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:2:\"Mr\";s:9:\"firstName\";s:5:\"David\";s:8:\"lastName\";s:8:\"Williams\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:14:\"254 Miller way\";s:5:\"add_2\";s:9:\"Thornbury\";s:4:\"town\";s:8:\"Plymouth\";s:6:\"county\";s:5:\"Devon\";s:8:\"postcode\";s:7:\"PL6 8UQ\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"20.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"20.98\";}', 'en', '0', 'Mr', 'David', 'Williams', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120321-231958-3737', '19', 'MRS LAURA HICKMAN', '17 herne road', 'cosham', 'portsmouth', 'Hampshire', 'po6 3pb', '826', 'MRS LAURA HICKMAN', '17 herne road', 'cosham', 'portsmouth', 'Hampshire', 'po6 3pb', '826', '02392341762', '07732072808', '21.98', '20.00', '1.98', '0.00', '0.00', '3', '', '82.24.228.112', '1332368398', 'laulau_laulau@hotmail.co.uk', 'Voucher: WHERESTIFF_111', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', 'Sorry this should have been updated on Friday I am sure you have the tops by now, hope you like them and well done for winning the voucher! Keep an eye out for the next comp!', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:14:{s:5:\"conts\";a:1:{s:20:\"19{:}5{@}28{|}6{@}25\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1332326980;}}s:10:\"codeResult\";i:0;s:4:\"code\";s:14:\"WHERESTIFF_111\";s:16:\"discount_percent\";s:4:\"0.00\";s:14:\"discount_price\";s:5:\"20.00\";s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"19\";s:4:\"name\";s:36:\"PnP Lycra Crop Top With Puff Sleeves\";s:11:\"productCode\";s:13:\"PNPCZC3O2/BL6\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 6 Years\r\n\";s:5:\"price\";s:5:\"21.98\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"28,25\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"MRS\";s:9:\"firstName\";s:5:\"LAURA\";s:8:\"lastName\";s:7:\"HICKMAN\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:13:\"17 herne road\";s:5:\"add_2\";s:6:\"cosham\";s:4:\"town\";s:10:\"portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"po6 3pb\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";d:20;s:8:\"subTotal\";s:4:\"1.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"1.98\";}', 'en', '0', 'MRS', 'LAURA', 'HICKMAN', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120328-141406-5418', '30', 'paul duffin', '33, seaway crescent', 'milton', 'portsmouth', 'Hampshire', 'po4 8ll', '826', 'paul duffin', '33, seaway crescent', 'milton', 'portsmouth', 'Hampshire', 'po4 8ll', '826', '02392737356', '', '20.98', '0.00', '20.98', '0.00', '0.00', '3', '', '92.24.122.132', '1332940446', 'paulduffin02@live.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:20:\"21{:}5{@}40{|}6{@}66\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1332939558;}s:20:\"22{:}5{@}61{|}6{@}62\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1332939838;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"21\";s:4:\"name\";s:18:\"PnP Lycra Leggings\";s:11:\"productCode\";s:16:\"PNPCY14315/YELL7\";s:11:\"prodOptions\";s:41:\"Colour - FL Yellow Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:4:\"9.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"40,66\";}i:2;a:8:{s:9:\"productId\";s:2:\"22\";s:4:\"name\";s:29:\"PnP Lycra Halter Neck Tie Top\";s:11:\"productCode\";s:16:\"PNPLJUSL15/YELL7\";s:11:\"prodOptions\";s:41:\"Colour - FL Yellow Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"61,62\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"paul\";s:8:\"lastName\";s:6:\"duffin\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:19:\"33, seaway crescent\";s:5:\"add_2\";s:6:\"milton\";s:4:\"town\";s:10:\"portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"po4 8ll\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"20.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"20.98\";}', 'en', '0', '', 'paul', 'duffin', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120328-231238-6726', '18', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', 'miss Lorraine Sankey', '3 North Drive', 'Appley Bridge', 'Wigan', 'Lancashire', 'wn6 9dz', '826', '01257 368248', '', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '86.131.20.100', '1332972758', 'lorrainesankey@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', 'PLEASE DELIVER NEXT DAY AS DISSCUSSED ON TELEPHONE', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'dancestyles', 'dancestyles', 'a:10:{s:5:\"conts\";a:1:{s:20:\"24{:}5{@}95{|}6{@}93\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1332972720;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"Lorraine\";s:8:\"lastName\";s:6:\"Sankey\";s:11:\"companyName\";s:11:\"dancestyles\";s:5:\"add_1\";s:13:\"3 North Drive\";s:5:\"add_2\";s:13:\"Appley Bridge\";s:4:\"town\";s:5:\"Wigan\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:7:\"wn6 9dz\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"24\";s:4:\"name\";s:22:\"Puffed sleeved unitard\";s:11:\"productCode\";s:16:\"PUF1BUOU15/PINK5\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"95,93\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";}', 'en', '0', 'miss', 'Lorraine', 'Sankey', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120329-145407-8782', '12', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', '12345656', '12345667', '28.00', '0.00', '28.00', '0.00', '0.00', '3', '', '195.212.29.84', '1333029247', 'mark@fabian-lovely.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:10;s:9:\"timestamp\";i:1333029195;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"28.00\";s:8:\"quantity\";d:10;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"Mark\";s:8:\"lastName\";s:13:\"Fabian-Lovely\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"8 Edgerly Gardens\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:10:\"Portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:15:\"mark@fabian-lov\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"28.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"28.00\";}', 'en', '0', '', 'Mark', 'Fabian-Lovely', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120416-131911-6313', '31', 'mrs stephanie hodson', '8 riverside cottage', 'roseworthy', 'camborne', 'Cornwall', 'tr14 0du', '826', 'mrs stephanie hodson', '8 riverside cottage', 'roseworthy', 'camborne', 'Cornwall', 'tr14 0du', '826', '01209718084', '', '2.50', '0.00', '2.50', '0.00', '0.00', '3', '', '2.125.22.75', '1334578751', 's-hodson@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:5:\"15{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1334578348;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"15\";s:4:\"name\";s:47:\"144 4mm Pink AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"1007RLI32\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.50\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:9:\"stephanie\";s:8:\"lastName\";s:6:\"hodson\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:19:\"8 riverside cottage\";s:5:\"add_2\";s:10:\"roseworthy\";s:4:\"town\";s:8:\"camborne\";s:6:\"county\";s:8:\"Cornwall\";s:8:\"postcode\";s:8:\"tr14 0du\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"2.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"2.50\";}', 'en', '0', 'mrs', 'stephanie', 'hodson', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120417-213448-1802', '32', 'MRS Dawn Waddell', '7 Pavilion Gardens', '', 'Irvine', 'Ayrshire', 'KA11 2FH', '826', 'MRS Dawn Waddell', '7 Pavilion Gardens', '', 'Irvine', 'Ayrshire', 'KA11 2FH', '826', '07592841033', '07592841033', '22.99', '0.00', '22.99', '0.00', '0.00', '3', '', '90.213.253.20', '1334694888', 'mrsbunchies@yahoo.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', 'HER COMP IS ON SUNDAY WILL IT ARRIVE BY THEN?', 'Order should be with you by Friday', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:2:{s:33:\"26{:}5{@}126{|}6{@}123{|}10{@}180\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1334694516;}s:20:\"20{:}5{@}48{|}6{@}45\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1334694603;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"26\";s:4:\"name\";s:41:\"Disco Freestyle Dance Costume Accessories\";s:11:\"productCode\";s:14:\"DISU2GEX15/BL6\";s:11:\"prodOptions\";s:55:\"Colour - Black Matt\r\nSize - 6 Years\r\nStones - Without\r\n\";s:5:\"price\";s:5:\"15.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:7:\"126,123\";}i:2;a:8:{s:9:\"productId\";s:2:\"20\";s:4:\"name\";s:16:\"PnP Lycra Shorts\";s:11:\"productCode\";s:14:\"PNP8IHMB15/BL6\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 6 Years\r\n\";s:5:\"price\";s:4:\"7.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"48,45\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"MRS\";s:9:\"firstName\";s:4:\"Dawn\";s:8:\"lastName\";s:7:\"Waddell\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:18:\"7 Pavilion Gardens\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:6:\"Irvine\";s:6:\"county\";s:8:\"Ayrshire\";s:8:\"postcode\";s:8:\"KA11 2FH\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"22.99\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"22.99\";}', 'en', '0', 'MRS', 'Dawn', 'Waddell', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120422-194357-9544', '33', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', '07521325738', '07521325738', '7.25', '0.00', '7.25', '0.00', '0.00', '3', '', '89.242.111.118', '1335120237', 'candt20112011@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:3:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:5;s:9:\"timestamp\";i:1335119423;}s:4:\"7{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335119778;}s:5:\"16{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335119910;}}s:8:\"invArray\";a:3:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"5.00\";s:8:\"quantity\";d:5;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:1:\"7\";s:4:\"name\";s:49:\"144 4mm Purple AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMROKAG9\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:3;a:7:{s:9:\"productId\";s:2:\"16\";s:4:\"name\";s:44:\"144 4mm Pink Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"100WNLLQ8\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"charlene\";s:8:\"lastName\";s:7:\"mcgrail\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"25 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:8:\"bt71 6us\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"7.25\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"7.25\";}', 'en', '0', 'miss', 'charlene', 'mcgrail', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120426-130204-2116', '33', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', '07521325738', '07521325738', '14.75', '0.00', '14.75', '0.00', '0.00', '3', '', '78.146.92.180', '1335441725', 'candt20112011@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:5:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1335441124;}s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:10;s:9:\"timestamp\";i:1335441190;}s:4:\"4{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335441270;}s:4:\"5{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335441425;}s:4:\"6{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335441590;}}s:7:\"shipKey\";i:1;s:8:\"invArray\";a:5:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"144 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"8.00\";s:8:\"quantity\";d:10;s:7:\"digital\";s:1:\"0\";}i:3;a:7:{s:9:\"productId\";s:1:\"4\";s:4:\"name\";s:40:\"144 4mm Orange AB Silverback Rhinestones\";s:11:\"productCode\";s:9:\"4MMZD5579\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:4;a:7:{s:9:\"productId\";s:1:\"5\";s:4:\"name\";s:48:\"144 4mm Lemon AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMMAZXF9\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:5;a:7:{s:9:\"productId\";s:1:\"6\";s:4:\"name\";s:47:\"144 4mm Mint AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMQXX7R9\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"charlene\";s:8:\"lastName\";s:7:\"mcgrail\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"25 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:8:\"bt71 6us\";s:7:\"country\";s:3:\"225\";}s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"14.75\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"14.75\";}', 'en', '0', 'miss', 'charlene', 'mcgrail', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120426-130738-3939', '33', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', '07521325738', '07521325738', '1.25', '0.00', '1.25', '0.00', '0.00', '3', '', '78.146.92.180', '1335442058', 'candt20112011@hotmail.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:5:\"15{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335442009;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"charlene\";s:8:\"lastName\";s:7:\"mcgrail\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"25 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:8:\"bt71 6us\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"15\";s:4:\"name\";s:47:\"144 4mm Pink AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"1007RLI32\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"1.25\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"1.25\";}', 'en', '0', 'miss', 'charlene', 'mcgrail', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120430-091931-5451', '34', 'Mrs Jacqueline Handley', '5 Hawfield Road', '', 'Tividale', 'West Midlands', 'B69 1LQ', '826', 'Mrs Jacqueline Handley', '5 Hawfield Road', '', 'Tividale', 'West Midlands', 'B69 1LQ', '826', '01384230639', '07960961272', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '94.5.59.234', '1335773971', 'jay.handley@sky.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', 'none', 'none', 'a:10:{s:5:\"conts\";a:1:{s:18:\"17{:}5{@}6{|}6{@}3\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335773650;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:37:\"PnP Lycra Catsuit with Puffed Sleeves\";s:11:\"productCode\";s:15:\"PNPQ33OT2/PINK4\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:3:\"6,3\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:10:\"Jacqueline\";s:8:\"lastName\";s:7:\"Handley\";s:11:\"companyName\";s:4:\"none\";s:5:\"add_1\";s:15:\"5 Hawfield Road\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:8:\"Tividale\";s:6:\"county\";s:13:\"West Midlands\";s:8:\"postcode\";s:7:\"B69 1LQ\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";}', 'en', '0', 'Mrs', 'Jacqueline', 'Handley', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120430-132914-2081', '35', 'Mrs Cheryl Anderton', '4 Bonham Place', 'Carterton', 'Oxford', 'Oxfordshire', 'OX18 1EA', '826', 'Mrs Cheryl Anderton', '4 Bonham Place', 'Carterton', 'Oxford', 'Oxfordshire', 'OX18 1EA', '826', '01993 842664', '07580491131', '1.50', '0.00', '1.50', '0.00', '0.00', '3', '', '213.83.112.138', '1335788954', 'andertonmx@aol.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1335788439;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"144 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:6:\"Cheryl\";s:8:\"lastName\";s:8:\"Anderton\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:14:\"4 Bonham Place\";s:5:\"add_2\";s:9:\"Carterton\";s:4:\"town\";s:6:\"Oxford\";s:6:\"county\";s:11:\"Oxfordshire\";s:8:\"postcode\";s:8:\"OX18 1EA\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"1.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"1.50\";}', 'en', '0', 'Mrs', 'Cheryl', 'Anderton', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120503-191800-2073', '37', 'Mrs Stephanie Nichols', '4 Newbridge Avenue', 'fulwell', 'Sunderland', 'Tyne and Wear', 'SR5 1LD', '826', 'Mrs Stephanie Nichols', '4 Newbridge Avenue', 'fulwell', 'Sunderland', 'Tyne and Wear', 'SR5 1LD', '826', '0191 5498802', '', '7.50', '0.00', '7.50', '0.00', '0.00', '3', '', '86.175.90.194', '1336069080', 'stephanie.nichols@mypostoffice.co.uk', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'Nochex APC', '', 'drop over back gate if no reply', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:5:\"47{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336068858;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"47\";s:4:\"name\";s:31:\"Second Hand Crop Top and Shorts\";s:11:\"productCode\";s:10:\"SECEV05S18\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"7.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:9:\"Stephanie\";s:8:\"lastName\";s:7:\"Nichols\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:18:\"4 Newbridge Avenue\";s:5:\"add_2\";s:7:\"fulwell\";s:4:\"town\";s:10:\"Sunderland\";s:6:\"county\";s:13:\"Tyne and Wear\";s:8:\"postcode\";s:7:\"SR5 1LD\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"7.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"7.50\";}', 'en', '0', 'Mrs', 'Stephanie', 'Nichols', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120503-215101-7821', '38', 'Mrs Lisa Knowles', '22 Newquay Close', '', 'Hinckley', 'Leicestershire', 'LE10 1XN', '826', 'Mrs Lisa Knowles', '22 Newquay Close', '', 'Hinckley', 'Leicestershire', 'LE10 1XN', '826', '01455450023', '', '1.25', '0.00', '1.25', '0.00', '0.00', '3', '', '90.195.3.159', '1336078261', 's.knowles4@sky.com', '', '0000-00-00', '1st Class Postage (3-5 Working Days)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"5{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336078097;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"5\";s:4:\"name\";s:48:\"144 4mm Lemon AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMMAZXF9\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.25\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:4:\"Lisa\";s:8:\"lastName\";s:7:\"Knowles\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"22 Newquay Close\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:8:\"Hinckley\";s:6:\"county\";s:14:\"Leicestershire\";s:8:\"postcode\";s:8:\"LE10 1XN\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:36:\"1st Class Postage (3-5 Working Days)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"1.25\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"1.25\";}', 'en', '0', 'Mrs', 'Lisa', 'Knowles', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120506-123849-8852', '33', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', 'miss charlene mcgrail', '25 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', '07521325738', '07521325738', '16.00', '0.00', '16.00', '0.00', '0.00', '3', '', '90.221.92.29', '1336304329', 'candt20112011@hotmail.co.uk', '', '0000-00-00', 'Local Pickup (use Code PICKUP for 10% discount)', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:20;s:9:\"timestamp\";i:1336304287;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"miss\";s:9:\"firstName\";s:8:\"charlene\";s:8:\"lastName\";s:7:\"mcgrail\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"25 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:8:\"bt71 6us\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"16.00\";s:8:\"quantity\";d:20;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:47:\"Local Pickup (use Code PICKUP for 10% discount)\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"16.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"16.00\";}', 'en', '0', 'miss', 'charlene', 'mcgrail', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120510-075837-9420', '40', 'Miss Marianne Pyfrom', '35 Brougham Rd', '', 'Southsea', 'Hampshire', 'Po5 4pa', '826', 'Miss Marianne Pyfrom', '35 Brougham Rd', '', 'Southsea', 'Hampshire', 'Po5 4pa', '826', '07753103214', '', '25.00', '0.00', '25.00', '0.00', '0.00', '3', '', '82.132.139.93', '1336633117', 'Colinandmarianne@btinternet.com', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', 'Order to be collected with Â£2.50 discount  Many Thanks', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:3:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1336631352;}s:5:\"47{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336631636;}s:22:\"51{:}5{@}214{|}6{@}211\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336631884;}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:8:\"Marianne\";s:8:\"lastName\";s:6:\"Pyfrom\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:14:\"35 Brougham Rd\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:8:\"Southsea\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"Po5 4pa\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:3:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.50\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:2:\"47\";s:4:\"name\";s:31:\"Second Hand Crop Top and Shorts\";s:11:\"productCode\";s:10:\"SECEV05S18\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"7.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:3;a:8:{s:9:\"productId\";s:2:\"51\";s:4:\"name\";s:17:\"PnP Lycra Leotard\";s:11:\"productCode\";s:14:\"PNPU8J2P15/BL5\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"15.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:7:\"214,211\";}}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"25.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"25.00\";}', 'en', '0', 'Miss', 'Marianne', 'Pyfrom', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120510-074603-6772', '40', 'Miss Marianne Pyfrom', '35 Brougham Rd', '', 'Southsea', 'Hampshire', 'Po5 4pa', '826', 'Miss Marianne Pyfrom', '35 Brougham Rd', '', 'Southsea', 'Hampshire', 'Po5 4pa', '826', '07753103214', '', '25.00', '0.00', '25.00', '0.00', '0.00', '6', '', '82.132.216.178', '1336632363', 'Colinandmarianne@btinternet.com', '', '', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:3:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1336631352;}s:5:\"47{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336631636;}s:22:\"51{:}5{@}214{|}6{@}211\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1336631884;}}s:8:\"invArray\";a:3:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.50\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:2:\"47\";s:4:\"name\";s:31:\"Second Hand Crop Top and Shorts\";s:11:\"productCode\";s:10:\"SECEV05S18\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"7.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:3;a:8:{s:9:\"productId\";s:2:\"51\";s:4:\"name\";s:17:\"PnP Lycra Leotard\";s:11:\"productCode\";s:14:\"PNPU8J2P15/BL5\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"15.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:7:\"214,211\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:8:\"Marianne\";s:8:\"lastName\";s:6:\"Pyfrom\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:14:\"35 Brougham Rd\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:8:\"Southsea\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"Po5 4pa\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"25.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"25.00\";}', 'en', '0', 'Miss', 'Marianne', 'Pyfrom', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120506-202916-1835', '39', 'Miss Nicole Hayes', 'oak lodge', 'saltney gate, saracens head', 'holbeach', 'Lincolnshire', 'PE12 8AT', '826', 'Miss Nicole Hayes', 'oak lodge', 'saltney gate, saracens head', 'holbeach', 'Lincolnshire', 'PE12 8AT', '826', '01406424225', '', '10.00', '0.00', '10.00', '0.00', '0.00', '3', '', '88.104.123.184', '1336332556', 'chelnicky@hotmail.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:10:{s:5:\"conts\";a:1:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:10;s:9:\"timestamp\";i:1336332530;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:6:\"Nicole\";s:8:\"lastName\";s:5:\"Hayes\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:9:\"oak lodge\";s:5:\"add_2\";s:27:\"saltney gate, saracens head\";s:4:\"town\";s:8:\"holbeach\";s:6:\"county\";s:12:\"Lincolnshire\";s:8:\"postcode\";s:8:\"PE12 8AT\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"144 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"10.00\";s:8:\"quantity\";d:10;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"10.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"10.00\";}', 'en', '0', 'Miss', 'Nicole', 'Hayes', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120519-141737-2262', '41', 'mrs janet mcgrail', '14 millview manor', '', 'dungannon', 'Tyrone', 'bt716us', '826', 'mrs janet mcgrail', '14 millview manor', '', 'dungannon', 'Tyrone', 'bt716us', '826', '07752770828', '07752770828', '13.00', '0.00', '13.00', '0.00', '0.00', '3', '', '109.153.206.37', '1337433457', 'fmorgan123@hotmail.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:10;s:9:\"timestamp\";i:1337432964;}s:4:\"6{:}\";a:2:{s:8:\"quantity\";d:5;s:9:\"timestamp\";i:1337433034;}}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"8.00\";s:8:\"quantity\";d:10;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:1:\"6\";s:4:\"name\";s:47:\"144 4mm Mint AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMQXX7R9\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"5.00\";s:8:\"quantity\";d:5;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"janet\";s:8:\"lastName\";s:7:\"mcgrail\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"14 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:7:\"bt716us\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"13.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"13.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'mrs', 'janet', 'mcgrail', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120520-135655-3821', '42', 'Dr Suzana Pavic', '61 Queenswood Drive', '', 'Sheffield', 'Yorkshire', 'S6 1RJ', '826', 'Dr Suzana Pavic', '61 Queenswood Drive', '', 'Sheffield', 'Yorkshire', 'S6 1RJ', '826', '01142321365', '', '19.99', '0.00', '19.99', '0.00', '0.00', '3', '', '86.167.28.217', '1337518615', 's.pavic@shu.ac.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:29:\"23{:}5{@}79{|}9{@}88{|}6{@}86\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1337518295;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"23\";s:4:\"name\";s:27:\"Rock &#39;n&#39; Roll Skirt\";s:11:\"productCode\";s:18:\"ROC6WOSS15/REDNET7\";s:11:\"prodOptions\";s:57:\"Colour - Neon Red Matt\r\nNetting - Black\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"19.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:8:\"79,86,88\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:2:\"Dr\";s:9:\"firstName\";s:6:\"Suzana\";s:8:\"lastName\";s:5:\"Pavic\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:19:\"61 Queenswood Drive\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"Sheffield\";s:6:\"county\";s:9:\"Yorkshire\";s:8:\"postcode\";s:6:\"S6 1RJ\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"19.99\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"19.99\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'Dr', 'Suzana', 'Pavic', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120521-130007-3632', '43', 'MRS JULIE NASH', '27 LIVESAY GARDENS', 'MILTON', 'PORTSMOUTH', 'Hampshire', 'PO3 6BN', '826', 'MRS JULIE NASH', '27 LIVESAY GARDENS', 'MILTON', 'PORTSMOUTH', 'Hampshire', 'PO3 6BN', '826', '02392360795', '', '2.50', '0.00', '4.00', '0.00', '1.50', '3', '', '94.13.150.221', '1337601607', 'POMPEYKIDS2@HOTMAIL.COM', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:5:\"16{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1337601031;}s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1337601310;}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"MRS\";s:9:\"firstName\";s:5:\"JULIE\";s:8:\"lastName\";s:4:\"NASH\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:18:\"27 LIVESAY GARDENS\";s:5:\"add_2\";s:6:\"MILTON\";s:4:\"town\";s:10:\"PORTSMOUTH\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"PO3 6BN\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:2:\"16\";s:4:\"name\";s:44:\"144 4mm Pink Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"100WNLLQ8\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"144 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"1.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"1.50\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"2.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"4.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'MRS', 'JULIE', 'NASH', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120621-143058-8499', '43', 'MRS JULIE NASH', '27 LIVESAY GARDENS', 'MILTON', 'PORTSMOUTH', 'Hampshire', 'PO3 6BN', '826', 'MRS JULIE NASH', '27 LIVESAY GARDENS', 'MILTON', 'PORTSMOUTH', 'Hampshire', 'PO3 6BN', '826', '02392360795', '', '6.50', '0.00', '6.50', '0.00', '0.00', '3', '', '94.13.150.221', '1340285458', 'POMPEYKIDS2@HOTMAIL.COM', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:4:\"9{:}\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1340285233;}s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1340285317;}}s:7:\"shipKey\";i:2;s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"MRS\";s:9:\"firstName\";s:5:\"JULIE\";s:8:\"lastName\";s:4:\"NASH\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:18:\"27 LIVESAY GARDENS\";s:5:\"add_2\";s:6:\"MILTON\";s:4:\"town\";s:10:\"PORTSMOUTH\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:7:\"PO3 6BN\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:1:\"9\";s:4:\"name\";s:35:\"144 4mm Clear AB Hotfix Rhinestones\";s:11:\"productCode\";s:9:\"144B6JUF7\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"6.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"6.50\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'MRS', 'JULIE', 'NASH', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120604-214126-4579', '44', 'Mrs Kellie Johnson', '150 molesworth road', 'Stoke', 'Plymouth', '-- Please Select --', 'Pl34aj', '826', 'Mrs Kellie Johnson', '150 molesworth road', 'Stoke', 'Plymouth', '-- Please Select --', 'Pl34aj', '826', '01752559555', '07752217764', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '77.100.103.199', '1338842486', 'Arrywizard@googlemail.com', '', '0000-00-00', 'Pick Up', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:20:\"18{:}5{@}20{|}6{@}13\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1338842277;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"18\";s:4:\"name\";s:35:\"PnP Lycra Catsuit with Long Sleeves\";s:11:\"productCode\";s:16:\"PNPE1NB815/YELL4\";s:11:\"prodOptions\";s:41:\"Colour - FL Yellow Matt\r\nSize - 4 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"20,13\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:6:\"Kellie\";s:8:\"lastName\";s:7:\"Johnson\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:19:\"150 molesworth road\";s:5:\"add_2\";s:5:\"Stoke\";s:4:\"town\";s:8:\"Plymouth\";s:6:\"county\";s:19:\"-- Please Select --\";s:8:\"postcode\";s:6:\"Pl34aj\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:7:\"Pick Up\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:3:\"OBT\";}', 'en', '0', 'Mrs', 'Kellie', 'Johnson', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120710-204805-8547', '46', 'Miss Nicki Pearce', '49 crummock place', 'Bletchley', 'Milton keynes', 'Buckinghamshire', 'Mk2 3er', '826', 'Miss Nicki Pearce', '49 crummock place', 'Bletchley', 'Milton keynes', 'Buckinghamshire', 'Mk2 3er', '826', '01908460258', '', '18.98', '0.00', '18.98', '0.00', '0.00', '6', '', '176.27.84.41', '1341949685', 'n.pearce432@googlemail.com', '', '0000-00-00', 'Pick Up', 'OBT', '', '', 'No payment received for order', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:20:\"20{:}5{@}46{|}6{@}67\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1341949213;}s:20:\"22{:}5{@}57{|}6{@}62\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1341949304;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"20\";s:4:\"name\";s:16:\"PnP Lycra Shorts\";s:11:\"productCode\";s:16:\"PNP8IHMB15/PINK7\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:4:\"7.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"46,67\";}i:2;a:8:{s:9:\"productId\";s:2:\"22\";s:4:\"name\";s:29:\"PnP Lycra Halter Neck Tie Top\";s:11:\"productCode\";s:16:\"PNPLJUSL15/PINK7\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 7 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"57,62\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:5:\"Nicki\";s:8:\"lastName\";s:6:\"Pearce\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"49 crummock place\";s:5:\"add_2\";s:9:\"Bletchley\";s:4:\"town\";s:13:\"Milton keynes\";s:6:\"county\";s:15:\"Buckinghamshire\";s:8:\"postcode\";s:7:\"Mk2 3er\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:7:\"Pick Up\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"18.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"18.98\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:3:\"OBT\";}', 'en', '0', 'Miss', 'Nicki', 'Pearce', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120711-230224-2457', '47', 'Brianna Robertson', 'PO Box 333', '', 'Otis', 'Oregon', '97368', '840', 'Brianna Robertson', 'PO Box 333', '', 'Otis', 'Oregon', '97368', '840', '5414181203', '', '2.00', '0.00', '3.50', '0.00', '1.50', '6', '', '71.53.68.125', '1342044144', 'bri90291@yahoo.com', '', '', 'Free for Orders Over Â£5.00', 'Nochex_APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:5:\"56{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1342042980;}}s:7:\"shipKey\";i:2;s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"56\";s:4:\"name\";s:53:\"144 SS20 5mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:10:\"14401ZXZ14\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:7:\"Brianna\";s:8:\"lastName\";s:9:\"Robertson\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:10:\"PO Box 333\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:4:\"Otis\";s:6:\"county\";s:6:\"Oregon\";s:8:\"postcode\";s:5:\"97368\";s:7:\"country\";s:3:\"226\";}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"1.50\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"2.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"3.50\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', '', 'Brianna', 'Robertson', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120711-231120-7119', '47', 'Brianna Robertson', 'PO Box 333', '', 'Otis', 'Oregon', '97368', '840', 'Brianna Robertson', 'PO Box 333', '', 'Otis', 'Oregon', '97368', '840', '5414181203', '', '2.00', '0.00', '3.50', '0.00', '1.50', '3', '', '71.53.68.125', '1342044680', 'bri90291@yahoo.com', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:5:\"56{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1342042980;}}s:7:\"shipKey\";i:2;s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"56\";s:4:\"name\";s:53:\"144 SS20 5mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:10:\"14401ZXZ14\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"2.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:7:\"Brianna\";s:8:\"lastName\";s:9:\"Robertson\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:10:\"PO Box 333\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:4:\"Otis\";s:6:\"county\";s:6:\"Oregon\";s:8:\"postcode\";s:5:\"97368\";s:7:\"country\";s:3:\"226\";}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"1.50\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"2.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"3.50\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', '', 'Brianna', 'Robertson', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120801-204648-4367', '48', 'Mrs Danielle Mullally', '10 Wyver Crescent', '', 'Coventry', 'West Midlands', 'CV25LQ', '826', 'Mrs Danielle Mullally', '10 Wyver Crescent', '', 'Coventry', 'West Midlands', 'CV25LQ', '826', '07980588309', '', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '2.126.47.186', '1343850408', 'Sales@roadwholesale.co.uk', '', '0000-00-00', 'Pick Up', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:18:\"17{:}5{@}6{|}6{@}4\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1343849786;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:37:\"PnP Lycra Catsuit with Puffed Sleeves\";s:11:\"productCode\";s:15:\"PNPQ33OT2/PINK5\";s:11:\"prodOptions\";s:45:\"Colour - Electric Pink Matt\r\nSize - 5 Years\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:3:\"6,4\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:8:\"Danielle\";s:8:\"lastName\";s:8:\"Mullally\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"10 Wyver Crescent\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:8:\"Coventry\";s:6:\"county\";s:13:\"West Midlands\";s:8:\"postcode\";s:6:\"CV25LQ\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:7:\"Pick Up\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'Mrs', 'Danielle', 'Mullally', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120808-230150-3399', '49', 'mrs margret mcdonagh', '3 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', 'mrs margret mcdonagh', '3 millview manor', '', 'dungannon', 'Tyrone', 'bt71 6us', '826', '07881453024', '07881453024', '101.80', '0.00', '101.80', '0.00', '0.00', '3', '', '90.214.66.37', '1344463310', 'mmcdonagh81@hotmail.co.uk', '', '0000-00-00', 'Pick Up', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:5:\"56{:}\";a:2:{s:8:\"quantity\";d:54;s:9:\"timestamp\";i:1344462667;}s:4:\"3{:}\";a:2:{s:8:\"quantity\";d:26;s:9:\"timestamp\";i:1344462843;}}s:8:\"invArray\";a:2:{i:1;a:7:{s:9:\"productId\";s:2:\"56\";s:4:\"name\";s:53:\"144 SS20 5mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:10:\"14401ZXZ14\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"81.00\";s:8:\"quantity\";d:54;s:7:\"digital\";s:1:\"0\";}i:2;a:7:{s:9:\"productId\";s:1:\"3\";s:4:\"name\";s:48:\"144 4mm Clear AB Silverback Rhinestones/Crystals\";s:11:\"productCode\";s:9:\"4MMJSGF79\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"20.80\";s:8:\"quantity\";d:26;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:7:\"margret\";s:8:\"lastName\";s:8:\"mcdonagh\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"3 millview manor\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"dungannon\";s:6:\"county\";s:6:\"Tyrone\";s:8:\"postcode\";s:8:\"bt71 6us\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:7:\"Pick Up\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:6:\"101.80\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:6:\"101.80\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'mrs', 'margret', 'mcdonagh', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120827-124418-6821', '14', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', 'mrs sarah norris', '27 prunier drive', '', 'peterhead', 'Aberdeenshire', 'ab421zf', '826', '01779472103', '', '20.98', '0.00', '20.98', '0.00', '0.00', '3', '', '89.168.121.156', '1346067858', 'sarahlvsdrew2@tiscali.co.uk', '', '0000-00-00', 'Pick Up', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:2:{s:20:\"19{:}5{@}28{|}6{@}25\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1346067678;}s:20:\"21{:}5{@}38{|}6{@}35\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1346067765;}}s:8:\"invArray\";a:2:{i:1;a:8:{s:9:\"productId\";s:2:\"19\";s:4:\"name\";s:36:\"PnP Lycra Crop Top With Puff Sleeves\";s:11:\"productCode\";s:13:\"PNPCZC3O2/BL6\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 6 Years\r\n\";s:5:\"price\";s:5:\"10.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"28,25\";}i:2;a:8:{s:9:\"productId\";s:2:\"21\";s:4:\"name\";s:18:\"PnP Lycra Leggings\";s:11:\"productCode\";s:14:\"PNPCY14315/BL6\";s:11:\"prodOptions\";s:37:\"Colour - Black Matt\r\nSize - 6 Years\r\n\";s:5:\"price\";s:4:\"9.99\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:5:\"38,35\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"mrs\";s:9:\"firstName\";s:5:\"sarah\";s:8:\"lastName\";s:6:\"norris\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:16:\"27 prunier drive\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:9:\"peterhead\";s:6:\"county\";s:13:\"Aberdeenshire\";s:8:\"postcode\";s:7:\"ab421zf\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:7:\"Pick Up\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"20.98\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"20.98\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'mrs', 'sarah', 'norris', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120901-123501-2198', '50', 'Miss Sophie Rodwell', '1st james green', 'Castle acre', 'Kings Lynn', 'Norfolk', 'PE32 2BD', '826', 'Miss Sophie Rodwell', '1st james green', 'Castle acre', 'Kings Lynn', 'Norfolk', 'PE32 2BD', '826', '07940725311', '07940725311', '10.50', '0.00', '10.50', '0.00', '0.00', '6', '', '86.165.244.121', '1346499301', 'sophie.rodwell@nhs.net', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', 'Hi cancelled as no payment received, please reorder if still required', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:3;s:9:\"timestamp\";i:1346498387;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:5:\"10.50\";s:8:\"quantity\";d:3;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:6:\"Sophie\";s:8:\"lastName\";s:7:\"Rodwell\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:15:\"1st james green\";s:5:\"add_2\";s:11:\"Castle acre\";s:4:\"town\";s:10:\"Kings Lynn\";s:6:\"county\";s:7:\"Norfolk\";s:8:\"postcode\";s:8:\"PE32 2BD\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"10.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"10.50\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'Miss', 'Sophie', 'Rodwell', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('120926-204400-4073', '52', 'Miss Helen Ttofa', '130 Chorley new road', 'Horwich', 'Bolton', 'Lancashire', 'Bl65qn', '826', 'Miss Helen Ttofa', '130 Chorley new road', 'Horwich', 'Bolton', 'Lancashire', 'Bl65qn', '826', '07969546591', '', '5.00', '0.00', '5.00', '0.00', '0.00', '3', '', '82.2.130.246', '1348688640', 'Helenttofa@hotmail.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:13:\"57{:}11{@}283\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1348688500;}}s:8:\"invArray\";a:1:{i:1;a:8:{s:9:\"productId\";s:2:\"57\";s:4:\"name\";s:24:\"Blinged Competition pins\";s:11:\"productCode\";s:15:\"BLITSI0615/CPAB\";s:11:\"prodOptions\";s:24:\"Pin Colour - Aqua Blue\r\n\";s:5:\"price\";s:4:\"5.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";s:10:\"assign_ids\";s:3:\"283\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:4:\"Miss\";s:9:\"firstName\";s:5:\"Helen\";s:8:\"lastName\";s:5:\"Ttofa\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:20:\"130 Chorley new road\";s:5:\"add_2\";s:7:\"Horwich\";s:4:\"town\";s:6:\"Bolton\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:6:\"Bl65qn\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"5.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"5.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'Miss', 'Helen', 'Ttofa', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121015-112737-6478', '12', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', '12345656', '12345667', '17.49', '0.00', '17.49', '0.00', '0.00', '6', '', '82.14.1.87', '1350296858', 'mark@fabian-lovely.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:20:\"18{:}6{@}51{|}5{@}16\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1350295532;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"18\";s:4:\"name\";s:35:\"PnP Lycra Catsuit with Long Sleeves\";s:11:\"productCode\";s:10:\"PNPE1NB815\";s:11:\"prodOptions\";s:45:\"Size - 7 Years\r\nColour - Electric Pink Matt\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"Mark\";s:8:\"lastName\";s:13:\"Fabian-Lovely\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"8 Edgerly Gardens\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:10:\"Portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:15:\"mark@fabian-lov\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', '', 'Mark', 'Fabian-Lovely', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121015-114708-4244', '12', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', '12345656', '12345667', '15.00', '0.00', '15.00', '0.00', '0.00', '6', '', '82.14.1.87', '1350298028', 'mark@fabian-lovely.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:33:\"26{:}10{@}180{|}6{@}130{|}5{@}124\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1350297992;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"Mark\";s:8:\"lastName\";s:13:\"Fabian-Lovely\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"8 Edgerly Gardens\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:10:\"Portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:15:\"mark@fabian-lov\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"26\";s:4:\"name\";s:41:\"Disco Freestyle Dance Costume Accessories\";s:11:\"productCode\";s:10:\"DISU2GEX15\";s:11:\"prodOptions\";s:63:\"Stones - Without\r\nSize - 3 Years\r\nColour - Electric Pink Matt\r\n\";s:5:\"price\";s:5:\"15.00\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"15.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"15.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', '', 'Mark', 'Fabian-Lovely', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121015-203658-9485', '55', 'Mrs Laura Tyrer', '6 Milne grove', 'Milnrow', 'Rochdale', 'Lancashire', 'Ol16 3ty', '826', 'Mrs Laura Tyrer', '6 Milne grove', 'Milnrow', 'Rochdale', 'Lancashire', 'Ol16 3ty', '826', '07885856743', '', '17.49', '0.00', '17.49', '0.00', '0.00', '6', '', '82.132.245.135', '1350329818', 'Lauratyy@live.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'Nochex APC', '', '', 'Hi We have cancelled this order as it seems a duplicate of #121016-120035-7927 which has been dispatched', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:18:\"17{:}6{@}3{|}5{@}2\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1350329769;}}s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:5:\"Laura\";s:8:\"lastName\";s:5:\"Tyrer\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:13:\"6 Milne grove\";s:5:\"add_2\";s:7:\"Milnrow\";s:4:\"town\";s:8:\"Rochdale\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:8:\"Ol16 3ty\";s:7:\"country\";s:3:\"225\";}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:37:\"PnP Lycra Catsuit with Puffed Sleeves\";s:11:\"productCode\";s:9:\"PNPQ33OT2\";s:11:\"prodOptions\";s:40:\"Size - 4 Years\r\nColour - Neon Red Matt\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'Mrs', 'Laura', 'Tyrer', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121015-211741-2192', '12', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', 'Mark Fabian-Lovely', '8 Edgerly Gardens', '', 'Portsmouth', 'Hampshire', 'mark@fabian-lov', '826', '12345656', '12345667', '5.00', '0.00', '5.00', '0.00', '0.00', '3', '', '82.14.1.87', '1350332261', 'mark@fabian-lovely.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:13:\"57{:}11{@}287\";a:2:{s:8:\"quantity\";d:2;s:9:\"timestamp\";i:1350331742;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"57\";s:4:\"name\";s:24:\"Blinged Competition pins\";s:11:\"productCode\";s:10:\"BLITSI0615\";s:11:\"prodOptions\";s:25:\"Pin Colour - Light Pink\r\n\";s:5:\"price\";s:4:\"5.00\";s:8:\"quantity\";d:2;s:7:\"digital\";s:1:\"0\";}}s:6:\"delInf\";a:10:{s:5:\"title\";s:0:\"\";s:9:\"firstName\";s:4:\"Mark\";s:8:\"lastName\";s:13:\"Fabian-Lovely\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:17:\"8 Edgerly Gardens\";s:5:\"add_2\";s:0:\"\";s:4:\"town\";s:10:\"Portsmouth\";s:6:\"county\";s:9:\"Hampshire\";s:8:\"postcode\";s:15:\"mark@fabian-lov\";s:7:\"country\";s:3:\"225\";}s:7:\"shipKey\";i:1;s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"5.00\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"5.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', '', 'Mark', 'Fabian-Lovely', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121016-120035-7927', '55', 'Mrs Laura Tyrer', '16 wicken bank', 'Heywood', 'Rochdale', 'Lancashire', 'Ol10 2lw', '826', 'Mrs Laura Tyrer', '16 wicken bank', 'Heywood', 'Rochdale', 'Lancashire', 'Ol10 2lw', '826', '07885856743', '', '17.49', '0.00', '17.49', '0.00', '0.00', '3', '', '82.132.213.133', '1350385235', 'Lauratyy@live.co.uk', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'Nochex APC', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:18:\"17{:}6{@}3{|}5{@}2\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1350385020;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"17\";s:4:\"name\";s:37:\"PnP Lycra Catsuit with Puffed Sleeves\";s:11:\"productCode\";s:9:\"PNPQ33OT2\";s:11:\"prodOptions\";s:40:\"Size - 4 Years\r\nColour - Neon Red Matt\r\n\";s:5:\"price\";s:5:\"17.49\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:5:\"Laura\";s:8:\"lastName\";s:5:\"Tyrer\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:14:\"16 wicken bank\";s:5:\"add_2\";s:7:\"Heywood\";s:4:\"town\";s:8:\"Rochdale\";s:6:\"county\";s:10:\"Lancashire\";s:8:\"postcode\";s:8:\"Ol10 2lw\";s:7:\"country\";s:3:\"225\";}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"0.00\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:5:\"17.49\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:5:\"17.49\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:10:\"Nochex_APC\";}', 'en', '0', 'Mrs', 'Laura', 'Tyrer', '', '', '', 'f'); #EOQ
INSERT INTO `cc4_CubeCart_order_summary` VALUES('121024-170942-3703', '57', 'Mrs Denise Townsend', '209 Farm View Road', 'Kimberworth', 'Rotherham', 'Yorkshire', 'S61 2BL', '826', 'Mrs Denise Townsend', '209 Farm View Road', 'Kimberworth', 'Rotherham', 'Yorkshire', 'S61 2BL', '826', '01709556339', '07770991639', '3.50', '0.00', '5.00', '0.00', '1.50', '3', '', '77.102.208.59', '1351094982', 'rayndenise209@virginmedia.com', '', '0000-00-00', 'Free for Orders Over Â£5.00', 'PayPal', '', '', '', '', '0.00', '', '0.00', '', '0.00', '', '', '', '', 'a:12:{s:5:\"conts\";a:1:{s:5:\"40{:}\";a:2:{s:8:\"quantity\";d:1;s:9:\"timestamp\";i:1351093802;}}s:8:\"invArray\";a:1:{i:1;a:7:{s:9:\"productId\";s:2:\"40\";s:4:\"name\";s:48:\"144 5mm (SS20) Crystal AB DMC Hotfix Rhinestones\";s:11:\"productCode\";s:10:\"144RJFR723\";s:11:\"prodOptions\";s:0:\"\";s:5:\"price\";s:4:\"3.50\";s:8:\"quantity\";d:1;s:7:\"digital\";s:1:\"0\";}}s:7:\"shipKey\";i:1;s:6:\"delInf\";a:10:{s:5:\"title\";s:3:\"Mrs\";s:9:\"firstName\";s:6:\"Denise\";s:8:\"lastName\";s:8:\"Townsend\";s:11:\"companyName\";s:0:\"\";s:5:\"add_1\";s:18:\"209 Farm View Road\";s:5:\"add_2\";s:11:\"Kimberworth\";s:4:\"town\";s:9:\"Rotherham\";s:6:\"county\";s:9:\"Yorkshire\";s:8:\"postcode\";s:7:\"S61 2BL\";s:7:\"country\";s:3:\"225\";}s:10:\"shipMethod\";s:27:\"Free for Orders Over Â£5.00\";s:8:\"shipCost\";s:4:\"1.50\";s:8:\"discount\";s:0:\"\";s:8:\"subTotal\";s:4:\"3.50\";s:3:\"tax\";s:4:\"0.00\";s:10:\"grandTotal\";s:4:\"5.00\";s:17:\"customer_comments\";s:0:\"\";s:7:\"gateway\";s:6:\"PayPal\";}', 'en', '0', 'Mrs', 'Denise', 'Townsend', '', '', '', 'f'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_order_tax`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_order_tax`
--

CREATE TABLE `cc4_CubeCart_order_tax` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `cart_order_id` varchar(18) collate utf8_unicode_ci NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  `amount` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cart_order_id` (`cart_order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_order_tax` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_permissions`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_permissions`
--

CREATE TABLE `cc4_CubeCart_permissions` (
  `permission_id` int(10) unsigned NOT NULL auto_increment,
  `admin_id` int(10) unsigned NOT NULL default '0',
  `section_id` int(10) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`permission_id`),
  KEY `admin_id` (`admin_id`),
  KEY `section_id` (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_permissions` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_pricing_group`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_pricing_group`
--

CREATE TABLE `cc4_CubeCart_pricing_group` (
  `price_id` int(10) unsigned NOT NULL auto_increment,
  `group_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `price` decimal(16,2) NOT NULL default '0.00',
  `sale_price` decimal(16,2) NOT NULL default '0.00',
  `tax_type` int(10) unsigned NOT NULL,
  `tax_inclusive` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`price_id`),
  KEY `group_id` (`group_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_pricing_group` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_pricing_quantity`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_pricing_quantity`
--

CREATE TABLE `cc4_CubeCart_pricing_quantity` (
  `discount_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL default '0',
  `quantity` int(10) unsigned NOT NULL,
  `price` decimal(16,2) NOT NULL,
  PRIMARY KEY  (`discount_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_pricing_quantity` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_request_log`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_request_log`
--

CREATE TABLE `cc4_CubeCart_request_log` (
  `request_id` int(10) unsigned NOT NULL auto_increment,
  `request_url` varchar(255) collate utf8_unicode_ci default NULL,
  `request` blob NOT NULL,
  `result` blob NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`request_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_request_log`
--

INSERT INTO `cc4_CubeCart_request_log` VALUES('1', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 07:11:14'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('2', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 09:00:02'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('3', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 09:16:19'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('4', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 09:16:46'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('5', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 09:41:02'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('6', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 10:24:09'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('7', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-07 10:24:35'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('8', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 04:31:54'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('9', 'http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Fwww.pnpdance.com%2Fsitemap.xml.gz', 'sitemap=http%3A%2F%2Fwww.pnpdance.com%2Fsitemap.xml.gz', '<html><meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">\n<head><title>Google Webmaster Tools\n-\nSitemap Notification Received</title>\n<meta name=\"robots\" content=\"noindex, noodp\">\n<script src=\"https://ssl.google-analytics.com/urchin.js\" type=\"text/javascript\">\n    </script>\n<script type=\"text/javascript\">\n      _uacct=\"UA-18009-2\";\n      _utcp=\"/webmasters/\";\n      _uanchor=1;\n      urchinTracker();\n    </script></head>\n<body><h2>Sitemap Notification Received</h2>\n<br>\nYour Sitemap has been successfully added to our list of Sitemaps to crawl. If this is the first time you are notifying Google about this Sitemap, please add it via  <a href=\"http://www.google.com/webmasters/tools/\">http://www.google.com/webmasters/tools/</a>  so you can track its status. Please note that we do not add all submitted URLs to our index, and we cannot make any predictions or guarantees about when or if they will appear.</body></html>', '2012-11-08 04:32:15'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('10', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 04:48:15'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('11', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 07:04:15'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('12', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 08:30:20'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('13', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 09:25:58'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('14', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-08 11:24:10'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('15', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 03:17:58'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('16', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 04:17:42'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('17', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 05:20:17'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('18', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 05:20:41'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('19', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 10:04:48'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('20', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 10:04:55'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('21', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 10:28:09'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('22', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-09 10:28:17'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('23', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-14 16:43:09'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('24', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-15 04:24:05'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('25', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-15 06:42:42'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('26', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-19 05:03:01'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('27', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-19 05:03:38'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('28', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-19 05:03:50'); #EOQ
INSERT INTO `cc4_CubeCart_request_log` VALUES('29', 'http://cp.cubecart.com/licence/version/5.1.5', 'version=5.1.5', '5.1.5\n', '2012-11-19 05:08:01'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_reviews`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_reviews`
--

CREATE TABLE `cc4_CubeCart_reviews` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `approved` smallint(1) NOT NULL default '0',
  `product_id` int(10) unsigned NOT NULL default '0',
  `type` smallint(1) NOT NULL,
  `rating` decimal(2,1) unsigned default '0.0',
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `email` varchar(254) collate utf8_unicode_ci NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `review` text collate utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci NOT NULL COMMENT 'Supports IPv6 addresses',
  `time` int(10) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `vote_up` int(11) NOT NULL default '0',
  `vote_down` int(11) NOT NULL default '0',
  `anon` tinyint(1) unsigned default '0',
  PRIMARY KEY  (`id`),
  KEY `product_id` (`product_id`),
  KEY `votes` (`vote_up`,`vote_down`),
  FULLTEXT KEY `fulltext` (`name`,`email`,`title`,`review`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_reviews`
--

INSERT INTO `cc4_CubeCart_reviews` VALUES('9', '1', '20', '0', '0.0', 'soldes canada goose', 'ngrpbpic@mail.com', 'http://www.doudounesale.com/', 'This is the best article I have read, thank you, I have learned a lot of knowledge in this area. take a look my web http://www.doudounesale.com/', '109.169.61.126', '1351860406', '0', '0', '0', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_saved_cart`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_saved_cart`
--

CREATE TABLE `cc4_CubeCart_saved_cart` (
  `customer_id` int(10) unsigned NOT NULL,
  `basket` mediumblob NOT NULL,
  PRIMARY KEY  (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_saved_cart` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_search`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_search`
--

CREATE TABLE `cc4_CubeCart_search` (
  `searchstr` varchar(255) collate utf8_unicode_ci NOT NULL default '',
  `hits` bigint(64) NOT NULL default '0',
  `id` bigint(64) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=212 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_search`
--

INSERT INTO `cc4_CubeCart_search` VALUES('crop', '1', '1'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('4mm', '1', '2'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('silver tights', '1', '3'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballroom', '1', '4'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('bags', '2', '5'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('pineapple', '1', '6'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyle', '3', '7'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('bag', '2', '8'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyle beginner', '1', '9'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('hair accessories', '1', '10'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('jazz boots', '2', '11'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velvet catsuit', '1', '12'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dancee tights', '1', '13'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('accessories', '2', '14'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blue catsuits', '1', '15'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leotards', '12', '16'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leotard', '5', '17'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leg warmers', '6', '18'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('tights', '6', '19'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballet shoes child size 11', '2', '20'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance shoes', '1', '21'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('footwear', '1', '22'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('head pieces', '1', '23'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('line dance skirts', '1', '24'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('navy ballet skirt', '1', '25'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballet costumes', '1', '26'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Dance', '1', '27'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Tap shoes', '9', '28'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('shorts', '5', '29'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('desgin coustume', '1', '30'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('design dance coustime', '1', '31'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sequin leggings', '1', '32'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velour dance shorts', '1', '33'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velshortsour dance shorts', '1', '34'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('all in one suits', '1', '35'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('latinformation weAR', '1', '36'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('jazz pants', '2', '37'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('glue', '1', '38'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('boys dance costumes', '1', '39'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sailor', '1', '40'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyle dance costumes', '1', '41'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('irish dancing', '1', '42'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dmc', '1', '43'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gold belt', '1', '44'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('rhinestone', '1', '45'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco freestyle', '1', '46'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('faq', '1', '47'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('amber rhinestones', '1', '48'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('orange rhinestones', '2', '49'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('glue for rhinestones', '2', '50'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('girls pink legginstights', '3', '51'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lyrical skirts', '1', '52'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gold skirt', '2', '53'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('slow dance costumes', '2', '54'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballet tights', '1', '55'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('shoes', '14', '56'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco freestyle dance wear', '1', '57'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco dance outfits', '2', '58'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('age 10', '1', '59'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lyrical dress', '1', '60'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('green dance shoes', '1', '61'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('black leotard size 16', '1', '62'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('puff sleeved leotards', '1', '63'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballroom dance wear', '1', '64'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velour leotards', '2', '65'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blavk unitards', '1', '66'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velor catsuit', '4', '67'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('irish dance heavys', '1', '68'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('latin shoes', '1', '69'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco dancing costum', '1', '70'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('childrens long sleeved black leotards', '2', '71'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('childrens black leotards', '1', '72'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Catsuit', '4', '73'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('accessorie', '1', '74'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Hotfix applicator', '1', '75'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance bag', '1', '76'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('2mm', '1', '77'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('foot thongs', '4', '78'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('b free', '1', '79'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('tap', '1', '80'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('salsa', '1', '81'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('swarovski', '1', '82'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('hotpants', '1', '83'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('hot pants', '1', '84'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('strap extensions', '1', '85'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('catsuits', '3', '86'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballet shoes', '3', '87'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ctasuit', '1', '88'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('waistcoats', '1', '89'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('modern dance', '1', '90'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('crowns', '1', '91'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sparkle shoes', '1', '92'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('under 14', '1', '93'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sequin top', '1', '94'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lyrical', '5', '95'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('DONUTS', '1', '96'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Slow u16', '1', '97'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('long sleeved leotard', '1', '98'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco ware', '1', '99'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('foot undeez', '1', '100'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('jessica', '1', '101'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('roberta', '1', '102'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ladies dresses', '1', '103'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('slow dance custumes', '1', '104'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra top', '1', '105'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('boys leotards gymnastics', '1', '106'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('girls catsuits', '1', '107'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('balerina costume', '1', '108'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance belt', '1', '109'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('acro', '1', '110'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('knee pads', '1', '111'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('1st positin', '1', '112'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('1st position', '1', '113'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('White crop top', '2', '114'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lond skirts', '1', '115'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('long skirts', '1', '116'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('bootleg dance pants', '1', '117'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ballet', '5', '118'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('age 12', '1', '119'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('hair wrap', '1', '120'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance trainers', '2', '121'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('mermaid', '1', '122'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blue childdrens leotards', '1', '123'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('adults leotards', '1', '124'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Starlite dance wear', '1', '125'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('velvet long sleeved leatard', '1', '126'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leggings', '4', '128'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Black velvet dance skirt', '1', '129'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('fabric', '2', '130'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco solo', '1', '131'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('split sole sneakers', '1', '132'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance pants', '1', '133'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Unitard', '1', '134'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra leggins', '1', '135'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leggins', '2', '136'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyle dancewear', '1', '137'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('flapper', '1', '138'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('flapper dresses', '1', '139'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('TASSLE WRIST BANDS', '2', '140'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gold leotards', '1', '141'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Fringe', '1', '142'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra leotard', '1', '143'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('crop top', '2', '144'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance wear', '1', '145'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lyrical7', '1', '146'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('tap ties', '1', '147'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('solo disco size 10', '1', '148'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('girls leotards wrap skirts', '1', '149'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('bands', '1', '150'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Hot fix crystals fuschia 5mm', '1', '151'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('zebra print leggings', '1', '152'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('black leotards', '1', '153'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('baton', '1', '154'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('bras', '2', '155'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sm1726 bra', '1', '156'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra shorts', '1', '157'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('disco outfit', '1', '158'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('tutu', '1', '159'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra shorts leeatard', '1', '160'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyke disco', '1', '161'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('freestyle disco', '1', '162'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('marie clarke', '1', '163'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('red headband', '1', '164'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('sneakers', '1', '165'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('poms costume', '2', '166'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('comps pictures', '1', '167'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('leg wwar', '2', '168'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('lycra', '1', '169'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Pink leotards', '2', '170'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gymnastic leotards', '3', '171'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gymnastic', '1', '172'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('gymnastics shoes', '1', '173'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Ballad shoes', '1', '174'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Boys', '1', '175'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Disco freestyle costumes', '2', '176'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Dress', '1', '177'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blue hotfix ab crystals', '1', '178'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blue crystas', '1', '179'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('blue crystals', '1', '180'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('chausoon', '1', '181'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('chausson', '1', '182'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Ladies ballroom dresses', '1', '183'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Head', '1', '184'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('christmas dance costume', '2', '185'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('httprvowilongwjhcom', '1', '186'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('crop tops', '1', '187'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('white catsuit', '1', '188'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('purple leertards', '1', '189'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('belly dance', '1', '190'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('TAP SHOES 4', '1', '191'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('roch valley', '1', '192'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('materiel colours', '1', '193'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('coral leggings', '1', '194'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Lyrical costumes', '3', '195'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Beginners', '2', '196'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('Freestyle starter costumes', '1', '197'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('latin dance outfits', '1', '198'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('unitards', '1', '199'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('dance leotards skirt', '1', '200'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('httpssvuvyevtmtpcom', '2', '201'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('neon yellow', '1', '202'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('SHOE/BOOT', '1', '203'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('COVERS', '1', '204'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('LADIES', '1', '205'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ROCK', '1', '206'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('\'N\'', '0', '207'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('ROLL', '1', '208'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('COSTUMES', '2', '209'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('\'N\'', '0', '210'); #EOQ
INSERT INTO `cc4_CubeCart_search` VALUES('PEARS', '1', '211'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_seo_urls`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_seo_urls`
--

CREATE TABLE `cc4_CubeCart_seo_urls` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `path` varchar(255) collate utf8_unicode_ci NOT NULL,
  `type` varchar(45) collate utf8_unicode_ci NOT NULL,
  `item_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`path`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_seo_urls`
--

INSERT INTO `cc4_CubeCart_seo_urls` VALUES('1', 'login', 'login', '0'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('2', 'register', 'register', '0'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('3', 'childrens-dance-wear', 'cat', '15'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('4', 'rock-n-roll-outfits', 'cat', '17'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('81', 'previously-owned', 'cat', '18'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('82', 'new-blinged-costumes', 'cat', '20'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('7', 'rhinestones/dmc-hotfix-rhinestones', 'cat', '23'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('8', 'rhinestones/hotfix-rhinestones/4mm-16ss-', 'cat', '6'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('9', 'rhinestones/hotfix-rhinestones/4mm-ab-16ss-', 'cat', '7'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('10', 'rhinestones/hotfix-rhinestones', 'cat', '2'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('11', 'rhinestones/silverback-rhinestones/4mm-16ss-', 'cat', '8'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('12', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-', 'cat', '9'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('13', 'rhinestones/silverback-rhinestones/5mm-20ss-', 'cat', '12'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('14', 'rhinestones/silverback-rhinestones/5mm-ab-20ss-', 'cat', '14'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('15', 'rhinestones/silverback-rhinestones', 'cat', '3'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('16', 'rhinestones', 'cat', '19'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('17', 'dancing-accessories', 'cat', '24'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('18', 'dancewear-size-guide', 'cat', '21'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('19', 'sale-items', 'saleitems', '0'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('20', 'gift-certificates', 'certificates', '0'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('21', 'search', 'search', '0'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('22', 'about-us', 'doc', '1'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('23', 'contact-us', 'doc', '2'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('24', 'terms-conditions', 'doc', '3'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('25', 'privacy-policy', 'doc', '4'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('26', 'dance-wear-size-guide', 'doc', '10'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('27', 'returns-policy', 'doc', '11'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('28', 'returns-policy-d12', 'doc', '12'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('29', 'feedback', 'doc', '16'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('30', 'bespoke-costumes', 'doc', '18'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('31', 'rhinestones/dmc-hotfix-rhinestones/144-2mm-ss6-fushia-pink-ab-dmc-hotfix-rhinestones', 'prod', '43'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('32', 'childrens-dance-wear/pnp-lycra-catsuit-with-puffed-sleeves', 'prod', '17'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('33', 'childrens-dance-wear/pnp-lycra-crop-top-with-puff-sleeves', 'prod', '19'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('34', 'childrens-dance-wear/pnp-lycra-catsuit-with-long-sleeves', 'prod', '18'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('35', 'childrens-dance-wear/disco-freestyle-dance-costume-accessories', 'prod', '26'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('36', 'childrens-dance-wear/pnp-lycra-shorts', 'prod', '20'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('37', 'childrens-dance-wear/pnp-lycra-leggings', 'prod', '21'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('38', 'rock-n-roll-outfits/rock-n-roll-outfit', 'prod', '25'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('39', 'previously-owned-and-loved-dancewear/previously-owned-freestyle-disco-solo-costume', 'prod', '55'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('40', 'rock-n-roll-outfits/rock-n-roll-skirt', 'prod', '23'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('41', 'brand-new-blinged-costumes/wow-brand-new-solo-costume', 'prod', '61'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('42', 'previously-owned-and-loved-dancewear/pair-of-disco-blinged-costumes', 'prod', '60'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('43', 'previously-owned-and-loved-dancewear/rock-n-roll-bright-pairs-costumes', 'prod', '59'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('44', 'previously-owned-and-loved-dancewear/previously-loved-green-disco-costume', 'prod', '58'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('45', 'dancing-accessories/blinged-competition-pins', 'prod', '57'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('46', 'rhinestones/silverback-rhinestones/5mm-ab-20ss-/144-ss20-5mm-clear-ab-silverback-rhinestones/crystals', 'prod', '56'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('47', 'rock-n-roll-outfits/rock-n-roll-pairs-costume-complete-with-stoned-accessories', 'prod', '54'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('48', 'childrens-dance-wear/pnp-lycra-leotard-with-long-sleeves', 'prod', '53'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('49', 'childrens-dance-wear/complete-disco-outfit', 'prod', '50'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('50', 'childrens-dance-wear/pnp-3/4-length-lycra-catsuit-with-puffed-sleeves', 'prod', '52'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('51', 'childrens-dance-wear/pnp-lycra-halter-neck-tie-top', 'prod', '22'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('52', 'childrens-dance-wear/pnp-lycra-leotard', 'prod', '51'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('53', 'rhinestones/dmc-hotfix-rhinestones/144-5mm-ss20-siam-ruby-dmc-hotfix-rhinestones', 'prod', '42'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('54', 'rhinestones/dmc-hotfix-rhinestones/144-5mm-ss20-crystal-ab-dmc-hotfix-rhinestones', 'prod', '40'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('55', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-purple-ab-silverback-rhinestones/crystals', 'prod', '7'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('56', 'rhinestones/silverback-rhinestones/4mm-16ss-/144-4mm-pink-silverback-rhinestones/crystals', 'prod', '16'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('57', 'brand-new-blinged-costumes/green-butterfly-costume', 'prod', '29'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('58', 'rhinestones/silverback-rhinestones/5mm-20ss-/144-5mm-aqua-blue-silverback-rhinestones', 'prod', '38'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('59', 'rhinestones/hotfix-rhinestones/4mm-16ss-/144-4mm-emerald-ab-hotfix-rhinestones', 'prod', '10'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('60', 'rhinestones/silverback-rhinestones/5mm-20ss-/144-5mm-topaz-silverback-rhinestones', 'prod', '34'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('61', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-mint-ab-silverback-rhinestones/crystals', 'prod', '6'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('62', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-orange-ab-silverback-rhinestones', 'prod', '4'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('63', 'rhinestones/hotfix-rhinestones/4mm-ab-16ss-/144-4mm-clear-ab-hotfix-rhinestones', 'prod', '9'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('64', 'previously-owned-and-loved-dancewear/second-hand-aqua-blue-and-pink-poodle-rock-and-roll-outfit', 'prod', '49'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('65', 'rhinestones/hotfix-rhinestones/4mm-16ss-/144-4mm-siam-ruby-hotfix-rhinestones', 'prod', '11'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('66', 'rhinestones/dmc-hotfix-rhinestones/144-2mm-ss6-black-ab-dmc-hotfix-rhinestones', 'prod', '45'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('67', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-clear-ab-silverback-rhinestones/crystals', 'prod', '3'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('68', 'rhinestones/silverback-rhinestones/4mm-16ss-/144-4mm-aqua-blue-silverback-rhinestones/crystals', 'prod', '39'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('69', 'rhinestones/silverback-rhinestones/4mm-16ss-/144-4mm-clear-silverback-rhinestones/crystals', 'prod', '2'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('70', 'rhinestones/silverback-rhinestones/5mm-20ss-/144-5mm-hot-pink-silverback-rhinestones', 'prod', '37'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('71', 'rhinestones/hotfix-rhinestones/4mm-16ss-/144-4mm-sapphire-hotfix-rhinestones', 'prod', '12'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('72', 'rhinestones/silverback-rhinestones/5mm-20ss-/144-5mm-mint-green-silverback-rhinestones', 'prod', '36'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('73', 'previously-owned-and-loved-dancewear/second-hand-peach-and-white-slow-costume', 'prod', '31'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('74', 'rhinestones/dmc-hotfix-rhinestones/144-5mm-ss20-crystal-dmc-hotfix-rhinestones', 'prod', '41'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('75', 'rhinestones/silverback-rhinestones/5mm-20ss-/144-5mm-purple-silverback-rhinestones', 'prod', '35'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('76', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-lemon-ab-silverback-rhinestones/crystals', 'prod', '5'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('77', 'rhinestones/silverback-rhinestones/4mm-ab-16ss-/144-4mm-pink-ab-silverback-rhinestones/crystals', 'prod', '15'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('78', 'rhinestones/hotfix-rhinestones/4mm-16ss-/144-4mm-clear-hotfix-rhinestones', 'prod', '8'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('79', 'childrens-dance-wear/puffed-sleeved-unitard', 'prod', '24'); #EOQ
INSERT INTO `cc4_CubeCart_seo_urls` VALUES('80', 'childrens-dance-wear/pnp-lycra-unitard', 'prod', '28'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_sessions`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_sessions`
--

CREATE TABLE `cc4_CubeCart_sessions` (
  `session_id` varchar(32) collate utf8_unicode_ci NOT NULL default '',
  `session_start` int(10) unsigned NOT NULL default '0',
  `session_last` int(10) unsigned NOT NULL default '0',
  `customer_id` int(10) unsigned NOT NULL default '0',
  `location` varchar(255) collate utf8_unicode_ci default NULL,
  `ip_address` varchar(45) collate utf8_unicode_ci default NULL,
  `useragent` text collate utf8_unicode_ci,
  `admin_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_sessions`
--

INSERT INTO `cc4_CubeCart_sessions` VALUES('1d3027cf502240f5b9c278c8fe91fb91', '1353327751', '1353327751', '0', 'http://www.pnpdance.com/index.php?', '178.255.152.2', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('48889137a1271fa4eb9711c59e081e30', '1353327835', '1353327835', '0', 'index.php?_a=error&amp;code=404', '157.55.32.84', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('d3d60c56bd8a1b7434b47b4b6d6cb77c', '1353328358', '1353328358', '0', 'http://www.pnpdance.com/index.php?', '67.228.213.178', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('ab092a52e930897b2a7644f438ae9343', '1353328547', '1353328547', '0', 'http://www.pnpdance.com/index.php?', '123.125.71.94', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('047c460702c0a59b738841aa445a2ca9', '1353328669', '1353328669', '0', 'index.php?_a=error&amp;code=503', '123.125.71.94', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('8073b3d05283206e21f48ec8e25a58d8', '1353329858', '1353329858', '0', 'http://www.pnpdance.com/index.php?', '46.20.45.18', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('fa6d3d165193356b85b2a804a9ef91b6', '1353328949', '1353328949', '0', 'http://www.pnpdance.com/index.php?', '85.17.156.76', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('183bf0c3db909bae30d26520b6289e57', '1353329715', '1353329715', '0', 'index.php?_a=error&amp;code=404', '173.199.120.75', 'Mozilla/5.0 (compatible; AhrefsBot/4.0; +http://ahrefs.com/robot/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('83d33f4c34d336e650586bba03aaaec0', '1353329728', '1353329728', '0', 'index.php?_a=error&amp;code=503', '180.76.5.171', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('8d2310814c76f69712ab46140661c9b8', '1353329250', '1353329250', '0', 'http://www.pnpdance.com/index.php?', '184.75.210.90', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('9fbecc265cc8f892f2b5454330417d92', '1353329344', '1353329344', '0', 'http://www.pnpdance.com/index.php?', '67.228.177.17', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('9701dc59b1d4787c0e239c7c5c45d91b', '1353329461', '1353329480', '0', 'http://www.pnpdance.com/index.php?_a=register', '218.93.127.117', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.121 Safari/535.2', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('249e10bbc4c16a78dd440129a49a5a0a', '1353329900', '1353329900', '0', 'index.php?_a=error&amp;code=404', '66.249.73.177', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('d2e3b7b8cdca16d8fc34ffc1b2886188', '1353330042', '1353330042', '0', 'http://www.pnpdance.com/index.php?_g=co&_a=reg&redir=%2Findex.php%3F_a%3DviewCat%26catId%3D14', '208.115.111.66', 'Mozilla/5.0 (compatible; Ezooms/1.0; ezooms.bot@gmail.com)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('5ea0b2c167da80d9719ea7275c2956b3', '1353330149', '1353330149', '0', 'http://www.pnpdance.com/index.php?', '69.59.28.19', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('c9391e44557756559d5df95ecd10e981', '1353329466', '1353329466', '0', 'index.php?_a=error&amp;code=503', '67.228.177.17', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('51014aa6c1785f779e5470eca836f884', '1353330091', '1353330091', '0', 'http://www.pnpdance.com/index.php?', '188.40.103.239', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('c7edbb00b397b4ce2df998b8df41b857', '1353329516', '1353329516', '0', 'index.php?_a=error&amp;code=404', '180.76.5.172', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('e6b525b9d723a74ea45e3a0ef1f683ae', '1353329549', '1353329549', '0', 'http://www.pnpdance.com/index.php?', '76.72.167.90', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('6edfcafc6eca749a49cc1178c64c7b13', '1353327150', '1353327150', '0', 'http://www.pnpdance.com/index.php?', '46.20.45.18', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('1602bc7d40455c6aad69f13099794415', '1353326905', '1353326905', '0', 'index.php?_a=error&amp;code=404', '157.55.33.44', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('85dc9fec4e409df96910192467a8a0f0', '1353327453', '1353327453', '0', 'http://www.pnpdance.com/index.php?', '69.59.28.19', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('738cf7a38ef15a2e31176f27c9df901b', '1353327487', '1353327487', '0', 'http://www.pnpdance.com/index.php?', '66.249.76.21', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('312324f8605edf5c735192c3de8e2a19', '1353327543', '1353327543', '0', 'http://www.pnpdance.com/index.php?', '67.228.177.17', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('0700411be54328109e69d13af3d9c8dd', '1353329621', '1353329621', '0', 'http://www.pnpdance.com/index.php?', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('f57f45bdeed31fec3380795478178f03', '1353329693', '1353329693', '0', '', '66.249.73.177', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('2c9d8072ef6f92f3afc24cec089a6d54', '1353329607', '1353329607', '0', 'http://www.pnpdance.com/index.php?', '180.76.5.171', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('3c8a02b12edb4e63a8a7e414faf66a88', '1353326858', '1353326858', '0', 'http://www.pnpdance.com/index.php?', '76.72.167.90', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('4cfbdca50cd1ec3701b477a5ec51d15c', '1353326774', '1353326774', '0', 'index.php?_a=error&amp;code=404', '65.55.24.214', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('b3b92caa655a7428d9b3c0d8e7b1bc70', '1353330212', '1353330212', '0', 'index.php?_a=error&amp;code=503', '188.40.103.239', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('cebd5c993e74e6656c9d2bea12ecf605', '1353330228', '1353330241', '0', 'http://www.pnpdance.com/admin.php?_g=maintenance', '82.14.1.87', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/536.26.17 (KHTML, like Gecko) Version/6.0.2 Safari/536.26.17', '1'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('3ca1b31b520fbc885b6d83159dbe2f6e', '1353326905', '1353326905', '0', 'index.php?_a=error&amp;code=404', '157.55.33.44', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('19617d93ad6f9fe88faf9d8bcca2368d', '1353327015', '1353327015', '0', 'index.php?_a=error&amp;code=404', '173.199.118.35', 'Mozilla/5.0 (compatible; AhrefsBot/4.0; +http://ahrefs.com/robot/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('594b73bb37fdd312cd827dd3cc4b5b0b', '1353326774', '1353326774', '0', 'index.php?_a=error&amp;code=404', '65.55.24.214', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('12b727ca8759e85ff1820afcdfc33478', '1353327665', '1353327665', '0', 'index.php?_a=error&amp;code=503', '67.228.177.17', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('c37080a31f58786a1769db7ef08fe602', '1353328649', '1353328649', '0', 'http://www.pnpdance.com/index.php?', '85.25.176.167', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('9a1a001e77fcc8e7d3dbb2edea7df927', '1353328767', '1353328767', '0', 'index.php?_a=error&amp;code=404', '66.249.73.177', 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('a6376c60102cef70c2d82b6e540c3de1', '1353328365', '1353328365', '0', 'index.php?_a=error&amp;code=404', '173.199.116.251', 'Mozilla/5.0 (compatible; AhrefsBot/4.0; +http://ahrefs.com/robot/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('8e6329c8868f40c4af4cac4b7062d83d', '1353328392', '1353328392', '0', 'index.php?_a=error&amp;code=404', '157.55.35.112', 'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('b0ef2167565749000633d4eab75f093e', '1353328403', '1353328403', '0', 'index.php?_a=error&amp;code=503', '188.40.103.239', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('b39e44144dbce4747fb23cfc85be68c1', '1353328487', '1353328487', '0', 'http://www.pnpdance.com/index.php?', '220.181.108.150', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('a53f24fe48331d02805aeb0ce1822dac', '1353328058', '1353328058', '0', 'http://www.pnpdance.com/index.php?', '173.204.85.217', 'Pingdom.com_bot_version_1.4_(http://www.pingdom.com/)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('d487cb177e76e56410f684d52af748f8', '1353328282', '1353328282', '0', 'http://www.pnpdance.com/index.php?', '188.40.103.239', 'Mozilla/5.0 (compatible; mon.itor.us - free monitoring service; http://mon.itor.us)', '0'); #EOQ
INSERT INTO `cc4_CubeCart_sessions` VALUES('85472d367e8bb04e2e323be1f7e2f1a9', '1353328609', '1353328609', '0', 'index.php?_a=error&amp;code=503', '220.181.108.150', 'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_system_error_log`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_system_error_log`
--

CREATE TABLE `cc4_CubeCart_system_error_log` (
  `log_id` int(10) unsigned NOT NULL auto_increment,
  `time` int(10) unsigned NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `read` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY  (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_system_error_log`
--

INSERT INTO `cc4_CubeCart_system_error_log` VALUES('1', '1352303767', 'File: [module.class.php] Line: [347] \"INSERT INTO `cc4_CubeCart_modules` (`status`,`default`,`folder`,`module`) VALUES (\'1\',\'\',\'Google_Checkout\',\'plugins\');\" - Duplicate entry \'Google_Checkout\' for key 1', '0'); #EOQ
INSERT INTO `cc4_CubeCart_system_error_log` VALUES('2', '1352303796', 'File: [module.class.php] Line: [347] \"INSERT INTO `cc4_CubeCart_modules` (`status`,`default`,`folder`,`module`) VALUES (\'1\',\'\',\'Google_Checkout\',\'plugins\');\" - Duplicate entry \'Google_Checkout\' for key 1', '0'); #EOQ
INSERT INTO `cc4_CubeCart_system_error_log` VALUES('3', '1352303808', 'File: [module.class.php] Line: [347] \"INSERT INTO `cc4_CubeCart_modules` (`status`,`default`,`folder`,`module`) VALUES (\'1\',\'\',\'Google_Checkout\',\'plugins\');\" - Duplicate entry \'Google_Checkout\' for key 1', '0'); #EOQ
INSERT INTO `cc4_CubeCart_system_error_log` VALUES('4', '1352371912', 'File: [module.class.php] Line: [347] \"INSERT INTO `cc4_CubeCart_modules` (`status`,`default`,`folder`,`module`) VALUES (\'1\',\'\',\'PayPal_Pro\',\'plugins\');\" - Duplicate entry \'PayPal_Pro\' for key 1', '0'); #EOQ
INSERT INTO `cc4_CubeCart_system_error_log` VALUES('5', '1352976795', '[<strong>Exception</strong>] 	/hermes/bosweb26a/b1803/ipg.pnpdancecom/includes/lib/smarty/sysplugins/smarty_internal_templatebase.php:174 - Invalid compiled template for \'templates/main.php\'', '0'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_tax_class`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_tax_class`
--

CREATE TABLE `cc4_CubeCart_tax_class` (
  `id` int(11) NOT NULL auto_increment,
  `tax_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_tax_class`
--

INSERT INTO `cc4_CubeCart_tax_class` VALUES('1', 'VAT - Standard'); #EOQ
INSERT INTO `cc4_CubeCart_tax_class` VALUES('2', 'VAT - Low Rate'); #EOQ
INSERT INTO `cc4_CubeCart_tax_class` VALUES('3', 'Tax Exempt'); #EOQ
INSERT INTO `cc4_CubeCart_tax_class` VALUES('1', 'VAT - Standard'); #EOQ
INSERT INTO `cc4_CubeCart_tax_class` VALUES('2', 'VAT - Low Rate'); #EOQ
INSERT INTO `cc4_CubeCart_tax_class` VALUES('3', 'Tax Exempt'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_tax_details`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_tax_details`
--

CREATE TABLE `cc4_CubeCart_tax_details` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varbinary(150) NOT NULL default '',
  `display` varbinary(150) NOT NULL default '',
  `reg_number` varbinary(150) NOT NULL default '',
  `status` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_tax_details` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_tax_rates`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_tax_rates`
--

CREATE TABLE `cc4_CubeCart_tax_rates` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `type_id` int(10) unsigned NOT NULL default '1',
  `details_id` int(10) unsigned NOT NULL,
  `country_id` int(10) unsigned NOT NULL default '0',
  `county_id` int(10) unsigned NOT NULL default '0',
  `tax_percent` decimal(7,4) NOT NULL default '0.0000',
  `goods` tinyint(1) unsigned NOT NULL default '0',
  `shipping` tinyint(1) unsigned NOT NULL default '0',
  `active` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `type_id` (`type_id`,`details_id`,`country_id`,`county_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_tax_rates` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_trackback`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_trackback`
--

CREATE TABLE `cc4_CubeCart_trackback` (
  `trackback_id` int(10) unsigned NOT NULL auto_increment,
  `product_id` int(10) unsigned NOT NULL,
  `url` varchar(250) collate utf8_unicode_ci NOT NULL,
  `title` text collate utf8_unicode_ci,
  `excerpt` tinytext collate utf8_unicode_ci,
  `blog_name` text collate utf8_unicode_ci,
  PRIMARY KEY  (`trackback_id`),
  UNIQUE KEY `url` (`url`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_CubeCart_trackback` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_CubeCart_transactions`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_CubeCart_transactions`
--

CREATE TABLE `cc4_CubeCart_transactions` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `gateway` varchar(255) collate utf8_unicode_ci default NULL,
  `extra` varchar(255) collate utf8_unicode_ci default NULL,
  `status` varchar(50) collate utf8_unicode_ci default NULL,
  `customer_id` int(10) unsigned default NULL,
  `order_id` varchar(18) collate utf8_unicode_ci default NULL,
  `trans_id` varchar(50) collate utf8_unicode_ci default NULL,
  `time` int(10) unsigned default NULL,
  `amount` decimal(16,2) NOT NULL default '0.00',
  `captured` decimal(16,2) default NULL,
  `notes` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `order_id` (`order_id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_CubeCart_transactions`
--

INSERT INTO `cc4_CubeCart_transactions` VALUES('1', 'Nochex', '', 'live', '6', '111215-104103-7193', '3121673', '1323963747', '18.98', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('2', 'Nochex', '', 'live', '8', '111226-064806-2952', '3138290', '1324900368', '40.00', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('3', 'Nochex', '', 'live', '11', '120104-162811-2214', '3154360', '1325712600', '38.47', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('4', 'Nochex', '', 'test', '0', '120106-051551-7002', '3156959', '1325847143', '10.00', '0.00', 'This is a test transaction. No money has actually been received. Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('5', 'PayPal IPN', '', 'Completed', '14', '120117-105841-8249', '75M85699RE422681B', '1326815974', '17.49', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('6', 'PayPal IPN', '', 'Refunded', '14', '120117-105841-8249', '47K5268602225371B', '1327176203', '-2.50', '0.00', 'Amount paid didn&#39;t match amount on invoice.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('7', 'PayPal IPN', '', 'Completed', '18', '120126-221919-4485', '50759408D7149241S', '1327616421', '17.49', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('8', 'PayPal IPN', '', 'Completed', '22', '120215-211311-7245', '1S642262EE5981137', '1329340550', '3.00', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('9', 'PayPal IPN', '', 'Completed', '24', '120221-215341-8137', '3W494290DW098141W', '1329861337', '10.00', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('10', 'PayPal IPN', '', 'Completed', '25', '120222-165455-3051', '1D184257P96717159', '1329929822', '2.00', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('11', 'PayPal IPN', '', 'Refunded', '18', '120217-112609-5973', '5PM64998CV356753D', '1330000880', '-8.00', '0.00', 'Amount paid didn&#39;t match amount on invoice.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('12', 'PayPal IPN', '', 'Completed', '24', '120223-232213-8789', '6XB16442FX236005W', '1330039472', '28.50', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('13', 'Nochex', '', 'live', '26', '120225-162703-4186', '3288052', '1330187471', '18.98', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('14', 'Nochex', '', 'live', '28', '120314-165023-6883', '3322805', '1331740374', '28.00', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('15', 'Nochex', '', 'live', '29', '120315-214032-8714', '3325532', '1331844191', '20.98', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('16', 'PayPal IPN', '', 'Completed', '19', '120321-231958-3737', '6CS25708W8681201M', '1332368909', '1.98', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('17', 'PayPal IPN', '', 'Completed', '30', '120328-141406-5418', '6HE323140W997301T', '1332940547', '20.98', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('18', 'PayPal IPN', '', 'Completed', '18', '120328-231238-6726', '2SW71270PP912273Y', '1332972819', '17.49', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('19', 'Nochex', '', 'live', '31', '120416-131911-6313', '3380188', '1334578882', '2.50', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('20', 'PayPal IPN', '', 'Completed', '32', '120417-213448-1802', '3ER23571HT543571R', '1334695060', '22.99', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('21', 'PayPal IPN', '', 'Completed', '33', '120422-194357-9544', '30574001NS7562839', '1335120343', '7.25', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('22', 'PayPal IPN', '', 'Completed', '33', '120426-130204-2116', '1VV41600FW2084845', '1335441815', '14.75', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('23', 'PayPal IPN', '', 'Completed', '33', '120426-130738-3939', '0S743423V22298523', '1335442171', '1.25', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('24', 'PayPal IPN', '', 'Completed', '34', '120430-091931-5451', '4HW78829R1498245M', '1335774021', '17.49', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('25', 'Nochex', '', 'live', '35', '120430-132914-2081', '3406268', '1335789086', '1.50', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('26', 'Nochex', '', 'live', '37', '120503-191800-2073', '3413155', '1336069270', '7.50', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('27', 'PayPal IPN', '', 'Completed', '38', '120503-215101-7821', '43J48599L1277464D', '1336078311', '1.25', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('28', 'PayPal IPN', '', 'Completed', '33', '120506-123849-8852', '9B909485PA8998706', '1336304399', '16.00', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('29', 'PayPal IPN', '', 'Completed', '39', '120506-202916-1835', '7KH5227815251213H', '1336332784', '10.00', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('30', 'PayPal IPN', '', 'Completed', '40', '120510-075837-9420', '8TS034799T768971R', '1336633200', '25.00', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('31', 'PayPal IPN', '', 'Completed', '41', '120519-141737-2262', '3NB71277KJ741371H', '1337433549', '13.00', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('32', 'Nochex', '', 'live', '42', '120520-135655-3821', '3441901', '1337518782', '19.99', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('33', 'Nochex', '', 'live', '43', '120521-130007-3632', '3443697', '1337601714', '4.00', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('34', 'Nochex', '', 'live', '44', '120604-214126-4579', '3467143', '1338842640', '17.49', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('35', 'Nochex', '', 'live', '43', '120621-143058-8499', '3490854', '1340285540', '6.50', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('36', 'PayPal IPN', '', 'Completed', '47', '120711-231120-7119', '8PX3809144362081M', '1342044892', '3.50', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('37', 'Nochex', '', 'live', '48', '120801-204648-4367', '3540731', '1343850501', '17.49', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('38', 'PayPal IPN', '', 'Completed', '49', '120808-230150-3399', '2UP736853M765100A', '1344463405', '101.80', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('39', 'PayPal IPN', '', 'Completed', '14', '120827-124418-6821', '5MF76300X58494333', '1346067904', '20.98', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: unverified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('40', 'PayPal IPN', '', 'Completed', '52', '120926-204400-4073', '6RK82989VF014141A', '1348688735', '5.00', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('41', 'PayPal IPN', '', 'Completed', '12', '121015-211741-2192', '5JU292275Y450032W', '1350332313', '5.00', '0.00', 'Payment successful. <br />Address: unconfirmed<br />Payer Status: verified'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('42', 'Nochex', '', 'live', '55', '121016-120035-7927', '3638469', '1350385965', '17.49', '0.00', 'Card charged successfully.'); #EOQ
INSERT INTO `cc4_CubeCart_transactions` VALUES('43', 'PayPal IPN', '', 'Completed', '57', '121024-170942-3703', '1J418743CJ695835G', '1351095783', '5.00', '0.00', 'Payment successful. <br />Address: confirmed<br />Payer Status: verified'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_cubehelper_reg`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_cubehelper_reg`
--

CREATE TABLE `cc4_cubehelper_reg` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `field_name` varchar(30) collate utf8_unicode_ci NOT NULL,
  `field_type` int(10) unsigned NOT NULL,
  `require_flag` int(10) default NULL,
  `show_in_order_flag` int(10) default NULL,
  `sort_order` int(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_cubehelper_reg`
--

INSERT INTO `cc4_cubehelper_reg` VALUES('1', 'Dance School', '1', '0', '1', '1'); #EOQ
INSERT INTO `cc4_cubehelper_reg` VALUES('2', 'Comment', '2', '0', '1', '2'); #EOQ
-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_cubehelper_reg_data`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_cubehelper_reg_data`
--

CREATE TABLE `cc4_cubehelper_reg_data` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `field_name` varchar(30) collate utf8_unicode_ci NOT NULL,
  `field_value` varchar(30) collate utf8_unicode_ci NOT NULL,
  `sort_order` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

-- Table `cc4_cubehelper_reg_data` has no data

-- --------------------------------------------------------

DROP TABLE IF EXISTS `cc4_cubehelper_reg_x_customer`; #EOQ

-- --------------------------------------------------------

-- 
-- Table structure for table `cc4_cubehelper_reg_x_customer`
--

CREATE TABLE `cc4_cubehelper_reg_x_customer` (
  `customer_id` int(10) unsigned NOT NULL,
  `reg_field_id` int(10) unsigned NOT NULL,
  `reg_data_id` int(10) unsigned NOT NULL,
  `reg_field_value` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`customer_id`,`reg_field_id`,`reg_data_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; #EOQ

--
-- Dumping data for table `cc4_cubehelper_reg_x_customer`
--

INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('22', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('22', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('18', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('18', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('23', '1', '0', 'kelly&#39;s angels dance club'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('23', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('24', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('0', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('0', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('24', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('25', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('25', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('26', '1', '0', 'Jane Gilbert'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('26', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('27', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('27', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('28', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('28', '2', '0', 'Waist size for loose belt is 25-26 inches.'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('29', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('29', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('19', '1', '0', 'dance divas'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('19', '2', '0', 'thank you x'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('30', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('30', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('31', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('31', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('32', '1', '0', 'DANCEWORKZ'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('32', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('33', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('33', '2', '0', 'im looking these for personal use'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('34', '1', '0', 'None'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('34', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('35', '1', '0', 'Bizz Kids'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('35', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('36', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('36', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('37', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('37', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('38', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('38', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('39', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('39', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('40', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('40', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('41', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('41', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('42', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('42', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('43', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('43', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('44', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('44', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('46', '1', '0', 'Freesteppin'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('46', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('47', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('47', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('48', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('48', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('49', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('49', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('50', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('50', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('51', '1', '0', 'HSOD'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('51', '2', '0', 'Would it be possible to send an other pictures of freestyle dance costumes you have?'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('52', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('52', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('53', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('53', '2', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('54', '2', '0', 'Wanting the GIRLS costume.\r\n\r\nCell phone (804)370-9418.'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('54', '1', '0', 'Skate A Way'); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('12', '1', '0', ''); #EOQ
INSERT INTO `cc4_cubehelper_reg_x_customer` VALUES('12', '2', '0', ''); #EOQ
-- --------------------------------------------------------
-- CubeCart SQL Dump Complete
-- --------------------------------------------------------